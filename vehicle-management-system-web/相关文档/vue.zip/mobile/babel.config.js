module.exports = {
  presets: [
    '@vue/app'
  ],
  //按需加载vantUI
  plugins: [
    ['import', {
      libraryName: 'vant',
      libraryDirectory: 'es',
      style: true
    }, 'vant']
  ]
}

# eidi

## 初始项目安装依赖
```
npm install
```

### 项目启动
```
npm run serve
```
### 清理npm缓存
npm cache clean -f

### 项目打包
```
npm run build
```

### 模拟数据mock安装依赖
```
到mock路径下，npm install
```

### 模拟数据mock启动
```
到mock路径下，npm run mock
```
<template>
  <div>
    <!-- <van-row> -->
      <!-- <van-col> -->
        <!-- <div style="font-size:30px" @click="readyOriginal" class="iconfont icon-yuyin"></div> -->
        <div class="iconfont icon-yuyin" :class="['mrecorder', {anirecorder: recording } ]"></div>
        <div
          class="mc-record"
          @touchstart="gotouchstart"
          @touchmove="gotouchmove"
          @touchend="gotouchend"
        >按住说话</div>
      <!-- </van-col> -->
    <!-- </van-row> -->
    <!-- <van-row>
      <van-col>
        <span class="tip">{{ tiptext }}</span>
      </van-col>
    </van-row>-->
  </div>
</template>
 
<script>
// import { MediaStreamRecorder } from "@/assets/js/MediaStreamRecorder.js";
import { HZRecorder } from "@/assets/js/recorder.js";
export default {
  name: "mcRecorder",
  props: {
    sampleRate: {
      default: 16000, // 默认为1min
      type: Number
    },
    // pushurl: {
    //   default: "", // 上传到服务器的路径
    //   type: String
    // }
  },
  data() {
    return {
      // mcounter: 0, // 累积时间
      recording: false, // 标记是否在录音
      // intervaltimerid: "", // 间隔时间定时器编号
      // tiptext: "点击录音", // 提示文字
      // mediaRecorder: null, // 录音笔
      // mediaConstraints: {
      //   audio: true
      // },
      isVoice: false,
      recorder: null,
      myurl: ""
    };
  },
  mounted() {
    let that = this;
    this.$nextTick(() => {
      try {
        //  检查是否能够调用麦克风
        window.AudioContext = window.AudioContext || window.webkitAudioContext;
        navigator.getUserMedia =
          navigator.getUserMedia || navigator.webkitGetUserMedia;
        window.URL = window.URL || window.webkitURL;

        // let audio_context = new AudioContext();
        console.log(
          "navigator.getUserMedia " +
            (navigator.getUserMedia ? "available." : "not present!")
        );
      } catch (e) {
        console.log("No web audio support in this browser!");
      }

      navigator.getUserMedia(
        { audio: true },
        function(stream) {
          that.recorder = new HZRecorder(stream,{sampleRate:that.sampleRate});
          console.log("初始化完成");
        },
        function(e) {
          console.log("No live audio input: " + e);
        }
      );
    });
  },
  methods: {
    gotouchstart() {
      let that = this;
      clearTimeout(this.timeOutEvent); //清除定时器
      this.timeOutEvent = 0;
      this.timeOutEvent = setTimeout(() => {
        console.log("执行长恩操作！");
        this.recorder && this.recorder.start();
        this.recorder.audioData.buffer = [];
        this.recorder.audioData.size = 0;
        this.isVoice = true;
        this.recording = true;
      }, 100);
    },
    gotouchend() {
      clearTimeout(this.timeOutEvent);
      if (this.timeOutEvent != 0) {
        console.log("结束事件！！");
            this.isVoice = false;
        //  结束录音
        this.recorder && this.recorder.stop();
        this.recording = false;
        setTimeout(() => {
          //  录音上传
          var mp3Blob = this.recorder.upload();
          this.myurl = URL.createObjectURL(mp3Blob);
          console.log(this.myurl);
          this.$emit("handleStop", {
            url: this.myurl,
            mblob: mp3Blob
          });
        }, 100);
      }
    },
    gotouchmove() {
      console.log("取消事件！！");
      clearTimeout(this.timeOutEvent);
      this.recorder.audioData.buffer = [];
        this.recorder.audioData.size = 0;
         this.isVoice = false;
        //  结束录音
        this.recorder && this.recorder.stop();
      this.timeOutEvent = 0;
       this.recording = false;
    },
    readyOriginal() {
      if (!this.isVoice) {
        //  开启录音
        this.recorder && this.recorder.start();
        console.log(this.recorder.audioData);
        this.recorder.audioData.buffer = [];
        this.recorder.audioData.size = 0;
        this.isVoice = true;
      } else {
        this.isVoice = false;
        //  结束录音
        this.recorder && this.recorder.stop();
        setTimeout(() => {
          //  录音上传
          var mp3Blob = this.recorder.upload();
          this.myurl = URL.createObjectURL(mp3Blob);
          console.log(this.myurl);
          this.$emit("handleStop", {
            url: this.myurl,
            mblob: mp3Blob
          });
        }, 1000);
      }
    }
    // 处理点击
    // handleClick() {
    //   var that = this;
    //   this.recording = !this.recording;
    //   // 如果开始录音
    //   if (this.recording === true) {
    //     this.mcounter = 0;
    //     this.tiptext = "录音中 " + this.mcounter + "s";
    //     this.captureRecord();
    //     this.intervaltimerid = setInterval(() => {
    //       // 开始累积
    //       that.mcounter = that.mcounter + 1;
    //       this.tiptext = "录音中 " + that.mcounter + "s";
    //     }, 1000);
    //   } else {
    //     // 如果结束录音
    //     // this.tiptext = '点击录音'
    //     this.mediaRecorder.stop();
    //     this.mediaRecorder.stream.stop();
    //   }
    // },
    // 错误处理方法
    // onMediaError(e) {
    //   console.log("阿偶~您的浏览器貌似不支持录音哦...", e);
    //   clearInterval(this.intervaltimerid);
    //   // this.tiptext = '点击录音'
    //   this.recording = false;
    //   this.$message.error("您的浏览器暂不支持录音功能");
    // },
    // 成功
    // onMediaSuccess(stream) {
    //   this.mediaRecorder = new MediaStreamRecorder(stream);
    //   // 获取音频流
    //   this.mediaRecorder.stream = stream;
    //   this.mediaRecorder.mimeType = "audio/wav";
    //   this.mediaRecorder.sampleRate = 16000;
    //   this.mediaRecorder.audioChannels = 1;
    //   var _that = this;
    //   this.mediaRecorder.ondataavailable = function(blob) {
    //     clearInterval(_that.intervaltimerid);
    //     const url = URL.createObjectURL(blob);
    //     _that.$emit("handleStop", {
    //       url: url,
    //       mblob: blob
    //     });
    //   };
    //   // 定义间隔
    //   this.mediaRecorder.start(this.timelimit * 1000);
    // },
    // 开始记录方法
    // captureRecord() {
    //   navigator.mediaDevices
    //     .getUserMedia(this.mediaConstraints)
    //     .then(this.onMediaSuccess)
    //     .catch(this.onMediaError);
    // }
  }
};
</script>
<style scoped>
.wrapper {
  text-align: center;
}
.mc-record {
  font-size: 23px;
  user-select: none;
  background-color: #e6e0e0;
  width: 100%;
}
.mrecorder {
    width:100%;
    height:70px;
    font-size:70px;
    margin-bottom:15px
}
.anirecorder {
    position: relative;
    animation: mymove 2s infinite;
    -webkit-animation: mymove 2s infinite;
    animation-direction:alternate;
    animation-timing-function: ease-in-out;
    /*safari & chrome*/
    -webkit-animation-direction: alternate;
    -webkit-transition-timing-function: ease-in-out;
}
 
 @keyframes mymove
{
    0%{
    transform: scale(1);  /*开始为原始大小*/
    }
    25%{
        transform: scale(1.1); /*放大1.1倍*/
    }
    50%{
        transform: scale(0.9);
    }
    75%{
        transform: scale(1.1);
    }
 
}
 
@-webkit-keyframes mymove /*Safari and Chrome*/
{
    0%{
    transform: scale(1);  /*开始为原始大小*/
    }
    25%{
        transform: scale(1.1); /*放大1.1倍*/
    }
    50%{
        transform: scale(0.9);
    }
    75%{
        transform: scale(1.1);
    }
}
</style>


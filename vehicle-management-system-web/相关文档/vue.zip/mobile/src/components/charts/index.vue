<template>
  <div :class="className" :id="id" :style="{height:height,width:width}" />
</template>

<script>
import echarts from "echarts";
import { randomString } from "@/assets/js/utils";

export default {
  props: {
    option: {
      type: Object
    },
    className: {
      type: String,
      default: "chart"
    },
    width: {
      type: String,
      default: "100%"
    },
    height: {
      type: String,
      default: "100%"
    },
    initCharts: Function
  },
  data() {
    return {
      chart: null,
      id: ""
    };
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart(option, city) {
      if (city) {
        echarts.registerMap(city.name, city.map);
      }

      this.chart = echarts.init(document.getElementById(this.id));
      if (option) {
        this.chart.setOption(option);
        this.chart.dispatchAction({
          type: "highlight",
          seriesIndex: 0,
          dataIndex: 0
        });
        this.chart.on('click',v=>{
          console.log('mouseout',v)
          if(v.seriesIndex != 0) {
            this.chart.dispatchAction({
              type: "downplay",
              seriesIndex: 0,
              dataIndex: 0
            });
            
          }
           
            
        })
      } else {
        this.chart.setOption(this.option);
      }
    },
    editEcahrt(option, id) {
      let index = 0;
      this.chart = echarts.init(document.getElementById(id));
      this.chart.setOption(option);
        this.chart.dispatchAction({
          type: "highlight",
          seriesIndex: 0,
          dataIndex: 0
        });
      this.chart.on("mousedown", function(e) {
        this.chart = echarts.init(document.getElementById(id));
        this.chart.setOption(option);
        if (e.dataIndex != index) {
          this.chart.dispatchAction({
            type: "downplay",
            seriesIndex: 0,
            dataIndex: 0
          });
        }
        this.chart.dispatchAction({
          type: "highlight",
          seriesIndex: 0,
          dataIndex: e.dataIndex
        });
      });
      this.chart.on("mouseout", function(e) {
        this.chart = echarts.init(document.getElementById(id));
        this.chart.setOption(option);
        index = e.dataIndex;
        this.chart.dispatchAction({
          type: "highlight",
          seriesIndex: 0,
          dataIndex: index
        });
      });
    },
    destroy() {
      if (this.chart) {
        this.chart.dispose();
      }
    }
  },
  created() {
    this.id = randomString();
  }
};
</script>

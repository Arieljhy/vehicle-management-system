<template>
  <div id="noRolls" style="user-select: none;">
    <h2 :class="['message',isError?'isError':'']">{{message}}</h2>
    <van-row>
      <van-col :offset="2" :span="20">
        <canvas id="handPassword-canvas" height="300" class="canvas"></canvas>
      </van-col>
    </van-row>
  </div>
</template>
<script>
import { Point } from "./Point.js";
import md5 from "js-md5";
const word = [
  "1a_a1",
  "2b_b2",
  "3c_c3",
  "4d_d4",
  "5e_e5",
  "6f_f6",
  "7g_g7",
  "8h_h8",
  "9i_i9"
];
export default {
  name: "Gesture",
  props: {
    topHeight: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      context: null,
      points: [],
      //画布距离body的距离
      gapX: 0,
      gapY: 0,
      currentPoint: null,
      passwordPoint: [],
      //最小长度
      minLength: 4,
      //提示信息
      isError: false,
      message: "请绘制手势密码"
    };
  },
  mounted() {
       document.getElementById('noRolls').addEventListener(
      "touchmove",
      function(e) {
        e.preventDefault();
      },{
        passive:false
      }
    )
    const canvas = document.getElementById("handPassword-canvas");
    this.context = canvas.getContext("2d");
    //画布距离body的距离
    this.gapX =
      (parseFloat(getComputedStyle(document.body).width) - canvas.width) / 2 +
      10;
    this.gapY = this.topHeight + 75 + 10;
    //监听canvas上 touch事件
    canvas.addEventListener("touchstart", e => {
      const { clientX, clientY } = e.touches[0];
      this.judgeCurrentPoint(clientX, clientY);
    });
    //
    canvas.addEventListener("touchmove", e => {
      //如果有已选中的点
      if (this.currentPoint) {
        const { clientX, clientY } = e.touches[0];
        this.currentPoint.drawCurrentLine({
          toX: clientX - this.gapX,
          toY: clientY - this.gapY,
          doInit: this.drawPoints
        });
        this.judgeCurrentPoint(clientX, clientY);
      }
    });
    canvas.addEventListener("touchend", async e => {
      //如果密码小于4位，则重新绘制，并清空密码和当前点
      if (this.passwordPoint.length < this.minLength) {
        //设置1秒的标红提示，然后清空密码
        this.drawPoints({
          fillStyle: "#FF0000",
          strokeStyle: "#FF0000"
        });
        this.message = "至少连接4个点，请重新绘制";
        this.isError = true;
        setTimeout(() => {
          if (
            !(
              this.firstPasswordPoint &&
              this.firstPasswordPoint.length >= this.minLength
            )
          ) {
            this.firstPasswordPoint = [];
            this.message = "请绘制手势密码";
          } else {
            this.message = "请重新绘制手势密码";
          }
          this.passwordPoint = [];
          this.currentPoint = null;
          this.drawPoints();
          this.isError = false;
        }, 500);
      } else {
        //密码长度达标
        //已有第一次密码了
        if (
          this.firstPasswordPoint &&
          this.firstPasswordPoint.length >= this.minLength
        ) {
          //对比两次密码
          let res =
            this.firstPasswordPoint.length === this.passwordPoint.length
              ? this.firstPasswordPoint.find(
                  (fPoint, index) =>
                    fPoint.code !== this.passwordPoint[index].code
                )
              : true;
          //两次密码一致
          if (!res) {
            //请求后端，设置密码
            this.message = "";
            this.isError = false;
            let handPassword = "";
            this.passwordPoint.forEach(p => {
              handPassword += p.code;
            });
            handPassword = md5(handPassword);
            this.$toast.loading({ forbidClick: true });
            const { code, msg } = await this.$api.setUserHandPass({
              handPassword
            });
            if (code === 0) {
              this.$toast.success(msg);
              //刷新该用户的信息
              const userInfo = JSON.parse(
                localStorage.getItem(this.$getMobileData.userInfo) || "{}"
              );
              userInfo.handPassword = handPassword;
              localStorage.setItem(
                this.$getMobileData.userInfo,
                JSON.stringify(userInfo)
              );
              this.$router.go(-1);
            } else {
              this.$toast.fail(msg);
              //失败，重置
              this.firstPasswordPoint = [];
              this.passwordPoint = [];
              this.currentPoint = null;
              this.drawPoints();
              this.message = "请绘制手势密码";
              this.isError = false;
            }
          } else {
            //两次密码不一致
            this.message = "两次手势不一致，请重新绘制";
            this.isError = true;
            //设置1秒的标红提示，然后清空密码
            this.drawPoints({
              fillStyle: "#FF0000",
              strokeStyle: "#FF0000"
            });
            setTimeout(() => {
              this.passwordPoint = [];
              this.currentPoint = null;
              this.drawPoints();
            }, 500);
          }
        } else {
          //这是第一次密码，请用户输入确认密码
          this.firstPasswordPoint = this.passwordPoint;
          //重新绘制密码手势，再次确认密码
          this.message = "请重新绘制手势密码";
          this.passwordPoint = [];
          this.currentPoint = null;
          this.drawPoints();
        }
      }
    });

    //start
    this.drawPoints();
  },
  methods: {
    drawPoints(style) {
      this.points = [];
      Point.clearCanvas(this.context);
      //画布的宽度
      const width = this.context.canvas.width;
      //每个点的间距 = r，则r = width-2padding/8
      const r = (width - 20) / 9;
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          //每个点代表的密码值
          const code = `_${word[3 * j + i]}`;
          //每个点的样式
          const res = this.passwordPoint.filter(item => {
            if (item.code === code) {
              item.style = style;
              item.setStyle(style);
              return true;
            }
          });
          const pointStyle = res.length > 0 ? style : null;
          const point = new Point({
            x: 1.2 * (3 * i + 1) * r,
            y: 1.2 * (3 * j + 1) * r,
            r,
            code,
            style: pointStyle,
            context: this.context
          });
          point.init();
          this.points.push(point);
        }
      }
      //如果已存有手势密码
      if (this.passwordPoint.length > 0) {
        this.passwordPoint.forEach((point, index) => {
          const beforePoint = index > 0 ? this.passwordPoint[index - 1] : null;
          point.drawLine(beforePoint);
          point.drawInnerPoint();
        });
      }
    },
    judgeCurrentPoint(clientX, clientY) {
      //判断是否触摸在某个点上，如果是则currentPoint为该点，并且画内圆
      const res = this.points.filter(({ x, y, r, code }) => {
        return (
          Math.pow(clientX - this.gapX - x, 2) +
            Math.pow(clientY - this.gapY - y, 2) <=
          Math.pow(r, 2)
        );
      });
      //当前触摸区域只能属于某个点，判断这个点是否已在密码库里，没有就添加
      if (res.length > 0) {
        const a = this.passwordPoint.filter(item => item.code === res[0].code);
        if (a.length === 0) {
          this.currentPoint = res[0];
          //画箭头
          // const beforePoint =
          //   this.passwordPoint.length > 0
          //     ? this.passwordPoint[this.passwordPoint.length - 1]
          //     : null;
          // this.currentPoint.drawArrow(beforePoint);
          this.passwordPoint.push(this.currentPoint);
          this.currentPoint.drawInnerPoint();
        }
      }
    }
  }
};
</script>
<style lang="less" scoped>
.canvas {
  width: 85%;
  padding: 10px;
}
.message {
  height: 50px;
  font-size: 13/16rem;
  font-weight: normal;
  line-height: 50px;
  padding: 0;
  margin: 0;
  margin-bottom: 30px
}
.isError {
  color: red;
}
</style>
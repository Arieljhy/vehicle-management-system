/**
 * 每个圆心点
 */
export class Point {
    //圆心点的半径
    //圆心点的位置
    //圆心点的方向线(方向、长度)
    //圆心点按压上去或者经过时-被填充，内圆（半径、）
    //主题色：黑色和白色
    constructor({ r, x, y, code, context, style, theme }) {
        this.code = code;
        this.r = r || 10;
        this.x = x || this.r;
        this.y = y || this.r;
        this.context = context || document.getElementById("handPassword-canvas").getContext("2d");
        this.style = style;
        this.theme = theme || "dark";
    }
    //设置样式
    setStyle() {
        const { strokeStyle, fillStyle } = this.style || {};
        this.context.strokeStyle = strokeStyle || "#108FEB";
        this.context.fillStyle = fillStyle || "#108FEB";
    }
    //初始化，画圆
    init() {
        const { x, y, r, context, theme } = this;
        switch (theme) {
            case "light": {
                context.strokeStyle = "#fff";
                context.fillStyle = "#fff";
                break;
            }
            default: {
                context.strokeStyle = "#323233";
                context.fillStyle = "#323233";
            }
        }
        context.beginPath();
        context.arc(x, y, r, 0, 2 * Math.PI);
        context.stroke();
    }
    //当用户手指选中当前点，画内圆
    drawInnerPoint() {
        const { x, y, r, context } = this;
        this.drawShadowPoint();
        this.setStyle();
        context.beginPath();
        context.arc(x, y, r / 3, 0, 2 * Math.PI);
        context.fill();
    }
    //设置阴影圆
    drawShadowPoint() {
        const { x, y, r, context, theme } = this;
        context.beginPath();
        switch (theme) {
            case "light": {
                context.fillStyle = "rgba(255,255,255,.4)";
                break;
            }
            default: {
                context.fillStyle = "rgba(50,50,51,.3)";
            }
        }
        context.arc(x, y, r / 3, 0, 2 * Math.PI);
        context.arc(x, y, r, 0, -2 * Math.PI);
        context.fill();
    }
    //当用户手指选中当前点，并且移动时，画线
    drawCurrentLine(params) {
        if (params) {
            const { toX, toY, doInit } = params;
            const { x, y, r, context } = this;
            this.setStyle();
            //从圆点伸出去到当前手指的点 的线段 与 当前圆 相交的点
            const beginX = Math.sqrt(Math.pow(toX, 2) * Math.pow(r, 2) / (Math.pow(toX, 2) - Math.pow(toY, 2)));
            const beginY = beginX * toY / toX;
            //清空画布
            Point.clearCanvas(context);
            if (doInit) {
                doInit();
            }
            context.beginPath();
            context.moveTo(x, y);
            context.lineTo(toX, toY);
            context.stroke();
        }
    }
    //画线
    drawLine(nextPoint) {
        if (nextPoint) {
            const { x: toX, y: toY } = nextPoint;
            const { x, y, context } = this;
            this.setStyle();
            context.beginPath();
            context.moveTo(x, y);
            context.lineTo(toX, toY);
            context.stroke();
        }
    }
    //当用户手指选中当前点和其他点产生移动轨迹的时候，画箭头
    drawArrow(beforePoint) {
        if (beforePoint) {
            const { x, y, r, context } = this;
            const { x: beforeX, y: beforeY } = beforePoint;
            this.setStyle();
            //画三角形
            //三角形 箭头坐标：y3 = r/2*Math.sqrt(1/(1+Math.pow((x-beforeX)/(y-beforeY),2)))
            const y3 = r / 2 * Math.sqrt(1 / (1 + Math.pow((x - beforeX) / (y - beforeY), 2)));
            const x3 = (x - beforeX) * (y3 - beforeY) / (y - beforeY) + beforeX;

        }
    }
    //清空画布
    static clearCanvas(context) {
        context.clearRect(0, 0, context.canvas.width, context.canvas.height);
    }

}
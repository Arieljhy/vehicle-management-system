<template>
  <div>
    {{title}}
  </div>
</template>
<script>
export default {
  name: "compoentTwo",
  props: {
    title: {
      default: String,
      required: false
    }
  },
  data() {
    return {};
  },
  methods: {}
};
</script>
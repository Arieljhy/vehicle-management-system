<template>
  <div class="pdf" ref="pdfDom" style="background: #fff;z-index: 2;" @scroll="handleScroll">
    <van-row style="margin-top:10px">
      <!-- <van-col span="6"><span @click="scaleD" style="text-align: right;">放大</span></van-col>
      <van-col span="6"><span @click="scaleX" style="text-align: right;">缩小</span></van-col>-->
      <van-col span="24">
        <span @click="comeBack" class="mc-back" id="target">
          <van-icon name="cross" />
        </span>
      </van-col>
      <!-- <span @click="comeBack" style="text-align: right;">放大</span>
       <span @click="comeBack" style="text-align: right;">缩小</span>
      <span @click="comeBack" class="mc-back"><van-icon name="cross" /></span>-->
    </van-row>
    <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
      <div v-for="item in pdfSrcs" :key="item.id">
        <pdf
          v-for="i in item.numPages"
          :key="i"
          ref="pdf"
          :src="item.pdfSrc"
          :page="i"
          :rotate="pageRotate"
        ></pdf>
      </div>
    </van-list>
    <!-- 返回顶部 -->
    <div>
      <van-row id="top" class="top" style="display:none" @click="top">
        <span>TOP</span>
      </van-row>
    </div>
  </div>
</template>
<script>
import pdf from "vue-pdf";
export default {
  name: "mcPdf",
  props: {
    pushurl: {
      default: "", // 预览文件路径
      type: String
    },
    cloudDocId: {
      default: "", // 预览文件路径
      type: String
    },
    fileType: {
      default: "", // 文件类型
      type: String
    }
  },
  metaInfo() {
    return {
      title: "eidi",
      meta: [
        { charset: "utf-8" },
        {
          name: "viewport",
          content: this.metaContent
        }
      ]
    };
  },
  components: { pdf },
  data() {
    return {
      topVal: 0,
      pdfSrcs: [
        { pdfSrc: this.pushurl, numPages: 0, id: 1 } // pdf文件地址
      ],
      numPages: undefined,
      pagenum: 1,
      pdfnum: 2,
      maxPages: 0,
      goPageFlag: false,
      loading: false,
      finished: false,
      pageRotate: 0,
      scale: 100, //放大系数
      metaContent:
        "width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=2,user-scalable=yes"
    };
  },
  mounted() {
    //监听滚动事件
    let box = this.$refs.pdfDom;
    let _this = this;
    box.addEventListener(
      "scroll",
      () => {
        _this.topVal = box.scrollTop;
      },
      false
    );
    // 有时PDF文件地址会出现跨域的情况,这里最好处理一下
    this.pdfSrcs.map(item => {
      item.pdfSrc = pdf.createLoadingTask(item.pdfSrc);
      item.pdfSrc
        .then(pdf => {
          item.numPages = pdf.numPages;
          // if (pdf.numPages < 4) {
          //   this.finished = true;
          // }
        })
        .catch(() => {
          this.finished = true;
        });
    });
    if (window.history && window.history.pushState) {
      history.pushState(null, null, document.URL);
      //给popstate 绑定一个方法，监听页面刷新
      window.addEventListener("popstate", this.comeBack, false);
    }
  },
  methods: {
    //放大
    scaleD() {
      this.scale += 10;
      this.$refs.pdf.map(item => {
        item.$el.style.width = parseInt(this.scale) + "%";
      });
      // this.$refs.pdf.$el.style.width = parseInt(this.scale)+ "%"
    },
    scaleX() {
      if (this.scale == 100) {
        return;
      }
      this.scale += -10;
      this.$refs.pdf.map(item => {
        item.$el.style.width = parseInt(this.scale) + "%";
      });
    },
    comeBack() {
      console.log("监听到了");
      this.metaContent =
        "width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no";
      setTimeout(() => {
        this.$emit("goBack");
      }, 100);
    },

    onLoad() {
      const url =
        "/api/processDoc/viewFile?cloudDocId=" +
        this.cloudDocId +
        "&pageSize=1&pageNum=" +
        this.pdfnum +
        "&lesseeId=" +
        this.$getMobileData.lesseeId; //马鞍山
      const keywords = {
        pdfSrc: pdf.createLoadingTask(url),
        numPages: 0,
        id: this.pdfnum
      };

      let that = this;
      keywords.pdfSrc
        .then(pdf => {
          that.loading = false;
          keywords.numPages = pdf.numPages;
          that.pdfSrcs.push(keywords);
          this.pdfnum++;
          // if (pdf.numPages < 4) {
          //   console.log("000000000000000");
          //   setTimeout(() => {
          //   that.finished = true;

          //   }, 30);
          // }
        })
        .catch(() => {
          this.loading = false;
          that.finished = true;
        });
    },
    // 按钮显示/隐藏
    handleScroll() {
      if (this.topVal > 200) {
        document.getElementById("top").style.display = "block";
      } else {
        document.getElementById("top").style.display = "none";
      }
    },
    // 以页面固定元素作为目标元素，返回顶部
    top() {
      setTimeout(() => {
        target.scrollIntoView();
      }, 100);
    }
  },
  destroyed() {
    window.removeEventListener("popstate", this.comeBack, false);
    // window.removeEventListener("scroll", this.onscroll);
  }
};
</script>

<style lang="less" scoped>
.pdf {
  position: fixed;
  top: 0;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  max-width: 1024px;
  width: 100%;
  margin: 0 auto;
  overflow-x: hidden;
  height: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  font-size: 0.28rem;
  span {
    width: 100%;
  }
}
.mc-back {
  text-align: left;
  margin-left: 16.25rem;
  i {
    font-size: 16/16rem;
  }
}
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  line-height: 35/16rem;
  color: #128feb;
  border-radius: 25/16rem;
  background: rgba(204, 204, 204, 0.3);
  right: 35/16rem;
  bottom: 80/16rem;
  &:hover {
    cursor: pointer;
  }
  span {
    line-height: 30/16rem;
  }
}
</style>





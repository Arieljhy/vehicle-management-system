<template>
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" />
      <div name="search" slot="title" class="word-navbar">
        <span @click="openSelect">
          {{title}}
        <van-icon name="arrow-down"  />
        </span>
      </div>
      <van-icon name="search" slot="right" />
    </van-nav-bar>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "NavBar",
  props: {
    title: {
      default: String,
      required: false
    }
  },
  data() {
    return {
      value: ""
    };
  },
  computed: {
    ...mapGetters([])
  },
  methods: {
    ...mapActions([]),
    openSelect() {
      console.log("diankaile");
    }
  }
};
</script>
<style scoped lang="scss">

</style>
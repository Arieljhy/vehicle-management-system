import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import riskTodo from './modules/riskTodo'
import common from './modules/common'
import ownerProject from './modules/ownerProject'
import superviseSelectFilter from './modules/superviseSelet'

Vue.use(Vuex)
const store = new Vuex.Store({
  modules: {
    common,
    riskTodo,
    ownerProject,
    superviseSelectFilter
  },
  getters
})

export default store

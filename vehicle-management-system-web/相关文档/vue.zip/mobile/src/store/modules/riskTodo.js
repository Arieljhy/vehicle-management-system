import http from "@/common/request";
import { mobileData } from "@/assets/js/mobileData.js";
const commonData = mobileData[process.env.VUE_APP_CITY]
export default {
    state: {
        finalRiskData: {},//最终风险报告
        riskReportData: [],
        riskCheckReport: [],
        listRiskTis: {},
        listRiskEvent: [],
        listInsList: {}
    },
    mutations: {
        FINAL_RIISK(state, data) {
            http
                .get("/risk/RiskReport/lastReport/", data)
                .then(res => {
                    if(res.code==2){
                        state.finalRiskDat={}
                    }else{
                        state.finalRiskData = res.data.riskReportDO;
                    if (state.finalRiskData.startWorkDate !== null) {
                        state.finalRiskData.startWorkDate = res.data.riskReportDO.startWorkDate.split(" ")[0]
                    }
                    if (state.finalRiskData.reportDate !== null) {
                        state.finalRiskData.reportDate = res.data.riskReportDO.reportDate.split(" ")[0]
                    }
                    }
                });
        },
        RISK_REPORT(state, data) {
            http.get('/risk/RiskReport', data).then(res => {
                state.riskReportData = res.data.rows;
                state.riskReportData.total = res.data.total;
                state.riskReportData.map((item, index) => {
                    if (item.reportDate !== null) {
                        state.riskReportData[index].reportDate = item.reportDate.split(" ")[0]
                    }
                })

            })
        },
        RISK_CHECK_REPORT(state, data) {
            http.get('/risk/RiskCheckReport', data).then(res => {
                state.riskCheckReport = res.data.rows;
                state.riskCheckReport.total = res.data.total;
                state.riskCheckReport.map((item, index) => {
                    if (item.surveyDate !== null) {
                        state.riskCheckReport[index].surveyDate = item.surveyDate.split(" ")[0]
                    }
                })
            })
        },
        RISK_TIS_LIST(state, data) {
            http.get('/project/PrjQueryInfo/App/', data).then(res => {
                state.listRiskTis = res.data
                if (state.listRiskTis.reportDate !== null) {
                    state.listRiskTis.reportDate =state.listRiskTis.reportDate.split(" ")[0]
                }
                if (state.listRiskTis.startWorkDate !== null) {
                    state.listRiskTis.startWorkDate = state.listRiskTis.startWorkDate.split(" ")[0]
                }
            })
        },
        RISK_EVENT_LIST(state, data) {
            http.post('/risk/RiskEvent/listRiskEvent', data).then(res => {
                state.listRiskEvent = res.data.rows;
                state.listRiskEvent.total = res.data.total;
                state.listRiskEvent.map((item, index) => {
                    if (item.riskFoundTime !== null) {
                        state.listRiskEvent[index].riskFoundTime = item.riskFoundTime.split(" ")[0]
                    }
                    if (item.proposedAmendDeadline !== null) {
                        state.listRiskEvent[index].proposedAmendDeadline = item.proposedAmendDeadline.split(" ")[0]
                    }
                    if (item.amendProgress !== null) {
                        state.listRiskEvent[index].amendProgress = parseFloat(item.amendProgress)
                    }
                    JSON.parse(
                        localStorage.getItem(commonData.baseSelects)
                    ).IDI_RISK_EVENT_LEVEL.map(_data => {
                        if (_data.dictKey == item.riskLevel) {
                            item.riskLevel = _data.dictValue;
                        }
                    });
                    JSON.parse(
                        localStorage.getItem(commonData.baseSelects)
                    ).IDI_RISK_EVENT__STATUS.map(_data => {
                        if (_data.dictKey == item.riskEventStatus) {
                            item.riskEventStatus = _data.dictValue;
                        }
                    });
                })
            })
        },
        LIST_INS_LIST(state, data) {
            http.get('/risk/RiskManagementPlan', data).then(res => {
                state.listInsList = res.data
            })
        }
    },
    actions: {
        // 获取最终风险报告接口
        finalRisk({ commit }, params) {
            commit('FINAL_RIISK', params)
        },
        //获取风险报告
        riskReport({ commit }, params) {
            commit('RISK_REPORT', params)
        },
        //获取回访报告
        riskCheckReportList({ commit }, params) {
            commit('RISK_CHECK_REPORT', params)
        },
        //获取tis头部信息
        riskTisList({ commit }, params) {
            commit('RISK_TIS_LIST', params)
        },
        //获取风险事件信息
        riskEventList({ commit }, params) {
            commit('RISK_EVENT_LIST', params)
        },
        //获取保险公司头部信息
        listInsList({ commit }, params) {
            commit('LIST_INS_LIST', params)
        }
    }
}
import http from '@/common/request'
import api from '@/common/api'
import { mobileData } from "@/assets/js/mobileData.js";
const commonData = mobileData[process.env.VUE_APP_CITY]
export default {
  state: {
    isPopup: false,
    // 省市县
    provinceList: [],
    setFilterData: {},
    // 展示列表
    superviseList: [],
    // 触底掉接口
    loading: false,
    finished: false,
    // 入参
    limit: 5,
    province: commonData.province,
    city: commonData.city,
    district: '',
    minCostPerMeter: '',
    maxCostPerMeter: '',
    beginSignDate: '',
    endSignDate: '',
    // 住宅性质
    buildingType: '',
    // 项目进度
    projectStatus: '',
    // 承保公司
    orgIds: '',
    // 是否含有老保单
    isChecked: false,
    userType: ''
  },
  mutations: {
    // 获取省
    GET_PROVINCE (state, data) {
      http.get('/sysconfig/DictionaryData/listAreaData').then(res => {
        if (res.code === 0) {
          state.provinceList = res.data
        }
      })
    },
    // 获取列表
    GET_SUPERVISE_LIST (state, data) {
      if (data.code === 0) {
        state.superviseList = state.superviseList.concat(data.data.rows)
        // 停止触底加载     
        if (state.superviseList.length == data.data.total) {
          state.finished = true
        }
      }
    },
    SET_FINISHED (state, data) {
      state.finished = data
    },


    SET_FILTER_DATA(state, data) {
      state.limit = data.limit
      state.province = data.province
      state.city = data.city
      state.district = data.district
      state.minCostPerMeter = data.minCostPerMeter
      state.maxCostPerMeter = data.maxCostPerMeter
      state.beginSignDate = data.beginSignDate
      state.endSignDate = data.endSignDate
      state.buildingType = data.buildingType
      state.projectStatus = data.projectStatus
      state.orgIds = data.orgIds
      if (data.isChecked.length != 0) {
        state.isChecked = true
      } else {
        state.isChecked = false
      }
    },
    SET_POPUP(state, data) {
      state.isPopup = data
    },
    GET_USER_TYPE(state, data) {
      state.userType = JSON.parse(
        localStorage.getItem(commonData.userInfo)
      ).roleType
    },

  },
  actions: {
    // 获取省
    getProvince ({ commit }, params) {
      commit('GET_PROVINCE')
    },
    // 获取列表
    async getSuperviseList({ commit }, params) {
      const res = await api.getSuperviseList(params)
      if (res.code === 0) {
        commit('GET_SUPERVISE_LIST', res)
      }
    },
    // 设置触底掉接口
    setFinished ({ commit }, params) {
      commit('SET_FINISHED', params)
    },
    // 从筛选模块获取参数并设置到state
    setFilterData ({ commit }, params) {
      commit('SET_FILTER_DATA', params)
    },
    setPopup({ commit }, params) {
      commit('SET_POPUP', params)
    },
    // 获取账号类型,以此来判断展示不同的筛选条件
    getUserType({ commit }, params) {
      commit('GET_USER_TYPE',params)
    },

  }
}

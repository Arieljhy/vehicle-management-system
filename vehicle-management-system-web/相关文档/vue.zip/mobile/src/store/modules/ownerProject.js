import http from '@/common/request'
import api from '@/common/api'
export default {
  state: {
    plotsList: [],
    projectData: [],
    houseNum: 0,
    houseList: [],
    selectedPrj: {},
    images: [],
    report: [],
    tips: 0,
    // 判断是否有项目
    isDataList: true,
    mainPostList: [],
    finished: false,
    showNum: 0
  },
  mutations: {
    // 获取小区列表接口
    GET_PROJECT_LIST(state, res) {
      // const keywords = data
      // http.post('/community/list', keywords).then((res) => {
      if (res.code === 0) {
        if (res.data.length !== 0) {
          state.isDataList = true
          // 清空数组，防止重复添加数据
          state.plotsList = res.data
          var storeDataIsHave = false;
          state.plotsList.map((_params, index) => {
            _params.text = _params.communityName
            if (JSON.parse(localStorage.getItem('eidi.selected_project'))) {
              if (JSON.parse(localStorage.getItem('eidi.selected_project')).projectId == _params.projectId) {
                state.showNum = index
                storeDataIsHave = true;
              }

            }
          })
          // 默认登录展示第一个小区
          if (!JSON.parse(localStorage.getItem('eidi.selected_project')) || !storeDataIsHave) {
            localStorage.setItem('eidi.selected_project', JSON.stringify(state.plotsList[0]))
          }

          state.selectedPrj = JSON.parse(localStorage.getItem('eidi.selected_project'))
        } else {
          // false: 表示没有小区(项目)
          // true: 表示有小区,正常展示
          state.isDataList = false
          // 没有小区时,展示默认图片
          state.images = [
            {
              imageUrl: require('@/assets/imgs/moren.jpg')
            }
          ]
        }
      }
      // })
    },
    GET_PROJECT_LISTZF(state, res) {
      if (res.code === 0) {
          state.plotsList = res.data
      }
    },
    // 当前项目的详情信息
    GET_PROJECT_DATA(state, data) {
      http.get('/forum/getForumInfoByProjectId/' + data).then((res) => {
        if (res.code === 0) {
          state.projectData = res.data
        }
      })
    },
    // 获取当前小区的栋楼
    GET_PLOTS_HOUSEHOLD(state, data) {
      http.get('/project/PrjSingleUnits',{projectId:data}).then(res => {
        if (res.code === 0) {
          state.houseNum = res.data.total
          state.houseList = res.data.rows.filter(_data => {
            return _data.buildingName != null
          })
        }
      })
    },
    SET_PROJECT(state, data) {
      localStorage.setItem('eidi.selected_project', JSON.stringify(data))
      state.selectedPrj = data
    },
    GET_IMAGES(state, data) {
      http.get('/project/concatImg/banner/' + data).then(res => {
        if (res.code === 0) {
          if (res.data.length !== 0) {
            state.images = res.data
            state.images.map(_url => {
              _url.imageUrl = '/api/processDoc/downloadProcessDoc?cloudDocId=' + _url.imageUri
            })
          } else {
            state.images = [
              {
                imageUrl: require('@/assets/imgs/fengxian001.png')
              }
            ]
          }
        }
      })
    },

    GET_CLAIM_TIP(state, res) {
      if (res.code === 0) {
        state.tips = res.data.total
      }
    },
    GET_MAIN_POST_LIST(state, res) {
      res.data.rows.map(item => {
        item.forumPicDOList.map(childItem => {
          childItem.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}`;
        });
      });
      state.mainPostList = res.data.rows;
    },
    POST_FINISHED(state, res) {
      state.finished = res
    },
    IS_DATA_LIST(state, res) {
      state.isDataList = res
    },
    CLEAR_MAIN_POST_LIST(state, res) {
      res.map(item => {
        item.forumPicDOList.map(childItem => {
          childItem.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}`;
        });
      });
      state.mainPostList = res
    },
    CLEAR_ALL(state, data) {
      state.plotsList= []
      state.projectData= []
      state.houseNum= 0
      state.houseList= []
      state.selectedPrj = {}
      state.images= []
      state.report= []
      state.tips= 0
      state.isDataList= true
      state.mainPostList= []
      state.finished= false
      state.showNum= 0
    },
    SET_SHOW_NUM(state, data){
      state.showNum= data
    }
  },
  actions: {
    // 获取列表接口
    async getProjectList({ commit }, params) {
      const res = await api.getProjectList(params)
      if (res.code === 0) {
        commit('GET_PROJECT_LIST', res)
      }
      return res
    },
    // 获取政府列表接口
    async getProjectListZF({ commit }, params) {
      const res = await api.getProjectList(params)
      if (res.code === 0) {
        commit('GET_PROJECT_LISTZF', res)
      }
      return res
    },
    // 选中小区后调取接口
    getProjectData({ commit }, params) {
      commit('GET_PROJECT_DATA', params)
    },
    // 获取小区总户数接口
    getPlotsHousehold({ commit }, params) {
      commit('GET_PLOTS_HOUSEHOLD', params)
    },
    setProject({ commit }, params) {
      commit('SET_PROJECT', params)
    },
    // 获取轮播图
    getImages({ commit }, params) {
      commit('GET_IMAGES', params)
    },
    // 设置触底掉接口
    setFinished({ commit }, params) {
      commit('SET_FINISHED', params)
    },
    // 获取理赔列表，首页调用展示提示点
    async getClaimTip({ commit }, params) {
      const res = await api.getClaimTip(params)
      if (res.code === 0) {
        commit('GET_CLAIM_TIP', res)
      }
      return res
    },
    setClaimsFinished({ commit }, params) {
      commit('SET_CLAIMSFINISHED', params)
    },
    getMainPostList({ commit }, params) {
      http.get("/forum/listMain", params).then(res => {
        if (res.code == 0) {
          commit('GET_MAIN_POST_LIST', res)
        }
      });
    },
    postFinished({ commit }, params) {
      commit('POST_FINISHED', params)
    },
    isDataList({ commit }, params) {
      commit('IS_DATA_LIST', params)
    },
    clearMainPostList({ commit }, params) {
      commit('CLEAR_MAIN_POST_LIST', params)
    },
    // 退出登录的时候,清空store
    clearArr({ commit }, params) {
      commit('CLEAR_ALL', params)
    },
    setShowNum({ commit }, params) {
      commit('SET_SHOW_NUM', params)
    }
  }
}

import http from "@/common/request";
import { mobileData } from "@/assets/js/mobileData.js";
const commonData = mobileData[process.env.VUE_APP_CITY]
export default {
    state: {
    },
    mutations: {
        SET_BASE_SELECT(state, params) {
            localStorage.setItem(
                commonData.baseSelects,
                JSON.stringify(params)
              );
        },
        SET_BAIDU_TOCKEN(state, params) {
            localStorage.setItem(
                "eidi_mobile.baiduTocken",
                JSON.stringify(params)
              );
        }
    },
    actions: {
        setBaseSelect({ commit }) {
            http.get("/sysconfig/DictionaryData/listBaseData").then(res => {
                commit('SET_BASE_SELECT', res.data);
            });
        },
        getBaiduTocken({ commit }) {
            http.get("/common/config/aaiasrToken").then(res => {
                commit('SET_BAIDU_TOCKEN', res.aaiasrApiToken);
            });
            
        },

    }
}
<template>
  <div :class="['content',!switchFlag?'absolute-setting':'']" :style="screen_height">
    <van-row>
      <van-col
        v-if="switchFlag"
        span="24"
        :class="['switch_login',hasStorage?'':'is-hide']"
        @click="switchLogin"
      >切换登录方式</van-col>
      <van-col
        v-if="!switchFlag"
        span="24"
        :class="['switch_login1',hasStorage?'':'is-hide']"
        @click="switchLogin"
      >切换登录方式</van-col>
      <van-col span="24" v-if="switchFlag">
        <van-col span="24">
          <div class="mc-cir">
            <img :src="logo_2" class="logo_2" />
          </div>
        </van-col>
        <van-col span="24" class="userId-margin">
          <van-cell-group>
            <van-field v-model="loginForm.userId" placeholder="请输入手机号" />
            <van-field
              v-model="loginForm.password"
              type="password"
              :error-message="errorMsg"
              placeholder="密码"
            />
          </van-cell-group>
        </van-col>
        <van-col span="12" class="forget_password" @click="forgetPassWord">忘记密码?</van-col>
        <van-col span="12" class="go_registered" @click="toRegister">注册</van-col>
      </van-col>
      <!-- <van-col v-if="switchFaceFlag && !switchFlag" class="loginOn-width"> -->
      <!-- <video id="video" width="300" height="300" preload autoplay loop muted></video>
      <canvas id="canvas" width="300" height="300"></canvas>-->
      <!-- <div style="font-weight: 600;color: white;margin-bottom: 10px;">欢迎回来,{{userName}}</div> -->
      <!-- <FaceLogin></FaceLogin>
      </van-col>-->
      <van-col span="24" v-if="!switchFlag && !switchFaceFlag">
        <GestureLogin :topHeight="17+54+28" />
      </van-col>
      <van-col span="24" v-if="switchFlag" class="loginOn-margin">
        <van-button
          type="info"
          class="base_login_btn"
          style="background-color:rgba(25,137,250,0.7)"
          @click="loginOn"
        >登录</van-button>
      </van-col>
      <van-col span="24" v-if="switchFlag">
        <van-divider class="divider-style">2.0</van-divider>
      </van-col>
      <van-col span="24" v-if="switchFlag" class="base_login_margin">
        <van-button
          :disabled="!hasStorage"
          @click="hasLogin"
          type="default"
          class="base_login_btn"
          style="background-color:rgba(255,255,255,0.3)"
        >人脸登录</van-button>
      </van-col>
      <van-col
        span="24"
        v-if="switchFlag"
        class="login_text"
        v-for="(item,index) in $getMobileData.units"
        :key="index"
      >{{item}}</van-col>
    </van-row>
    <van-popup v-model="show" class="model-content">
      <div class="wrapper">
        <div class="body-content">
          <!-- 文字部分 -->
          <div class="word-text">
            <div style="height:300px;overflow:auto;user-select: none;">
              <div class="title">{{$getMobileData.modelContent}}IDI信息平台隐私保护提示</div>
              <div style="text-indent: 0px;" class="padding-top">尊敬的用户：</div>
              <div
                class="padding-top"
              >您好，感谢您的信任与使用！{{$getMobileData.modelContent}}IDI信息平台非常重视用户的隐私保护和个人信息保护。</div>
              <div
                class="padding-top"
              >我们依据最新的法律法规要求，更新了《{{$getMobileData.modelContent}}IDI信息平台隐私政策》。其中涉及与您权利义务相关的特别规定等重要条款，请您重点仔细阅读。</div>
              <div
                class="padding-top"
              >在您使用{{$getMobileData.modelContent}}IDI信息平台及服务前，请您务必仔细阅读并透彻理解该协议及政策，您同意并接受全部条款后可开始使用我们的服务。</div>
              <div class="padding-top">
                您可以点击下述链接阅读完整的
                <em
                  style="color: #2277ff;font-style: normal;"
                  @click.stop="privacyDeils(0)"
                >《{{$getMobileData.modelContent}}IDI信息平台隐私政策》</em>了解具体内容，如您对协议内容有任何疑问、意见或建议，您可通过客服与我们联系。
              </div>
              <div
                class="padding-top"
                style="font-weight:bold"
              >特别提示，当您点击“同意”即表示您已充分阅读、理解并接受《{{$getMobileData.modelContent}}IDI信息平台隐私政策》的全部内容，如您不同意其中的任何条款，您应立即停止使用{{$getMobileData.modelContent}}IDI信息平台及服务。</div>
            </div>
          </div>
          <div style="border-top:1px solid #f2f2f2">
            <van-button plain type="info" class="btn" @click.stop="privacyDeils(1)">同意</van-button>
            <van-button type="default" class="btn" @click.stop="privacyDeils()">取消</van-button>
          </div>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import md5 from "js-md5";
import logo_2 from "@/assets/imgs/logo-2.png";
import http from "@/common/request";
import "@/assets/js/tracking.js";
import "@/assets/js/face-min.js";
import "@/assets/js/mouth-min.js";
import $ from "jquery";
import cookie from "js-cookie";
import GestureLogin from "@/components/gesture/login";
import FaceLogin from "@/components/faceLogin";
import BJimg from "@/assets/imgs/bjlogin.jpg";
import MASimg from "@/assets/imgs/maslogin.jpg";
import YQimg from "@/assets/imgs/yqlogin.jpg";
import SHimg from "@/assets/imgs/shlogin.jpg";
export default {
  name: "login",
  components: {
    GestureLogin,
    FaceLogin,
  },
  data() {
    return {
      userInfoList: {},
      bgimg: {
        beijing: BJimg,
        maanshan: MASimg,
        shanghai: SHimg,
        yangquan: YQimg,
      },
      privateClause: "",
      tenantIdprivacy: "",
      userIdprivacy: "",
      show: false,
      logo_2,
      fullscreenLoading: false,
      times: "发送验证码",
      interval: "",
      findPassword: false,
      lesseeId: this.$getMobileData.lesseeId, //马鞍山
      // lesseeId: "eidi-yangquan",//阳泉
      loginDialog: false,
      input: "",
      disInforList: [], //信息公开
      sampleFileList: [], //样例文件
      loginForm: {
        userId: "", //账号
        password: "", //密码
        loginCode: "", //验证码
        loginType: "password",
      }, //登录输入框
      videoEle: null,
      trackerTask: null,
      switchFlag: true,
      num: 1,
      errorMsg: null,
      oppenTracking: null,
      hasStorage: false,
      tis: "",
      switchFaceFlag: false,
      beforeRoute: false,
      userName: "",
    };
  },
  created() {
    if (this.$route.query.title == 0) {
      this.show = true;
    }
    const userInfo = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo) || "{}"
    );
    this.hasStorage = !!userInfo.userId;
    // this.switchFlag = !userInfo.handPassword;
    // if(userInfo.txFaceId){

    // }
    this.loginForm.userId = userInfo.mobile;
    if (cookie.get(this.$getMobileData.userInfo)) {
      this.loginForm.password = cookie.get(this.$getMobileData.userInfo);
    }

    setTimeout(() => {
      if (typeof androidApp !== "undefined") {
        androidApp.setRefresh(false); //禁用刷新
      }
    });
  },
  computed: {
    screen_height() {
      const mc_height = document.body.clientHeight + "px";
      return {
        height: mc_height,
        background:
          "url(" + this.bgimg[this.$getMobileData.control] + ")" + "no-repeat",
        "background-size": "cover",
      };
    },
  },
  mounted() {
    if (window.history && window.history.pushState) {
      history.pushState(null, null, document.URL);
      //给popstate 绑定一个方法，监听页面刷新
      window.addEventListener("popstate", this.comeBack, false);
    }
    this.videoEle = this.$refs.video;
  },
  destroyed() {
    //  window.removeEventListener("popstate", this.comeBack, false);
    // 停止侦测;
    // this.trackerTask.stop();
    // 关闭摄像头;
    // window.tracking.closeCamera();
  },
  beforeRouteLeave(to, from, next) {
    if (this.beforeRoute) {
      next(false);
    } else {
      next();
    }
  },
  methods: {
    ...mapActions(["login", "setBaseSelect", "getBaiduTocken", "clearArr"]),
    comeBack() {
      this.beforeRoute = true;
    },
    privacyDeils(flag) {
      if (flag == 0) {
        if (this.$getMobileData.lesseeId == "eidi-maanshan") {
          this.$router.push({
            path: "/masprivacyPoilcy",
          });
        } else if (this.$getMobileData.lesseeId == "eidi-beijing") {
          this.$router.push({
            path: "/bjprivacyPoilcy",
          });
        } else if (this.$getMobileData.lesseeId == "eidi-shanghai") {
          this.$router.push({
            path: "/shprivacyPoilcy",
          });
        } else if (this.$getMobileData.lesseeId == "eidi-yangquan") {
          this.$router.push({
            path: "/yqprivacyPoilcy",
          });
        }
      } else if (flag == 1) {
        http
          .post("/privateClause", {
            userId: this.userIdprivacy,
            tenantId: this.tenantIdprivacy,
            privateClause: "Y",
          })
          .then((res) => {
            if (res.code == 0) {
              this.show = false;
              this.tis = JSON.parse(
                localStorage.getItem(this.$getMobileData.userInfo)
              );
              this.setBaseSelect();
              this.getBaiduTocken();
              if (typeof androidApp !== "undefined") {
                androidApp.setUser(this.tis.userId); //手机消息推送配置
                androidApp.setRefresh(true); //禁用刷新
              }
              if (
                this.tis.roleType == "INS" ||
                this.tis.roleType == "BLD" ||
                this.tis.roleType == "SGF" ||
                this.tis.roleType == "TIS" ||
                this.tis.roleType == "KC" ||
                this.tis.roleType == "JL" ||
                this.tis.roleType == "SJ"
              ) {
                this.$router.push("myToDoRisk");
              } else if (
                this.tis.roleType == "OP" ||
                this.tis.roleType == "GOV"
              ) {
                this.$router.push("statistics");
              } else if (
                this.tis.roleType == "OWN" ||
                this.tis.roleType == "WY"
              ) {
                this.$router.push("ownerCommunity");
              }
            }
          });
      } else {
        http
          .post("/privateClause", {
            userId: this.userIdprivacy,
            tenantId: this.tenantIdprivacy,
            privateClause: "N",
          })
          .then((res) => {
            if (res.code == 0) this.logout();
          });
        this.show = false;
      }
    },
    //退出登录
    logout() {
      // const keywords = { userId: this.userInfoList.userId,tenantId:this.userInfoList.tenantId,logoutStatus:"0"};
      const keywords = {
        userId: this.userIdprivacy,
        tenantId: this.tenantIdprivacy,
        logoutStatus: "0",
      };
      http.get("/logout", keywords).then((res) => {
        if (res.code === 0) {
          localStorage.clear();
          this.clearArr();
        }
      });
    },
    hasLogin() {
      // this.switchFlag = false;
      // this.switchFaceFlag = true;
      this.$router.push("/faceLogin");
      this.userName = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).username;
    },

    switchLogin() {
      this.switchFlag = !this.switchFlag;
      this.switchFaceFlag = false;
      // if (typeof androidApp !== "undefined") {
      //   androidApp.setRefresh(false); //禁用刷新
      // }
      // if (!this.switchFlag) {
      //   this.openCamera();
      // } else {
      //   this.oppenTracking.events_.stop[0]();
      //   //关闭摄像头
      //   window.tracking.closeCamera();
      // }
    },
    //登录 忘记密码
    changeType(flag) {
      if (this.$refs["loginForm"]) {
        this.$refs["loginForm"].resetFields();
      }
      this.loginForm = {};
      clearInterval(this.interval);
      this.times = "发送验证码";
      if (flag == "loginImmediately") {
        this.findPassword = false;
        this.loginDialog = true;
        this.rulesLoginForm.userId[0].message = "请输入账号";
      } else {
        this.fullscreenLoading = false;
        this.findPassword = true;
        this.rulesLoginForm.userId[0].message = "请输入手机号";
      }
    },
    //登录
    loginOn(loginForm) {
      if (!this.loginForm.userId) {
        this.$toast("账号不能为空！");
        return;
      }
      if (!this.loginForm.password) {
        this.$toast("密码不能为空！");
        return;
      }
      const { password } = this.loginForm;
      cookie.set(this.$getMobileData.userInfo, password);
      const keywords = {
        ...this.loginForm,
        password: md5(password),
        tenantId: this.$getMobileData.lesseeId, //马鞍山
      };

      http.post("/logincas", keywords).then((res) => {
        if (res && res.code == 0) {
          this.tenantIdprivacy = res.data.tenantId;
          this.userIdprivacy = res.data.userId;
          this.privateClause = res.data.privateClause;
          localStorage.setItem(
            this.$getMobileData.userInfo,
            JSON.stringify(res.data)
          );
          localStorage.setItem(this.$getMobileData.token, res.token);
          if (res.data.privateClause == "N") {
            // if (typeof androidApp !== "undefined") {
            //   androidApp.setRefresh(false); //手机消息推送配置
            // }
            this.show = true;
          } else {
            this.beforeRoute = false;
            this.setBaseSelect();
            this.getBaiduTocken();
            if (typeof androidApp !== "undefined") {
              androidApp.setUser(res.data.userId); //手机消息推送配置
              androidApp.setRefresh(true); //手机消息推送配置z
            }
            if (
              res.data.roleType == "INS" ||
              res.data.roleType == "BLD" ||
              res.data.roleType == "SGF" ||
              res.data.roleType == "TIS" ||
              res.data.roleType == "KC" ||
              res.data.roleType == "JL" ||
              res.data.roleType == "SJ"
            ) {
              this.$router.push("myToDoRisk");
            } else if (
              res.data.roleType == "OP" ||
              res.data.roleType == "GOV"
            ) {
              this.$router.push("statistics");
            } else if (
              res.data.roleType == "OWN" ||
              res.data.roleType == "WY"
            ) {
              this.$router.push("ownerCommunity");
            }
          }
        } else {
          this.$toast(res.msg);
        }
      });
    },
    //人脸登录
    faceLoginOn(faceId) {
      const keywords = {
        tenantId: this.$getMobileData.lesseeId, //马鞍山
        loginType: "password",
        faceId: faceId,
      };
      http.post("/logincas", keywords).then((res) => {
        if (res && res.code == 0) {
          localStorage.setItem(
            this.$getMobileData.userInfo,
            JSON.stringify(res.data)
          );
          this.setBaseSelect();
          this.getBaiduTocken();
          if (typeof androidApp !== "undefined") {
            androidApp.setUser(res.data.userId); //手机消息推送配置
          }
          if (res.data.roleType == "INS" || res.data.roleType == "BLD") {
            this.$router.push("myToDoRisk");
          } else if (res.data.roleType == "OP") {
            this.$router.push("statistics");
          } else {
            this.$router.push(res.data.rolePath);
          }
        }
      });
    },
    //去注册
    toRegister() {
      this.$router.push("/toRegister");
    },
    //忘记密码
    forgetPassWord() {
      this.$router.push("/forgetPassWord");
    },
  },
};
</script>
<style lang="less" scoped>
.absolute-setting {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  height: auto !important;
}
// 弹窗遮罩
.model-content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 350/16rem;
}
.btn {
  width: 100/16rem;
  margin: 15/16rem 20/16rem;
}
.wrapper {
  // display: flex;
  // align-items: center;
  // justify-content: center;
  height: 60%;
}
.body-content {
  background: #fff;
  border: 1px solid #f2f2f2;
  border-radius: 5px;
}
.word-text {
  height: 300/16rem;
  overflow: scroll;
  padding: 15/16rem;
}
.padding-top {
  padding-top: 10/16rem;
}
.word-text div {
  font-family: PingFangSC-Medium;
  text-align: left;
  font-size: 14px;
  text-indent: 20/16rem;
}
.title {
  font-size: 0.875rem;
  color: black;
  font-weight: bold;
  text-align: center !important;
}
.block {
  // border-radius: 5%;
  width: 80%;
  background-color: #fff;
  text-align: left;
  padding: 20/16rem;
}
.blockdiv {
  background-color: #fff;
  text-align: left;
  padding: 20/16rem;
}
.content {
  padding: 28/16rem 20/16rem;
  background-size: cover;
  background-repeat: no-repeat;
  background-attachment: fixed;
}
.switch_login {
  text-align: right;
  margin-bottom: 54/16rem;
  color: #ffffff;
  font-size: 13/16rem;
  &.is-hide {
    visibility: hidden;
  }
}
.switch_login1 {
  text-align: right;
  margin-bottom: 40px;
  color: #ffffff;
  font-size: 13/16rem;
  height: 35px;
  &.is-hide {
    visibility: hidden;
  }
}
.base_login_btn {
  width: 80%;
  border-radius: 25/16rem;
  border: none;
  color: #ffffff;
}
.forget_password {
  text-align: left;
  padding-left: 15/16rem;
  color: #ffffff;
  font-size: 15/16rem;
}
.go_registered {
  text-align: right;
  padding-right: 15/16rem;
  color: #ffffff;
  font-size: 15/16rem;
}
// video,
// canvas {
//   position: absolute;
//   left: 70/16rem;
//   border-radius: 12016rem;
//   top: 90/16rem;
// }
.van-cell-group {
  background-color: transparent;
}
.van-cell-group .van-cell {
  background-color: transparent;
}
.van-cell /deep/ input::-webkit-input-placeholder {
  color: #ffffff;
  font-size: 15/16rem;
}
.van-cell /deep/ input:-moz-placeholder {
  color: #ffffff;
  font-size: 15/16rem;
}
.van-cell /deep/ input::-moz-placeholder {
  color: #ffffff;
  font-size: 15/16rem;
}
.van-cell /deep/ input:-ms-input-placeholder {
  color: #ffffff;
  font-size: 15/16rem;
}
.van-cell /deep/ .van-field__control {
  color: #ffffff;
  font-size: 15/16rem;
  line-height: 34/16rem;
}
.van-cell /deep/.van-field__body {
  border-bottom: 1/16rem solid #108feb;
}
// .van-cell-group {
//   background-color: transparent;
//   .van-cell {
//     background-color: transparent;
//     // border-bottom: 1px solid #1989fa;
//     /deep/ {
//       input::-webkit-input-placeholder {
//         color: #ffffff;
//         font-size: 15px;
//       }

//       input:-moz-placeholder {
//         color: #ffffff;
//         font-size: 15px;
//       }

//       input::-moz-placeholder {
//         color: #ffffff;
//         font-size: 15px;
//       }

//       input:-ms-input-placeholder {
//         color: #ffffff;
//         font-size: 15px;
//       }
//       .van-field__control {
//         color: #ffffff;
//         font-size: 15px;
//         line-height: 34px;
//       }
//       .van-field__body {
//         border-bottom: 1px solid #108feb;
//       }
//     }
//   }
// }

[class*="van-hairline"]::after {
  border: none;
}
.van-cell:not(:last-child)::after {
  border: none;
}
.mc-cir {
  border-radius: 62/16rem;
  margin: auto;
  width: 124/16rem;
  height: 124/16rem;
  background-color: rgba(255, 255, 255, 0.6);
}
.login_text {
  color: #ffffff;
  font-size: 12/16rem;
  line-height: 25/16rem;
}
.van-divider {
  margin: 2/16rem 0;
}
.logo_2 {
  width: 110/16rem;
  height: 75/16rem;
  margin-top: 22/16rem;
}
.userId-margin {
  margin-top: 30/16rem;
}
.loginOn-width {
  width: 100%;
  height: 283/16rem;
}
.loginOn-margin {
  margin-top: 20/16rem;
}
.divider-style {
  color: #ffffff;
  border-color: #ffffff;
  padding: 0 55/16rem;
}
.base_login_margin {
  margin-bottom: 25/16rem;
}
</style>

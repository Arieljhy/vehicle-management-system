<template>
  <div>
    <van-nav-bar title="重置密码" left-text="返回" left-arrow @click-left="onClickLeft" class="mc-navbar" />
    <!-- <div>忘记密码</div> -->
    <van-field clearable class="iconfont icon-face" v-model="mobile" placeholder="请输入手机号" />
    <van-field
      center
      clearable
      class="iconfont icon-yaoshi"
      v-model="loginCode"
      placeholder="请输入短信验证码"
    >
      <van-button v-show="show" slot="button" size="small" type="primary" @click="sendVerificationCode">发送验证码</van-button>
      <van-button v-show="!show" disabled class="count" slot="button" size="small" type="primary">重新发送（{{count}}）</van-button>
    </van-field>
    <van-field clearable v-model="password" type="password" placeholder="输入新密码" />
    <van-field clearable v-model="againPwd" type="password" placeholder="再次输入新密码" />
    <div class="back-button">
      <van-button type="info" size="large" @click="conservePassWord">保存</van-button>
    </div>
  </div>
</template>
<script>

import http from "@/common/request";
import md5 from "js-md5";

export default {
  name: "forgetPassWord",

  data() {
    return {
      mobile: "",
      loginCode: "",
      show:true,
      count:'',
      timer:null,
      password: "",
      againPwd: ""
    };
  },
  created() {
  },
  methods: {
    // 发送验证码
    sendVerificationCode() {
      // 是否输入手机号
      if (this.mobile == "") {
        this.$toast("请输入手机号");
        return;
      }
      if (this.mobile.length !== 11) {
        this.$toast("请输入正确的手机号");
        return;
      }
      var reg = /^[0-9]+.?[0-9]*$/;
      if (!reg.test(this.mobile)) {
        this.$toast("请输入正确的手机号");
        return;
      }
     const TIME_COUNT = 60;
     if (!this.timer) {
        this.count = TIME_COUNT;
        this.show = false;
        this.timer = setInterval(() => {
          if (this.count > 0 && this.count <= TIME_COUNT) {
           this.count--;
          } else {
           this.show = true;
           clearInterval(this.timer);
           this.timer = null;
          }
        }, 1000)
      }
      const keywords = {
        // loginCode: this.loginCode,
        mobile: this.mobile
      };
      http.post("/getLoginCode", keywords).then(res => {
        if (res.code === 0) {
          this.$toast(res.msg);
        } else {
          this.$toast(res.msg);
        }
      });
    },
    // 修改密码
    conservePassWord() {
      if(this.password=="" && this.againPwd=="") {
          this.$toast("请输入密码");
          return
        }
      var regex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}');
      if (!regex.test(this.password)) {
        this.$toast("密码至少8位且必须包含字母、数字，请及时修改!");
        return
      }   
      if (this.password != this.againPwd) {
        this.$toast("两次密码输入不一致！");
        return;
      }
      const keywords = {
        loginCode: this.loginCode,
        mobile: this.mobile,
        password: md5(this.password)
      };
      http.post("/findPwd", keywords).then(res => {
        if (res.code === 0) {
          this.$toast(res.msg);
          
          if(this.$route.query.flag){
            this.$router.push("/personalSettings");
          }else{
            this.$router.go(-1);
          }
          
        } else {
          this.$toast(res.msg);
        }
      });
    },
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.count{
  background: #bdbdbd;
  border: #bdbdbd;
}
.back-button {
  position: fixed;
  bottom: 0;
  width: 100%;
}
</style>
<template>
  <!-- 马鞍山 -->
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >安徽省马鞍山市IDI信息平台隐私政策</div>
    </van-nav-bar>
    <div class="padding-all text-left font14">
      <div class="title_div">安徽省马鞍山市IDI信息平台隐私政策</div>
      <div
        class="padding-top word-indent"
      >【特别提示】安徽省马鞍山市建设工程质量潜在缺陷保险信息系统（安徽省马鞍山市IDI信息平台），是中再集团受安徽省马鞍山市住房保障和城乡建设管理局委托代为建设的政府工作平台。本平台由中国再保险（集团）股份有限公司及其关联公司建设运营（以下中国再保险集团股份有限公司及其关联公司合称“我们”），在使用安徽省马鞍山市IDI信息平台产品与/或服务前，请仔细阅读《安徽省马鞍山市IDI信息平台隐私政策》（下称“本政策/本隐私政策”），以粗体/粗体下划线标识的条款，您应重点阅读。在确认充分理解并同意本政策后再使用安徽省马鞍山市IDI信息平台产品与/或服务。阅读本政策的过程中，如果您不同意其中任何条款，您应立即停止使用安徽省马鞍山市IDI信息平台。如对本政策内容有任何疑问、意见或建议，您可通过安徽省马鞍山市IDI信息平台提供的各种联系方式与我们联系。</div>
      <div class="padding-top bold word-indent">引言</div>
      <div
        class="padding-top word-indent"
      >我们非常重视用户的隐私和个人信息保护。您在使用我们的产品与/或服务时，我们可能会收集和使用您的相关信息。我们希望通过《安徽省马鞍山市IDI信息平台隐私政策》（“本隐私政策”）向您说明我们在您使用我们的产品与/或服务时如何收集、使用、保存、共享和转让这些信息，以及我们为您提供的访问、更新、删除和保护这些信息的方式。</div>
      <div class="padding-top word-indent">本政策将帮助您了解以下内容：</div>
      <div class="padding-top word-indent">一、我们如何收集和使用您的信息</div>
      <div class="padding-top word-indent">二、我们如何使用 Cookie 和同类技术</div>
      <div class="padding-top word-indent">三、我们如何共享、转让、公开披露您的个人信息</div>
      <div class="padding-top word-indent">四、我们如何保护和保存您的个人信息</div>
      <div class="padding-top word-indent">五、您如何管理您的信息</div>
      <div class="padding-top word-indent">六、未成年人信息的保护</div>
      <div class="padding-top word-indent">七、您的信息如何在全球范围转移</div>
      <div class="padding-top word-indent">八、通知和修订</div>
      <div class="padding-top word-indent">九、如何联系我们</div>
      <div
        class="padding-top word-indent bold unline"
      >本隐私政策与您所使用的安徽省马鞍山市IDI信息平台产品与/或服务及该产品与/或服务所包括的各种业务功能（以下统称“我们的产品与/或服务”）息息相关，本隐私政策中涉及的相关术语，我们尽量简明扼要地表述，并提供进一步说明的链接，以便您更好地理解。您使用我们的产品与/或服务或在我们更新本隐私政策后（我们会及时提示您更新的情况）继续使用我们的产品与/或服务，即意味着您同意本隐私政策(含更新版本)内容，并且同意我们按照本隐私政策收集、使用、保存和共享您的相关信息。</div>
      <div
        class="padding-top word-indent"
      >如对本隐私政策或相关事宜有任何问题，您可随时通过访问在线客服系统、发送邮件至【idisupportgroup@chinare.com.cn】或拨打安徽省马鞍山市IDI信息平台客服电话等多种方式与我们联系。</div>
      <div class="padding-top word-indent bold">一、我们如何收集和使用您的信息</div>
      <div
        class="padding-top word-indent"
      >个人信息是指以电子或者其他方式记录的能够单独或者与其他信息结合识别特定自然人身份或者反映特定自然人活动情况的各种信息。</div>
      <div class="padding-top word-indent">我们仅会出于本政策所述的以下目的，收集和使用您的个人信息：</div>
      <div class="padding-top word-indent bold">（一）为实现向您提供我们产品与/或服务的基本功能，您须授权我们收集和使用的必要的信息。</div>
      <div
        class="padding-top word-indent bold"
      >我们的产品与/或服务包括安徽省马鞍山市IDI保险业务开展所必须的功能以及改进我们的产品与/或服务所必须的功能。我们会收集、保存和使用下列与您有关的信息才能实现上述基本功能。如果您拒绝提供相关信息，您将无法享受我们提供的产品与/或服务。这些功能包括：</div>
      <div class="padding-top word-indent bold">1、用户注册</div>
      <div class="padding-top word-indent">
        您首先需要注册一个安徽省马鞍山市IDI信息平台账户成为安徽省马鞍山市IDI信息平台用户。
        <em
          class="unline bold font-nolmal"
        >当您注册时，您需要至少向我们提供您本人的手机号码、身份证号以及邮箱信息，我们将通过发送短信验证码的方式来加强验证您的身份是否正确，通过身份证号验证您的身份真实有效，通过邮箱向您发送工作待办、业务提醒等信息。</em>您的账户名为您的默认昵称，您可以修改补充您的头像、昵称、个人基本信息（包括真实姓名、性别、生日、专业），这些信息均属于您的“账户信息”。您补充的账户信息将有助于我们为您提供更加便捷的使用体验，但如果您不提供这些补充信息，不会影响您开展安徽省马鞍山市IDI保险业务的基本功能。
      </div>
      <div class="padding-top word-indent bold">2、风险管理功能</div>
      <div
        class="padding-top word-indent"
      >IDI信息平台提供工程项目现场风险管理功能，您可以使用客户端在施工现场上报风险事件信息和风险事件的整改信息，实现实时上报。在您使用上述功能中，会调用您的拍照功能和客户端图片浏览功能，用于上传现场图片。</div>
      <div class="padding-top word-indent bold">3、项目关注功能</div>
      <div
        class="padding-top word-indent"
      >在您使用我们客户端的过程中，您可以选择对感兴趣的项目进行关注（业主需要输入项目对应的保单号进行关注），方便用户查看项目信息、项目风险信息以及项目理赔信息（业主可在线报案）。在您使用上述功能的过程中，我们会收集您的关注记录信息用于实现上述功能及其他我们明确告知的目的。</div>
      <div class="padding-top word-indent bold">4、在线报案</div>
      <div class="padding-top word-indent">
        业主可通过安徽省马鞍山市IDI信息平台移动端在线报案。当住宅发生损坏，业主可通过安徽省马鞍山市IDI信息平台向保险公司报案，
        <em
          class="unline bold font-nolmal"
        >您需要在报案信息中至少填写报案地址以及报案原因，我们收集这些信息是为了确认案发地址并方便保险公司进行立案勘察，进而定损理赔及其他我们明确告知的目的。</em>
      </div>
      <div class="padding-top word-indent">5、在线评论</div>
      <div
        class="padding-top word-indent"
      >相关用户可通过安徽省马鞍山市IDI信息平台移动端对项目下的风险事件发表在线评论（除业主用户外），保险公司、业主等用户可在小区信息下发表评论。我们收集这些信息是一者为了保证更加方便地开展项目风险管理工作，另外是为了通过社区评论的方式实现广泛监督，帮助保险公司更好服务小区业主。</div>
      <div class="padding-top word-indent">6、理赔查询</div>
      <div
        class="padding-top word-indent"
      >相关用户可通过安徽省马鞍山市IDI信息平台移动端查询权限范围内小区的理赔情况，获取案件理赔进度，理赔金额等，已实现广泛监督，保障业主权利。</div>
      <div class="padding-top word-indent bold">（二）您可选择是否授权我们收集和使用您的个人信息的情形</div>
      <div class="padding-top word-indent">
        1、为向您提供更便捷、更优质、个性化的产品及/或服务，提升您的使用体验，我们在向您提供的以下附加服务中可能会收集和使用您的个人信息。
        <em
          class="bold font-nolmal"
        >如果您不提供这些信息，不会影响您使用安徽省马鞍山市IDI信息平台的基本服务，但您可能无法获得这些附加服务给您带来的用户体验。</em>
      </div>
      <div class="padding-top word-indent bold">这些附加服务包括：</div>
      <div class="padding-top word-indent">
        <em class="bold font-nolmal">（1）基于摄像头（相机）的附加功能：</em>您可以使用这个附加功能完成现场拍照、刷脸登陆的功能。
      </div>
      <div class="padding-top word-indent">
        <em class="bold font-nolmal">（3）基于图片上传的附加功能：</em>您可在开启相册权限后使用该功能上传您的照片/图片，以实现更换头像、与上报风险事件、在线报案等功能。
      </div>
      <div class="padding-top word-indent">
        <em class="bold font-nolmal">（4）基于语音技术的附加功能：</em>您可在开启麦克风权限后使用语音搜索功能，方便项目搜索。
      </div>
      <div class="padding-top word-indent">
        2、上述附加功能可能需要您在您的设备中向我们开启您的相机（摄像头）、相册（图片库）以及麦克风（语音）的访问权限，以实现这些功能所涉及的信息的收集和使用。
        <em
          class="bold unline font-nolmal"
        >请您注意，您开启这些权限即代表您授权我们可以收集和使用这些个人信息来实现上述的功能，您关闭权限即代表您取消了这些授权，则我们将不再继续收集和使用您的这些个人信息，也无法为您提供上述与这些授权所对应的功能。您关闭权限的决定不会影响此前基于您的授权所进行的信息收集及使用。</em>
      </div>
      <div class="padding-top word-indent bold">（三）其他</div>
      <div
        class="padding-top word-indent bold"
      >1、若你提供的信息中含有其他用户的个人信息，在向安徽省马鞍山市IDI信息平台提供这些个人信息之前，您需确保您已经取得合法的授权。</div>
      <div
        class="padding-top word-indent bold"
      >2、若我们将信息用于本政策未载明的其他用途，或者将基于特定目的收集而来的信息用于其他目的，或者我们主动从第三方处获取您的个人信息，均会事先获得您的同意。若我们从第三方处间接获取您的信息的，我们会在收集前明确以书面形式要求该第三方在已依法取得您同意后收集个人信息，并向您告知共享的信息内容，且涉及敏感信息的在提供给我们使用前需经过您的明确确认，要求第三方对个人信息来源的合法性和合规性作出承诺，如第三方有违反行为的，我们会明确要求对方承担相应法律责任；同时，我们的专业安全团队对个人信息会进行安全加固（包括敏感信息报备、敏感信息加密存储、访问权限控制等）。我们会使用不低于我们对自身用户个人信息同等的保护手段与措施对间接获取的个人信息进行保护。</div>
      <div class="padding-top word-indent bold">3、您充分知晓，以下情形中，我们收集、使用个人信息无需征得您的授权同意：</div>
      <div class="padding-top word-indent bold unline">（1）与国家安全、国防安全有关的；</div>
      <div class="padding-top word-indent bold unline">（2）与公共安全、公共卫生、重大公共利益有关的；</div>
      <div class="padding-top word-indent bold unline">（3）与犯罪侦查、起诉、审判和判决执行等有关的；</div>
      <div class="padding-top word-indent bold unline">（4）出于维护个人信息主体或其他个人的生命、财产等重大合法权益但又很难得到本人同意的；</div>
      <div class="padding-top word-indent bold unline">（5）所收集的个人信息是个人信息主体自行向社会公众公开的；</div>
      <div class="padding-top word-indent bold unline">（6）从合法公开披露的信息中收集的您的个人信息的，如合法的新闻报道、政府信息公开等渠道；</div>
      <div class="padding-top word-indent bold unline">（7）根据您的要求签订和履行合同所必需的；</div>
      <div
        class="padding-top word-indent bold unline"
      >（8）用于维护所提供的产品与/或服务的安全稳定运行所必需的，例如发现、处置产品与/或服务的故障；</div>
      <div
        class="padding-top word-indent bold unline"
      >（9）学术研究机构基于公共利益开展统计或学术研究所必要，且对外提供学术研究或描述的结果时，对结果中所包含的个人信息进行去标识化处理的；</div>
      <div class="padding-top word-indent bold unline">（10）法律法规或监管规定规定的其他情形。</div>
      <div class="padding-top word-indent">
        请知悉，根据适用的法律法规或监管规定，若我们
        <em
          class="bold unline font-nolmal"
        >对个人信息采取技术措施和其他必要措施进行处理，使得数据接收方无法重新识别特定个人且不能复原，</em>或我们可能会对收集的信息进行去标识化地研究、统计分析和预测，用于改善安徽省马鞍山市IDI信息平台的内容和布局，为商业决策提供产品或服务支撑，以及改进我们的产品和服务（包括使用匿名数据进行机器学习或模型算法训练），
        <em
          class="bold unline font-nolmal"
        >则此类处理后数的使用无需另行向您通知并征得您的同意。</em>此外，我们仅会在您同意的目的和范围内对数据进行去标识化。
      </div>
      <div
        class="padding-top word-indent"
      >4、如我们停止运营安徽省马鞍山市IDI信息平台产品或服务，我们将及时停止继续收集您个人信息的活动，将停止运营的通知以逐一送达或公告的形式通知您，并对我们所持有的与已关停业务相关的个人信息进行删除或匿名化处理。</div>
      <div class="padding-top word-indent bold">二、我们如何使用 Cookie 和同类技术</div>
      <div class="padding-top word-indent bold">（一）Cookie 的使用</div>
      <div
        class="padding-top word-indent"
      >为确保网站正常运转、为您获得更轻松的访问体验，我们会在您的计算机或移动设备上存储 Cookie、Flash Cookie，或浏览器（或关联应用程序）提供的其他通常包含标识符、站点名称以及一些号码和字符的本地存储（统称“Cookie”）。</div>
      <div class="padding-top word-indent">
        <em class="bold unline font-nolmal">如果您的浏览器或浏览器附加服务允许，您可修改对 Cookie 的接受程度或拒绝我们的Cookie。</em>有关详情，请参见 AboutCookies.org。但如果您这么做，在某些情况下可能会影响您安全访问我们的网站，且可能需要在每一次访问我们的网站时更改用户设置。
      </div>
      <div class="padding-top word-indent bold">三、我们如何共享、转让、公开披露您的个人信息</div>
      <div class="padding-top word-indent bold">（一）共享</div>
      <div class="padding-top word-indent bold">1、我们不会与安徽省马鞍山市IDI信息平台以外的任何公司、组织和个人共享您的个人信息，但以下情况除外：</div>
      <div class="padding-top word-indent">（1）与国家安全、国防安全直接相关的；</div>
      <div class="padding-top word-indent"></div>
      <div class="padding-top word-indent">（2）与公共安全、公共卫生、重大公共利益直接相关的；</div>
      <div class="padding-top word-indent">（3）与犯罪侦查、起诉、审判和判决执行等直接相关的；</div>
      <div class="padding-top word-indent">（4）出于维护个人信息主体或其他个人的生命、财产等重大合法权益但又很难得到本人同意的；</div>
      <div class="padding-top word-indent">（5）个人信息主体自行向社会公众公开的个人信息；</div>
      <div class="padding-top word-indent">（6）从合法公开披露的信息中收集个人信息的，如合法的新闻报道、政府信息公开等渠道。</div>
      <div
        class="padding-top word-indent bold"
      >2、我们可能会将您的个人信息与我们的关联方共享。但我们只会共享必要的个人信息，且受本隐私政策中所声明目的的约束。我们的关联方如要改变个人信息的处理目的，将再次征求您的授权同意。</div>
      <div class="padding-top word-indent">
        <em
          class="bold font-nolmal"
        >3、我们可能会向合作伙伴等第三方共享您的项目信息、账户信息、风险管理信息以及保险信息，以保障为您提供的服务顺利完成。但我们仅会出于合法、正当、必要、特定、明确的目的共享您的个人信息，并且只会共享提供服务所必要的个人信息。我们的合作伙伴无权将共享的个人信息用于任何其他用途。</em>我们的合作伙伴主要是技术服务的供应商。
        <em class="bold unline font-nolmal">我们可能会将您的个人信息共享给支持我们功能的第三方。</em>这些支持包括为我们提供基础设施技术服务、人脸认证服务、语音识别或身份验证等。我们共享这些信息的目的是可以实现我们产品与/或服务的核心功能。中再集团出于合法、正当、必要、特定、明确的目的可共享您的个人信息，并且只会共享提供服务所必要的个人信息。
      </div>
      <div class="padding-top word-indent bold">（二）转让</div>
      <div class="padding-top word-indent">我们不会将您的个人信息转让给任何公司、组织和个人，但以下情况除外：</div>
      <div class="padding-top word-indent">1、事先获得您明确的同意或授权；</div>
      <div class="padding-top word-indent">2、根据适用的法律法规或监管规定、法律程序的要求、强制性的行政或司法要求所必须的情况进行提供；</div>
      <div class="padding-top word-indent">3、符合与您签署的相关协议（包括在线签署的电子协议以及相应的平台规则）或其他的法律文件约定所提供；</div>
      <div
        class="padding-top word-indent bold unline"
      >4、在涉及合并、收购、资产转让或类似的交易时，如涉及到个人信息转让，我们会告知您合并、收购、资产转让或类似的交易相关情况，并要求新的持有您个人信息的公司、组织继续受本隐私政策的约束。否则,我们将要求该公司、组织重新向您征求授权同意。</div>
      <div class="padding-top word-indent bold">（三）公开披露</div>
      <div class="padding-top word-indent">我们仅会在以下情况下，且采取符合业界标准的安全防护措施的前提下，才会公开披露您的个人信息：</div>
      <div class="padding-top word-indent">1、在您明确同意的披露方式下披露您所指定的个人信息；</div>
      <div
        class="padding-top word-indent"
      >2、根据法律法规或监管规定的要求、强制性的行政执法或司法要求所必须提供您个人信息的情况下，我们可能会依据所要求的个人信息类型和披露方式公开披露您的个人信息。在符合法律法规的前提下，当我们收到上述披露信息的请求时，我们会要求必须出具与之相应的法律文件，如传票或调查函。我们坚信，对于要求我们提供的信息，应该在法律允许的范围内尽可能保持透明。我们对所有的请求都进行了慎重的审查，以确保其具备合法依据，且仅限于执法部门因特定调查目的且有合法权利获取的数据。在法律法规或监管规定许可的前提下，我们披露的文件均在加密密钥的保护之下。</div>
      <div class="padding-top word-indent bold">四、我们如何保护和保存您的个人信息</div>
      <div
        class="padding-top word-indent"
      >（一）我们已采取符合业界标准、合理可行的安全防护措施保护您的信息，防止个人信息遭到未经授权访问、公开披露、使用、修改、损坏或丢失。</div>
      <div
        class="padding-top word-indent"
      >（二）我们有行业先进的以数据为核心、围绕数据生命周期进行的数据安全管理体系，从组织建设、制度设计、人员管理、产品技术等方面多维度提升整个系统的安全性。</div>
      <div class="padding-top word-indent">
        （三）我们会采取合理可行的措施，尽力避免收集无关的个人信息。
        <em
          class="bold unline font-nolmal"
        >我们只会在达成本政策所述目的所需的期限内保留您的个人信息，除非法律法规或监管规定有强制的存留要求。而我们判断前述期限的标准包括：</em>
      </div>
      <div class="padding-top word-indent bold">1、完成与您相关的交易目的、维护相应交易及业务记录、应对您可能的查询或投诉；</div>
      <div class="padding-top word-indent bold">2、保证我们为您提供服务的安全和质量；</div>
      <div class="padding-top word-indent bold">3、您是否同意更长的留存期间；</div>
      <div class="padding-top word-indent bold">4、是否存在保留期限的其他特别约定。</div>
      <div
        class="padding-top word-indent bold unline"
      >在您的个人信息超出保留期间后，我们会根据适用法律法规或监管规定的要求删除您的个人信息，或使其匿名化处理。</div>
      <div class="padding-top word-indent">
        （四）互联网并非绝对安全的环境，使用安徽省马鞍山市IDI信息平台时，
        <em
          class="bold unline font-nolmal"
        >我们强烈建议您不要使用非安徽省马鞍山市IDI信息平台推荐的通信方式发送您的信息。</em>您可以通过我们的服务建立联系和相互分享。当您通过我们的服务创建交流、交易或分享时，您可以自主选择沟通、交易或分享的对象，作为能够看到您的交易内容、联络方式、交流信息或分享内容等相关信息的第三方。
      </div>
      <div
        class="padding-top word-indent"
      >请注意，您在使用我们服务时自愿共享甚至公开分享的信息，可能会涉及您或他人的个人信息甚至个人敏感信息。请您更加谨慎地考虑，是否在使用我们的服务时共享甚至公开分享相关信息。</div>
      <div
        class="padding-top word-indent"
      >请使用复杂密码，协助我们保证您的账号安全。我们将尽力保障您发送给我们的任何信息的安全性。如果我们的物理、技术或管理防护设施遭到破坏，导致信息被非授权访问、公开披露、篡改或毁坏，导致您的合法权益受损，我们将承担相应的法律责任。</div>
      <div
        class="padding-top word-indent"
      >（五）在不幸发生个人信息安全事件后，我们将按照法律法规的要求向您告知：安全事件的基本情况和可能的影响、我们已采取或将要采取的处置措施、您可自主防范和降低风险的建议、对您的补救措施等。事件相关情况我们将以邮件、信函、电话、推送通知等方式告知您，难以逐一告知个人信息主体时，我们会采取合理、有效的方式发布公告。</div>
      <div class="padding-top word-indent">同时，我们还将按照监管部门要求，上报个人信息安全事件的处置情况。</div>
      <div class="padding-top word-indent bold">五、您如何管理您的个人信息</div>
      <div
        class="padding-top word-indent"
      >安徽省马鞍山市IDI信息平台非常重视您对个人信息的关注，并尽全力保护您对于您个人信息访问、更正、删除以及撤回同意的权利，以使您拥有充分的能力保障您的隐私和安全。您的权利包括：</div>
      <div class="padding-top word-indent bold">（一）访问和管理您的个人信息</div>
      <div class="padding-top word-indent">您可以通过以下方式访问及管理您的信息：</div>
      <div
        class="padding-top word-indent"
      >1、您可以登录安徽省马鞍山市IDI信息平台客户端，点击左上角进入“我的”对账户信息、登录密码、手势密码、刷脸登录等进行查询、更正或补充。</div>
      <div class="padding-top word-indent">2、您可以联系向您分发账号的管理员，修改您的账号信息或重置密码。</div>
      <div class="padding-top word-indent bold">（二）删除您的信息</div>
      <div class="padding-top word-indent bold">在以下情形中，您可以向我们提出删除个人信息的请求：</div>
      <div class="padding-top word-indent">1、如果我们处理个人信息的行为违反法律法规；</div>
      <div class="padding-top word-indent">2、如果我们收集、使用您的个人信息，却未征得您的同意；</div>
      <div class="padding-top word-indent">3、如果我们处理个人信息的行为违反了与您的约定；</div>
      <div class="padding-top word-indent">4、如果我们终止服务及运营。</div>
      <div
        class="padding-top word-indent"
      >若我们决定响应您的删除请求，我们还将同时尽可能通知从我们处获得您的个人信息的主体，并要求其及时删除（除非法律法规或监管规定另有规定，或这些主体已独立获得您的授权）。</div>
      <div
        class="padding-top word-indent bold unline"
      >当您或我们协助您删除相关信息后，因为适用的法律法规或监管规定、安全技术，我们可能无法立即从备份系统中删除相应的信息，我们将安全地存储您的个人信息并将其与任何进一步处理隔离，直到备份可以清除或实现匿名。</div>
      <div class="padding-top word-indent bold">（三）改变您授权同意的范围或撤回您的授权</div>
      <div
        class="padding-top word-indent bold unline"
      >您可以通过删除信息、关闭设备功能、在客户端进行隐私设置等方式改变您授权我们继续收集个人信息的范围或撤回您的授权。您也可以通过注销账户的方式，撤回我们继续收集您个人信息的全部授权。</div>
      <div
        class="padding-top word-indent bold unline"
      >请您理解，每个业务功能需要一些基本的个人信息才能得以完成，当您撤回同意或授权后，我们无法继续为您提供撤回同意或授权所对应的服务，也不再处理您相应的个人信息。但您撤回同意或授权的决定，不会影响此前基于您的授权而开展的个人信息处理。</div>
      <div class="padding-top word-indent bold">（四）注销账户</div>
      <div
        class="padding-top word-indent bold unline"
      >您可以登录安徽省马鞍山市IDI信息平台客户端，点击左上角进入“我的”，在安全管理选项下注销您安徽省马鞍山市IDI信息平台的账号。</div>
      <div class="padding-top word-indent bold">（五）响应您的请求</div>
      <div
        class="padding-top word-indent"
      >如果您无法通过上述方式访问、更正或删除您的个人信息，或您需要访问、更正或删除您在使用我们产品与/或服务时所产生的其他个人信息，或您认为安徽省马鞍山市IDI信息平台存在任何违反法律法规或与您关于个人信息的收集或使用的约定，您均可以发送电子邮件至【idisupportgroup@chinare.com.cn】或通过本协议下方的其他方式与我们联系。为了保障安全，我们可能需要您提供书面请求，或以其他方式证明您的身份，我们将在收到您反馈并验证您的身份后的 15个工作日内答复您的请求。对于您合理的请求，我们原则上不收取费用，但对多次重复、超出合理限度的请求，我们将视情收取一定成本费用。对于那些无端重复、需要过多技术手段（例如，需要开发新系统或从根本上改变现行惯例）、给他人合法权益带来风险或者非常不切实际（例如，涉及备份磁带上存放的信息）的请求，我们可能会予以拒绝。</div>
      <div class="padding-top word-indent">在以下情形中，按照法律法规或监管规定要求，我们将无法响应您的请求：</div>
      <div class="padding-top word-indent">1、与国家安全、国防安全有关的；</div>
      <div class="padding-top word-indent">2、与公共安全、公共卫生、重大公共利益有关的；</div>
      <div class="padding-top word-indent">3、与犯罪侦查、起诉和审判等有关的；</div>
      <div class="padding-top word-indent">4、有充分证据表明您存在主观恶意或滥用权利的；</div>
      <div class="padding-top word-indent">5、响应您的请求将导致您或其他个人、组织的合法权益受到严重损害的。</div>
      <div class="padding-top word-indent bold">六、我们如何处理未成年人的信息</div>
      <div
        class="padding-top word-indent bold"
      >在IDI业务开展中我们推定您具有相应的民事行为能力。如您为未成年人，我们要求您请您的父母或监护人仔细阅读本隐私权政策，并在征得您的父母或监护人同意的前提下使用我们的服务或向我们提供信息。</div>
      <div
        class="padding-top word-indent"
      >对于经父母或监护人同意使用我们的产品或服务而收集未成年人个人信息的情况，我们只会在法律法规允许、父母或监护人明确同意或者保护未成年人所必要的情况下使用、共享、转让或披露此信息。</div>
      <div class="padding-top word-indent bold">七、您的信息如何在全球范围转移</div>
      <div class="padding-top word-indent">我们在中华人民共和国境内运营中收集和产生的个人信息，存储在中国境内，以下情形除外：</div>
      <div class="padding-top word-indent">1、适用的法律法规或监管规定有明确规定；</div>
      <div class="padding-top word-indent">2、获得您的明确授权；</div>
      <div class="padding-top word-indent">3、您通过互联网进行跨境交易等个人主动行为。</div>
      <div class="padding-top word-indent">针对以上情形，我们会确保依据本隐私权政策对您的个人信息提供足够的保护。</div>
      <div class="padding-top word-indent bold">八、通知和修订</div>
      <div
        class="padding-top word-indent"
      >1、为给您提供更好的服务以及随着IDI业务的发展，本隐私政策也会随之更新。但未经您明确同意，我们不会削减您依据本隐私政策所应享有的权利。我们会通过在安徽省马鞍山市IDI信息平台客户端发出更新版本并在生效前通过适当方式提醒您相关内容的更新。</div>
      <div
        class="padding-top word-indent"
      >2、对于重大变更，我们还会提供更为显著的通知（我们会通过包括但不限于邮件、短信或弹窗等做特别提示，说明隐私政策的具体变更内容）。</div>
      <div class="padding-top word-indent">本政策所指的重大变更包括但不限于：</div>
      <div class="padding-top word-indent">（1）我们的服务模式发生重大变化。如处理个人信息的目的、处理的个人信息类型、个人信息的使用方式等；</div>
      <div class="padding-top word-indent">（2）我们在所有权结构、组织架构等方面发生重大变化。如业务调整、破产并购等引起的所有者变更等；</div>
      <div class="padding-top word-indent">（3）个人信息共享、转让或公开披露的主要对象发生变化；</div>
      <div class="padding-top word-indent">（4）您参与个人信息处理方面的权利及其行使方式发生重大变化；</div>
      <div class="padding-top word-indent">（5）我们负责处理个人信息安全的责任部门、联络方式及投诉渠道发生变化时；</div>
      <div class="padding-top word-indent">（6）个人信息安全影响评估报告表明存在高风险时。</div>
      <div class="padding-top word-indent">3、我们还会将本策略的旧版本存档，供您查阅。</div>
      <div class="padding-top word-indent bold">九、如何联系我们</div>
      <div
        class="padding-top word-indent"
      >（一）如您对本隐私政策或您个人信息的相关事宜有任何问题、意见或建议，请通过访问在线客服系统、发送邮件【idisupportgroup@chinare.com.cn】或拨打我们的任何一部客服电话等多种方式与我们联系。</div>
      <div
        class="padding-top word-indent"
      >（二）一般情况下，我们将在15个工作日内回复。如果您对我们的回复不满意，特别是我们的个人信息处理行为损害了您的合法权益，您还可以向网信、电信、公安及工商等监管部门进行投诉或举报。</div>
    </div>
    <!-- 返回顶部 -->
    <div>
      <van-row id="top" class="top" style="display:none" @click="top">
        <span>top</span>
      </van-row>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  mounted() {
    // this.Echarts() //echarts接口调用
    //监听滚动事件
    window.addEventListener("scroll", this.onscroll);
  },
  methods: {
    onClickLeft() {
      if (this.$route.query.flag == 1) {
        this.$router.replace({
          path: "/aboutApp",
          query: {
            title: 0
          }
        });
      }else{
        this.$router.push({
          path: "/login",
          query: {
            title: 0
          }
        });
      }
    },
    // 返回顶部
    top() {
      window.scrollTo(0, 0);
    },
    // 返回顶部
    onscroll() {
      // debugger
      if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
        document.getElementById("top").style.display = "block";
      } else {
        document.getElementById("top").style.display = "none";
      }
    }
  }
};
</script>
<style lang="less" scoped>
.text-left {
  text-align: left;
}
.font14 {
  font-size: 14/16rem;
}
.padding-all {
  padding: 15/16rem;
}
.padding-top {
  padding-top: 15/16rem;
}
.bold {
  font-weight: bold;
}
.word-indent {
  text-indent: 20/16rem;
}
.unline {
  text-decoration: underline;
}
.font-nolmal {
  font-style: normal;
}
.title_div {
  text-align: center;
  font-size: 17/16rem;
  font-weight: bold;
}
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  border: 1/16rem solid #ccc;
  color: #fff;
  border-radius: 25/16rem;
  background: #ccc;
  right: 25/16rem;
  bottom: 40/16rem;
}
.top:hover {
  cursor: pointer;
}
.top /deep/ span {
  line-height: 30/16rem;
}
</style>

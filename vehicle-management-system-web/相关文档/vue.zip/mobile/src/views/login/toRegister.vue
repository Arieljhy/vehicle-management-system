<template>
  <div>
    <van-nav-bar title="注册" left-text="返回" left-arrow @click-left="onClickLeft" class="mc-navbar" />
    <div class="register-padding">
      <div class="mc-register">
        <div class="ertivcalLine"></div>
      </div>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="账号："
            v-model="registerDO.mobile"
            placeholder="输入手机号"
            required
            @change="isSendChange"
            label-class="name"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            center
            clearable
            required
            label="验证码："
            v-model="registerDO.loginCode"
            placeholder="输入验证码"
            @change="isSendChange"
          >
            <van-button
              v-show="show"
              slot="button"
              size="small"
              type="primary"
              @click="sendVerificationCode"
            >获取验证码</van-button>
            <van-button
              v-show="!show"
              class="count"
              slot="button"
              size="small"
              type="primary"
            >重新发送（{{count}}）</van-button>
          </van-field>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="姓名："
            v-model="registerDO.name"
            placeholder="输入真实姓名"
            :disabled="isDisable"
            required
            label-class="name"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="身份证号："
            v-model="registerDO.idCard"
            placeholder="输入身份证号"
            :disabled="isDisable"
            required
            label-class="name"
          />
        </van-cell-group>
      </van-col>

      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="邮箱："
            v-model="registerDO.email"
            placeholder="输入邮箱"
            :disabled="isDisable"
            required
            label-class="name"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="出生日期："
            readonly
            :disabled="isDisable"
            v-model="registerDO.proposedAmendDeadline"
            placeholder="年/月/日"
            @focus="rectificationTime()"
          />
        </van-cell-group>
      </van-col>
      <van-dialog
        v-model="proposedAmendDeadlineShow"
        title="选择时间"
        show-cancel-button
        @confirm="proposedAmendDeadlineConfirm"
      >
        <van-datetime-picker
          v-model="currentDate"
          type="date"
          :min-date="minDate"
          @change="getValues(currentDate)"
          :formatter="formatter"
          :show-toolbar="false"
        />
      </van-dialog>
      <van-col span="24">
        <van-cell-group>
          <van-field
            readonly
            clickable
            label="性别："
            :value="sexValue"
            placeholder="性别"
            @click="!isDisable?(showPickerCtry = true):''"
          />
          <van-popup v-model="showPickerCtry" position="bottom">
            <van-picker
              show-toolbar
              :columns="columns"
              @cancel="showPickerCtry = false"
              @confirm="onConfirmCtry"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            clearable
            required
            :disabled="isDisable"
            style="text-align: left;"
            label="输入密码："
            v-model="registerDO.password"
            type="password"
            placeholder="输入密码"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            :disabled="isDisable"
            style="text-align: left;"
            label="确认密码："
            v-model="registerDO.againPwd"
            type="password"
            placeholder="输入密码"
            required
            label-class="name"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            :disabled="isDisable"
            style="text-align: left;"
            label="所在小区："
            required
            readonly
            v-model="carmodel"
            placeholder="所在小区"
            :value="station"
            @click="!isDisable?(showPicker = true):''"
          />
          <van-popup v-model="showPicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="areaColumns"
              @change="onChange"
              @cancel="showPicker = false"
              @confirm="onConfirm"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            :disabled="isDisable"
            style="text-align: left;"
            label="小区名称："
            required
            readonly
            v-model="riskLevel"
            placeholder="小区名称"
            :value="communitySelect"
            @click="!isDisable?(riskLevelPicker = true):''"
          />
          <van-popup v-model="riskLevelPicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="communitySelect"
              @cancel="riskLevelPicker = false"
              @confirm="onConfirmCommunity"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            :disabled="isDisable"
            style="text-align: left;"
            label="保单号："
            v-model="registerDO.insContractNo"
            placeholder="输入保单号"
            required
            label-class="name"
          />
        </van-cell-group>
      </van-col>
      <van-row>
        <van-col span="7" class="name">
          <span style="margin-left: -5px;">上传真实头像：</span>
        </van-col>
        <van-col span="16">
          <van-uploader
            :disabled="isDisable"
            v-model="userDO.userImage"
            :after-read="afterRead"
            :before-delete="afterDelete"
            :max-count="1"
            style="padding-right: 65%;"
          >
            <div class="iconfont icon-xaingji pictures-porder">
              <div class="pictures-size">上传图片</div>
            </div>
            <input
              v-show="false"
              type="file"
              id="uploadImage"
              name="image"
              ref="uploadBtn"
              class="getImgUrl_file"
              @change="shangc($event)"
              accept="image/jpg, image/jpeg, image/png"
            />
          </van-uploader>
        </van-col>
      </van-row>
      <van-row>
        <van-col span="15" :offset="6" class="checkBoxResult-margin">
          <van-checkbox-group v-model="checkBoxResult">
            <van-col span="11">
              <van-checkbox
                :disabled="isDisable"
                v-model="registerDO.isUserAgreement"
                name="isChecked"
                shape="square"
                @click="isAgree"
                style="margin-right:0"
              >
                我已同意
                <!-- <span @click="userAgreement" style="color:#026AA1">【用户协议】</span> -->
              </van-checkbox>
            </van-col>
            <van-col span="13" style="text-align:left">
              <span @click="userAgreement" style="color:#026AA1">【用户协议】</span>
            </van-col>
          </van-checkbox-group>
        </van-col>
      </van-row>
      <van-row @click="submissionRisk">
        <van-col span="24" style="margin-bottom: 5%;margin-top: 2%;">
          <van-button type="info" size="large" class="btnName">注册</van-button>
        </van-col>
      </van-row>
      <van-row>
        <van-col span="24">
          <span @click="login" class="go-login">已有账号，去登录</span>
        </van-col>
      </van-row>
      <!-- 激活账号 -->
      <van-dialog
        v-model="activationDialog"
        title="提示"
        required
        show-cancel-button
        :beforeClose="onBldingsConfirm"
      >
        <span>{{activationMsg}}</span>
      </van-dialog>
      <van-dialog v-model="accountExistsDialog" title="提示" required :beforeClose="onAccountExists">
        <span>{{accountExistsMsg}}</span>
      </van-dialog>
      <!-- 遮罩层 -->
    <!-- <van-popup
      v-model="transferMission"
      closeable
      close-icon-position="top-left"
      :close-on-click-overlay="overlayFlag"
      overlay-class="dialogPar"
      :overlay-style="overlayStyle"
      style="width:100%"
    >
      <userAgreement />
    </van-popup> -->
    </div>
    <!-- <van-row id="top" class="top" style="display:none" @click="top">
      <span>top</span>
    </van-row> -->
  </div>
</template>  
<script>
import http from "@/common/request";
import md5 from "js-md5";
import userAgreement from "@/views/login/userAgreement.vue"
import { Dialog } from "vant";

export default {
  name: "toRegister",
  components:{
    userAgreement
  },
  data() { 
    return {
      dealImgWidth:300,
      // 用户协议
      transferMission:false,
      overlayFlag:false,
      overlayStyle:{},
      activationMsg: "",
      accountExistsMsg: "",
      minDate: new Date(1900, 0, 1),
      sexValue: "",
      columns: [
        { text: "男", id: 0 }, //显示值必须为text
        { text: "女", id: 1 }
      ],
      activationDialog: false,
      accountExistsDialog: false,
      areaList: {},
      showPickerCtry: false,
      showPicker: false,
      carmodel: "",
      userDO: [{ userImage: "", isImage: true }],
      // sex: "",
      // userNamed: "",
      // telephone: "",
      field: "",
      selected: [],
      station: "",
      dataList: [],
      areaColumns: [
        {
          values: [],
          className: "province",
          defaultIndex: 0
        },
        {
          values: [],
          className: "city",
          defaultIndex: 1
        },
        {
          values: [],
          className: "district",
          defaultIndex: 2
        }
      ],
      // username: [],
      // fileListImg: false,
      isChecked: false,
      checkBoxResult: [],
      show: true,
      count: "",
      timer: null,
      communitySelect: [],
      communityInfos: {},
      registerDO: {
        mobile: "",
        loginCode: "",
        password: "",
        againPwd: "",
        idCard: "",
        name: "",
        insContractNo: "",
        province: "",
        city: "",
        district: "",
        projectId: "",
        projectName: "",
        communityName: "",
        selectId: "",
        proposedAmendDeadline: "",
        email: "",
        isUserAgreement: false
      },
      riskLevel: "",
      result: [],
      resultList: [],
      currentDate: new Date(),
      proposedAmendDeadlineShow: false,
      riskLevelPicker: false, //打开选择器

      rectificationInfo: {},
      riskEventType: "",
      constructionStage: "",
      construction: "",
      inspectList: [],
      // message: "",
      // message1: "",
      // show1: false,
      // riskBldingsShow: false,
      // radio: "",
      // list: [],
      riskEventTypePicker: false,
      constructionStagePicker: false,
      // eventTypeList: [],
      // riskLevelList: [],
      // riskEventTypeList: [],
      // myTime: "",
      // selectValue: "",

      // baoan: {
      //   value: "",
      //   address: "",
      //   bldings: ""
      // },
      // bldings: [],
      //判断手机
      isPhone: false,
      isSendCode: false,
      isDisable: true
    };
  },
  computed: {},
  created() {
    http.get("/getPrjSelectInfos/"+this.$getMobileData.lesseeId).then(res => { //马鞍山
      if (res.code === 0) {
        this.dataList = res.data;
        this.initSelectData();
      } else {
        this.$toast(res.msg);
      }
    });
  },
  methods: {
    guid() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
        v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    initSelectData() {
      let _areaList = this.dataList;
      let _areaColumns = this.areaColumns;
      let _communityInfos = this.communityInfos;
      const provinces = _areaColumns[0].values;
      _areaList.map(province => {
        provinces.push(province.province);
        const citys = _areaColumns[1].values;
        province.citys.map(city => {
          citys.push(city.city);
          const districts = _areaColumns[2].values;
          city.districts.map(district => {
            districts.push(district.district);
            _communityInfos[province.province + city.city + district.district] =
              district.communityInfos;
          });
        });
      });
    },
    onConfirmCommunity(value, index) {
      this.riskLevel = value.toString();
      this.riskLevelPicker = false;
      let _registerDO = this.registerDO;
      let _communitySelect = this.communitySelect;

      this.communityInfos[
        _registerDO.province + _registerDO.city + _registerDO.district
      ].map(item => {
        if (item.communityName == value) {
          _registerDO.projectId = item.projectId;
          _registerDO.projectName = item.projectName;
          _registerDO.communityName = item.communityName;
        }
      });
    },
    onConfirm(picker, values) {
      this.carmodel = picker.toString();
      this.showPicker = false;
      this.communitySelect = [];
      this.registerDO.province = picker[0];
      this.registerDO.city = picker[1];
      this.registerDO.district = picker[2];
      this.initCommunityData();
    },
    onChange(picker, values) {
      this.riskLevel = ''
      this.communitySelect = [];
      this.registerDO.province = values[0];
      this.registerDO.city = values[1];
      this.registerDO.district = values[2];
      this.initCommunityData();
    },
    initCommunityData() {
      let _registerDO = this.registerDO;
      let _communitySelect = this.communitySelect;

      this.communityInfos[
        _registerDO.province + _registerDO.city + _registerDO.district
      ].map(item => {
        _communitySelect.push(item.communityName);
      });
    },
    onConfirmCtry(item) {
      this.sexValue = item.text;
      this.registerDO.selectId = item.id;
      this.showPickerCtry = false;
    },
    initAreaSelect() {
      let _areaList = this.dataList;

      let _areaSelect = this.defaultAddress;
      const provinces = _areaSelect[0].values;
      _areaList.map(item => {
        provinces.push(item.province);
        const citys = _areaSelect[1].values;
        item.citys.map(province => {
          citys.push(province.city);
          const districts = _areaSelect[2].values;
          province.districts.map(city => {
            districts.push(city.district);
          });
        });
      });
    },
    isSendChange() {
      if (this.registerDO.mobile && this.registerDO.loginCode) {
        const keywords = {
          loginCode: this.registerDO.loginCode,
          mobile: this.registerDO.mobile,
          appChnName: this.$getMobileData.appChnName,
          tenantId: this.$getMobileData.lesseeId//马鞍山
        };
        http.post("/checkUser", keywords).then(res => {
          if (res.code === 0) {
            this.isDisable = false;
            this.$toast(res.msg);
          } else if (res.code === 20001) {
            //需要弹框(确定调接口返回登录,取消返回登录)
            this.accountExistsMsg = res.msg;
            this.accountExistsDialog = true;
            this.onAccountExists();
          } else if (res.code === 20002) {
            //需要弹框(确定返回登录)
            this.activationMsg = res.msg;
            this.activationDialog = true;
            this.onBldingsConfirm();
          }
        });
      }
    },
    // 激活
    onBldingsConfirm(action, done) {
      if (action === "cancel") {
        this.$router.go(-1);
        done();
      } else if (action === "confirm") {
        const keywords = {
          mobile: this.registerDO.mobile,
          loginCode: this.registerDO.loginCode,
          tenantId:this.$getMobileData.lesseeId 
            // tenantId: "eidi-yangquan"
        };
        http.post("/regisitApp", keywords).then(res => {
          if (res.code === 0) {
            this.$toast(res.msg);
            this.$router.go(-1);
          } else {
            this.$toast(res.msg);
          }
        });
        done();
      }
    },
    onAccountExists(action, done) {
      if (action === "confirm") {
        this.$router.go(-1);
        done();
      }
    },
    // 弹出层显示
    showPopup() {
      this.showPicker = true;
    },
    shangc(e) {
      let files = document.getElementById("uploadImage").files[0];
      let name = document.getElementById("uploadImage").files[0].name;
      let fileSize = 0;
      let fileMaxSize = 10240; //1M
      if (files) {
        fileSize = files.size;
        if (fileSize > 10 * 1024 * 1024) {
          alert("文件大小不能大于10M！");
          file.value = "";
          return false;
        } else if (fileSize <= 0) {
          alert("文件大小不能为0M！");
          file.value = "";
          return false;
        }
      } else {
        return false;
      }

      //转码base64
      let reader = new FileReader();
      let imgFile;
      // let that = this
      reader.readAsDataURL(files);
      reader.onload = e => {
        imgFile = e.target.result;
        this.userDO.userImage = imgFile;
        http.post("/sys/user/updateUserMySelf", this.userDO).then(res => {
          if (res.code === 0) {
            localStorage.setItem(
              this.$getMobileData.userInfo,
              JSON.stringify(this.userDO)
            );
            this.$toast(res.msg);
          }
        });
      };
    },
    //   用户协议
    userAgreement() {
      this.$router.push({
        path: "/userAgreement"
      });
      // this.transferMission = true
      // this.$router.push("/userAgreement");
    },
    // 发送验证码
    sendVerificationCode() {
      // 是否输入手机号
      if (this.registerDO.mobile == "") {
        this.$toast("请输入手机号");
        return;
      }
      if (this.registerDO.mobile.length !== 11) {
        this.$toast("请输入正确的手机号");
        return;
      }
      var reg = /^[0-9]+.?[0-9]*$/;
      if (!reg.test(this.registerDO.mobile)) {
        this.$toast("请输入正确的手机号");
        return;
      }
      const TIME_COUNT = 60;
      if (!this.timer) {
        this.count = TIME_COUNT;
        this.show = false;
        this.timer = setInterval(() => {
          if (this.count > 0 && this.count <= TIME_COUNT) {
            this.count--;
          } else {
            this.show = true;
            clearInterval(this.timer);
            this.timer = null;
          }
        }, 1000);
      }
      const keywords = {
        mobile: this.registerDO.mobile
      };
      http.post("/getLoginCode", keywords).then(res => {
        if (res.code === 0) {
          this.isSendCode = true;
          this.$toast(res.msg);
        } else {
          this.$toast(res.msg);
        }
      });
    },

    //   所在小区
    // userName() {
    // },
    //图片缩略
    // img() {},
    // 删除图片
    // imgDelete() {},
    //上传
    changeHead() {
      this.$refs.uploadBtn.click();
    },
    async afterRead(param) {
      var toFile = param.file;
      if (toFile.type.startsWith("image") && toFile.size > 1024*100) {
        let _this = this;
        var base64 = await _this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth
        )
        toFile = _this.$dataURLtoFile(base64,toFile.name);
      }
      this.userDO[0].userImage = param.content;
    },
    // 删除图片
    afterDelete(file, detail) {
      return this.userDO.userImage.splice(detail.index, 1);
    },
    isAgree(a) {
      this.registerDO.isUserAgreement = !this.registerDO.isUserAgreement;
    },
    // 注册 registerDO.proposedAmendDeadline
    isAgree(a) {
      this.registerDO.isUserAgreement = !this.registerDO.isUserAgreement;
    },
    // 注册
    submissionRisk() {
      // 是否输入手机号
      if (this.registerDO.mobile == "") {
        this.$toast("请输入手机号");
        return;
      }
      if (this.registerDO.mobile.length !== 11) {
        this.$toast("请输入正确的手机号");
        return;
      }
      var reg = /^[0-9]+.?[0-9]*$/;
      if (!reg.test(this.registerDO.mobile)) {
        this.$toast("请输入正确的手机号");
        return;
      }
      // 是否输入验证码
      if (this.registerDO.loginCode == "") {
        this.$toast("请输入验证码");
        return;
      }
      // 是否输入姓名
      if (this.registerDO.name == "") {
        this.$toast("请输入姓名");
        return;
      }
      // 是否输入身份证号
      if (this.registerDO.idCard == "") {
        this.$toast("请输入身份证号");
        return;
      }
      if (this.registerDO.idCard.length !== 18) {
        this.$toast("请输入正确的身份证号");
        return;
      }
      //是否输入邮箱
      var regEmail= /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
      if (this.registerDO.email == "") {
        this.$toast("请输入邮箱");
        return
      }else if(!regEmail.test(this.registerDO.email)){
        this.$toast("邮箱格式不正确");
        return
      }
      // 是否输入密码
      var regex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}');
      if (!regex.test(this.registerDO.password)) {
        this.$toast("密码至少8位且必须包含字母、数字，请及时修改!");
        return
      } 
      if (this.registerDO.password=="" && this.registerDO.againPwd=="") {
        this.$toast("请输入密码");
        return
      }
      if (this.registerDO.password != this.registerDO.againPwd) {
        this.$toast("两次密码输入不一致！");
        return;
      }
      //所在小区
      if (
        this.registerDO.province == "" &&
        this.registerDO.city == "" &&
        this.registerDO.district == ""
      ) {
        this.$toast("请输入所在小区");
        return;
      }
      //小区
      if (this.registerDO.communityName == "") {
        this.$toast("请输入小区");
        return;
      }
      // 是否输入保单号province,city,district,communityName
      if (this.registerDO.insContractNo == "") {
        this.$toast("请输入保单号");
        return;
      }
      // 用户协议
      if (this.registerDO.isUserAgreement == false) {
        this.$toast("请选择用户协议");
        return;
      }
      const keywords = {
        userId: this.guid(),
        loginCode: this.registerDO.loginCode,
        mobile: this.registerDO.mobile,
        password: md5(this.registerDO.password),
        idCard: this.registerDO.idCard,
        name: this.registerDO.name,
        username: this.registerDO.name,
        province: this.registerDO.province,
        city: this.registerDO.city,
        district: this.registerDO.district,
        projectId: this.registerDO.projectId,
        projectName: this.registerDO.projectName,
        communityName: this.registerDO.communityName,
        status: "1",
        appChnName: this.$getMobileData.appChnName,
        tenantId: this.$getMobileData.lesseeId,
        //  appChnName: "阳泉市IDI平台",
        // tenantId: "eidi-yangquan",
        sex: this.registerDO.selectId,
        birth: this.registerDO.proposedAmendDeadline,
        userImage: this.userDO.userImage
          ? this.userDO.userImage[0].content
          : "",
        email: this.registerDO.email,
        insContractNo: this.registerDO.insContractNo
      };
      http.post("/register", keywords).then(res => {
        if (res.code === 0) {
          this.$router.go(-1);
          this.$toast(res.msg);
        } else {
          this.$toast(res.msg);
        }
      });
    },

    // 所选时间(需要修改)
    rectificationTime() {
      this.proposedAmendDeadlineShow = true;
    },
    // 所选时间(需要修改)
    proposedAmendDeadlineConfirm() {
      this.registerDO.proposedAmendDeadline = this.formatDate(this.currentDate);
    },
    //改变时间，输出选中事件
    getValues(data) {
      console.log(this.formatDate(data));
    },
    //转化时间格式
    formatDate(now) {
      var year = now.getFullYear();
      var month = now.getMonth() + 1;
      var date = now.getDate();
      return year + "-" + month + "-" + date;
    },
    //过滤面板时间
    formatter(type, value) {
      if (type === "year") {
        return `${value}年`;
      } else if (type === "month") {
        return `${value}月`;
      } else if (type === "day") {
        return `${value}日`;
      }
      return value;
    },
    // onRiskLevel(item) {
    //   this.sex = item.text;
    //   this.riskLevelPicker = false;
    // },
    // 去登录
    login() {
      this.$router.go(-1);
    },
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.name {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-top: 10/16rem;
  text-align: center;
  padding-right: 2%;
}

.frame {
  height: 40/16rem;
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.btnName {
  font-family: PingFangSC-Medium;
  font-size: 16/16rem;
  color: #ffffff;
  letter-spacing: 0;
  text-align: center;
  border-radius: 24.5/16rem;
}
.nameImg {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-top: 18/16rem;
}
.textarea {
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.van-checkbox-group .van-checkbox {
  float: left;
  margin-right: 10/16rem;
  margin-bottom: 10/16rem;
}
.count {
  background: #bdbdbd;
  border: #bdbdbd;
}
.go-login{
   color:#026AA1; 
   border-bottom: 1/16rem solid;
}
.checkBoxResult-margin{
  margin-top: 20/16rem;
}
.pictures-porder{
  font-size: 30/16rem; 
  text-align: center;
  border: 1/16rem solid #c5c5c5; 
  width: 78/16rem; 
  height: 68/16rem;
  padding-top: 10/16rem;
}
.pictures-size{
   font-size: 15/16rem;
}
.register-padding{
   padding:0 15/16rem;
}
.mc-register{
  padding-top: 15/16rem;
  padding-bottom: 10/16rem;
}
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  border: 1/16rem solid #ccc;
  color: #fff;
  border-radius: 25/16rem;
  background: #ccc;
  right: 25/16rem;
  bottom: 40/16rem;
}
.top:hover {
  cursor: pointer;
}
.top /deep/ span {
  line-height: 30/16rem;
}
</style>
<template>
  <div class="container">
    <!-- 顶部 -->
    <van-row span="24" class="header">
      <van-col span="6" class="logo">
        <van-image fit="contain" :src="boobyBlockLogoImg" />
        <!-- <span>区  块  链</span> -->
      </van-col>
    </van-row>
    <!-- 交易详情主体内容 -->
    <van-row class="content-one">
      <van-col span="24">
        <van-cell-group :border="false">
          <van-cell title="交易详情" title-class="firstTitle" :border="false" />
          <van-cell title="交易hash ：" :value="tradingHash" :border="false" />
          <van-cell title="区块高度 ：" :value="blockHeight" :border="false" />
          <van-cell title="nonce ：" :value="nonce" :border="false" />
          <van-cell title="表达式 ：" value="-" :border="false" />
          <van-cell
            title="交易发起方 ："
            :value="sourceAddress"
            :border="false"
          />
          <van-cell title="交易时间 ：" :value="closeTime | dateTransferFormat()" :border="false" />
          <van-cell
            title="metadata ："
            :value="metadata?metadata:'-'"
            :border="false"
          />
        </van-cell-group>
      </van-col>
    </van-row>
    <van-row class="content-two">
      <van-col span="24">
        <van-cell-group :border="false">
          <van-cell title="0-设置metadata" :border="false" title-class="titleColor" />
          <van-divider dashed :style="{borderColor:'#333333',marginTop:'0'}"></van-divider>
          <van-cell
            title="键 ："
            :border="false"
            :value="setKey"
          />
          <van-cell title="值 ：" :border="false" />
          <van-row class="form-control">
            <van-col span="23">
              <van-field
                class="form-control"
                style="background: #eceeef;color:#55595c;"
                rows="4"
                type="textarea"
                readonly
                :value="setValue"
              />
            </van-col>
          </van-row>
          <van-cell
            title="版本 ："
            :border="false"
            :value="version"
          />
        </van-cell-group>
      </van-col>
    </van-row>
    <van-row class="content-three">
      <van-col span="24">
        <van-cell-group :border="false">
          <van-cell title="签名列表" :border="false" title-class="titleColor" />
          <van-divider dashed :style="{borderColor:'#333333',marginTop:'0'}"></van-divider>
          <van-row
            v-for="(item,index) of signatureLists"
            :key="index"
          >
            <van-cell title="公钥 ：" :border="false" />
            <van-cell :border="false" :value="item.publicKey" />
            <van-cell title="签名数据 ：" :border="false"/>
            <van-cell :border="false" :value="item.signData" />
            <br />
          </van-row>

          <!-- <van-cell title="公钥 ：" :border="false" value="gongyao" />
          <van-cell title="签名数据 ：" :border="false" value="qianmingshuju" />-->
        </van-cell-group>
      </van-col>
    </van-row>
    <van-divider :style="{boderColor:'#333333'}" />
    <br />
    <br />
    <br />
    <!-- 底部 -->
    <van-row class="footer">
      <van-col span="24">
        <span>©2016 布比(北京)网络技术有限公司 | 京ICP备15052630</span>
      </van-col>
    </van-row>
  </div>
</template>

<script>
import boobyBlockLogoImg from "@/assets/imgs/logo.png";
import http from "@/common/request";
import { dateTransferFormat } from "@/utils";
// import { version } from 'vant';
import { Image } from "vant";

export default {
  data() {
    return {
      // boobyBlockLogoImg: require("@/assets/imgs/logo-2.png")
      boobyBlockLogoImg,
      //签名列表
      signatureLists: [],
      tradingHash: '',
      blockHeight: null,      
      nonce: null,
      sourceAddress: '',
      closeTime: null,
      metadata: null,
      setKey: '',
      setValue: '',
      version:null
    };
  },
  created() {
    this.getTradingDetail();
  },
  filters:{
    dateTransferFormat
  },
  methods: {
    //获取交易详情
    getTradingDetail() {
      const _this = this;
      const getVueQrUrl='/common/HomePage/getdata/'+this.$route.query.content;
      http
        .get(
          getVueQrUrl
        )
        .then(res => {
          if (res.code === 0) {
              res.fileInfo.transactions.map((item) => {
                _this.tradingHash = item.hash;
                _this.blockHeight = item.ledgerSeq;
                _this.nonce = item.transaction.nonce;
                _this.sourceAddress = item.transaction.sourceAddress;
                _this.closeTime = item.closeTime;
                _this.signatureLists = item.signatures;
                _this.metadata = item.transaction.metadata;
                item.transaction.operations.map((itemChild) => {
                  _this.setKey = itemChild.setMetadata.key;
                  _this.setValue = itemChild.setMetadata.value;
                  _this.version = itemChild.setMetadata.version;
                })
              })
          }
        });
    }
  }
};
</script>

<style lang="less" scoped>
.container {
  font-family: Microsoft Yahei;
  .header {
    background: #f8f8f8;
    padding: 10/16rem 0;
    width: 100%;
    .logo {
      .van-image {
        width: 130/16rem;
      }
    }
  }
  .content-one,
  .content-two,
  .content-three {
    // padding: 0 10/16rem;
    .van-cell-group {
      padding-top: 10/16rem;
      padding-bottom: 10/16rem;
      .van-cell-group__title {
        text-align: left;
        color: #333333;
      }
      .van-cell {
        padding-top: 8/16rem;
        padding-bottom: 0;
        .van-cell__title {
          text-align: left;
          max-width: 33%;
          color: #333333;
        }
        .van-cell__value {
          text-align: left;
          font-family: consolas;
          color: #666666;
        }
        .firstTitle {
          padding-bottom: 10/16rem;
          font-size: 16/16rem;
          letter-spacing: 0;
          color: #000000;
        }
        .titleColor {
          color: #2c5e54;
        }
      }
    }
  }
  .footer {
    width: 100%;
    background: #222222;
    padding: 15/16rem 0;
    font-size: 10/16rem;
    color: #bebebe;
    position: fixed;
    bottom: 0;
    // z-index: 1000;
  }
  .form-control {
    font-size: 16/16rem;
    width: 98%;
    height: 1.5;
    border-radius: 5/16rem;
    margin: 6/16rem 0 6/16rem 7/16rem;
    overflow: auto;
  }
}
</style>
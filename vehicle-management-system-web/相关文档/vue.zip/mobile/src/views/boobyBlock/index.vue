<template>
  <div class="container">
    <!-- 顶部 -->
    <van-row class="header">
      <van-col span="6" class="logo">
        <img :src="boobyBlockLogoImg" />
        <!-- <span>区  块  链</span> -->
      </van-col>
    </van-row>
    <!-- <div>
      <div>区块首页跳转它页测试</div>
      <van-button @click="jumpBlockDetail">区块详情</van-button>
      <van-button @click="jumpBlockTradingDetail">交易详情</van-button>
    </div>-->
    <!-- 首页区块部分内容 -->
    <van-row class="blocks">
      <van-col span="24">
        <van-cell
          title="区块"
          title-class="titleStyle"
          value="最新生成的区块"
          value-class="valueStyle"
          :border="false"
        />
        <van-divider :style="{boderColor:'#2c5e54',margin:'0'}" />
        <div class="line-styles paddings">
          <van-col span="4">
            <span>区块高度</span>
          </van-col>
          <van-col span="6">
            <span>区块hash</span>
          </van-col>
          <van-col span="6">
            <span>账号树hash</span>
          </van-col>
          <van-col span="8">
            <span>生成时间</span>
          </van-col>
        </div>
      </van-col>
      <van-col span="24" class="line-styles paddings">
        <van-col span="4">
          <span style="color:#333333;" @click="jumpBlockDetail">917262</span>
        </van-col>
        <van-col span="6">
          <span>9bc4751fc</span>
        </van-col>
        <van-col span="6">
          <span>aaf61a6e</span>
        </van-col>
        <van-col span="8">
          <span>2020.02.15 18:37:04</span>
        </van-col>
      </van-col>
    </van-row>
    <!-- 首页交易部分内容 -->
    <van-row class="tradings">
      <van-col span="24">
        <van-cell
          title="交易"
          title-class="titleStyle"
          value="最新生成的交易"
          value-class="valueStyle"
          :border="false"
        />
        <van-divider :style="{boderColor:'#2c5e54',margin:'0'}" />
        <div class="line-styles paddings">
          <van-col span="4">
            <span>交易序号</span>
          </van-col>
          <van-col span="8">
            <span>交易发起方地址</span>
          </van-col>
          <van-col span="8">
            <span>交易时间</span>
          </van-col>
          <van-col span="4">
          </van-col>
        </div>
      </van-col>
      <van-col span="24" class="line-styles paddings">
        <van-col span="4">
          <span>915611</span>
        </van-col>
        <van-col span="8">
          <span>afefhoasehf</span>
        </van-col>
        <van-col span="8">
          <span>2020.02.14 15:05:52</span>
        </van-col>
        <van-col span="4">
          <span>
            <van-button size="mini" style="color: #2c5e54;border-color:2c5e54" @click="jumpBlockTradingDetail">详情</van-button>
          </span>
        </van-col>
      </van-col>
    </van-row>
    <!-- 底部 -->
    <van-row class="footer">
      <van-col span="24">
        <span>© 2016 布比（北京）网络技术有限公司 | 京ICP备15052630</span>
      </van-col>
    </van-row>
  </div>
</template>

<script>
import boobyBlockLogoImg from "@/assets/imgs/logo.png";
import http from "@/common/request";
export default {
  data() {
    return {
      // boobyBlockLogoImg: require("@/assets/imgs/logo-2.png")
      boobyBlockLogoImg,
      //首页数据
      boobyBlockDatas: []
    };
  },
  created() {
    this.getBlockData();
  },
  methods: {
    //获取首页数据
    getBlockData() {
      const _this = this;
      http.get("/common/HomePage/getdata/17a60f3d2631c735a8f050d9dbb602232c787de8c5dd44cc8831482d2243c3f2").then(res => {
        if (res.code == 0) {
          _this.boobyBlockDatas = res.data;
        }
      });
    },
    //跳转到区块详情页面
    jumpBlockDetail() {
      this.$router.push("/blockDetail");
    },
    //跳转到交易详情页面
    jumpBlockTradingDetail() {
      this.$router.push("/blockTradingDetail");
    }
  }
};
</script>

<style lang="less" scoped>
.container {
  font-family: Microsoft Yahei;
  .header {
    background: #f8f8f8;
    padding: 10/16rem 0;
    width: 100%;
    .logo {
      img {
        width: 130/16rem;
        height: 100%;
      }
      // span {
      //   font-size: 8/16rem;
      //   color: #d1d1d1;
      // }
    }
  }
  .blocks ,.tradings {
    margin: 15/16rem 0;
    .van-cell {
      .van-cell__title {
        text-align: left;
        max-width: 15%;
        color: #333333;
      }
      .van-cell__value {
        text-align: left;
        font-family: consolas;
        color: #666666;
      }
      .titleStyle {
        // padding-bottom: 10/16rem;
        font-size: 16/16rem;
        letter-spacing: 0;
        color: #000000;
      }
      .valueStyle {
        font-size: 12/16rem;
        color: #2c5e54;
      }
    }
    .line-styles {
      font-size: 12/16rem;
      color: #666666;
      height: 25/16rem;
      line-height: 25/16rem;
      text-align: left;
      &.paddings {
        padding-left: 16/16rem;
      }
    }
  }
  .footer {
    width: 100%;
    background: #222222;
    padding: 15/16rem 0;
    font-size: 10/16rem;
    color: #bebebe;
    position: fixed;
    bottom: 0;
    // z-index: 1000;
  }
}
</style>
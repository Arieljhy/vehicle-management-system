<template>
  <div style="background:#F2F2F2;">
    <div class='color-background'></div>
    <van-nav-bar
      left-text=''
      left-arrow
      class="mc-navbar"
      @click-left="back"
      :title="selectedPrj.communityName"
    ></van-nav-bar>
    <div class="blue-padding">
      <div class="ertivcalLine"></div>
      <span
        
        class="blue font-bold blue-style"
      >保单信息</span>
    </div>
    <!-- 内容 -->
    <div class="contents-margin">
      <van-row class="contents">
        <div class="card">
          <van-col span="24">
            <van-cell-group class="contents-border">
              <van-cell size="large">
                <van-col span="8">项目名称</van-col>
                <van-col span="16" class="detail-text">{{selectedPrj.projectName?selectedPrj.projectName: '空'}}</van-col>
              </van-cell>
              <van-cell size="large">
                <van-col span="8">牵头保险公司</van-col>
                <van-col span="16" class="detail-text">{{projectDatae.orgName?projectDatae.orgName: '空'}}</van-col>
              </van-cell>
              <van-cell size="large">
                <van-col span="8">风险管理机构</van-col>
                <van-col span="16" class="detail-text">{{insBasicInfoDO.tisOrgName}}</van-col>
              </van-cell>
              <van-cell size="large">
                <van-col span="8">保险分类</van-col>
                <van-col span="16" class="detail-text">{{insurance}}</van-col>
              </van-cell>
              <van-cell size="large">
                <van-col span="8">保单号</van-col>
                <van-col span="16" class="detail-text">{{selectedPrj.insContractNo?selectedPrj.insContractNo: '空'}}</van-col>
              </van-cell>
              <van-cell size="large">
                <van-col span="8">备注信息</van-col>
                <van-col span="16" class="detail-text">{{insBasicInfoDO.description}}</van-col>
              </van-cell>
              <!-- 只有运营方有保单文件 需加条件 v-if="yunying=='OP'" -->
              <van-cell size="large" v-if="yunying!='OWN'&& yunying!='WY'">
                <van-col span="8">保单文件</van-col>
                <van-col span="16" style="color:#1989fa" class="detail-text" @click.stop.self="checkPdf(insBasicInfoDO.insurancePolicy)">{{insBasicInfoDO.insurancePolicyName}}</van-col>
                <!-- <van-col span="8">
                  <van-button class="detail-button" @click.stop.self="checkPdf(insBasicInfoDO.insurancePolicy)">预览</van-button>
                </van-col> -->
              </van-cell>
            </van-cell-group>
          </van-col>
        </div>
      </van-row>
      <van-row>
        <van-col span="24">
          <van-col span="24">
            <div class="ertivcalLine-padding">
              <div class="ertivcalLine"></div>
              <span
                
                class="blue font-bold ertivcalLine-style"
              >本保单所涉及保险覆盖范围</span>
            </div>
            <van-cell-group>
              <van-col span="22" offset="1" >
                <div v-for="(item, index) in mainInsLiabilitiesDOList" :key="index" class="main-ins">
                  <van-cell size="large" v-if="item.selected=='Y'">
                    <van-col span="22" offset="1" class="duty" >主险责任范围</van-col>
                    <van-col span="8" class="terms">保险条款</van-col>
                    <van-col span="16" class="detail-text">{{item.clause?item.clause:'空'}}</van-col>
                    <van-col span="8">期限</van-col>
                    <van-col span="16" class="detail-text">{{item.deadline}}年</van-col>
                    <van-col span="8">责任起止期</van-col>
                    <van-col span="16" class="detail-text" v-if="item.policyStartDate">{{item.policyStartDate}}至{{item.policyEndDate}}</van-col>
                  </van-cell>
                </div>
              </van-col>
            </van-cell-group>
            <van-cell-group>
              <van-col span="22" offset="1">
                <div v-for="(item, index) in otherInsLiabilitiesDOList" :key="index" class="other-style">
                  <van-cell size="large" v-if="item.selected=='Y'">
                    <van-col span="22" offset="1" class="duty" >附加险责任范围</van-col>
                    <van-col span="8" class="terms">保险条款</van-col>
                    <van-col span="16" class="detail-text">{{item.clause?item.clause:'空'}}</van-col>
                    <van-col span="8">期限</van-col>
                    <van-col span="16" class="detail-text">{{item.deadline}}年</van-col>
                    <van-col span="8">责任起止期</van-col>
                    <van-col span="16" class="detail-text" v-if="item.policyStartDate">{{item.policyStartDate}}至{{item.policyEndDate}}</van-col>
                  </van-cell>
                </div>
              </van-col>
            </van-cell-group>
          </van-col>
        </van-col>
      </van-row>
    </div>
    <div class="back-button">
      <van-button type="info" size="large" @click="back">返回</van-button>
    </div>
    <div v-if="showPdf">
      <mcPdf :pushurl="pdfurl" :cloudDocId="cloudDocId" @goBack = goBack v-if="fileType=='pdf'"/>
    </div>
     <van-overlay :show="show">
      <div class="wrapper">
         <van-loading size='24px' vertical style="position: absolute;top: 50%; left: 43%;" >加载中...</van-loading>
      </div>
    </van-overlay>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import http from '@/common/request'
import mcPdf from "@/components/mcPdf";
import { ImagePreview } from 'vant'
export default {
  name: 'policyDetail',
  components: {
    mcPdf
  },
  data() {
    return {
       show:false,
      showPdf:false,
      pdfurl:'',
      cloudDocId:'',
      yunying:'',
      insBasicInfoDO: {},
      // 保险分类
      insurance: '',
      // 主险范围
      mainInsLiabilitiesDOList: [],
      // 附加险范围
      otherInsLiabilitiesDOList: [],
      // 保险分类字典表
      insuranceList: [],
      activeNames: [],
      selectedPrj:{},
      projectDatae:{},
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId="
    }
  },
  computed: {
  },
  methods: {
    // 当前项目的详情信息
    projectDatas(data) {
      http.get('/forum/getForumInfoByProjectId/' + data).then((res) => {
        if (res.code === 0) {
          this.projectDatae = res.data
        }
      })
    },
    back() {
      this.$router.go(-1)
    },
    goBack() {
      this.showPdf = false;
    },
    checkPdf(docId) {
        this.show=true
      const keys = {
        cloudDocId:docId,
        pageSize: 1,
        pageNum: 1,
        lesseeId: this.$getMobileData.lesseeId
        //  lesseeId: "eidi-yangquan"
    };
    //9000未不支持文件格式，9001为图片，为空就是没有数据，存在数据，为pdf数据
    http.get("/processDoc/viewFile", keys).then(res => {
      if (res) {
        if(res.code=="9000"){
            this.show=false
          this.$toast("不支持此格式文件预览");
        }else if (res.code == "9002") {
            this.show = false;
            this.$toast("该文件不存在");
          }else if(res.code=="9001"){
            this.show=false
          // ImagePreview([this.imagesUrl+docId]);
          ImagePreview({
            images: [this.imagesUrl+docId],
            closeable: true,
            closeOnPopstate: true           
          });
        }else{
          var binaryData = [];
          binaryData.push(res);
          this.cloudDocId = docId
          this.pdfurl = '/api/processDoc/viewFile?cloudDocId='+docId+'&pageSize=1&pageNum=1&lesseeId='+this.$getMobileData.lesseeId
          // this.pdfurl = '/api/processDoc/viewFile?cloudDocId='+docId+'&pageSize=1&pageNum=1&lesseeId=eidi-yangquan'
          this.fileType ="pdf"
            this.show=false
          this.showPdf = true
          console.log("pdf数据");
        }
      } else {
        console.log("没数据");
      }
    });
    },
    // 获取详情
    getDetails(data) {
      const keywords = data
      http.get("/insurance/compose/underWriting/", keywords).then(res => {
        if (res.code == 0) {
          this.insBasicInfoDO = res.data.insBasicInfoDO
          this.mainInsLiabilitiesDOList = res.data.mainInsLiabilitiesDOList
          this.otherInsLiabilitiesDOList = res.data.otherInsLiabilitiesDOList
          this.getInsurance()
          // 将时间进行重新初始化
          this.formatTime()
        }
      })
    },
    // 获取保险分类
    getInsurance() {
      const _this = this
      _this.insuranceList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_INS_CATEGORIES
      _this.insuranceList.map(_data => {
        if (_data.dictKey == _this.insBasicInfoDO.insCategory) {
         _this.insurance =  _data.dictValue
        } 
      })
    },
    // 格式化时间,将yyyy-mm-dd hh:mm:ss 转换成 yyyy-mm-dd
    formatTime(){
      const _this = this
      _this.mainInsLiabilitiesDOList.map(_time => {
        if (_time.policyStartDate) {
          _time.policyStartDate = _time.policyStartDate.slice(0, 10)
        }
        if (_time.policyEndDate) {
          _time.policyEndDate = _time.policyEndDate.slice(0, 10)
        }
      })
      _this.otherInsLiabilitiesDOList.map(_time => {
        if (_time.policyStartDate) {
          _time.policyStartDate = _time.policyStartDate.slice(0, 10)
        }
        if (_time.policyEndDate) {
          _time.policyEndDate = _time.policyEndDate.slice(0, 10)
        }
      })
      
    },
  },
  created() {
    this.yunying = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
    this.projectDatas(this.$route.query.projectId)
    this.selectedPrj = this.$route.query
    this.getDetails(this.$route.query.projectId)
  },

}
</script>
<style lang="less" scoped>
.ertivcalLine {
  width: 4/16rem;
  background: #128feb;
  height: 15/16rem;
  float: left;
  margin-top: 4/16rem;
  margin-left: 5%;
}
.mask {
  width: 100%;
  background: #fff;
  padding-bottom: 5/16rem;
}
.content {
  margin: 0 30/16rem;
  text-align: left;
}
.content /deep/ .van-step__title {
  background: #f2f2f2;
}
.contents {
  background: #fff;
  margin: 10/16rem 15/16rem;
  text-align: left;
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.content /deep/ .van-step__title h3 {
  font-size: 16/16rem;
  position: relative;
  top: 12/16rem;
  color: #595959;
  margin-left: 5/16rem;
}
.content /deep/ .van-step__title p {
  font-size: 12/16rem;
  color: #969799;
  margin-left: 5/16rem;
}
.content /deep/ img.van-image__img {
  width: 20/16rem;
  height: 20/16rem;
  position: relative;
  left: -3/16rem;
}

// 返回按钮,固定在底部
.back-button {
  position: fixed;
  bottom: 0;
  width: 100%;
}

.card {
  width: 100%;
  margin: 0 auto;
  text-align: left;
}
.card-item {
  font-size: 20/16rem;
  margin: 10/16rem;
}
.color-background {
  background:#F2F2F2;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.collapse-style {
  padding: 5/16rem 14/16rem;
}
// 保险责任范围
.duty {
  font-size: 16/16rem;
  text-align: left;
  margin-bottom: 8/16rem;
  margin-left: 0;
}
.terms {

}
/deep/ .van-cell--large {
  border-radius: 6/16rem;
}
.other-style{
  margin-bottom:10/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
  border-radius: 6/16rem;
}
.main-ins{
  margin-bottom:10/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
  border-radius: 6/16rem;
}
.ertivcalLine-style{
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128FEB;
  margin-left:-41%;
  font-weight: 700;
}
.ertivcalLine-padding{
  padding:10/16rem 0;
}
.contents-border{
  border-radius: 6/16rem;
}
.contents-margin{
  margin-bottom:50px;
}
.blue-style{
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128FEB;
  margin-left:-72%;
  font-weight: 700;
}
.blue-padding{
  padding:10/16rem 0;
}
.detail-button{
  height: 30/16rem;
  line-height: 30/16rem;
  margin-left: -4/16rem;
}
.van-nav-bar__title{
  max-width: 80%;
}
</style>
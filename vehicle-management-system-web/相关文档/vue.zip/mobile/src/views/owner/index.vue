<template>
  <div style="background: #F2F2F2;">
    <van-nav-bar class="mc-navbar">
      <div name="search" slot="title"  class="word-navbar">
       <span @click="openSelect">
          {{selectedPrj.communityName}}
        <van-icon name="arrow-down" class="arrow-down" />
       </span>
      </div>
      <van-icon name="setting-o" slot="right" @click="jumpMy" class="jumpMy-size" />
    </van-nav-bar>
    <van-popup v-model="isDialog" position="bottom">
      <van-picker
        show-toolbar
        :columns="plotsList"
        @cancel="isDialog = false"
        :default-index="showNum"
        @confirm="onConfirm"
      />
    </van-popup>

    <!-- 轮播 -->
    <van-row>
      <van-swipe :autoplay="3000">
        <span v-if="images.length>0">
          <van-swipe-item v-for="(image, index) in imagesList" :key="index">
            <img v-lazy="image.imageUrl" />
          </van-swipe-item>
        </span>
      </van-swipe>
    </van-row>
    <!-- 内容 -->
    <div class="content">
      <van-row class="nav">
        <van-grid :border="false" :column-num="3">
          <van-grid-item :class="{ownerColor:setOwnerCommunity}" @click="setPic('/ownerCommunity')">
            <img class="owner-btn" :src="ownerCommunityImg" />
            <span>小区</span>
          </van-grid-item>
          <van-grid-item :class="{ownerColor:setOwnerReport}" @click="setPic('/ownerReport')">
            <img class="owner-btn" :src="ownerReportImg" />
            <span>报案</span>
          </van-grid-item>
          <van-grid-item
            :class="{ownerColor:setOwnerClaims,tipPosition:isTip}"
            @click="setPic('/ownerClaims')"
          >
            <img class="owner-btn" :src="ownerClaimsImg" />
            <span>
              理赔
              <span class="tip" v-if="isTip">{{tips}}</span>
            </span>
          </van-grid-item>
        </van-grid>
      </van-row>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import riskimage1 from "@/assets/imgs/fengxian001.png";
import riskimage2 from "@/assets/imgs/fengxian002.png";
import riskimage3 from "@/assets/imgs/fengxian003.png";
export default {
  name: "owner",
  components: {},
  data() {
    return {
      communityName: "",
      title: "",
      baoan: {
        value: ""
      },
      radio: "1",
      isDialog: false,
      report: [],
      isTip: false,
      tips: 0,
      setOwnerCommunity: true,
      setOwnerReport: false,
      setOwnerClaims: false,
      ownerCommunityImg: require("@/assets/imgs/owner-images/icon_community_checked.png"),
      ownerReportImg: require("@/assets/imgs/owner-images/icon_report.png"),
      ownerClaimsImg: require("@/assets/imgs/owner-images/icon_claims.png"),
      imagesList:[
        {imageUrl:riskimage1},{imageUrl:riskimage2},{imageUrl:riskimage3}
      ]
    };
  },
  computed: {
    ...mapGetters(["plotsList", "selectedPrj", "images", "showNum"])
  },
  methods: {
    ...mapActions([
      "getProjectList",
      "getProjectData",
      "setProject",
      "getPlotsHousehold",
      "getImages",
      "setFinished",
      "setClaimsFinished",
      "getClaimTip",
      "getMainPostList",
      "postFinished"
    ]),

    // 打开选择小区
    openSelect() {
      // 不在此掉接口，初始化的时候掉接口
      // this.getProjectList({ isPage: false })
      this.isDialog = true;
    },
    // 切换'小区','报案','理赔'图标样式更改
    setPic(type) {
      this.$router.push(type);
      if (type == "/ownerCommunity") {
        this.ownerCommunityImg = require("@/assets/imgs/owner-images/icon_community_checked.png");
        this.ownerReportImg = require("@/assets/imgs/owner-images/icon_report.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims.png");
        this.setOwnerCommunity = true;
        this.setOwnerReport = false;
        this.setOwnerClaims = false;
      } else if (type == "/ownerReport") {
        this.ownerCommunityImg = require("@/assets/imgs/owner-images/icon_community.png");
        this.ownerReportImg = require("@/assets/imgs/owner-images/icon_report_checked.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims.png");
        this.setOwnerCommunity = false;
        this.setOwnerReport = true;
        this.setOwnerClaims = false;
      } else if (type == "/ownerClaims") {
        this.ownerCommunityImg = require("@/assets/imgs/owner-images/icon_community.png");
        this.ownerReportImg = require("@/assets/imgs/owner-images/icon_report.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims_checked.png");
        this.setOwnerCommunity = false;
        this.setOwnerReport = false;
        this.setOwnerClaims = true;
      }
    },
    // 选中小区点击‘确认’
    onConfirm(value, index) {
      this.setProject(value);
      this.getImages(value.projectId);
      this.getProjectData(this.selectedPrj.projectId);
      this.getPlotsHousehold(this.selectedPrj.projectId);
      this.getMainPostList({
        offset: 1,
        limit: 5,
        projectId: this.selectedPrj.projectId
      });
      this.postFinished(false);
      this.setTips();
      this.isDialog = false;
    },
    // 跳转到_我的
    jumpMy() {
      this.$router.push("/personalSettings");
    },

    setTips() {
      // 理赔列表展示小红点
      this.getClaimTip({
        limit: 5,
        offset: 1,
        projectId: this.selectedPrj.projectId,
        sqlStatus: 1
        // caseReporter: this.selectedPrj.userId
      }).then(res => {
        if (res.code === 0) {
          this.tips = res.data.total;
          if (this.tips > 0) {
            this.isTip = true;
          } else if (this.tips == 0) {
            this.isTip = false;
          }
        }
      });
    }
  },

  created() {
    this.setPic(this.$route.path);
    this.getProjectList({ isPage: false }).then(res => {
      // debugger
      if (res.code === 0) {
        // 当没有小区时,直接跳出
        if (res.data.length == 0) {
          this.$store.state.ownerProject.plotsList = [];
          this.$store.state.ownerProject.selectedPrj = "";
          return;
        } else {
          // 初始化调取轮播,小区数组,该小区所属栋楼
          this.getImages(this.selectedPrj.projectId);
          this.getProjectData(this.selectedPrj.projectId);
          this.getPlotsHousehold(this.selectedPrj.projectId);
          this.setTips();
        }
      }
    });
  }
};
</script>
<style lang="less" scoped>
.content {
  margin: 0 15/16rem;
  text-align: left;
}
.van-swipe {
  height: 238/16rem;
}
.van-swipe /deep/ img {
  width: 100%;
  height: 100%;
}
.nav {
  margin: 10.5/16rem 0;
  text-align: center;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.nav /deep/ img {
  width: 100%;
  height: 100%;
}
/deep/ .van-grid-item__content--center {
  border-radius: 6/16rem;
}
.home {
  margin: 10.5/16rem 0;
  text-align: left;
  height: 153/16rem;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.home /deep/ p {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.home /deep/ .subhead {
  line-height: 26/16rem;
}

.comment {
  text-align: left;
}
.comment /deep/ p {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.comments {
  text-align: left;
}
.comments /deep/ .title {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.comments /deep/ .news {
  // font-size:16px;
  // font-weight: bold;
  padding-left: 15/16rem;
}
.comments /deep/ .news /deep/ .newscont {
  padding: 0 35/16rem;
}
.owner-btn {
  width: 45/16rem !important;
  height: 45/16rem !important;
}
.ownerColor {
  color: #f99139;
}

// 右上角提示小圆点
.tipPosition {
  position: relative;
  // padding: 7px;
  // margin: 40px;
  display: inline-block;
}
.tip {
  display: block;
  background: #f00;
  border-radius: 50%;
  width: 18/16rem;
  height: 18/16rem;
  text-align: center;
  line-height: 18/16rem;
  position: absolute;
  top: 14/16rem;
  color: #fff;
  margin-left: 24/16rem;
  font-size: 12/16rem;
}
.word-navbar {
  font-size: 14/16rem;
}
.arrow-down {
  font-size: 16/16rem;
  margin-top: -2/16rem; 
}
.jumpMy-size {
  font-size: 20/16rem;
}
.van-nav-bar__title{
  max-width: 80%;
}
</style>
<template>
  <div style="background:#F2F2F2;">
    <div class="color-background"></div>
    <van-nav-bar
      left-text="返回"
      left-arrow
      class="mc-navbar"
      @click-left="back"
      :title="selectedPrj.communityName"
    ></van-nav-bar>
    <div class="main_post">
      <van-row>
        <van-col span="4">
          <van-image
            round
            class="manager mouse-pointer"
            :src="mainPost.userImage"
            width="40"
            height="40"
          />
        </van-col>
        <van-col span="20">
          <van-col span="24" class="post_title">{{mainPost.mainTopic}}</van-col>
          <van-col span="24" class="post_user">{{mainPost.userName}}</van-col>
        </van-col>
      </van-row>
      <van-row>
        <van-col span="20" offset="4">
          <div class="main_contents">
            {{mainPost.mainContents}}
            <div class="mainContents-top">
              <span
                v-for="childItem in mainPost.forumPicDOList"
                :key="childItem.id"
                class="mainContents-right"
              >
                <van-image
                  width="60"
                  height="60"
                  :src="childItem.imgUrl"
                  @click="clickImage(childItem)"
                  alt
                />
              </span>
            </div>
          </div>
        </van-col>
      </van-row>
    </div>
    <div class="interval-line"></div>
    <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
      <div v-for="item in followPostList" :key="item.id" class="main_post">
        <van-row>
          <van-col span="4">
            <van-image
              round
              class="manager mouse-pointer"
              :src="item.userImage"
              width="40"
              height="40"
            />
          </van-col>
          <van-col span="20">
            <van-col span="24" class="post_user">{{item.userName}}</van-col>
            <van-col span="24">
              <div class="main_contents" v-if="!item.followContentMedia">
                   {{item.followContents}}
                <div class="followContents-top">
                  <span
                    v-for="childItem in item.forumPicDOList"
                    :key="childItem.id"
                    class="followContents-right"
                  >
                    <van-image
                      width="60"
                      height="60"
                      :src="childItem.imgUrl"
                      @click.stop="clickImage(childItem)"
                      alt
                    />
                  </span>
                </div>
              </div>
              <div class="main_contents" v-else>
                <div @click="openVoice(item)">
                  <van-image v-if="!item.playVoice" width="30" height="30" :src="voiceImg" />
                  <van-image v-else width="30" height="30" :src="voicegif" />
                </div>
              </div>
            </van-col>
            <van-col span="24" class="post_reply" v-if="item.forumReplyDOList.length>0">
              <div v-for="reItem in item.forumReplyDOList" :key="reItem.id" class="post_review">
                <span>{{reItem.userName}}：</span>
                {{reItem.replyContents}}
              </div>
            </van-col>
            <van-col span="24" class="post_user">
              <van-col span="12">{{item.followTime}}</van-col>
              <van-col span="10" style="text-align: right">
                <van-icon name="chat-o" class="followTime-font" @click="openNewReply(item)" />
              </van-col>
            </van-col>
          </van-col>
        </van-row>
        <div class="new_post" v-if="newReply">
          <van-cell-group style="text-align: left;">
            <van-field
              v-model="item.replyContents"
              rows="3"
              autosize
              type="textarea"
              placeholder="请输入正文"
            />
          </van-cell-group>
          <van-row>
            <van-button type="default" style="width:50%" @click="newReply=false">取消</van-button>
            <van-button type="primary" style="width:50%" @click="saveReply(item)">发表</van-button>
          </van-row>
        </div>
      </div>
    </van-list>

    <div class="new_post" v-if="openNewPost">
      <van-cell-group style="text-align: left;">
        <van-field v-model="followContents" rows="3" autosize type="textarea" placeholder="请输入内容" />
        <van-uploader
          :after-read="uploadFile"
          :before-delete="afterDelete"
          v-model="imageList.imageCloudId"
          class="pictures-margin"
        >
          <div class="iconfont icon-xaingji pictures-style">
            <div class="upload-pictures">上传图片</div>
          </div>
        </van-uploader>
      </van-cell-group>
      <van-row>
        <van-button type="default" style="width:50%" @click="openNewPost=false">取消</van-button>
        <van-button
          type="info"
          style="width:50%"
          v-if="!showAddBtn"
          @click="saveFollowPost"
          :disabled="disabled"
        >发表</van-button>
        <van-button loading type="info" style="width:50%" v-if="showAddBtn" loading-text="发表中..." />
      </van-row>
    </div>

    <div v-if="!openNewPost && !newReply" class="new_post">
      <!-- <van-button type="primary" style="width:100%" @click="openNewPost=true">评论</van-button> -->
      <van-search
        shape="round"
        show-action
        left-icon="edit"
        @click="openNewPost=true"
        background="#128feb"
        placeholder="我要评论"
      >
        <template #action>
            <!-- @click="openRecordDiolog"   暂时注掉语音-->

          <div
            class="iconfont icon-yuyin"
            style="font-size: 25px;color:white"
          ></div>
        </template>
      </van-search>
    </div>
    <van-dialog
      v-model="openRecord"
      :show-confirm-button="showButton"
      :overlay="showOverlay"
      width="230px"
    >
      <div style="padding:35px;">
        <mcRecorder @handleStop="handelEndRecord" :sampleRate="sampleRate" />
      </div>
    </van-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import mcRecorder from "@/components/mcRecorder";
import { ImagePreview } from "vant";

export default {
  name: "forumOpen",
  components: { mcRecorder },
  data() {
    return {
      dealImgWidth: 600,
      voiceImg: require("@/assets/imgs/audio.png"),
      voicegif: require("@/assets/imgs/audio.gif"),
      disabled: false,
      mainPost: {},
      finished: false,
      openNewPost: false,
      newReply: false,
      loading: false,
      followPostList: [],
      limit: 5, //每页几条数据
      offset: 1, //第几页
      imageList: [],
      followContents: "",
      replyType: "1",
      replyToReplyId: null,
      showAddBtn: false,
      openRecord: false,
      showButton: false,
      showOverlay: false,
      sampleRate: 42000
    };
  },
  computed: {
    ...mapGetters(["selectedPrj"])
  },
  created() {
    this.getMainPost();
    this.getListFollowReply();
  },
  methods: {
    handelEndRecord(param) {
      console.log(param);
      this.openRecord = false;
      let voiceFile = new File(
        [param.mblob],
        Math.floor(Math.random() * 10000000) + ".wav",
        { type: "audio/wav" }
      );
      console.log(voiceFile);
      let file = new FormData();
      file.append("file", voiceFile);
      file.append("fileIcon", "idiwav");
      file.append("projectId", this.$route.query.projectId);
      let keepPic = {
        picType: "2",
        picName: "",
        picPath: "",
        picUidName: "V" + Math.floor(Math.random() * 10000000),
        projectId: this.$route.query.projectId,
        mainId: this.$route.query.mainId
      };
      console.log(keepPic);
      http.post("/processDoc/uploadProcessDocTmp", file).then(res => {
        if (res.code === 0) {
          keepPic.picPath = res.data.cloudDocId;
          keepPic.picUidName = res.data.uidFileName;
          this.imageList.push(keepPic);
          const keywords = {
            userId: JSON.parse(
              localStorage.getItem(this.$getMobileData.userInfo)
            ).userId,
            userName: JSON.parse(
              localStorage.getItem(this.$getMobileData.userInfo)
            ).username,
            mainId: this.$route.query.mainId,
            projectId: this.$route.query.projectId,
            followContents: "",
            forumPicDOList: [],
            followTopic: "",
            forumContentMedia: keepPic
          };
          http.post("/forum/saveFollow", keywords).then(res => {
            if (res.code == 0) {
              this.offset = 1;
              this.getListFollowReply();
              this.$toast({ message: "发表成功" });
            }
          });
        } else {
          param.status = "failed";
          param.message = "上传失败";
          this.disabled = false;
        }
      });
    },
    openVoice(item) {
      item.playVoice = !item.playVoice;
      if (item.playVoice) {
        item.audio = new Audio();
        item.audio.src = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.followContentMedia}&view=2`;
        let playPromise = item.audio.play();
        if(playPromise) {
          playPromise.then(()=>{
            item.tiemr = setInterval(()=> {
              if(item.audio.paused){
                clearInterval(item.tiemr)
                item.playVoice = false
                console.log('播放结束')
              }
            },1000)
          })
        }
      } else {
        item.audio.pause();
      }
    },
    openRecordDiolog() {
      this.openRecord = true;
      setTimeout(() => {
        this.openRecord = false;
      }, 10000);
    },
    clickImage(item) {
      ImagePreview({
        images: [item.imgUrl],
        closeable: true,
        closeOnPopstate: true
      });
    },
    openNewReply(item) {
      this.newReply = true;
      this.followId = item.id;
    },
    saveReply(reItem) {
      //校验空格加这行 reItem.replyContents = reItem.replyContents.trim()
      if (!reItem.replyContents) {
        this.$toast("请输入正文");
        return;
      }
      const keywords = {
        replyToReplyId: this.replyToReplyId,
        followId: this.followId,
        mainId: this.$route.query.mainId,
        userId: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .userId,
        userName: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .username,
        projectId: this.$route.query.projectId,
        replyType: this.replyType,
        replyTopic: "",
        replyContents: reItem.replyContents
      };
      http.post("/forum/saveReply", keywords).then(res => {
        if (res.code == 0) {
          this.offset = 1;
          this.getListFollowReply();
          this.followContents = "";
          this.newReply = false;
        }
      });
    },
    //获取贴子详情
    getListFollowReply() {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        mainId: this.$route.query.mainId
      };

      http.get("/forum/listFollowReply", keywords).then(res => {
        res.data.rows.map((item, index) => {
          if (item.forumReplyDOList.length > 0) {
            item.flag = true;
          } else {
            item.flag = false;
          }
          item.forumPicDOList.map((childItem, index1) => {
            childItem.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}&view=1`;
          });
        });
        this.followPostList = res.data.rows;
        this.followPostList.map(item => {
          // item.playVoice = false;
          this.$set(item, "playVoice", false);
        });
        this.total = res.data.total;
      });
    },
    onLoad() {
      setTimeout(() => {
        this.offset += 1;
        const keywords = {
          offset: this.offset,
          limit: this.limit,
          mainId: this.$route.query.mainId
        };
        http.get("/forum/listFollowReply", keywords).then(res => {
          if (res.code == 0) {
            res.data.rows.map(item => {
              // item.playVoice = false;
              this.$set(item, "playVoice", false);
            });
            this.followPostList.push(...res.data.rows);
            // 加载状态结束
            this.loading = false;
            if (res.data.rows.length < 5) {
              this.finished = true;
            }
          }
        });
      }, 500);
    },
    //获取主贴
    getMainPost() {
      http
        .get("/forum/getMainPointCount/", this.$route.query.mainId)
        .then(res => {
          if (res.data.forumPicDOList) {
            res.data.forumPicDOList.map((item, index) => {
              item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
            });
          }
          this.mainPost = res.data;
        });
    },
    back() {
      this.$router.go(-1);
    },
    // 删除图片
    afterDelete(file, detail) {
      return this.imageList.splice(detail.index, 1);
    },
    async uploadFile(param) {
      this.disabled = true;
      param.status = "uploading";
      param.message = "上传中";
      var toFile = param.file
      if(toFile.type.startsWith("image") && toFile.size > 1024*1024) {
        var _this = this
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        )
        toFile = _this.$dataURLtoFile(base64, toFile.name)
      }
      let file = new FormData();
      file.append("file", toFile);
      file.append("fileIcon", "forumPic");
      file.append("projectId", this.$route.query.projectId);
      let keepPic = {
        picType: "2",
        picName: "",
        picPath: "",
        picUidName: param.file.uid,
        projectId: this.$route.query.projectId,
        mainId: this.$route.query.mainId
      };
      http.post("/processDoc/uploadProcessPicsTmp", file).then(res => {
        if (res.code === 0) {
          keepPic.picPath = res.data.cloudDocId;
          keepPic.picUidName = res.data.uidFileName;
          this.imageList.push(keepPic);
          param.status = "done";
          this.disabled = false;
        } else {
          param.status = "failed";
          param.message = "上传失败";
          this.disabled = false;
        }
      });
    },
    saveFollowPost() {
      if (!this.followContents.replace(/\s*/g, "")) {
        this.$toast("请录入跟帖信息！");
        return;
      }
      const keywords = {
        userId: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .userId,
        userName: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .username,
        mainId: this.$route.query.mainId,
        projectId: this.$route.query.projectId,
        followContents: this.followContents,
        forumPicDOList: this.imageList,
        followTopic: ""
      };
      this.showAddBtn = true;
      http.post("/forum/saveFollow", keywords).then(res => {
        if (res.code == 0) {
          this.followContents = "";
          this.imageList = [];
          this.fileList = [];
          this.offset = 1;
          this.showAddBtn = false;
          this.getListFollowReply();
          this.openNewPost = false;
          this.$toast({ message: "发表成功" });
          // this.back()
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.main_post {
  background-color: white;
  padding: 15/16rem 10/16rem 0 0;
  border-bottom: 1/16rem solid #ebedf0;
}
.post_title {
  text-align: left;
  font-weight: bold;
  font-size: 16/16rem;
}
.post_user {
  text-align: left;
  color: #b4b8bf;
  font-size: 13/16rem;
  padding: 5/16rem 0;
}
.main_contents {
  text-align: left;
  padding: 5/16rem 5/16rem 5/16rem 0;
}
.interval-line {
  height: 10/16rem;
  background-color: #f3f3f3;
}
.new_post {
  position: fixed;
  bottom: 0;
  width: 100%;
  z-index: 2;
}
.post_reply {
  background-color: #f7f7f7;
  text-align: left;
  padding: 10/16rem;
}
.post_review {
  line-height: 25/16rem;
}
.post_review span {
  color: #1271ce;
  font-weight: 500;
}
.upload-pictures {
  font-size: 15/16rem;
}
.pictures-style {
  font-size: 30/16rem;
  text-align: center;
  border: 1/16rem solid #c5c5c5;
  width: 78/16rem;
  height: 68/16rem;
  padding-top: 10/16rem;
}
.pictures-margin {
  margin: 5/16rem 0 5/16rem 15/16rem;
}
.followTime-font {
  font-size: 16/16rem;
}
.followContents-right {
  margin-right: 10/16rem;
}
.followContents-top {
  margin-top: 3/16rem;
}
.mainContents-right {
  margin-right: 10/16rem;
}
.mainContents-top {
  margin-top: 3/16rem;
}
.van-dialog {
  background: rgba(20, 35, 54, 0.5);
}
</style>
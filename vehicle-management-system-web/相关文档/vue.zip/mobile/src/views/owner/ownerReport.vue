<template>
  <div>
    <div style="background: #F2F2F2;" v-if="isDataList1">
      <div class="content">
        <van-row class="form">
          <van-row>
            <van-col span="24">
              <van-cell-group title="添加报案">
                <!-- 动态展示'其他'还是所属楼栋 -->
                <van-row style="height:1px;background:#cccccc;margin:0 15px 15px 15px"></van-row>
                <van-field
                  v-model="baoan.riskBldings"
                  label="所属楼栋"
                  :placeholder="isOther?'其他':'所属楼栋'"
                  required
                  readonly
                  @focus="rectificationTime('riskBldings')"
                />
                <van-dialog
                  v-model="riskBldingsShow"
                  title="所属楼栋"
                  required
                  show-cancel-button
                  :beforeClose="onBldingsConfirm"
                >
                  <!-- '其他'按钮 -->
                  <van-checkbox-group v-model="result">
                    <van-cell-group>
                      <van-cell
                        v-for="(iteam, index) in otherList"
                        :key="index"
                        clickable
                        :title="`${iteam}`"
                        @click="otherToggle(iteam,index)"
                      >
                        <van-checkbox :name="iteam" ref="otherCheckboxes" slot="right-icon" />
                      </van-cell>
                    </van-cell-group>
                  </van-checkbox-group>
                  <!-- 遍历出来的栋楼 -->
                  <van-checkbox-group v-model="result" ref="checkboxGroup">
                    <van-cell-group style="overflow: auto;max-height: 300px;">
                      <van-cell
                        v-for="(item, index) in houseList"
                        clickable
                        :key="index"
                        :title="`${item.buildingName}`"
                        @click="isOther?'':toggle(item,index)"
                      >
                        <van-checkbox
                          :name="item"
                          ref="checkboxes"
                          slot="right-icon"
                          :disabled="isOther"
                        />
                      </van-cell>
                    </van-cell-group>
                  </van-checkbox-group>
                </van-dialog>
                <van-field v-model="floorOthers" label placeholder="所属楼栋" v-if="isOther" />
                <van-field v-model="baoan.address" label="我的地址" placeholder="我的地址" required />
                <van-field
                  v-model="riskEventType"
                  label="事件类型"
                  placeholder="风险事件类型"
                  required
                  readonly
                  @focus="rectificationTime('riskEventType')"
                />
                <van-popup v-model="riskEventTypeShow" position="bottom">
                  <van-picker
                    show-toolbar
                    :columns="eventTypeList"
                    @cancel="riskEventTypeShow = false"
                    @confirm="onTypeConfirm"
                  />
                </van-popup>
                <div v-if="projectData.orgName.indexOf('中国大地')!=-1">
                  <van-field
                    v-model="baoan.riskDesc"
                    rows="1"
                    autosize
                    type="textarea"
                    label="事件描述"
                    placeholder="事件描述"
                    required
                  />
                  <van-field
                    v-model="baoan.amountDemage"
                    label="损失估计"
                    placeholder="损失估计多少元"
                    required
                    readonly
                    @touchstart.stop="openKeymap(true)"
                  />
                  <van-number-keyboard
                    :show="isKeymap"
                    extra-key="."
                    close-button-text="完成"
                    @blur="openKeymap(false)"
                    @input="onInput"
                    @delete="onDelete"
                  />
                  <van-field
                    v-model="lossType"
                    label="出险原因"
                    placeholder="出险原因"
                    required
                    readonly
                    @focus="rectificationTime('lossType')"
                  />
                  <van-popup v-model="lossTypeShow" position="bottom">
                    <van-picker
                      show-toolbar
                      :columns="reasonRiskLists"
                      @cancel="lossTypeShow = false"
                      @confirm="onLossTypeShow"
                    />
                  </van-popup>
                </div>

                <div v-if="projectData.orgName.indexOf('太保财险')!=-1">
                  <van-field
                    v-model="claimRelate"
                    label="报案人关系"
                    placeholder="报案人关系"
                    required
                    readonly
                    @focus="rectificationTime('claimRelate')"
                  />
                  <van-popup v-model="claimRelateShow" position="bottom">
                    <van-picker
                      show-toolbar
                      :columns="claimRelateList"
                      @cancel="claimRelateShow = false"
                      @confirm="onClaimRelateConfirm"
                    />
                  </van-popup>
                  <van-field
                    v-model="payMode"
                    label="支付方式"
                    placeholder="支付方式"
                    required
                    readonly
                    @focus="rectificationTime('payMode')"
                  />
                  <van-popup v-model="payModeShow" position="bottom">
                    <van-picker
                      show-toolbar
                      :columns="payModeList"
                      @cancel="payModeShow = false"
                      @confirm="onPayModeConfirm"
                    />
                  </van-popup>
                </div>
                <div v-if="projectData.orgName.indexOf('平安财')!=-1">
                  <!-- 报案人 -->
                  <van-field
                    v-model="baoan.caseReporter"
                    autosize
                    label="报案人"
                    placeholder="报案人姓名"
                    required
                  />
                  <!-- 报案电话 -->
                  <van-field
                    v-model="baoan.caseContact"
                    autosize
                    label="报案电话"
                    placeholder="报案电话"
                    required
                    @blur="checkPhone"
                    clearable
                  />
                  <van-field
                    v-model="baoan.claimTime"
                    label="出险时间"
                    placeholder="出险时间"
                    required
                    readonly
                    @click="getTimeShow=true"
                  />
                  <!-- 时间控件 -->
                  <van-dialog
                    v-model="getTimeShow"
                    title="选择时间"
                    show-cancel-button
                    @confirm="onSetTime"
                  >
                    <van-datetime-picker
                      v-model="currentDate"
                      type="date"
                      :formatter="formatter"
                      :show-toolbar="false"
                    />
                  </van-dialog>
                  <van-field
                    v-model="accidentCauseLevel2"
                    label="出险原因"
                    placeholder="出险原因"
                    required
                    readonly
                    @focus="rectificationTime('riskBecause')"
                  />
                  <van-popup v-model="riskBecauseShow" position="bottom">
                    <van-picker
                      show-toolbar
                      :columns="reasonRiskList"
                      @cancel="riskBecauseShow = false"
                      @confirm="onReasonConfirm"
                    />
                  </van-popup>
                  <van-field
                    v-model="baoan.accidentPlaceDetail"
                    rows="1"
                    autosize
                    type="textarea"
                    label="出险地点"
                    placeholder="出险地点"
                    required
                  />
                  <van-field
                    v-model="baoan.riskDesc"
                    rows="1"
                    autosize
                    type="textarea"
                    label="出险经过"
                    placeholder="出险经过"
                    required
                  />
                  <van-field
                    v-model="baoan.payAmout"
                    autosize
                    label="报损金额"
                    placeholder="报损金额"
                    required
                    type="number"
                    maxlength="16"
                  />
                  <van-field
                    v-model="lossType"
                    label="损伤类型"
                    placeholder="损伤类型"
                    required
                    readonly
                    @focus="rectificationTime('damageType')"
                  />
                  <van-popup v-model="damageTypeShow" position="bottom">
                    <van-picker
                      show-toolbar
                      :columns="damageTypeList"
                      @cancel="damageTypeShow = false"
                      @confirm="onDamageTypeConfirm"
                    />
                  </van-popup>
                  <!-- 暂时注释 -->
                  <!-- <van-col span="7" class="name">是否物损</van-col>
                  <van-col
                    span="16"
                    style="padding-left: 10px;font-size: 14px;padding-bottom: 10px;"
                  >
                    <van-radio-group v-model="baoan.isCargoLoss" direction="horizontal">
                      <van-radio name="Y">是</van-radio>
                      <van-radio name="N ">否</van-radio>
                    </van-radio-group>
                  </van-col>
                  <van-col span="7" class="name">是否人伤</van-col>
                  <van-col span="16" style="padding-left: 10px;font-size: 14px;">
                    <van-radio-group v-model="baoan.isInjured" direction="horizontal">
                      <van-radio name="Y">是</van-radio>
                      <van-radio name="N">否</van-radio>
                    </van-radio-group>
                  </van-col>-->
                </div>
                <van-field
                  v-model="baoan.damagedObject"
                  rows="1"
                  autosize
                  type="textarea"
                  label="受损标的"
                  placeholder="受损标的"
                  required
                />
              </van-cell-group>
            </van-col>
          </van-row>
          <!-- 现场图片背景色 -->
          <van-row style="background-color: #fff;">
            <van-col span="6" class="nameImg">
              <span style="margin-left:34%">现场图片</span>
            </van-col>
            <van-col span="16">
              <!-- <span v-for="(img, index) in baoan.imageList" :key="index">
                <van-col span="8">
                  <img :src="imagesUrl+img.imageCloudId" style="width: 76px;height: 66px;" />
                </van-col>
              </span>-->
              <van-uploader
                :after-read="afterRead"
                :before-delete="afterDelete"
                v-model="baoan.imageList.imageCloudId"
                :max-count="9"
              >
                <div class="iconfont icon-xaingji pictures-porder">
                  <div class="upload-pictures">上传图片</div>
                </div>
              </van-uploader>
            </van-col>
          </van-row>
          <van-row>
            <van-col span="22" style="margin-bottom: 5%;margin-left: 4.5%">
              <van-button
                type="info"
                size="large"
                class="btnName btnName-radius"
                @click="reqBaoan"
              >提交</van-button>
            </van-col>
          </van-row>
        </van-row>
        <van-row>
          <span v-if="tis=='OWN'">我的报案</span>
          <span v-else>小区报案</span>
          <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
            <div class="report" v-for="(item,index) of report" :key="index">
              <van-col span="24" class="title" @click="jumpDetail(item.id,item.caseReportId)">
                <div class="subhead">
                  <van-col span="16" class="time-color">{{item.createdDate}}</van-col>
                  <van-col
                    v-if="tis=='OWN'"
                    span="8"
                    style="text-align:right;color:#F00;width: 100%"
                  >{{item.complete=== null?' ':'确认修复完成'}}</van-col>
                  <van-col
                    v-else
                    span="8"
                    style="text-align:right;color:#F00;width: 100%"
                  >{{item.complete==='已结案'?'修复完成(已结案)':'' || item.wyRepair==='Y'?'修复完成':''}}</van-col>
                </div>
                <div style="subhead-style"></div>
                <div class="subhead1">
                  <van-col span="24">
                    事件类型：
                    <span>{{item.type}}</span>
                  </van-col>
                  <van-col span="24">
                    报案号：
                    <span>{{item.insCaseReportId}}</span>
                  </van-col>
                  <van-col span="24">
                    事件描述：
                    <span>{{item.riskDesc}}</span>
                  </van-col>
                </div>
              </van-col>
            </div>
          </van-list>
        </van-row>
      </div>
    </div>
    <!-- 当没有小区时展示的文字 -->
    <div style="background: #F2F2F2;" v-else>
      <div class="color-background"></div>
      <div>请到设置里"我的项目"进行添加</div>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "ownerReport",
  components: {},
  data() {
    return {
      dealImgWidth: 600,
      disabled: false,
      tis: undefined,
      title: "查询",
      images: [
        "https://img.yzcdn.cn/vant/apple-1.jpg",
        "https://img.yzcdn.cn/vant/apple-2.jpg"
      ],
      baoan: {
        projectId: "",
        // 保单号
        insContractNo: "",
        address: "",
        // 所属楼栋
        riskBldings: "",
        // 事件类型
        riskEventType: "",
        // 缺陷描述
        riskDesc: "",
        // 损失估计
        amountDemage: "",
        // 报案人
        caseReporter: null,
        // 受损标的
        damagedObject: "",
        // 出险原因
        lossType: "",
        // 出险时间
        claimTime: null,
        // 报案人关系
        claimRelate: null,
        // 支付方式
        payMode: null,
        // 损伤类型
        lossType: null,
        // 开户姓名
        payName: null,
        // 开户行账号
        bankNo: null,
        // 开户行名称
        bankName: null,
        // 客户类型
        clientType: null,
        // 收款途径
        collectPayApproach: null,
        // 保险公司
        claimHanleCompany: null,
        sqlStatus: 1,
        // 现场图片
        imageList: [],
        caseReporter: "",
        caseContact: "",
        accidentPlaceDetail: "",
        isCargoLoss: "Y",
        isInjured: "N",
        riskDesc: "",
        payAmout: ""
      },
      // 损伤类型
      lossType: "",
      accidentCauseLevel2: "",
      // 事件类型
      riskEventType: "",
      // 出险原因
      lossType: "",
      // 报案人关系
      claimRelate: "",
      // 开户行名称
      bankName: "",
      // 客户类型
      clientType: "",
      // 支付方式
      payMode: "",
      // 收款途径
      collectPayApproach: "",
      riskBldings: [],
      // 获取时间
      currentDate: new Date(),
      // 打开数字键盘
      isKeymap: false,
      riskBldingsShow: false,
      riskEventTypeShow: false,
      riskBecauseShow: false,
      lossTypeShow: false,
      claimRelateShow: false,
      clientTypeShow: false,
      payModeShow: false,
      damageTypeShow: false,
      bankNameShow: false,
      collectPayApproachShow: false,
      getTimeShow: false,
      result: ["a", "b"],
      // 字典表
      // 事件类型
      eventTypeList: [],
      // 出险原因
      reasonRiskList: [],
      reasonRiskLists: [],
      // 报案人关系
      claimRelateList: [],
      // 支付方式
      payModeList: [],
      // 损伤类型
      damageTypeList: [],
      // 客户类型
      clientTypeList: [],
      // 开户行名称
      bankNameList: [],
      // 收付途径
      collectPayList: [],

      showPicker: false, //打开选择器
      //风险类型
      riskEventTypeConfirm() {},
      // 我的报案
      report: [],
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      // 触底加载
      loading: false,
      finished: false,
      // 当前页数
      offset: 0,
      // 控制所属栋楼'其他'
      isOther: false,
      // 定义'其他'数组
      otherList: ["其他"],
      // 所属栋楼输入框
      floorOthers: ""
    };
  },
  computed: {
    ...mapGetters(["houseList", "selectedPrj", "projectData", "isDataList1"])
  },
  watch: {
    selectedPrj: function(newVal, oldVal) {
      if (newVal.id === oldVal.id) {
        return;
      }
      this.finished = false;
      this.offset = 0;
      (this.riskBldings = []),
        (this.baoan = {
          projectId: "",
          // 保单号
          insContractNo: "",
          address: "",
          // 所属楼栋
          riskBldings: "",
          // 事件类型
          riskEventType: "",
          // 缺陷描述
          riskDesc: "",
          // 损失估计
          amountDemage: "",
          // 报案人
          caseReporter: null,
          // 受损标的
          damagedObject: "",
          // 出险原因
          lossType: "",
          // 出险时间
          claimTime: null,
          // 报案人关系
          claimRelate: null,
          // 支付方式
          payMode: null,
          // 损伤类型
          lossType: null,
          // 开户姓名
          payName: null,
          // 开户行账号
          bankNo: null,
          // 开户行名称
          bankName: null,
          // 客户类型
          clientType: null,
          // 收款途径
          collectPayApproach: null,
          // 保险公司
          claimHanleCompany: null,
          sqlStatus: 1,
          // 现场图片
          imageList: [],
          caseReporter: "",
          caseContact: "",
          accidentPlaceDetail: "",
          isCargoLoss: "Y",
          isInjured: "N",
          riskDesc: "",
          payAmout: ""
        });
      // 损伤类型
      (this.lossType = ""),
        // 重新获取一遍报案人
        (this.accidentCauseLevel2 = ""),
        this.getUserId();
      this.riskEventType = "";
      // 事件类型
      this.riskEventType = "";
      // 出险原因
      this.lossType = "";
      // 报案人关系
      this.claimRelate = "";
      // 损伤类型
      // 开户行名称
      this.bankName = "";
      // 客户类型
      this.clientType = "";
      // 支付方式
      this.payMode = "";
      // 收款途径
      this.collectPayApproach = "";
      (this.report = []),
        // 所属栋楼输入框
        (this.floorOthers = "");
      // 切换小区后,关闭'其他'
      this.isOther = false;
      // 由于'其他'多选框是单独分离出来,所以提交成功后将checked置为false
      if (this.$refs.otherCheckboxes) {
        this.$refs.otherCheckboxes.forEach(_check => {
          _check.checked = false;
        });
        if (this.$refs.checkboxes) {
          // 提交后多选框选中的楼栋,将checked置为false
          this.$refs.checkboxes.forEach(_check => {
            check.checked = false;
          });
        }
      }
    }
  },

  // created(){
  //   this.getMyReportCase()
  // },
  methods: {
    ...mapActions(["getProjectList"]),
    checkPhone() {
      if (this.baoan.caseContact.length !== 11) {
        this.$toast("请输入正确手机号");
        return;
      }
      var reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
      if (!reg.test(this.baoan.caseContact)) {
        this.$toast("请输入正确手机号");
        return;
      }
    },
    toggle(item, index) {
      this.$refs.checkboxes[index].toggle();
      // 将选中的添加到 blidings 数组内
      if (this.$refs.checkboxes[index].checked == false) {
        this.riskBldings.push(this.$refs.checkboxes[index].name.buildingName);
      } else if (this.$refs.checkboxes[index].checked == true) {
        // 如果复选框为打开状态时，则关闭，删除所选
        // 使用findIndex获取索引值
        let inx = this.riskBldings.findIndex(_name => {
          return _name == item.buildingName;
        });
        this.riskBldings.splice(inx, 1);
      }
    },
    // 确认后将数组，放到页面展示
    onBldingsConfirm(action, done) {
      if (action === "cancel") {
        this.$refs.checkboxGroup.toggleAll(false);
        this.riskBldings = [];
        this.baoan.riskBldings = this.riskBldings.toString();
        done();
      } else if (action === "confirm") {
        this.baoan.riskBldings = this.riskBldings.toString();
      }
      done();
    },
    // 所属栋楼,点击'其他'事件
    otherToggle(iteam, index) {
      const _this = this;
      this.$refs.otherCheckboxes[index].toggle();
      if (this.$refs.otherCheckboxes[index].checked == false) {
        // true, 表示'其他'选中, 其他复选框无法点击
        this.isOther = true;
        // 选中后,将所有已选小区复选框置空
        this.$refs.checkboxes.forEach(_check => {
          _check.checked = false;
        });
        // 如果勾选了栋楼,则需要清空输入框,否则无限添加栋楼
        this.riskBldings = [];
        this.baoan.riskBldings = "";
      } else if (this.$refs.otherCheckboxes[index].checked == true) {
        this.isOther = false;
      }
    },
    // 选择出险类型
    onTypeConfirm(value, index) {
      this.riskEventType = value.dictValue;
      this.riskEventTypeShow = false;
    },
    // 选择原因
    onReasonConfirm(value, index) {
      this.accidentCauseLevel2 = value.dictValue;
      this.riskBecauseShow = false;
    },
    onLossTypeShow(value, index) {
      this.lossType = value.dictValue;
      this.lossTypeShow = false;
    },
    // 选择报案人关系
    onClaimRelateConfirm(value, index) {
      this.claimRelate = value.dictValue;
      this.claimRelateShow = false;
    },
    // 选择支付方式
    onPayModeConfirm(value, index) {
      this.payMode = value.dictValue;
      this.payModeShow = false;
    },
    // 损伤类型
    onDamageTypeConfirm(value, index) {
      this.lossType = value.dictValue;
      this.damageTypeShow = false;
    },
    // 客户类型
    onClientTypeConfirm(value, index) {
      this.clientType = value.dictValue;
      this.clientTypeShow = false;
    },
    // 开户行名称
    onBankNameConfirm(value, index) {
      this.bankName = value.dictValue;
      this.bankNameShow = false;
    },
    // 收付途径
    onCollectPayConfirm(value, index) {
      this.collectPayApproach = value.dictValue;
      this.collectPayApproachShow = false;
    },
    // 触发弹窗列表
    rectificationTime(val) {
      if (val == "riskBldings") {
        this.riskBldingsShow = true;
      } else if (val == "riskEventType") {
        this.riskEventTypeShow = true;
      } else if (val == "riskBecause") {
        this.riskBecauseShow = true;
      } else if (val == "claimRelate") {
        this.claimRelateShow = true;
      } else if (val == "clientType") {
        this.clientTypeShow = true;
      } else if (val == "payMode") {
        this.payModeShow = true;
      } else if (val == "damageType") {
        this.damageTypeShow = true;
      } else if (val == "bankName") {
        this.bankNameShow = true;
      } else if (val == "collectPayApproach") {
        this.collectPayApproachShow = true;
      } else if (val == "lossType") {
        this.lossTypeShow = true;
      }
    },
    // 获取时间
    // 转化时间格式
    formatDate(now) {
      var year = now.getFullYear();
      var month = now.getMonth() + 1;
      var date = now.getDate();
      return year + "-" + month + "-" + date;
    },
    // 过滤面板时间
    formatter(type, value) {
      if (type === "year") {
        return `${value}年`;
      } else if (type === "month") {
        return `${value}月`;
      } else if (type === "day") {
        return `${value}日`;
      }
      return value;
    },
    // 设置时间
    onSetTime() {
      this.baoan.claimTime = this.formatDate(this.currentDate);
    },
    // 弹出数字键盘
    openKeymap(value) {
      this.isKeymap = value;
    },
    onInput(value) {
      // 检测'.'是否存在
      if (this.baoan.amountDemage.indexOf(".") > -1 && value == ".") {
        return;
      }
      this.baoan.amountDemage += String(value);
    },
    onDelete() {
      this.baoan.amountDemage = this.baoan.amountDemage.slice(
        0,
        this.baoan.amountDemage.length - 1
      );
    },
    // 上传图片，调取摄像头
    async afterRead(param) {
      this.disabled = true;
      param.status = "uploading";
      param.message = "上传中";
      var toFile = param.file;
      if (toFile.type.startsWith("image") && toFile.size > 1024 * 1024) {
        var _this = this;
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        );
        toFile = _this.$dataURLtoFile(base64, toFile.name);
      }
      // 此时可以自行将文件上传至服务器
      let file = new FormData();
      file.append("file", toFile);
      file.append("fileIcon", "caseReportImage");
      file.append("projectId", this.selectedPrj.projectId);
      http.post("/processDoc/uploadProcessPicsTmp", file).then(res => {
        if (res.code === 0) {
          this.baoan.imageList.push({
            imageCloudId: res.data.cloudDocIdTmp,
            imageCloudPath: res.data.cloudPath
          });
          this.disabled = false;
          param.status = "done";
        } else {
          this.disabled = true;
          param.status = "failed";
          param.message = "上传失败";
        }
      });
    },
    // 删除图片
    afterDelete(file, detail) {
      return this.baoan.imageList.splice(detail.index, 1);
    },
    // 获取事件类型字典表
    getRiskEventType() {
      this.eventTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_TYPE;
      this.eventTypeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取出险原因
    getCpicClaimReason() {
      this.reasonRiskList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PA_CLAIM_REASON;
      this.reasonRiskList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取出险原因
    getCpicClaimReasons() {
      this.reasonRiskLists = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_CPIC_CLAIM_REASON;
      this.reasonRiskLists.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取报案人关系
    getClaimRelate() {
      this.claimRelateList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_CPIC_CLAIM_RELATE;
      this.claimRelateList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取支付方式
    getPayMode() {
      this.payModeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_CPIC_PAY_MODE;
      this.payModeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取损伤类型
    getDamageType() {
      this.damageTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PA_DAMAGE_TYPE;
      this.damageTypeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取客户类型
    getClientType() {
      this.clientTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PA_CILENT_TYPE;
      this.clientTypeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取开户行名称(如果报错,找后端)
    getBankName() {
      this.bankNameList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PA_BANK_CODE;
      this.bankNameList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取收付途径
    getCollectPay() {
      this.collectPayList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PA_PAY_APPROACH;
      this.collectPayList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取 userId
    getUserId() {
      this.baoan.caseReporter = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).userId;
    },
    // 将事件类型,出险原因转换成key
    setCode() {
      this.eventTypeList.map(_data => {
        if (_data.dictValue == this.riskEventType) {
          this.baoan.riskEventType = _data.dictKey;
        }
      });
      this.reasonRiskList.map(_data => {
        if (_data.dictValue == this.accidentCauseLevel2) {
          this.baoan.accidentCauseLevel2 = _data.dictKey;
        }
      });
      this.reasonRiskLists.map(_data => {
        if (_data.dictValue == this.lossType) {
          this.baoan.lossType = _data.dictKey;
        }
      });
    },

    // 将报案人关系,支付方式转换成key
    setClaimPay() {
      this.claimRelateList.map(_data => {
        if (_data.dictValue == this.claimRelate) {
          this.baoan.claimRelate = _data.dictKey;
        }
      });
      this.payModeList.map(_data => {
        if (_data.dictValue == this.payMode) {
          this.baoan.payMode = _data.dictKey;
        }
      });
    },
    // 将损伤类型,客户类型,开户行名称,收付途径
    setDamageClientBankNameCollectPay() {
      this.damageTypeList.map(_data => {
        if (_data.dictValue == this.lossType) {
          this.baoan.lossType = _data.dictKey;
        }
      });
      this.clientTypeList.map(_data => {
        if (_data.dictValue == this.clientType) {
          this.baoan.clientType = _data.dictKey;
        }
      });
      this.bankNameList.map(_data => {
        if (_data.dictValue == this.bankName) {
          this.baoan.bankName = _data.dictKey;
        }
      });
      this.collectPayList.map(_data => {
        if (_data.dictValue == this.collectPayApproach) {
          this.baoan.collectPayApproach = _data.dictKey;
        }
      });
    },
    // 前进行非空校验,请求接口上传数据
    reqBaoan() {
      if (this.isOther == false && this.baoan.riskBldings === "") {
        this.$toast("所属楼栋不能为空");
        return false;
      } else if (this.isOther && this.floorOthers === "") {
        this.$toast("所属楼栋不能为空");
        return false;
      } else if (this.baoan.address === "") {
        this.$toast("我的地址不能为空");
        return false;
      } else if (this.riskEventType === "") {
        this.$toast("事件类型不能为空");
        return false;
      } else if (
        this.baoan.riskDesc === "" &&
        this.projectData.orgName.indexOf("中国大地") != -1
      ) {
        this.$toast("事件描述不能为空");
        return false;
      } else if (
        this.baoan.claimTime === null &&
        this.projectData.orgName === "太保财险"
      ) {
        this.$toast("出险时间不能为空");
        return false;
      } else if (
        this.lossType === "" &&
        this.projectData.orgName === "中国大地"
      ) {
        this.$toast("出险原因不能为空");
        return false;
      } else if (
        this.claimRelate === "" &&
        this.projectData.orgName === "太保财险"
      ) {
        this.$toast("报案人关系不能为空");
        return false;
      } else if (
        this.payMode === "" &&
        this.projectData.orgName === "太保财险"
      ) {
        this.$toast("支付方式不能为空");
        return false;
      } else if (
        (this.lossType === "" || this.lossType === null) &&
        this.projectData.orgName === "平安财险"
      ) {
        this.$toast("损伤类型不能为空");
        return false;
      } else if (
        this.clientType === "" &&
        this.projectData.orgName === "平安财险"
      ) {
        this.$toast("客户类型不能为空");
        return false;
      } else if (this.baoan.damagedObject === "") {
        this.$toast("受损标的不能为空");
        return false;
      } else if (
        this.accidentCauseLevel2 === "" &&
        this.projectData.orgName === "平安财险"
      ) {
        this.$toast("出险原因不能为空");
        return false;
      }
      /*
       **  校验完成后,将选好的字段转换成key
       */
      // 上传前将原因还是事件转换成key
      this.setCode();
      if (this.projectData.orgName === "太保财险") {
        this.setClaimPay();
      }
      if (this.projectData.orgName.indexOf("平安财") != -1) {
        this.checkPhone();
        this.setDamageClientBankNameCollectPay();
      }
      // 提交报案接口
      // 接口更改后,由一个对象 => 改两个对象入参不变
      // sqlStatus 为必传字段
      // 如果有手动输入栋楼,需要将栋楼拼接到地址后面
      if (this.isOther) {
        this.baoan.address = this.baoan.address + this.floorOthers;
      }
      const _this = this;
      const keywords = {
        insCaseReportDO: this.baoan,
        insClaimDO: {
          sqlStatus: 1
        }
      };
      http
        .post("/insurance/InsCaseReport/externalPrjClaim", keywords)
        .then(res => {
          if (res.code === 0) {
            // 暂时使用刷新页面方式清理输入框
            _this.report = [];
            _this.offset = 0;
            _this.finished = false;
            _this.$toast("报案成功");
            // 清空输入框所有字段
            _this.riskBldings = [];
            _this.baoan = {
              projectId: "",
              // 保单号
              insContractNo: "",
              address: "",
              // 所属楼栋
              riskBldings: "",
              // 事件类型
              riskEventType: "",
              // 缺陷描述
              riskDesc: "",
              // 损失估计
              amountDemage: "",
              // 受损标的
              damagedObject: "",
              // 出险原因
              lossType: "",
              // 出险时间
              claimTime: null,
              // 报案人关系
              claimRelate: null,
              // 支付方式
              payMode: null,
              // 损伤类型
              lossType: null,
              // 开户姓名
              payName: null,
              // 开户行账号
              bankNo: null,
              // 开户行名称
              bankName: null,
              // 客户类型
              clientType: null,
              // 收款途径
              collectPayApproach: null,
              // 保险公司
              claimHanleCompany: null,
              sqlStatus: 1,
              // 现场图片
              imageList: [],
              caseReporter: "",
              caseContact: "",
              accidentPlaceDetail: "",
              isCargoLoss: "Y",
              isInjured: "N",
              riskDesc: "",
              payAmout: ""
            };
            (_this.lossType = ""),
              (_this.accidentCauseLevel2 = ""),
              // 重新获取一遍报案人
              _this.getUserId();
            // 这里清空,是因为将数据弹框内的输入框清空
            _this.riskEventType = "";
            // 事件类型
            _this.riskEventType = "";
            // 出险原因
            _this.lossType = "";
            // 报案人关系
            _this.claimRelate = "";
            // 开户行名称
            _this.bankName = "";
            // 客户类型
            _this.clientType = "";
            // 支付方式
            _this.payMode = "";
            // 收款途径
            _this.collectPayApproach = "";
            (_this.report = []),
              // 所属栋楼输入框
              (_this.floorOthers = "");
            // 提交成功后,关闭'其他'
            (_this.isOther = false),
              // 由于'其他'多选框是单独分离出来,所以提交成功后将checked置为false
              _this.$refs.otherCheckboxes.forEach(_check => {
                _check.checked = false;
              });
            // 提交后多选框选中的楼栋,将checked置为false
            _this.$refs.checkboxes.forEach(_check => {
              _check.checked = false;
            });
          } else if (res.code === 1) {
            _this.$toast(res.msg);
          }
        });
    },

    /**
     *  获取我的报案列表
     */
    getMyReportCase(userId, projectId) {
      const _this = this;
      const keywords = {
        limit: 5,
        offset: this.offset,
        projectId: projectId
      };
      if (this.tis == "OWN") {
        keywords.caseReporter = userId;
      }
      http
        .get("/insurance/InsCaseReport", keywords)
        .then(res => {
          if (res.code === 0) {
            _this.report = _this.report.concat(res.data.rows);

            // 遍历拿到的数据
            _this.report.map(_data => {
              // 遍历字典表
              _this.eventTypeList.map(_text => {
                // 判断返回数据与字典表相同
                if (_data.riskEventType === _text.dictKey) {
                  _data.type = _text.dictValue;
                }
              });
            });
            if (_this.report.length >= res.data.total) {
              _this.finished = true;
            }
          } else {
            _this.finished = true;
          }
        })
        .catch(err => {
          _this.finished = true;
        });
    },
    // 跳转详情
    jumpDetail(id, caseReportId) {
      this.$router.push({
        path: "ownerReportDetail",
        query: {
          id: id,
          caseReportId: caseReportId
        }
      });
    },
    onLoad() {
      // 下拉加载数据
      setTimeout(() => {
        this.loading = false;
        if (this.selectedPrj.projectId) {
          this.offset += 1;
          this.getMyReportCase(
            this.selectedPrj.userId,
            this.selectedPrj.projectId
          );
        } else {
          // 如果没有projectId则不能进行查询,并终止
          this.finished = true;
        }
      }, 500);
    }
  },
  created() {
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
    // 事件类型
    this.getRiskEventType();
    // 出险原因
    this.getCpicClaimReason();
    this.getCpicClaimReasons();
    // 报案人关系
    this.getClaimRelate();
    // 支付方式
    this.getPayMode();
    // 损伤类型
    this.getDamageType();
    // 客户类型
    this.getClientType();
    // 收付途径
    this.getCollectPay();
    // 获取 userId
    this.getUserId();
    this.finished = false;
    // 开户行名称
    // 由于缓存中没有开户行字段,所以会报错,暂时注掉
    // this.getBankName()
  },
  updated() {
    this.baoan.projectId = this.selectedPrj.projectId;
    this.baoan.insContractNo = this.selectedPrj.insContractNo;
    this.baoan.claimHanleCompany = this.projectData.orgName;
  }
};
</script>
<style lang="less" scoped>
.content {
  margin: 0 15/16rem;
  text-align: left;
}
.van-swipe {
  height: 238/16rem;
}
.van-swipe img {
  width: 100%;
  height: 100%;
}
.nav {
  margin: 10.5/16rem 0;
  text-align: center;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.nav img {
  width: 100%;
  height: 100%;
}
.form {
  margin: 10.5/16rem 0;
  text-align: left;
  background: #ffffff;
  border-radius: 8/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.form .van-cell-group__title {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-bottom: 15/16rem;
}
.form .van-field {
  padding-left: 30/16rem;
}
.form .van-cell--required::before {
  position: absolute;
  left: 22/16rem;
}
.form .van-field__label {
  width: 75/16rem;
}
.nameImg {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-top: 18/16rem;
}
.van-field__control {
  background-color: #f2f3f5;
}
.van-cell span {
  margin-left: 25/16rem;
}
.report {
  margin: 10/16rem 0;
  text-align: left;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
  padding-bottom: 15/16rem;
}
::after {
  // 清除浮动,自动获取高度
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.report .title {
  padding: 0 15/16rem;
}
.report .subhead {
  line-height: 30/16rem;
}
.report .subhead1 {
  line-height: 26/16rem;
  margin-top: 10/16rem;
}
.report .subhead1 span {
  color: #595959;
}
/deep/ .van-uploader {
  margin: 10/16rem 0;
}
.time-color {
  color: #757575;
}
// 上传图片一行展示三张图片
/deep/ .van-uploader__preview {
  margin: 0 5/16rem 5/16rem 0;
}
// 背景底色
.color-background {
  background: #f2f2f2;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.subhead-style {
  width: 100%;
  margin: 0 auto;
  border-bottom: 1/16rem solid #ebedf0;
}
.btnName-radius {
  border-radius: 8/16rem;
  margin-top: 20/16rem;
}
.upload-pictures {
  font-size: 10/16rem;
}
.pictures-porder {
  font-size: 30/16rem;
  text-align: center;
  border: 1/16rem solid #c5c5c5;
  width: 78/16rem;
  height: 68/16rem;
  padding-top: 10/16rem;
  margin-left: 18/16rem;
}
.name {
  font-size: 14px;
  padding-left: 10px;
  text-align: center;
}
</style>
<template>
  <div style="background:#F2F2F2;">
    <van-nav-bar
      left-text="返回"
      left-arrow
      class="mc-navbar"
      @click-left="back"
      :title="selectedPrj.communityName"
    ></van-nav-bar>
    <div class="detail-padding">
      <div class="ertivcalLine"></div>
      <span class="blue font-bold ertivcalLine-font">理赔进度</span>
    </div>
    <!-- 内容 -->
    <div class="mask">
      <van-row class="content">
        <van-steps
          direction="vertical"
          :active="0"
          :active-icon="checked_icon"
          :inactive-icon="unChecked_icon"
        >
          <van-step v-for="(item, index) in stepList" :key="index">
            <i class="sam"></i>
            <h3>{{item.claimHandleProgress | filterCode(listBaseData,'dictValue','dictKey')}}</h3>
            <p>{{item.progressDate}}</p>
          </van-step>
        </van-steps>
      </van-row>
    </div>
    <div class="mask">
      <van-row class="contents">
        <div class="subhead">
          <van-col span="12">报案号: {{claimsData.insCaseReportId}}</van-col>
          <!-- <van-col span="12" style="text-align:right">{{}}</van-col> -->
        </div>
        <!-- <div class="line-divider"></div> -->
        <van-divider class="line-divider"/>
        <div class="subhead1">
          <van-col span="24">
            <van-col span="8" class="subhead1-weight">赔偿条款名称：</van-col>  
            <van-col span="16">{{claimsData.claimTermName?claimsData.claimTermName: '空'}}</van-col>
          </van-col>
          <van-col span="24">
            <van-col span="8" class="subhead1-weight">赔偿项目名称：</van-col>
            <van-col span="16">{{claimsData.claimItemName?claimsData.claimItemName: '空'}}</van-col>

          </van-col>
          <van-col span="24">
            <van-col span="8" class="subhead1-weight">所属楼栋：</van-col>   
            <van-col span="16">{{claimsData.riskBldings?claimsData.riskBldings: '其他'}}</van-col>
          </van-col>
          <van-col span="24">
            <van-col span="8" class="subhead1-weight">赔偿金额：</van-col> 
            <van-col span="16">{{money?money: 0 | numberFormat()}} 元</van-col>
          </van-col>
          <van-col span="24">
            <van-col span="8" class="subhead1-weight">报案受理公司：</van-col> 
           
            <van-col span="16">{{claimsData.claimHanleCompany?claimsData.claimHanleCompany: '暂无'}}</van-col>
          </van-col>
          <van-col span="24">
            <van-col span="8" class="subhead1-weight">理赔用时：</van-col> 
            
            <van-col span="16" v-if="timeDifference !== ''">{{timeDifference + 1}} 天</van-col>
            <van-col span="16" v-else>计算中</van-col>
          </van-col>
        </div>
      </van-row>
    </div>
    <!-- 描述 -->
    <div class="mask">
      <van-row class="contents">
        <div class="subhead">
          <van-col span="12">描述</van-col>
        </div>
        <van-divider class="line-divider" />
        <div class="subhead2">
          <van-col span="24">{{claimsData.remark?claimsData.remark: '暂无描述'}}</van-col>
        </div>
      </van-row>
    </div>
    <!-- 图片 -->
    <div class="mask mask-bottom">
      <van-row class="contents">
        <div class="subhead">
          <van-col span="12">现场图片</van-col>
        </div>
        <van-divider class="line-divider" />
        <div class="subhead3" v-if="liveImages.length !== 0">
          <van-col span="8" v-for="(item, index) in liveImages" :key="index">
            <van-image width="100" height="100" fit="cover" :src="item.imgUrl" />
          </van-col>
        </div>
        <div v-else>
          <span class="subhead3-img">暂无上传现场图片</span>
        </div>
      </van-row>
    </div>
    <div class="back-button">
      <van-button type="info" size="large" @click="back">返回</van-button>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex"
import http from "@/common/request"
import { numberFormat } from "@/utils"
export default {
  name: "ownerCommunity",
  components: {},
  data() {
    return {
      listBaseData: [],
      title: "查询",
      stepList: [],
      checked_icon: require("@/assets/imgs/owner-images/icon_pending.png"),
      unChecked_icon: require("@/assets/imgs/owner-images/icon_completed.png"),
      claimsData: {},
      timeDifference: "",
      liveImages: [],
      // 展示的金额数,由所有理赔进度返回的金额总数
      money: 0
    };
  },
  computed: {
    ...mapGetters(["selectedPrj"])
  },
  filters:{
    tatusFilter(status){
      const statusMap = {
        published:"success",
        draft:"info",
        deleted:"danger"
      };
      return statusMap[status];
    },
    numberFormat
  },
  methods: {
    ...mapActions([]),
    back() {
      this.$router.go(-1);
    },
    // 获取详情
    getDetail() {
      const _this = this;
      const keywords = {
        sqlStatus: '1',
        claimId: this.$route.query.claimId,
        isPage: false
      };
      http.get("/insurance/InsClaimDetail", keywords).then(res => {
        if (res.code === 0) {
          _this.stepList = res.data;
          if (_this.stepList.length > 1) {
            // 计算时间
            let endTime = _this.stepList[0].progressDate;
            let startTime =
              _this.stepList[_this.stepList.length - 1].progressDate;
            endTime = Date.parse(endTime.substr(0, endTime.indexOf(" ")));
            startTime = Date.parse(startTime.substr(0, startTime.indexOf(" ")));
            _this.timeDifference = Math.floor(
              Math.abs(endTime - startTime) / (24 * 3600 * 1000)
            );
          }
          // 计算所有金额
          _this.stepList.map(_money => {
            _this.money += _money.claimAmount
          })
        }
      });
    },
    // 获取现场图片
    getImages() {
      const _this = this;
      const keywords = { insCaseReportId: this.$route.query.caseReportId };
      http.get("/insurance/InsCaseReport/caseImages", keywords).then(res => {
        if (res.code === 0) {
          _this.liveImages = res.data;
          _this.liveImages.map(_url => {
            _url.imgUrl =
              "/api/processDoc/downloadProcessDoc?cloudDocId=" +
              _url.imageCloudId;
          });
        }
      });
    }
  },
  created() {
     this.listBaseData = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_CLAIM_HANDLE_PROGRESS;
    this.claimsData = this.$route.query;
    this.getDetail();
    this.getImages();
  }
};
</script>
<style lang="less" scoped>
.ertivcalLine {
  width: 4/16rem;
  background: #128feb;
  height: 15/16rem;
  float: left;
  margin-top: 4/16rem;
  margin-left: 5%;
}
.mask {
  width: 100%;
  background: #fff;
  padding-bottom: 5/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.content {
  margin: 0 30/16rem;
  text-align: left;
}
.content /deep/ .van-step__title {
  background: #f2f2f2;
}
.contents {
  background: #fff;
  margin: 10/16rem 20/16rem;
  text-align: left;
}
.contents /deep/ .subhead {
  font-family: PingFangSC-Medium;
  font-size: 16/16rem;
  font-weight: bold;
  color: #000000;
  padding: 10/16rem 0 7/16rem 0;
}
.contents /deep/ .subhead1 {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #000000;
  line-height: 20/16rem;
  margin-left: 15/16rem;
  margin-top: 15/16rem;
}
.contents /deep/ .subhead1 .van-col {
  margin-bottom: 6/16rem;
}
.contents /deep/ .subhead2 {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #595959;
  line-height: 20/16rem;
  margin-left: 15/16rem;
  margin-top: 15/16rem;
}
.contents /deep/ .subhead3 {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #595959;
  line-height: 20/16rem;
  margin-left: 15/16rem;
  margin-top: 15/16rem;
}
// 步骤条背景色
.content /deep/ .van-step__title {
  background-color: #fff;
}
.content /deep/ .van-step--vertical {
  padding: 0;
}
.content /deep/ .sam {
  width: 0;
  height: 0;
  border-top: 5/16rem solid transparent;
  border-bottom: 5/16rem solid transparent;
  border-right: 5/16rem solid #f2f2f2;
  position: absolute;
  left: 5/16rem;
  top: 20/16rem;
}
.content /deep/ .van-step__title h3 {
  font-size: 16/16rem;
  position: relative;
  top: 12/16rem;
  color: #595959;
  margin-left: 5/16rem;
}
.content /deep/ .van-step__title p {
  font-size: 12/16rem;
  color: #969799;
  margin-left: 5/16rem;
}
.content /deep/ img.van-image__img {
  width: 20/16rem;
  height: 20/16rem;
  position: relative;
  left: -3/16rem;
}
// 步骤条左侧样式
.content /deep/ .van-step__circle-container,
.content /deep/ .van-step__line {
  margin-top: 5/16rem;
}
.content /deep/ .van-step__line {
  top: 30/16rem;
}
.content /deep/ .van-step__title {
  margin-left: 10/16rem;
  background-color: #f2f2f2;
  border-radius: 7/16rem;
}
.content /deep/ .van-step--vertical:not(:last-child)::after {
  border-bottom: 0;
}
// 返回按钮,固定在底部
.back-button {
  position: fixed;
  bottom: 0;
  width: 100%;
}
.subhead1-weight{
  font-weight: 700
}
.subhead3-img{
   font-size: 14/16rem;
   color: #595959;
   line-height: 20/16rem;
   margin-left:15/16rem;
}
.mask-bottom{
   margin-bottom:50/16rem;
   box-shadow:0 0 0;
}
.ertivcalLine-font{
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128FEB;
  margin-left:-72%;
  font-weight: 700;
}
.detail-padding{
  padding:10/16rem 0;
  background:#fff;
}
.line-divider{
  width: 100%;
}
</style>
 
<template>
  <div>
    <div style="background: #F2F2F2;" v-if="isDataList1">
      <div class="color-background"></div>
      <!-- 内容 -->
      <div class="content">
        <!-- 主内容 -->
        <van-row class="home">
          <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
            <div class="report" v-for="(item,index) of report" :key="index">
              <van-col span="24" class="title" @click="jump(item)">
                <div class="subhead">
                  <van-col span="12">报案号：{{item.insCaseReportId}}</van-col>
                  <van-col
                    span="12"
                    style="text-align:right;"
                    class="blueColor"
                    :class="{redColor:item.claimHandleProgress==='已结案'}"
                  >{{item.claimHandleProgress | filterCode(listBaseData,'dictValue','dictKey')}}</van-col>
                </div>
                <!-- <div style="width:100%; margin: 0 auto">
                  <van-col span="24" style="margin: -25px 0">
                    <van-divider />
                  </van-col>
                </div>-->
                <div class="subhead1">
                  <!-- 点点--左 -->
                  <i class="point-left" />
                  <!-- 点点--右 -->
                  <i class="point-right" />
                  <van-col span="24">
                    <van-col span="7" class="subhead1-weight">赔偿项目名称：</van-col>
                    <van-col span="17">{{item.claimItemName}}</van-col>
                  </van-col>
                  <van-col span="24">
                    <van-col span="7" class="subhead1-weight">所属楼栋：</van-col>
                    <van-col span="17">{{item.riskBldingsName?item.riskBldingsName:'其他'}}</van-col>
                  </van-col>
                  <van-col span="24">
                    <van-col span="7" class="subhead1-weight">报案受理公司：</van-col>
                    <van-col span="17">{{item.claimHanleCompany}}</van-col>
                  </van-col>
                  <!-- <van-col span="24">
                    理赔用时：
                    <span>{{item.day}}天</span>
                  </van-col>-->
                </div>
              </van-col>
            </div>
          </van-list>
        </van-row>
      </div>
    </div>
    <!-- 当没有小区时展示的文字 -->
    <div style="background: #F2F2F2;" v-else>
      <div class="color-background"></div>
      <div>请到设置里"我的项目"进行添加</div>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "ownerCommunity",
  components: {},
  data() {
    return {
      listBaseData: [],
      title: "查询",
      images: [
        "https://img.yzcdn.cn/vant/apple-1.jpg",
        "https://img.yzcdn.cn/vant/apple-2.jpg"
      ],
      report: [],
      loading: false,
      finished: false,
      offset: 0
    };
  },
  computed: {
    ...mapGetters(["selectedPrj", "isDataList1"])
  },
  watch: {
    selectedPrj: function(newVal, oldVal) {
      if (newVal.id === oldVal.id || !oldVal.id) {
        return;
      }
      this.report = [];
      this.offset = 1;
      this.finished = false;
      this.getClaimList(this.selectedPrj.projectId, this.selectedPrj.userId, 1);
    }
  },
  methods: {
    ...mapActions([]),
    jump(eId) {
      this.$router.push({
        path: "/ownerClaimsDetail",
        query: eId
      });
    },
    // 获取理赔列表
    getClaimList(projectId, userId, sqlStatus) {
      this.listBaseData = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_CLAIM_HANDLE_PROGRESS;
      const _this = this;
      const keywords = {
        limit: 5,
        offset: this.offset,
        sqlStatus: sqlStatus,
        projectId: projectId
        // caseReporter: userId
      };
      http.get("/insurance/InsCaseReport/listPrjClaim", keywords).then(res => {
        if (res.code === 0) {
          _this.report = _this.report.concat(res.data.rows);
          if (res.data.rows.length < 5) {
            _this.finished = true;
          }
        }
      });
    },
    onLoad() {
      // 下拉加载数据
      this.offset += 1;
      setTimeout(() => {
        this.loading = false;
        if (this.selectedPrj.projectId) {
          this.getClaimList(
            this.selectedPrj.projectId,
            this.selectedPrj.userId,
            1
          );
        } else {
          // 如果没有projectId则不能进行查询,并终止
          this.finished = true;
        }
      }, 500);
    }
  }
};
</script>
<style lang="less" scoped>
.content {
  margin: 0 15/16rem;
  text-align: left;
}
.van-swipe {
  height: 238/16rem;
}
.van-swipe /deep/ img {
  width: 100%;
  height: 100%;
}
.nav {
  margin: 10.5/16rem 0;
  text-align: center;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
}
.nav /deep/ img {
  width: 100%;
  height: 100%;
}
.report {
  margin: 10/16rem 0;
  text-align: left;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  // height: 145px;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
  padding-bottom: 15/16rem;
}
::after {
  // 清除浮动,自动获取高度
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.report /deep/ .title {
  padding: 0 15/16rem;
}
.report /deep/ .subhead {
  line-height: 50/16rem;
  border-bottom: 1/16rem solid #eee;
  margin-bottom: 10/16rem;
}
.report /deep/ .subhead1 {
  font-size: 13/16rem;
  line-height: 26/16rem;
}
.report /deep/ .subhead1 /deep/ span {
  color: #595959;
}
/* .report  */
.color-background {
  background: #f2f2f2;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.blueColor {
  color: #4a47ff;
}
.redColor {
  color: #f00;
}
.point-left,
.point-right {
  display: inline-block;
  position: absolute;
  // margin-top: 55px;
  background-color: #f2f2f2;
  border-style: solid;
  border-width: 1/16rem;
  border-top-color: #dfdfdf;
  border-bottom-color: #dfdfdf;
}
// 点点
.point-left {
  width: 5/16rem;
  height: 13/16rem;
  left: 15/16rem;
  border-radius: 0 9/16rem 9/16rem 0;
  border-right-color: #dfdfdf;
  border-left-color: transparent;
}
.point-right {
  width: 5/16rem;
  height: 13/16rem;
  right: 15/16rem;
  border-radius: 9/16rem 0 0 9/16rem;
  border-left-color: #dfdfdf;
  border-right-color: transparent;
}
// 背景底色
.color-background {
  background: #f2f2f2;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.subhead1-weight {
  font-weight: 700;
}
</style>
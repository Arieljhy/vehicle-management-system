<template>
  <div style="background:#F2F2F2;">
    <div class="color-background"></div>
    <van-nav-bar
      left-text="返回"
      left-arrow
      class="mc-navbar"
      @click-left="back"
      :title="selectedPrj.communityName"
    ></van-nav-bar>
    <div class="communityName-padding">
      <div class="ertivcalLine"></div>
      <div class="card">
        <van-cell-group>
          <van-cell size="large">
            <van-col span="8">我的地址</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.address?reportDetail.address: '空'}}</van-col>
          </van-cell>
          <van-cell size="large">
            <van-col span="8">所属栋楼</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.riskBldings?reportDetail.riskBldings: '其他'}}</van-col>
          </van-cell>
          <van-cell size="large">
            <van-col span="8">事件类型</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.riskEventType?reportDetail.riskEventType: '空'}}</van-col>
          </van-cell>
          <van-cell size="large">
            <van-col span="8">事件描述</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.riskDesc?reportDetail.riskDesc: '空'}}</van-col>
          </van-cell>

          <van-cell size="large">
            <van-col span="8">损失估计</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.amountDemage?reportDetail.amountDemage: 0 | numberFormat()}}</van-col>
          </van-cell>
          <van-cell size="large">
            <van-col span="8">出险时间</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.caseReportData?reportDetail.caseReportData: '空'}}</van-col>
            <van-col span="16" class="detail-text"></van-col>
          </van-cell>

          <van-cell size="large">
            <van-col span="8">出险原因</van-col>
            <van-col
              span="16"
              class="detail-text"
            >{{reportDetail.lossType?reportDetail.lossType: '空'}}</van-col>
          </van-cell>
          <div v-if="reportDetail.claimHanleCompany === '太保财险'">
            <van-cell size="large">
              <van-col span="8">报案人关系</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.claimRelate?reportDetail.claimRelate: '空'}}</van-col>
            </van-cell>
            <van-cell size="large">
              <van-col span="8">支付方式</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.payMode?reportDetail.payMode: '空'}}</van-col>
            </van-cell>
          </div>

          <div v-if="reportDetail.claimHanleCompany === '平安财险'">
            <van-cell size="large">
              <van-col span="8">损伤类型</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.damageType?reportDetail.damageType: '空'}}</van-col>
            </van-cell>
            <van-cell size="large">
              <van-col span="8">客户类型</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.clientType?reportDetail.clientType: '空'}}</van-col>
            </van-cell>
            <van-cell size="large">
              <van-col span="8">开户姓名</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.payName?reportDetail.payName: '空'}}</van-col>
            </van-cell>
            <van-cell size="large">
              <van-col span="8">开户行账号</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.bankNo?reportDetail.bankNo: '空'}}</van-col>
            </van-cell>
            <van-cell size="large">
              <van-col span="8">开户行名称</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.bankName?reportDetail.bankName: '空'}}</van-col>
            </van-cell>
            <van-cell size="large">
              <van-col span="8">收付途径</van-col>
              <van-col
                span="16"
                class="detail-text"
              >{{reportDetail.collectPayApproach?reportDetail.collectPayApproach: '空'}}</van-col>
            </van-cell>
          </div>
          <van-cell size="large">
            <van-col span="8">受损标的</van-col>
            <van-col span="16" class="detail-text">{{reportDetail.damagedObject}}</van-col>
          </van-cell>
          <van-cell size="large" v-if="tis=='OWN'">
            <van-col span="8">物业评论</van-col>
            <van-col span="16" class="detail-text">
              <span v-if="reportDetail.wyRepair=='Y'" style="color: red;">(已确认维修)</span>
              <span v-if="reportDetail.wyRepair==null" style="color: red;">(未确认维修)</span>
              {{reportDetail.wyEvaluate}}
            </van-col>
          </van-cell>
        </van-cell-group>
        <van-row style="background-color: #fff;min-height: 55px;">
          <van-col span="8" class="nameImg">
            <span>现场图片</span>
          </van-col>
          <van-col span="16" >
            <span v-for="(img, index) in reportDetail.imageList" :key="index">
              <van-col span="8" style="margin-right: 10px;margin-top: 5px;">
                <img :src="imagesUrl+img.imageCloudId" class="img"   @click="imgDate(imagesUrl+img.imageCloudId)"/>
              </van-col>
            </span>
          </van-col>
        </van-row>
      </div>
      <!-- 评论模块 -->
      <div class="comment">
        <div class="card" style="background: #ffffff;">
          <div class="comment-padding">
            <span class="comment-style">评论</span>
          </div>
          <van-field
            v-model="evaluate"
            rows="2"
            autosize
            type="textarea"
            maxlength="50"
            placeholder="请输入留言"
            show-word-limit
            :disabled="isMessageRate"
          />
          <div class="ertivcalLine-padding" v-if="tis=='OWN'">
            <div class="ertivcalLine"></div>
            <van-row class="ertivcalLine-line">
              <van-col span="4">
                <span class="ertivcalLine-pingfen">评分</span>
              </van-col>
              <van-col span="8" :offset="4" class="ertivcalLine-height">
                <!-- 评分模块 -->
                <van-rate
                  v-model="score"
                  allow-half
                  void-icon="star"
                  void-color="#eee"
                  :size="26"
                  :gutter="10"
                  :readonly="isMessageRate"
                />
              </van-col>
            </van-row>
          </div>
          <!-- 提交按钮 -->
          <div class="submitRate-padding">
            <span class="submitRate-style"></span>
            <van-row>
              <van-col span="4" class="submitRate-top">
                <van-button
                  round
                  v-if="tis=='OWN'"
                  type="info"
                  size="small"
                  @click="submitRate"
                  class="submitRate-width"
                  :disabled="isMessageRate"
                >提交</van-button>
                <van-button
                  round
                  v-if="tis=='WY'&&reportDetail.wyRepair==null"
                  type="info"
                  size="small"
                  @click="confirm"
                  class="submitRate-width"
                  :disabled="isMessageRate"
                >确认维修</van-button>
                <van-button
                  round
                  v-if="tis=='WY'&&reportDetail.wyRepair=='Y'"
                  type="info"
                  size="small"
                  class="submitRate-width"
                  :disabled="disabled"
                >已确认维修</van-button>
              </van-col>
            </van-row>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import { numberFormat } from "@/utils";
import { ImagePreview } from "vant";
export default {
  name: "ownerReportDetail",
  components: {},
  data() {
    return {
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      disabled: undefined,
      tis: undefined,
      reportDetail: {},
      // 事件类型
      eventTypeList: [],
      // 出险原因
      reasonRiskList: [],
      // 评论
      evaluate: "",
      // 评分
      score: 0,
      // 控制是否可以评论,和评分, true: 表示有值,则不可以评论
      isMessageRate: true
    };
  },
  computed: {
    ...mapGetters(["selectedPrj"])
  },
  created() {
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
    if (this.tis == "WY") {
      this.getDetail();
    } else {
      this.getDetail();
      this.getRate();
    }
  },
  filters: {
    tatusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "info",
        deleted: "danger"
      };
      return statusMap[status];
    },
    numberFormat
  },
  methods: {
   //图片缩略
    imgDate(item) {
      ImagePreview([item]);
    },
    back() {
      this.$router.go(-1);
    },
    getDetail() {
      http.get("/insurance/InsCaseReport/", this.$route.query.id).then(res => {
        if (res.code === 0) {
          this.reportDetail = res.data;
          if (this.reportDetail.wyRepair == "Y") {
            this.isMessageRate = true;
            this.disabled = true;
            if (this.reportDetail.wyEvaluate != null) {
              this.evaluate = this.reportDetail.wyEvaluate;
            } else {
              this.evaluate = "暂无评论";
            }
          }else{
             this.isMessageRate = false;
          }
          this.getRiskEventType();
          this.getCpicClaimReason();
        }
      });
    },
    // 获取事件类型字典表
    getRiskEventType() {
      this.eventTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_TYPE;
      this.eventTypeList.map(_data => {
        if (_data.dictKey === this.reportDetail.riskEventType) {
          this.reportDetail.riskEventType = _data.dictValue;
        }
      });
    },
    // 获取出险原因
    getCpicClaimReason() {
      this.reasonRiskList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_CPIC_CLAIM_REASON;
      this.reasonRiskList.map(_data => {
        if (_data.dictKey === this.reportDetail.lossType) {
          this.reportDetail.lossType = _data.dictValue;
        }
      });
    },
    // 获取评论,评分接口
    getRate() {
      const _this = this;
      const keywords = {
        caseReportId: this.$route.query.caseReportId,
        ownnerName: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .userId
      };
      http
        .get("/insurance/InsBasicInfo/own/getEvaluate", keywords)
        .then(res => {
          if (res.code === 0) {
            if (res.data === null) {
              // 判断是否为空,如果为空,则表示可以填写评论和评分
              _this.isMessageRate = false;
            } else {
              _this.isMessageRate = true;
              // 评分赋值
              _this.score = Number(res.data.score);
              if (res.data.evaluate == "") {
                _this.evaluate = "暂无评论";
              } else {
                _this.evaluate = res.data.evaluate;
              }
            }
          }
        });
    },
    //物业确认维修
    confirm() {
      const keywords = {
        wyRepair: "Y",
        caseReportId: this.$route.query.caseReportId,
        wyEvaluate: this.evaluate
      };
      http.put("/insurance/InsCaseReport", keywords).then(res => {
        if (res.code === 0) {
          // 提交成功后,调接口,刷新评分
          this.$toast("提交成功");
          this.$router.go(-1);
        }
      });
    },
    // 提交评论,评分接口
    submitRate() {
      const _this = this;
      const keywords = {
        // 项目id
        projectId: this.selectedPrj.projectId,
        // 小区名称
        communityName: this.selectedPrj.communityName,
        // 报案号
        caseReportId: this.$route.query.caseReportId,
        // 评价人
        ownnerName: this.selectedPrj.userId,
        // 评论内容
        evaluate: this.evaluate,
        // 评分
        score: this.score
      };
      // 添加校验,如果评分为0,则不可以提交
      if (this.score == 0) {
        this.$toast("请给此报案进行评分!");
        return;
      }
      http.post("/insurance/InsBasicInfo/own/evaluate", keywords).then(res => {
        if (res.code === 0) {
          // 提交成功后,调接口,刷新评分
          this.$toast("提交成功");
          _this.getRate();
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.card {
  width: 90%;
  margin: 0 auto;
  text-align: left;
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.card-item {
  font-size: 20/16rem;
  margin: 10/16rem;
}
.van-cell-group,
.card /deep/ .van-cell--large {
  border-radius: 6/16rem;
}
.color-background {
  background: #f2f2f2;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.detail-text {
  color: #969799;
}
.submitRate-width {
  width: 165/16rem;
}
.submitRate-top {
  margin-top: 22/16rem;
  margin-left: 25%;
}
.submitRate-padding {
  padding: 10/16rem 0;
}
.submitRate-style {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  font-weight: bold;
}
.ertivcalLine-pingfen {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128feb;
  margin-left: 15/16rem;
  font-weight: bold;
}
.ertivcalLine-height {
  height: 30/16rem;
}
.ertivcalLine-line {
  line-height: 30/16rem;
}
.ertivcalLine-padding {
  padding: 10/16rem 0;
}
.comment-style {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128feb;
  margin-left: 15/16rem;
  font-weight: bold;
}
.comment-padding {
  padding: 10/16rem 0;
}
/* 评论模块样式 */
.comment {
  margin-top: 20/16rem;
}
.communityName-padding {
  padding-top: 10/16rem;
}
.nameImg {
  padding-left: 16/16rem;
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-top: 18/16rem;
  padding-bottom: 18/16rem;
}
.img {
  width: 76/16rem;
  height: 66/16rem;
}
</style>
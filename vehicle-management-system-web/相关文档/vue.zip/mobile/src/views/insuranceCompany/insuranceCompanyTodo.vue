<template>
  <div style="position: relative;">
    <van-row>
      <van-swipe :autoplay="3000">
        <van-swipe-item v-for="(image, index) in images" :key="index">
          <img v-lazy="image" />
        </van-swipe-item>
      </van-swipe>
    </van-row>
    <van-row type="flex" justify="center">
      <van-col span="22" class="content">
        <van-cell-group :title="title" >
          <van-cell title="开始介入日期：" value="内容" />
          <van-cell title="竣工检查日期：" value="内容" />
          <van-cell title="已关闭风险事件：" value="内容" />
        </van-cell-group>
        
      </van-col>
    </van-row>
    <van-row >
      1111111
    </van-row>
  </div>
</template>
<script>
// import ComponentOne from '@/components/component1'
// import ComponentTwo from '@/components/component2'
export default {
  name: 'insuranceCompanyTodo',
  components: {
    // ComponentOne: ComponentOne,
    // ComponentTwo: ComponentTwo
  },
  data() {
    return {
      images: [
        'https://img.yzcdn.cn/vant/apple-1.jpg',
        'https://img.yzcdn.cn/vant/apple-2.jpg'
      ],
      title:"城市"
    }
  }
}
</script>
<style lang="scss" scoped>
.van-swipe{
  height: 238px;
}
.van-swipe img{
    width: 100%;
    height: 100%;
}
.content{
  position: absolute;
  top:192px;
  height: 176px;
  border-radius: 15px;
  background:rgba(194, 192, 192, 0.4)
}
.van-cell-group__title {
  text-align: left;
  font-size: 24px;
}
.van-cell__title{
  text-align: left
}
</style>
<template>
  <div style="position: relative;">
    <van-row>
      <van-image
        height="173"
        src="https://img.yzcdn.cn/vant/cat.jpeg"
      />
    </van-row>
    <van-row class="content">
      <span>2022室外有裂缝</span>
    </van-row>
    <van-row>
      <van-cell-group :title="title">
        <van-cell title="所属楼栋：" :value="id" />
        <van-cell title="风险等级：" value="内容" />
        <van-cell title="风险事件类型：" value="内容" />
        <van-cell title="建议整改截止日期：" value="内容" />
        <van-cell title="项目阶段：" value="内容" />
        <van-cell title="形象进度：" value="内容" />
        <van-cell title="检查方式：" value="内容" />
        <van-cell title="缺陷描述：" value="内容" />
        <van-cell title="整改建议：" value="内容" />
        <van-cell title="参与人：" value="内容" />
      </van-cell-group>
    </van-row>
  </div>
</template>
<script>
export default {
  name: 'insuranceCompanyTodo',
  components: {
  },
  data() {
    return {
      title: '接地钢管与方管间',
      id: '33栋'
    }
  }
}
</script>
<style lang="scss" scoped>

.content{
  position: absolute;
  top:136px;
  width: 100%;
  height: 38px;
  text-align: left;
  background:rgba(0, 0, 0, 0.2)
}
.content span{
  line-height: 33px;
  color: #FFF;
  margin-left:25px
}
.van-cell-group__title {
  text-align: left;
  font-size: 16px;
  color: #128FEB;
}
.van-cell__title{
  text-align: left
}
</style>
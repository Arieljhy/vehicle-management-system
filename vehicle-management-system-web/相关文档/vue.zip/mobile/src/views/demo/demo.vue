<template>
  <div>
    <mcRecorder @handleStop="handelEndRecord" />
    {{transtlate}}

    <div @click="beginluyin('start')">开始语音1</div>
    <div @click="beginluyin('end')">结束录音</div>
    语音：{{yuyinvalue}}
    <!-- <component :is="item.key" v-for="item in allComponents" :key="item.key" :title="item.title"></component> -->

    <!-- 时间控件 -->
    <!-- <span>--------------时间控件---------------</span>
    <van-field v-model="myTime" placeholder="请选择时间" @click="showTime=true" />
    <van-dialog v-model="showTime" title="选择时间" show-cancel-button @confirm="confirm">
      <van-datetime-picker
        v-model="currentDate"
        type="date"
        @change="getValues(currentDate)"
        :formatter="formatter"
      />
    </van-dialog>

    <!-- 引用样式库图标-->
    <!-- <span>----------引用样式库图标-----------</span>
    <br />
    <span class="iconfont icon-duigou">引用样式库图标</span>
    <br />-->

    <!-- select选择器 -->
    <!-- <span>------------select选择器-------------</span>
    <van-field
      readonly
      clickable
      label="城市"
      :value="selectValue"
      placeholder="选择城市"
      @click="showPicker = true"
    />
    <van-popup v-model="showPicker" position="bottom">
      <van-picker
        show-toolbar
        :columns="columns"
        @cancel="showPicker = false"
        @confirm="onConfirm"
      />
    </van-popup>-->

    <!-- <span>--------------复选框组---------------</span>
    <br />
    <van-row>
      <van-col span="24">
        <van-checkbox-group v-model="checkBoxResult">
          <van-checkbox name="a">复选框 a</van-checkbox>
          <van-checkbox name="b">复选框 b</van-checkbox>
          <van-checkbox name="c">复选框 c</van-checkbox>
        </van-checkbox-group>
      </van-col>
    </van-row>
    <span>--------------步骤条---------------</span>
    <br />-->
    <!-- <van-steps direction="vertical" :active="1">
      <van-step>
        <h3>【城市】物流状态1</h3>
        <p>2016-07-12 12:40</p>
      </van-step>
      <van-step>
        <h3>【城市】物流状态2</h3>
        <p>2016-07-11 10:00</p>
      </van-step>
      <van-step>
        <h3>快件已发货</h3>
        <p>2016-07-10 09:30</p>
      </van-step>
    </van-steps>-->
    <!-- 
    <span>--------------文件上传---------------</span>
    <br />
    <van-uploader :after-read="afterRead">
      <van-button icon="photo" type="primary">上传图片</van-button>
    </van-uploader>
    <span>--------------多级联动---------------{{columns001}}</span>
    <br />
    <van-picker :columns="columns001" @change="onChange" />-->

    <div class="rem1">000</div>
    <div class="rem2">000</div>
    <div>
      <input type="text" x-webkit-speech lang="zh-CN" />
    </div>
    <mcPdf :pushurl="pdfurl" v-if="fileType=='pdf'" />
    <van-button @click="checkPdf()">预览</van-button>
  </div>
</template>

<script>
import NavBar from "@/components/navBar";
import ComponentTwo from "@/components/component2";
import http from "@/common/request";
import mcRecorder from "@/components/mcRecorder";
import mcPdf from "@/components/mcPdf";
import $ from "jquery";
export default {
  name: "home",
  components: {
    NavBar: NavBar,
    ComponentTwo: ComponentTwo,
    mcRecorder,
    mcPdf
  },
  data() {
    return {
      yuyinvalue:'',
      transtlate:'',
      selected: "",
      citys: [
        {
          name: "apple",
          list: [
            { name: "abc", id: "001" },
            { name: "ff", id: "003" },
            { name: "gg", id: "002" }
          ]
        },
        {
          name: "apple0001",
          list: [
            { name: "abc", id: "003" },
            { name: "fd", id: "004" },
            { name: "bb", id: "001" }
          ]
        }
      ],
      columns001: [
        {
          values: [],
          className: "column1"
        },
        {
          values: [],
          className: "column2",
          defaultIndex: 0
        }
      ],
      allComponents: [
        { key: "NavBar", title: "查询" },
        { key: "ComponentTwo", title: "BBBBBBBBBBBBB" }
      ],
      currentDate: new Date(),
      showTime: false, //打开时间控件
      showPicker: false, //打开选择器
      columns: [
        { text: "杭州2", id: 11 }, //显示值必须为text
        { text: "广东", id: 22 },
        { text: "南京", id: 33 },
        { text: "上海", id: 44 }
      ],
      myTime: "",
      selectValue: "",
      selectId: "",
      checkBoxResult: ["a", "b"],
      msource: "",
      pdfurl: "",
      fileType: ""
    };
  },
  created() {
    //调取服务
    // this.getHttp();
    this.columns001[0].values = this.getColumns(this.citys);
    this.columns001[1].values = this.getColumns(this.citys[0].list);
    this.selected = this.getColumns(this.citys[0].list)[0];
    // const keywords = {
    //   speech_url:
    //     "http://speech-doc.gz.bcebos.com/rest-api-asr/public_audio/16k.pcm",
    //   format: "pcm",
    //   pid: 1537,
    //   rate: "16000"
    // };
    // http.get("/common/config/aaiasrToken").then(res => {
    //   console.log(res);
    //   const updateUrl =
    //     "https://aip.baidubce.com/rpc/2.0/aasr/v1/create?access_token=" +
    //     res.aaiasrApiToken;
    //   $.ajax({
    //     url: updateUrl,
    //     type: "post",
    //     dataType: "json",
    //     data: keywords,
    //     // contentType: "application/json;charset=utf-8",
    //     success: function(res) {
    //       console.log(res);
    //     }
    //   });
    // });
  },
  methods: {
    beginluyin(flag) {
      if(flag=='start') {
        app.startRecord('24.737930b8bbded2e92de4d1609737e161.2592000.1585721208.282335-17693572')
      }
      if(flag=="end") {
        this.yuyinvalue = app.stopRecord(true)
      }
        
    },
    checkPdf() {
      const keys = {
        cloudDocId:
          "gns://BD2E7AEBE0C341588B6A7C05B3D4219E/FF0F4B22BD6044A4AF01B2D8D566592C/DEDEB99043D64CCFB8F9A1E18CBCA75C/EDAFCBA61BED4BC5BEB6E428D801282D/A95C0E1EC6254F9A9DC10EC52D4BC88B",
        pageSize: 10,
        pageNum: 1,
        lesseeId: "eidi-maanshan"//maanshan
        //  lesseeId: "eidi-yangquan"//阳泉
      };
      http.get("/processDoc/viewFile", keys).then(res => {
        console.log("22222222222222222222222222222222");
        if (res) {
          var binaryData = [];
          binaryData.push(res);
          this.pdfurl =
            "/api/processDoc/viewFile?cloudDocId=gns%3A%2F%2FBD2E7AEBE0C341588B6A7C05B3D4219E%2FFF0F4B22BD6044A4AF01B2D8D566592C%2FDEDEB99043D64CCFB8F9A1E18CBCA75C%2FEDAFCBA61BED4BC5BEB6E428D801282D%2FA95C0E1EC6254F9A9DC10EC52D4BC88B&pageSize=10&pageNum=1&lesseeId=eidi-maanshan";
          this.fileType = "pdf";
          console.log(this.pdfurl);
          console.log("有数据");
        } else {
          console.log("没数据");
        }
      });
    },
    handelEndRecord(param) {
      console.log(param);
      let reader = new FileReader();
      reader.readAsDataURL(param.mblob);
      reader.onload = e => {
        console.log(e.target.result);
        this.msource = e.target.result.replace("data:audio/wav;base64,","");
        const keywords = {
          speech: this.msource,
          format: "wav",
          channel:1,
          rate: 16000,
          token: JSON.parse(localStorage.getItem("eidi_mobile.baiduTocken")),
          cuid: "baidu_eidi",
          dev_pid: 1537,
          len:param.mblob.size
        };
        http.post("/baidu/server_api", keywords).then(res => {
          if(res.err_no==0) {
            this.transtlate = res.result[0]
          }
         
          console.log(res);
        });
      };
    },
    getColumns(lists) {
      const column = [];
      lists.map(city => {
        column.push(city.name);
      });
      return column;
    },

    onChange(picker, values) {
      console.log(values);
      let childColumn = [];
      this.citys.map(city => {
        if (values[0] == city.name) {
          childColumn = this.getColumns(city.list);
        }
      });
      picker.setColumnValues(1, childColumn);
      //获取列中的值
      console.log(picker.getColumnValue(0));
      console.log(picker.getColumnValue(1));
      this.selected = picker.getColumnValue(0);
    },

    afterRead(param) {
      // 此时可以自行将文件上传至服务器
      console.log(param);
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "file");

      console.log(file);
      http.post("/processDoc/uploadProcessDocTmp", file).then(res => {
        console.log(res);
      });
    },
    getHttp() {
      const keywords = { apple: "appple" };
      http.post("/forum/saveMain", keywords).then(res => {
        console.log(res);
      });
    },
    confirm() {
      this.myTime = this.formatDate(this.currentDate);
    },
    //改变时间，输出选中事件
    getValues(data) {
      console.log(this.formatDate(data));
    },
    //转化时间格式
    formatDate(now) {
      var year = now.getFullYear();
      var month = now.getMonth() + 1;
      var date = now.getDate();
      return year + "-" + month + "-" + date;
    },
    //过滤面板时间
    formatter(type, value) {
      if (type === "year") {
        return `${value}年`;
      } else if (type === "month") {
        return `${value}月`;
      } else if (type === "day") {
        return `${value}日`;
      }
      return value;
    },

    onConfirm(item) {
      console.log(item);
      this.selectValue = item.text;
      this.selectId = item.id;
      this.showPicker = false;
    }
  }
};
</script>
<style lang="less" scoped>
.van-checkbox-group .van-checkbox {
  float: left;
  margin-left: 20px;
}
.van-step {
  text-align: left;
}
.rem1 {
  font-size: 30/16rem;
}
.rem2 {
  font-size: 30px;
}
</style>

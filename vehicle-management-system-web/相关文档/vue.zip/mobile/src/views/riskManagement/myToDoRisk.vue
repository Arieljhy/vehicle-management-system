<template>
  <div style="background: #F2F3F5;">
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="search" slot="left" @click="goSearch" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >
       <span  @click="openSelect">
          {{selectedPrj.communityName}}
           <van-icon name="arrow-down" />
       </span>
       
      </div>
      <van-icon name="setting-o" slot="right" @click="jumpMy" />
    </van-nav-bar>
    <component :is="item.key" v-for="item in allComponents" :key="item.key" :title="item.title"></component>
    <van-popup v-model="showPicker" position="bottom">
      <van-picker
        show-toolbar
        :columns="plotsList"
        @cancel="showPicker = false"
        :default-index="showNum"
        @confirm="onConfirm"
      />
    </van-popup>
    <div style="height:70px"></div>
    <van-row span="24" class="informationBtn" @click="newRiskEvent()" v-if="tis=='TIS'">
      <van-button type="info" class="btn">新增风险事件</van-button>
    </van-row>
  </div>
</template>

<script>
import ReturnVisitReport from "@/views/riskManagement/child/returnVisitReport";//回访报告
import RiskEvent from "@/views/riskManagement/child/riskEvent";//风险事件
import RiskHead from "@/views/riskManagement/child/riskHead";
import RiskReport from "@/views/riskManagement/child/riskReport";//风险报告
import FinalRiskReport from "@/views/riskManagement/child/finalRiskReport";//最终报告
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "RiskToDo",
  components: {
    ReturnVisitReport: ReturnVisitReport,
    RiskEvent: RiskEvent,
    RiskHead: RiskHead,
    RiskReport: RiskReport,
    FinalRiskReport: FinalRiskReport
  },
  computed: {
    ...mapGetters([
      "finalRiskData",
      "plotsList",
      "selectedPrj",
      "images",
      "showNum"
    ])
  },
  data() {
    return {
      allComponents: [
        { key: "RiskHead", title: "头部" },
        { key: "RiskEvent", title: "风险事件" },
        { key: "FinalRiskReport", title: "最终风险报告" },
        { key: "RiskReport", title: "风险报告" },
        { key: "ReturnVisitReport", title: "回访报告" }
      ],
      showPicker: false,
      columns: [],
      selectValue: "",
      selectId: "",
      tis: undefined,
      mySqlStatus:''
      // finalRiskData: {}
    };
  },
  created() {
    this.getProvince();
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
    this.getProjectList({ isPage: false }).then(res => {
      if (res.data.length == 0) {
        this.goSearch();
      } else {
        if(!(this.tis=='INS' || this.tis=='TIS')){
          this.mySqlStatus = 1
        }
        this.finalRisk(this.selectedPrj.projectId);
        this.riskReport({
          projectId: this.selectedPrj.projectId,
          limit: 3,
          offset: 1,
          reportType: 1,
          sqlStatus:this.mySqlStatus
        });
        this.riskCheckReportList({
          projectId: this.selectedPrj.projectId,
          limit: 3,
          offset: 1,
          sqlStatus:this.mySqlStatus
        });
        if (this.tis == "TIS" || this.tis == "INS" || this.tis == "BLD"
        || this.tis == "JL"|| this.tis == "SJ"|| this.tis == "SGF"|| this.tis == "KC") {
          //TODO 暂时添加INS，BLD，待确定
          this.riskTisList(this.selectedPrj.projectId);
        } else if (this.tis == "INS" || this.tis == "BLD") {
          this.listInsList({
            projectId: this.selectedPrj.projectId
          });
        }
        if (this.tis == "BLD" || this.tis == "JL"|| this.tis == "SJ"|| this.tis == "SGF"|| this.tis == "KC"||this.tis == "INS") {
          this.riskEventList({
            projectId: this.selectedPrj.projectId,
            limit: 3,
            offset: 1,
            sqlStatus: 1
          });
        } else {
          this.riskEventList({
            projectId: this.selectedPrj.projectId,
            limit: 3,
            offset: 1
          });
        }
      }
      this.getImages(this.selectedPrj.projectId);
    });
  },
  methods: {
    ...mapActions([
      "finalRisk",
      "riskReport",
      "riskCheckReportList",
      "riskTisList",
      "getProjectList",
      "getImages",
      "riskEventList",
      "setProject",
      "listInsList",
      "getProvince"
    ]),
    openSelect() {
      this.getProjectList({ isPage: false });
      this.showPicker = true;
    },
    goBack() {
      this.$router.go(-1);
    },
    onConfirm(item) {
      this.selectValue = item.text;
      this.selectId = item.id;
      this.showPicker = false;
      if(!(this.tis=='TIS')){
          this.mySqlStatus = 1
        }
      this.finalRisk(item.projectId);
      this.riskReport({
        projectId: item.projectId,
        limit: 3,
        offset: 1,
        reportType: 1,
        sqlStatus:this.mySqlStatus
      });
      this.riskCheckReportList({
        projectId: item.projectId,
        limit: 3,
        offset: 1,
        sqlStatus:this.mySqlStatus
      });
      this.riskTisList(item.projectId);
      if (this.tis == "TIS") {
        this.riskEventList({
          projectId: item.projectId,
          limit: 3,
          offset: 1
        });
      } else {
        this.riskEventList({
          projectId: item.projectId,
          limit: 3,
          offset: 1,
          sqlStatus: 1
        });
      }
      this.getImages(item.projectId);
      this.setProject(item);
      // this.getProjectList({ isPage: false })
    },
    //新增风险事件
    newRiskEvent() {
      this.$router.push({
        path: "/newRiskEvents",
        query: {
          projectId: this.selectedPrj.projectId,
          title: this.selectedPrj.communityName
        }
      });
    },
    //搜索
    goSearch() {
      this.$router.push({
        path: "/search",
        query: {
          // id: item.projectId,
          // item: item
          // item: JSON.stringify(item)
        }
      });
    },
    // 跳转到_我的
    jumpMy() {
      this.$router.push("/personalSettings");
    }
  }
};
</script>
<style scoped lang="less">
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  // background: #128feb;
  bottom: 0px;
}
.btn {
  font-size: 16/16rem;
  width: 100%;
}
.word-navbar{
  font-size: 14/16rem
}
.van-nav-bar__title{
  max-width: 80%;
}
</style>

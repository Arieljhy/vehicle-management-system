<template>
  <div style="background: #F2F3F5;">
    <div v-if="!showPdf">
      <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
        <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
        <div
          name="search"
          slot="title"
          class="word-navbar"
          style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
        >{{communityName}}</div>
      </van-nav-bar>
      <div style="padding:0 15px">
        <!--最终风险报告-->
        <van-row v-if="this.$route.query.type=='final'">
          <div style="padding-top: 10px;padding-bottom: 10px;text-align: left;">
            <div class="ertivcalLine"></div>
            <span
              style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;font-weight: 800;"
              class="blue font-bold"
            >最终风险报告</span>
          </div>
          <van-row class="title">
            <van-col span="23" style="margin-left: 0.5%;">
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="getRiskFinalReport.startWorkDate"
                    rows="1"
                    autosize
                    label="开始介入日期："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="getRiskFinalReport.reportDate"
                    rows="1"
                    autosize
                    label="竣工检查日期："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="getRiskFinalReport.faultChangeCount"
                    rows="1"
                    autosize
                    label="改正缺陷数量："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="getRiskFinalReport.projDesc"
                    rows="1"
                    autosize
                    label="工程概况："
                    type="textarea"
                    disabled
                    label-width="130"
                    class="gongcheng"
                    input-align="right"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="getRiskFinalReport.insReviewNote"
                    rows="1"
                    autosize
                    label="保险公司审核意见："
                    type="textarea"
                    disabled
                    label-width="130"
                    class="gongcheng"
                    input-align="right"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    class="file-name"
                    @click="checkPdf(getRiskFinalReport.assessmentReportFileLast)"
                    v-model="getRiskFinalReport.fileName"
                    rows="1"
                    autosize
                    label="最终检查报告："
                    type="textarea"
                    placeholder="未填写"
                    disabled
                    label-width="130"
                    input-align="right"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="5">
              </van-col>
            </van-col>
          </van-row>
          <div style="text-align: left;padding: 20px 0px;padding-left: 5%;">
            <span
              style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;"
              class="blue font-bold"
            >本报告所涉及的承保范围</span>
          </div>
          <van-row class="title">
            <van-col span="23" style="padding-left: 5%;">
              <van-cell>
                <div>
                  <div>{{getRiskFinalReport.reportScope}}</div>
                </div>
              </van-cell>
            </van-col>
          </van-row>
          <div style="text-align: left;padding: 20px 0px;padding-left: 5%;">
            <span
              style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;"
              class="blue font-bold"
            >针对承保范围的总体风险评价</span>
          </div>
          <van-row class="title">
            <van-col span="23" style="padding-left: 5%;">
              <van-cell>
                <div>
                  <div>{{getRiskFinalReport.reportScopeNote}}</div>
                </div>
              </van-cell>
            </van-col>
          </van-row>
        </van-row>
        <!-- 风险报告 -->
        <van-row v-if="this.$route.query.type=='presentation'">
          <div style="padding-top: 10px;padding-bottom: 10px;text-align: left;">
            <div class="ertivcalLine"></div>
            <span
              style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;font-weight: 800;"
              class="blue font-bold"
            >风险报告</span>
          </div>
          <van-row class="title">
            <van-col span="23" style="margin-left: 0.5%;">
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="riskReportDO.name"
                    rows="1"
                    autosize
                    label="报告名称："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                    style="text-align: left;padding-left: 5%;"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="riskEventName"
                    rows="1"
                    autosize
                    label="涉及风险事件："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="riskReportDO.reportDate"
                    rows="1"
                    autosize
                    label="报告时间："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                    style="text-align: left;padding-left: 5%;"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="riskReportDO.reporter"
                    rows="1"
                    autosize
                    label="报告人："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                    style="text-align: left;padding-left: 5%;"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="riskReportDO.reviewer"
                    rows="1"
                    autosize
                    label="审核人："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                    style="text-align: left;padding-left: 5%;"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    v-model="riskReportDO.approver"
                    rows="1"
                    autosize
                    label="批准人："
                    type="textarea"
                    disabled
                    label-width="130"
                    input-align="right"
                    label-align="left"
                    style="text-align: left;padding-left: 5%;"
                  />
                </van-cell-group>
              </van-col>
              <van-col span="24">
                <van-cell-group>
                  <van-field
                    class="file-name"
                    @click="checkPdf(riskReportDO.assessmentReportFile)"
                    v-model="riskReportDO.fileName"
                    rows="1"
                    autosize
                    label="风险评估报告："
                    type="textarea"
                    placeholder="未填写"
                    disabled
                    label-width="130"
                    label-align="left"
                    input-align="right"
                  />
                </van-cell-group>
              </van-col>
            </van-col>
          </van-row>
          <!-- 风险条款 -->
          <div style="padding: 20px 0;">
            <span
              style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;margin-left: -70%;"
              class="blue font-bold"
            >风险条款</span>
          </div>
          <van-row class="title" v-if="!visitDisplay">
            <van-col span="24" style="padding: 5% 0 2% 5%;text-align: left;">保险责任范围:</van-col>
            <van-col span="23" style="padding-left: 5%;">
              <van-cell v-for="(item,index) in riskReportItemTrueDO" :key="index">
                <div>
                  <div>
                    条款名称:
                    <span style="padding-left: 5%">{{item.clause}}</span>
                  </div>
                  <div>
                    保险期限:
                    <span style="padding-left: 5%">{{item.deadline}}年</span>
                  </div>
                  <div>
                    保险类型:
                    <span style="padding-left: 5%">{{item.type}}</span>
                  </div>
                  <div>
                    <div style="width: 22%;float: left;">建&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;议:</div>
                    <div style="width: 75%;float: right;">{{item.insRemark}}</div>
                  </div>
                </div>
              </van-cell>
            </van-col>
          </van-row>
        </van-row>
        <van-row class="visitTitle" v-if="visitDisplay">
          <van-col span="14">
            <p
              class="iconfont icon-gantanhao"
              style="margin-left: 80%;font-size:30px;color: #bfbfbf;margin-top: 20%;"
            ></p>
            <p style="margin-left: 79%;color: #bfbfbf; margin-top: 7%">暂无</p>
          </van-col>
        </van-row>
        <div style="height: 75px;"></div>
      </div>
    </div>
    <div v-if="showPdf">
      <mcPdf :pushurl="pdfurl" :cloudDocId="cloudDocId" @goBack = goBack v-if="fileType=='pdf'"/>
    </div>
     <van-overlay :show="show">
      <div class="wrapper">
         <van-loading size='24px' vertical style="position: absolute;top: 50%; left: 43%;" >加载中...</van-loading>
      </div>
    </van-overlay>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import mcPdf from "@/components/mcPdf";
import { ImagePreview } from 'vant'
export default {
  name: "newRiskEvents",
  computed: {
    // ...mapGetters(["selectedPrj"])
  },
  components: {
    mcPdf
  },
  data() {
    return {
      show:false,
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      getRiskFinalReport: {},
      riskReportDO: {
        reportDate: ""
      },
      riskReportItemTrueDO: [],
      riskReportingData: {},
      dossierSelectId: [],
      riskEventName: "",
      visitDisplay: false,
      showPdf:false,
      fileType:'',
      pdfurl:'',
      cloudDocId:'',
      communityName:''
    };
  },
  created() {
       this.communityName = JSON.parse(localStorage.getItem("eidi.selected_project")).communityName
    if (this.$route.query.type != "final") {
      this.riskAssessment();
      this.riskEventFunction();
      // this.getProjectList({ isPage: false });
    } else {
      this.finalReportRequest();
      // this.getProjectList({ isPage: false });
    }
  },
  methods: {
    ...mapActions(["getProjectList"]),
    onClickLeft() {
      this.$router.go(-1);
    },
    goBack() {
      this.showPdf = false;
    },
    //最终报告详情
    finalReportRequest() {
      http
        .get("/risk/RiskReport/lastReport/", this.$route.query.projectId)
        .then(res => {
          this.getRiskFinalReport = res.data.riskReportDO;
          if (this.getRiskFinalReport.startWorkDate !== null) {
            this.getRiskFinalReport.startWorkDate = res.data.riskReportDO.startWorkDate.split(
              " "
            )[0];
          }
          if (this.getRiskFinalReport.reportDate !== null) {
            this.getRiskFinalReport.reportDate = res.data.riskReportDO.reportDate.split(
              " "
            )[0];
          }
        });
    },
    //风险事件报告详情
    riskAssessment() {
      let _this = this;
      http.get("/risk/RiskReport/", _this.$route.query.id).then(res => {
        _this.riskReportDO = res.data.riskReportDO;
        if (_this.riskReportDO.reportDate !== null) {
          _this.riskReportDO.reportDate = _this.riskReportDO.reportDate.split(
            " "
          )[0];
        }
        _this.riskReportItemTrueDO = res.data.riskReportItemTrueDO;
        _this.riskReportItemTrueDO.map((item, index) => {
          JSON.parse(
            localStorage.getItem(this.$getMobileData.baseSelects)
          ).IDI_LIABILITIES_TYPE.map(_data => {
            if (_data.dictKey == item.type) {
              item.type = _data.dictValue;
            }
          });
        });
        if (_this.riskReportItemTrueDO.length == 0) {
          this.visitDisplay = true;
        } else {
          this.visitDisplay = false;
        }
      });
    },
    //请求风险事件数据(勾选)
    riskEventFunction() {
      http
        .get("risk/RiskEvent/done", { reportId: this.$route.query.reportId })
        .then(res => {
          this.riskReportingData = res.data;
          if (this.riskReportingData.length > 0) {
            this.riskReportingData.map((item, index) => {
              this.dossierSelectId.push(item.riskEventName);
            });
            if (this.dossierSelectId.length == 0) {
              this.riskEventName = "";
            } else {
              this.riskEventName = this.dossierSelectId.join(",");
            }
          }
        });
    },
    checkPdf(docId) {
      this.show=true
      const keys = {
        cloudDocId:docId,
        pageSize: 1,
        pageNum: 1,
        lesseeId: this.$getMobileData.lesseeId
        //  lesseeId: "eidi-yangquan"
    };
    //9000未不支持文件格式，9001为图片，为空就是没有数据，存在数据，为pdf数据
    http.get("/processDoc/viewFile", keys).then(res => {
      if (res) {
        if(res.code=="9000"){
            this.show=false
          this.$toast("不支持此格式文件预览");
        } else if (res.code == "9002") {
            this.show = false;
            this.$toast("该文件不存在");
          }else if(res.code=="9001"){
           this.show=false
          // ImagePreview([this.imagesUrl+docId]);
            ImagePreview({
              images: [this.imagesUrl+docId],
              closeable: true,
              closeOnPopstate: true           
            });
        }else{
          var binaryData = [];
          binaryData.push(res);
          this.cloudDocId = docId
          this.pdfurl = '/api/processDoc/viewFile?cloudDocId='+docId+'&pageSize=1&pageNum=1&lesseeId='+this.$getMobileData.lesseeId
          // this.pdfurl = '/api/processDoc/viewFile?cloudDocId='+docId+'&pageSize=1&pageNum=1&lesseeId=eidi-yangquan'
          this.fileType ="pdf"
          this.show=false
          this.showPdf = true
          console.log("pdf数据");
        }
      } else {
        console.log("没数据");
      }
    });
    },
  }
};
</script>
<style scoped lang="less">
.ertivcalLine {
  width: 4/16rem;
  background: #128feb;
  height: 15/16rem;
  float: left;
  margin-top: 1%;
  margin-right: 2%;
}
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  max-width: 640/16rem;
  background: #128feb;
  bottom: 0/16rem;
}
.title {
  margin: 0 auto;
  background: #ffffff;
  box-shadow: 2px 2px 8px -2px rgba(155, 155, 155, 0.5);
  border-radius: 5/16rem;
}
.content {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  text-align: left;
  padding-left: 9.3%;
  padding-top: 15/16rem;
}
.academician {
  font-family: PingFangSC-Regular;
  font-size: 14/16rem;
  color: #595959;
  letter-spacing: 0;
  text-align: right;
  padding-right: 7.4%;
  padding-top: 15/16rem;
}
.van-field__body.van-field__control {
  text-align: right;
}
.engineering {
  margin-left: -5%;
}
.van-cell {
  padding: 10/16rem 0;
}
[class*="van-hairline"]::after {
  right: -53%;
}
.van-cell:not(:last-child)::after {
  right: 15/16rem;
}
.visitTitle {
  background: rgb(255, 255, 255);
  width: 100%;
  box-shadow: rgba(155, 155, 155, 0.5) 2px 2px 8px -2px;
  border-radius: 5/16rem;
  height: 150/16rem;
  margin: 0 auto;
}
.gongcheng {
  text-align: left;
  padding-left: 18/16rem;
}
.mc-pdf {
  position: fixed;
  width: 100%
}
.van-nav-bar__title{
  max-width: 80%;
}
</style>

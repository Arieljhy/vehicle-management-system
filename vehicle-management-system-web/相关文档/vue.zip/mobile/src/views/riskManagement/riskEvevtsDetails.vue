<template>
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >{{selectedPrj.communityName}}</div>
    </van-nav-bar>
    <div v-if="$route.query.type=='riskDetails'">
      <van-row style="position: relative;">
        <van-swipe :autoplay="3000" @change="onChange" v-if="images.lenght!=0">
          <van-swipe-item v-for="(image1, index) in images" :key="index">
            <img v-lazy="image1" />
          </van-swipe-item>
        </van-swipe>
        <van-image :src="checked_icon" v-else></van-image>
        <van-row type="flex" justify="center">
          <van-col span="22" class="content" v-if="images.lenght!=0">
            <span style="line-height: 35px;">{{current[index]}}</span>
          </van-col>
        </van-row>
      </van-row>
      <van-row>
        <van-col span="24">
          <div class="blue font-bold name">{{riskEventDO.riskEventName}}</div>
        </van-col>
      </van-row>
      <van-row style="margin-bottom: 20%;">
        <van-cell-group>
          <van-cell
            title="所属楼栋："
            :value="riskEventDO.riskBldings+riskEventDO.other"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="风险等级："
            :value="riskEventDO.riskLevel"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="风险事件类型："
            :value="riskEventDO.riskEventType"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="建议整改截止日期："
            :value="riskEventDO.proposedAmendDeadline"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="项目阶段："
            :value="riskEventDO.constructionStage"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="形象进度："
            :value="riskEventDO.projectVisualProgress?riskEventDO.projectVisualProgress:'未填写'"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="检查方式："
            :value="riskEventDO.checkMethod"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="缺陷描述："
            :value="riskEventDO.riskDesc"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="整改建议："
            :value="riskEventDO.proposedAmendPlan"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="参与人："
            :value="participant"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
      </van-row>
    </div>
    <div v-if="$route.query.type=='rectification'">
      <van-row style="position: relative;">
        <van-swipe :autoplay="3000" @change="onChange">
          <van-swipe-item v-for="(image, index) in picture" :key="index">
            <img v-lazy="image" />
          </van-swipe-item>
        </van-swipe>
        <van-row type="flex" justify="center">
          <van-col span="22" class="content">
            <span style="line-height: 35px;">{{this.content[index]}}</span>
          </van-col>
        </van-row>
      </van-row>
      <van-row style="margin-bottom: 20%;">
        <van-cell-group>
          <van-cell
            title="整改时间："
            :value="rectificationInfo.riskPepairTime"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="项目阶段:"
            :value="rectificationInfo.projectPhase"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="形象进度："
            :value="rectificationInfo.projectVisualProgress"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="检查方式："
            :value="rectificationInfo.checkMethod"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="检查人："
            :value="rectificationInfo.checkPtcp"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="整改描述："
            :value="rectificationInfo.amendActionDesc"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="提交人："
            :value="rectificationInfo.createdName"
            title-class="titleClass"
            value-class="valueClass"
          />
        </van-cell-group>
      </van-row>
    </div>
    <van-row span="24" class="informationBtn" @click="newRiskEvent">
      <van-button type="info">返回</van-button>
    </van-row>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  computed: {
    ...mapGetters(["selectedPrj"])
  },
  data() {
    return {
      checked_icon: require("@/assets/imgs/moren.jpg"),
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      images: [],
      riskEventDO: {},
      riskEventPicDO: {},
      userDO: {},
      username: [],
      participant: "",
      current: [],
      picDescription: "",
      index: 0,
      rectificationInfo: "",
      picture: [],
      content: [],
      checkMethodPop: [],
      rectificationCheckMethod: []
    };
  },
  created() {
    if (this.$route.query.type == "rectification") {
      this.riskEventRepair();
    } else {
      this.riskEvent();
    }
    this.getProjectList({ isPage: false });
  },
  methods: {
    ...mapActions(["getProjectList"]),
    //获取风险事件详情
    riskEvent() {
      http.get("/risk/RiskEvent/", this.$route.query.id).then(res => {
        this.riskEventDO = res.data.riskEventDO;
        this.riskEventPicDO = res.data.riskEventPicDO;
        this.userDO = res.data.userDO;
        this.riskLevelList();
        this.riskEventTypeList();
        this.constructionStageList();
        this.inspectionMode();
        if (this.userDO != null) {
          this.userDO.map((item, index) => {
            this.username.push(item.username);
          });
        }
        if (this.username.length > 0) {
          this.participant = this.username.join(",");
        }
        if (this.riskEventDO.proposedAmendDeadline !== null) {
          this.riskEventDO.proposedAmendDeadline = this.riskEventDO.proposedAmendDeadline.split(
            " "
          )[0];
        }
        if (this.riskEventPicDO.length > 0) {
          this.riskEventPicDO.map(url => {
            this.images.push(this.imagesUrl + url.picPath);
            this.current.push(url.picDescription);
          });
        } else {
          this.images.push(this.checked_icon);
        }
      });
    },
    riskLevelList() {
      JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_LEVEL.map(_data => {
        if (_data.dictKey == this.riskEventDO.riskLevel) {
          this.riskEventDO.riskLevel = _data.dictValue;
        }
      });
    },
    riskEventTypeList() {
      JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_TYPE.map(_data => {
        if (_data.dictKey == this.riskEventDO.riskEventType) {
          this.riskEventDO.riskEventType = _data.dictValue;
        }
      });
    },
    constructionStageList() {
      JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PROJ_PROCESS.map(_data => {
        if (_data.dictKey == this.riskEventDO.constructionStage) {
          this.riskEventDO.constructionStage = _data.dictValue;
        }
      });
    },
    // 获取项目阶段字典表
    projectStage() {
      JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PROJ_PROCESS.map(_data => {
        if (_data.dictKey == this.rectificationInfo.projectPhase) {
          this.rectificationInfo.projectPhase = _data.dictValue;
        }
      });
    },
    // 获取项目阶段字典表
    projectStageList() {
      JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_CHECK.map(_data => {
        if (_data.dictKey == this.rectificationInfo.checkMethod) {
          this.rectificationInfo.checkMethod = _data.dictValue;
        }
      });
    },
    // 获取检查方式字典表
    inspectionMode() {
      if (this.$route.query.type == "riskDetails") {
        JSON.parse(
          localStorage.getItem(this.$getMobileData.baseSelects)
        ).IDI_RISK_EVENT_CHECK.map(_data => {
          if (this.riskEventDO.checkMethods.length > 0) {
            this.riskEventDO.checkMethods.map((item1, index) => {
              if (_data.dictKey == item1) {
                this.checkMethodPop.push(_data.dictValue);
              }
            });
          }
        });
        if (this.checkMethodPop.length > 0) {
          this.riskEventDO.checkMethod = this.checkMethodPop.join(",");
        }
      } else {
        JSON.parse(
          localStorage.getItem(this.$getMobileData.baseSelects)
        ).IDI_RISK_EVENT_CHECK.map(_data => {
          if (this.rectificationInfo.checkMethods.length > 0) {
            this.rectificationInfo.checkMethods.map((item1, index) => {
              if (_data.dictKey == item1) {
                this.rectificationCheckMethod.push(_data.dictValue);
              }
            });
          }
        });
        if (this.rectificationCheckMethod.length > 0) {
          this.rectificationInfo.checkMethod = this.rectificationCheckMethod.join(
            ","
          );
        }
      }
    },
    //获取事件整改
    riskEventRepair() {
      http.get("/risk/RiskEventRepair/", this.$route.query.id).then(res => {
        this.rectificationInfo = res.data;
        this.projectStage();
        this.projectStageList();
        this.inspectionMode();
        if (this.rectificationInfo.imagePathList.length > 0) {
          this.rectificationInfo.imagePathList.map(url => {
            this.picture.push(this.imagesUrl + url.picPath);
            this.content.push(url.picDescription);
          });
        } else {
          this.picture.push(this.checked_icon);
        }
      });
    },
    onChange(index1) {
      this.index = index1;
    },
    newRiskEvent() {
      this.$router.go(-1);
    },
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="less" scoped>
.van-swipe {
  height: 238/16rem;
}
.van-swipe img {
  width: 100%;
  height: 100%;
}
.content {
  text-align: left;
  padding-left: 16/16rem;
  width: 100%;
  position: absolute;
  bottom: 1%;
  height: 15%;
  background: rgba(0, 0, 0, 0.5);
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #ffffff;
  letter-spacing: 0;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
  overflow: hidden;
}
.titleClass {
  max-width: 130/16rem;
  text-align: left;
  font-size: 14/16rem;
  color: #000000;
  line-height: 24/16rem;
  font-family: Source Han Sans CN;
}
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  max-width: 640/16rem;
  background: #128feb;
  bottom: 0/16rem;
  span{
    font-size: 14/16rem
  }
}
.name {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128feb;
  font-weight: 800;
  padding: 5% 0 5% 16/16rem;
  text-align: left;
}
.valueClass {
  text-align: right;
   font-size: 14/16rem;
  color: #4c4c4e;
  line-height: 24/16rem;
  font-family: Source Han Sans CN;
}
.mc-navbar{
  div {
    font-size: 14/16rem
  }
}
.van-nav-bar__title{
  max-width: 80%;
}
</style>
<template>
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >{{$route.query.title}}</div>
    </van-nav-bar>
    <div style="padding:0 15px">
      <div style="padding-top: 10px;padding-bottom: 10px;text-align: left;">
        <div class="ertivcalLine"></div>
        <span
          style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;font-weight: 800;"
          class="blue font-bold"
        >新增风险事件</span>
      </div>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="风险事件名称:"
            v-model="riskEventDO.riskEventName"
            placeholder="风险事件名称"
            required
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <!-- 风险事件编号 -->
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="风险事件编号:"
            v-model="riskEventDO.eventIdForUser"
            placeholder="风险事件编号"
            required
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-field
          style="text-align: left;"
          label="所属楼栋:"
          readonly
          required
          v-model="riskEventDO.riskBldings"
          :placeholder="isOther?'其他':'所属楼栋'"
          @focus="rectificationTime('riskBldings')"
          label-class="name1"
        />
        <van-dialog
          v-model="riskBldingsShow"
          title="所属楼栋"
          show-cancel-button
          :beforeClose="onBldingsConfirm"
        >
          <!-- '其他'按钮 -->
          <van-checkbox-group v-model="result">
            <van-cell-group>
              <van-cell
                v-for="(iteam, index) in otherList"
                :key="index"
                clickable
                :title="`${iteam}`"
                @click="otherToggle(iteam,index)"
              >
                <van-checkbox :name="iteam" ref="otherCheckboxes" slot="right-icon" />
              </van-cell>
            </van-cell-group>
          </van-checkbox-group>
          <van-checkbox-group v-model="result" ref="checkboxGroup">
            <van-cell-group style="overflow: auto;max-height: 300px;">
              <van-cell
                v-for="(item, index) in houseList"
                clickable
                :key="index"
                :title="`${item.unitId}`"
                @click="isOther?'':toggle(item,index)"
              >
                <van-checkbox :name="item" ref="checkboxes" slot="right-icon" :disabled="isOther" />
              </van-cell>
            </van-cell-group>
          </van-checkbox-group>
        </van-dialog>
        <van-field v-model="riskEventDO.other" label placeholder="所属楼栋" v-if="isOther" />
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="风险等级:"
            required
            readonly
            v-model="riskLevel"
            placeholder="风险等级"
            :value="riskLevelList"
            @click="riskLevelPicker = true"
            label-class="name1"
          />
          <van-popup v-model="riskLevelPicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="riskLevelList"
              @cancel="riskLevelPicker = false"
              @confirm="onRiskLevel"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="风险事件类型:"
            readonly
            v-model="riskEventType"
            placeholder="风险事件类型"
            @click="riskEventTypePicker = true"
            label-class="name1"
          />
          <van-popup v-model="riskEventTypePicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="riskEventTypeList"
              @cancel="riskEventTypePicker = false"
              @confirm="onRiskEventType"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="发生时间:"
            required
            readonly
            v-model="riskEventDO.riskFoundTime"
            placeholder="年/月/日"
            @focus="rectificationTime('riskFoundTime')"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-dialog
        v-model="riskFoundTimeShow"
        title="选择时间"
        show-cancel-button
        @confirm="riskFoundTimeConfirm"
      >
        <van-datetime-picker
          :min-date="minDate"
          :max-date="maxDate"
          v-model="riskCurrentDate"
          type="date"
          @change="getValues(riskCurrentDate)"
          :formatter="formatter"
          :show-toolbar="false"
        />
      </van-dialog>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="整改截止日期:"
            required
            readonly
            v-model="riskEventDO.proposedAmendDeadline"
            placeholder="年/月/日"
            @focus="rectificationTime('proposedAmendDeadline')"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-dialog
        v-model="proposedAmendDeadlineShow"
        title="选择时间"
        show-cancel-button
        @confirm="proposedAmendDeadlineConfirm"
      >
        <van-datetime-picker
          :min-date="minCurrentDate"
          :max-date="maxCurrentDate"
          v-model="currentDate"
          type="date"
          @change="getValues(currentDate)"
          :formatter="formatter"
          :show-toolbar="false"
        />
      </van-dialog>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="项目阶段:"
            readonly
            v-model="constructionStage"
            placeholder="项目阶段"
            :value="construction"
            @click="constructionStagePicker = true"
            label-class="name1"
          />
          <van-popup v-model="constructionStagePicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="eventTypeList"
              @cancel="constructionStagePicker = false"
              @confirm="onConstructionStage"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="形象进度:"
            v-model="riskEventDO.projectVisualProgress"
            placeholder="形象进度"
            class="frame"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-col span="7" class="name" style="text-align: left;padding-left: 15px;">检查方式:</van-col>
      <van-col span="16" style=" margin-bottom: 10px;margin-left: 10px;">
        <van-checkbox-group v-model="resultList" @change="singleChecked()">
          <van-checkbox
            class="checkStyle"
            style="width: 50%;margin-right: 0;"
            v-for="(item,index) in inspectList"
            :key="index"
            :name="item.dictKey"
            shape="square"
          >{{item.dictValue}}</van-checkbox>
        </van-checkbox-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="参与人姓名:"
            readonly
            v-model="userNamed"
            placeholder="参与人姓名"
            :value="station"
            @click="userName"
            label-class="name1"
          />
          <van-popup v-model="showPicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="defaultAddress"
              @change="onChange"
              @cancel="showPicker = false"
              @confirm="onConfirm"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            v-model="telephone"
            disabled
            label="联系电话:"
            style="text-align: left;"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            v-model="field"
            disabled
            label="专业领域:"
            style="text-align: left;"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="缺陷描述:"
            v-model="riskEventDO.riskDesc"
            rows="1"
            :autosize=" {minRows: 2}"
            type="textarea"
            placeholder="缺陷描述"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="整改建议方案:"
            v-model="riskEventDO.proposedAmendPlan"
            rows="1"
            :autosize=" {minRows: 2}"
            type="textarea"
            placeholder="整改建议方案"
            class="textarea"
            label-class="name1"
          />
        </van-cell-group>
      </van-col>
      <van-row>
        <van-col span="7" class="name" style="text-align: left;padding-left: 15px;">
          <span>现场图片:</span>
        </van-col>
        <van-col span="17">
          <div v-for="(item, index) in riskEventPicDO" :key="index" style="height: 1px;">
            <van-col span="8" class="divcol">
              <img :src="imagesUrl+item.picPath" @click="img(imagesUrl+item.picPath)" />
              <van-col class="imgcol" @click.stop="imgDelete(item,index)">
                <van-icon name="cross" />
              </van-col>
            </van-col>
            <van-col span="13" class="textareacol">
              <van-cell-group>
                <van-field
                  style="background: #f2f3f5;"
                  v-model="item.picDescription"
                  rows="1"
                  :autosize="{ maxHeight:25, minHeight: 20 }"
                  type="textarea"
                  placeholder="图片描述"
                  class="textarea"
                />
              </van-cell-group>
            </van-col>
          </div>
          <van-uploader :after-read="afterRead" style="padding-right: 65%;">
            <div class="iconfont icon-xaingji xiangji">
              <div>上传图片</div>
            </div>
          </van-uploader>
        </van-col>
      </van-row>
      <van-row @click="submissionRisk">
        <van-col span="24" style="margin-bottom: 5%;margin-top: 2%;">
          <van-button
            type="info"
            size="large"
            class="btnName"
            style="border-radius: 24.5px;"
            :disabled="disabled"
          >提交</van-button>
        </van-col>
      </van-row>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import { ImagePreview } from "vant";
import http from "@/common/request";
export default {
  name: "newRiskEvents",
  data() {
    return {
      // 定义'其他'数组
      otherList: ["其他"],
      isOther: false,
      dealImgWidth: 600,
      disabled: false,
      minDate: new Date(1900, 0, 1),
      maxDate: new Date(),
      minCurrentDate: new Date(1900, 0, 1),
      maxCurrentDate: new Date(2100, 10, 1),
      userNamed: "",
      telephone: "",
      field: "",
      selected: [],
      station: "",
      showPicker: false,
      defaultAddress: [
        {
          values: [],
          className: "column1"
        },
        {
          values: [],
          className: "column2",
          defaultIndex: 0
        }
      ],
      username: [],
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      fileListImg: false,
      riskEventDO: {
        eventIdForUser: "",
        riskEventName: "",
        riskLevel: "",
        riskBldings: "",
        riskEventType: "",
        proposedAmendDeadline: "",
        constructionStage: "",
        projectVisualProgress: "",
        riskDesc: "",
        proposedAmendPlan: "",
        checkMethods: [],
        riskEventPtcp: "",
        riskFoundTime: "",
        other:''
      },
      riskEventPicDO: [],
      rectificationInfo: {},
      riskEventType: "",
      riskLevel: "",
      constructionStage: "",
      construction: "",
      title: "测试-宣厅",
      result: [],
      resultList: [],
      inspectList: [],
      message: "",
      message1: "",
      currentDate: new Date(),
      riskCurrentDate: new Date(),
      show1: false,
      proposedAmendDeadlineShow: false,
      riskFoundTimeShow: false,
      riskBldingsShow: false,
      radio: "",
      list: [],
      riskLevelPicker: false, //打开选择器
      riskEventTypePicker: false,
      constructionStagePicker: false,
      eventTypeList: [],
      riskLevelList: [],
      riskEventTypeList: [],
      myTime: "",
      selectValue: "",
      selectId: "",
      baoan: {
        value: "",
        address: "",
        bldings: ""
      },
      bldings: [],
      houseList: []
    };
  },
  created() {
    this.getPlotsHousehold(this.$route.query.projectId);
    this.getRiskEventType();
    this.inspectionMode();
    this.getriskLevel();
    this.projectStage();
    this.riskEvntOrg();
  },
  methods: {
    getPlotsHousehold(data) {
      http.get("/project/PrjSingleUnits", { projectId: data }).then(res => {
        if (res.code === 0) {
          if (res.data.total > 0) {
            this.houseList = res.data.rows;
          } else {
          }
        }
      });
    },
    // 所属栋楼,点击'其他'事件
    otherToggle(iteam, index) {
      this.riskEventDO.riskBldings = "";
      const _this = this;
      this.$refs.otherCheckboxes[index].toggle();
      if (this.$refs.otherCheckboxes[index].checked == false) {
        // true, 表示'其他'选中, 其他复选框无法点击
        this.isOther = true;
        // 选中后,将所有已选小区复选框置空
        this.$refs.checkboxes.forEach(_check => {
          _check.checked = false;
        });
        // 如果勾选了栋楼,则需要清空输入框,否则无限添加栋楼
        this.riskBldings = [];
        this.baoan.riskBldings = "";
      } else if (this.$refs.otherCheckboxes[index].checked == true) {
        this.isOther = false;
      }
    },
    //参与人
    userName() {
      this.showPicker = true;
    },
    onChange(picker, values) {
      let childColumn = [];
      this.username.map(item => {
        if (values[0] == item.orgName) {
          childColumn = this.getColumns(item.userList, 2);
        }
      });
      picker.setColumnValues(1, childColumn);
      //获取列中的值
      // this.selected = picker.getColumnValue(0);
    },
    onConfirm(value) {
      this.username.map((item, index) => {
        if (value[0] == item.orgName) {
          item.userList.map(item2 => {
            if (value[1] == item2.username) {
              this.selected = item2;
              return;
            }
          });
        }
      });
      this.riskEventDO.riskEventPtcp = this.selected.userId;
      this.userNamed = this.selected.username;
      this.telephone = this.selected.mobile;
      this.field = this.selected.professional;
      this.showPicker = false;
    },
    getColumns(lists, flag) {
      const column = [];
      lists.map(item => {
        if (flag == 1) column.push(item.orgName);
        if (flag == 2) column.push(item.username);
      });
      return column;
    },
    //获取机构
    riskEvntOrg() {
      http
        .get("/risk/RiskEventRepair/org/", this.$route.query.projectId)
        .then(res => {
          this.username = res.data;
          this.defaultAddress[0].values = this.getColumns(this.username, 1);
          this.defaultAddress[1].values = this.getColumns(
            this.username[0].userList,
            2
          );
          (this.riskEventDO.riskEventPtcp = this.getColumns(
            this.username[0].userList
          )[0]),
            2;
        });
    },
    //图片缩略
    img(item) {
      // ImagePreview([item]);
      ImagePreview({
        images: [item],
        closeable: true,
        closeOnPopstate: true
      });
    },
    // 获取项目阶段字典表
    projectStage() {
      this.eventTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PROJ_PROCESS;
      this.eventTypeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取风险事件字典表
    getriskLevel() {
      this.riskLevelList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_LEVEL;
      this.riskLevelList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取事件类型字典表
    getRiskEventType() {
      this.riskEventTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_TYPE;
      this.riskEventTypeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取检查方式字典表
    inspectionMode() {
      this.inspectList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_CHECK;
      this.inspectList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    setCode() {
      this.eventTypeList.map((item, index) => {
        if (item.dictValue == this.constructionStage) {
          this.riskEventDO.constructionStage = item.dictKey;
        }
      });
      this.riskLevelList.map((item, index) => {
        if (item.dictValue == this.riskLevel) {
          this.riskEventDO.riskLevel = item.dictKey;
        }
      });
      this.riskEventTypeList.map((item, index) => {
        if (item.dictValue == this.riskEventType) {
          this.riskEventDO.riskEventType = item.dictKey;
        }
      });
    },
    // 删除图片
    imgDelete(item, index) {
      this.riskEventPicDO.splice(index, 1);
    },
    //上传
    async afterRead(param) {
      param.status = "uploading";
      param.message = "上传中";
      this.disabled = true;
      var toFile = param.file;
      if (toFile.type.startsWith("image") && toFile.size > 1024 * 1024) {
        var _this = this;
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        );
        toFile = _this.$dataURLtoFile(base64, toFile.name);
      }
      // 此时可以自行将文件上传至服务器
      let file = new FormData();
      file.append("file", toFile);
      file.append("fileIcon", "riskEventRepairPic");
      file.append("projectId", this.$route.query.projectId);
      http.post("/processDoc/uploadProcessPicsTmp", file).then(res => {
        if (res.code === 0) {
          this.riskEventPicDO.push({
            picPath: res.data.cloudDocIdTmp,
            picUidName: res.data.picUidName,
            picType: "1",
            picDescription: ""
          });
          param.status = "done";
          this.disabled = false;
        } else {
          this.disabled = false;
          param.status = "failed";
          param.message = "上传失败";
        }
      });
    },
    singleChecked() {
      this.riskEventDO.checkMethods = this.resultList;
    },
    onBldingsConfirm(action, done) {
      if (action === "cancel") {
        this.$refs.checkboxGroup.toggleAll(false);
        this.bldings = [];
        this.riskEventDO.riskBldings = this.bldings.toString();
        //取消按钮
        done();
      } else if (action === "confirm") {
        //确定按钮
        if (this.isOther) {
          this.bldings = [];
          this.riskEventDO.riskBldings = this.bldings.toString();
        } else {
          this.riskEventDO.riskBldings = this.bldings.toString();
        }
      }
      done();
    },
    toggle(item, index) {
      this.$refs.checkboxes[index].toggle();
      // 将选中的添加到 blidings 数组内
      if (this.$refs.checkboxes[index].checked == false) {
        this.bldings.push(this.$refs.checkboxes[index].name.unitId);
      } else if (this.$refs.checkboxes[index].checked == true) {
        // 如果复选框为打开状态时，则关闭，删除所选
        // 使用findIndex获取索引值
        let inx = this.bldings.findIndex(_name => {
          return _name == item.unitId;
        });
        this.bldings.splice(inx, 1);
      }
    },
    onClickLeft() {
      this.$router.go(-1);
    },
    rectificationTime(val) {
      if (val == "proposedAmendDeadline") {
        this.proposedAmendDeadlineShow = true;
      } else if (val == "riskBldings") {
        this.riskBldingsShow = true;
      } else if (val == "riskFoundTime") {
        this.riskFoundTimeShow = true;
      }
    },
    //提交
    submissionRisk() {
      if (this.riskEventDO.riskEventName == "") {
        this.$toast("事件名称不能为空");
        return false;
      }
      if (this.riskEventDO.eventIdForUser == "") {
        this.$toast("事件编号不能为空");
        return false;
      }
      if (this.isOther && this.riskEventDO.other == "") {
        this.$toast("所属楼栋不能为空");
        return false;
      }
      if (!this.isOther && this.riskEventDO.riskBldings == "") {
        this.$toast("所属楼栋不能为空");
        return false;
      }
      if (this.riskLevel == "") {
        this.$toast("风险等级不能为空");
        return false;
      }
      if (this.riskEventDO.proposedAmendDeadline == "") {
        this.$toast("整改截止日期不能为空");
        return false;
      }
      if (this.riskEventDO.riskFoundTime == "") {
        this.$toast("发生时间为空");
        return false;
      }
      if (
        new Date(this.riskEventDO.proposedAmendDeadline) <
        new Date(this.riskEventDO.riskFoundTime)
      ) {
        this.$toast("请重新选择整改截止日期");
        return false;
      }
      this.setCode();
      this.riskEventDO.sqlStatus = 1;
      this.riskEventDO.completeType = 0;
      this.riskEventDO.projectId = this.$route.query.projectId;
      this.rectificationInfo.riskEventDO = this.riskEventDO;
      this.rectificationInfo.riskEventPicDO = this.riskEventPicDO;
      this.rectificationInfo.riskEventDO.riskFoundTime =
        this.rectificationInfo.riskEventDO.riskFoundTime + " " + "00:00:00";
      this.rectificationInfo.riskEventDO.proposedAmendDeadline =
        this.rectificationInfo.riskEventDO.proposedAmendDeadline +
        " " +
        "00:00:00";
      this.$toast("提交中");
      http.post("/risk/RiskEvent", this.rectificationInfo).then(res => {
        if (res.code == 0) {
          this.onClickLeft();
        }
      });
    },
    proposedAmendDeadlineConfirm() {
      this.riskEventDO.proposedAmendDeadline = this.formatDate(
        this.currentDate
      );
      this.maxDate = new Date(this.riskEventDO.proposedAmendDeadline);
    },
    riskFoundTimeConfirm() {
      this.riskEventDO.riskFoundTime = this.formatDate(this.riskCurrentDate);
      this.minCurrentDate = new Date(this.riskEventDO.riskFoundTime);
    },
    //改变时间，输出选中事件
    getValues(data) {},
    //转化时间格式
    formatDate(now) {
      var year = now.getFullYear();
      var month = now.getMonth() + 1;
      var date = now.getDate();
      // let u=navigator.userAgent
      // let isAndroid=u.indexOf('Android')>-1||u.indexOf('Linux')>-1
      // let ios=!!u.match(/\(i[^;]+;( U;)?CUP.Mac OS X/);
      //  if(isAndroid){
      //    return year + "-" + month + "-" + date;
      //  }
      //  if(ios){
      //  return year + "/" + month + "/" + date;
      //  }
      return year + "-" + month + "-" + date;
    },
    //过滤面板时间
    formatter(type, value) {
      if (type === "year") {
        return `${value}年`;
      } else if (type === "month") {
        return `${value}月`;
      } else if (type === "day") {
        return `${value}日`;
      }
      return value;
    },
    onRiskLevel(item) {
      this.riskLevel = item.text;
      this.selectId = item.id;
      this.riskLevelPicker = false;
    },
    onRiskEventType(item) {
      this.riskEventType = item.text;
      this.selectId = item.id;
      this.riskEventTypePicker = false;
    },
    onConstructionStage(item) {
      this.constructionStage = item.text;
      this.selectId = item.id;
      this.constructionStagePicker = false;
    }
  }
};
</script>
<style scoped lang="less">
.ertivcalLine {
  width: 4/16rem;
  background: #128feb;
  height: 15/16rem;
  float: left;
  margin-top: 1%;
  margin-right: 2%;
}
.name {
  font-family: PingFangSC-Medium;
  font-size: 14px;
  color: #313131;
  letter-spacing: 0;
  text-align: center;
  text-align: left;
  padding-left: 16/16rem;
}

.frame {
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.btnName {
  font-family: PingFangSC-Medium;
  font-size: 16/16rem;
  color: #ffffff;
  letter-spacing: 0;
  text-align: center;
}
.nameImg {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-top: 18/16rem;
}
.textarea {
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.van-checkbox-group .van-checkbox {
  float: left;
  margin-right: 10/16rem;
  margin-bottom: 10/16rem;
}
.van-cell span {
  margin-left: 25/16rem;
}
/deep/.van-cell__value {
  margin-left: 5/16rem;
}
.imgcol {
  height: 19/16rem;
  position: absolute;
  top: -10%;
  right: -4/16rem;
  color: rgb(150, 151, 153);
  font-size: 18/16rem;
  background-color: rgb(255, 255, 255);
  border-radius: 100%;
}
.textareacol {
  margin: 15/16rem 0/16rem 15/16rem 1.2rem;
}
.divcol {
  position: relative;
  padding-left: 7/16rem;
  img {
    width: 76/16rem;
    height: 66/16rem;
  }
}
.xiangji {
  font-size: 30/16rem;
  text-align: center;
  border: 1px solid #c5c5c5;
  width: 64/16rem;
  height: 64/16rem;
  div {
    font-size: 10/16rem;
  }
}
.checkStyle {
  font-size: 14/16rem;
}
.van-nav-bar__title {
  max-width: 80%;
}
</style>

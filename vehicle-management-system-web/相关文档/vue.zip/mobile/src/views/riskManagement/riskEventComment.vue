<template>
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >{{riskEnevtData.riskEventDO.riskEventName}}</div>
    </van-nav-bar>
    <div style="padding-right:10px;margin-top: 5%;">
      <van-row>
        <van-steps direction="vertical" :active="active" :inactive-icon="inactiveIcon">
          <van-step
            style="border-radius:10px;box-shadow: 2px 2px 8px -2px rgba(155,155,155,0.50);background: #f3f3f3;margin-bottom: 3%;"
          >
            <van-cell
              class="cellriskEventName"
              label-class="labelriskEventName"
              :label="riskEnevtData.riskEventDO.createdDate"
              center
              :title="riskEnevtData.riskEventDO.riskEventName"
            />
            <div style="position: relative;padding-left: 2%;">
              <img
                style="width:100%;object-fit: cover; height: 156px;border-radius:5px"
                @click="img()"
                :src="riskEnevtData.riskEventPicDO.length>0?imagesUrl+riskEnevtData.riskEventPicDO[0].picPath:ownerCommunityImg"
              />
              <div
                v-if="riskEnevtData.riskEventPicDO.length>0"
                class="riskEnevt"
              >{{riskEnevtData.riskEventPicDO[0].picDescription}}</div>
            </div>
            <div style="width: 100%;" @click="riskDetails('riskDetails')">
              <van-cell
                :border="false"
                title="风险等级"
                :value="riskEnevtData.riskEventDO.riskLevel"
                style="text-align: left;"
              />
              <van-cell
                :border="false"
                title="发生时间"
                :value="riskEnevtData.riskEventDO.riskFoundTime"
                style="text-align: left;"
              />
              <van-cell
                label-width
                :border="false"
                title="建议截止时间"
                :value="riskEnevtData.riskEventDO.proposedAmendDeadline"
                style="text-align: left;"
              />
              <van-cell
                title="整改进度"
                style="text-align: left;"
                value-class="right"
                :border="false"
                label-width="50"
              >
                <template>
                  <van-progress
                    :percentage="riskEnevtData.riskEventDO.amendProgress"
                    stroke-width="8"
                    style="width: 75%;"
                  />
                </template>
              </van-cell>
            </div>
          </van-step>
          <van-step
            v-for="(item,index) in stepList"
            :key="index"
            style="box-shadow: 2px 2px 8px -2px rgba(155,155,155,0.50);background: #f3f3f3;margin-bottom: 3%;"
          >
            <van-cell
              class="cellriskEventName"
              label-class="labelriskEventName"
              :label="item.createdDate"
              center
              :title="item.number"
            />
            <div style="position: relative;padding-left: 2%;">
              <img
                :src="item.imagePathList.length>0 ?imagesUrl+item.imagePathList[0].picPath:ownerCommunityImg"
                alt
                @click="imgPic(item.imagePathList)"
                style="width: 100%;object-fit: cover; height: 156px;border-radius:5px"
              />
              <div
                v-if="item.imagePathList.length>0"
                class="riskEnevt"
              >{{item.imagePathList.length>0 ? item.imagePathList[0].picDescription:''}}</div>
            </div>
            <div style="width: 100%;" @click="rectificationDetails(item,'rectification')">
              <van-cell
                :border="false"
                title="项目阶段"
                :value="item.projectPhase"
                style="text-align: left;"
              />
              <van-cell
                :border="false"
                title="形象进度"
                :value="item.projectVisualProgress"
                style="text-align: left;"
              />
              <van-cell
                :border="false"
                title="整改描述"
                :value="item.amendActionDesc"
                style="text-align: left;"
              />
              <van-cell title="整改进度" style="text-align: left;" value-class="right" :border="false">
                <template>
                  <van-progress
                    :percentage="item.amendProgress"
                    stroke-width="8"
                    style="width:75%;"
                  />
                </template>
              </van-cell>
            </div>
            <van-row>
              <!-- <van-progress :percentage="50" stroke-width="8" /> -->
            </van-row>
          </van-step>
        </van-steps>
      </van-row>
    </div>
    <van-divider :style="{ color: '#1989fa', borderColor: '#ebedf0' }"></van-divider>
    <div style="padding:0 15px">
      <div class="title">评论</div>
      <!-- v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad" -->
      <van-list>
        <div v-for="item in followPostList" :key="item.id" class="main_post">
          <van-row>
            <van-col span="4">
              <van-image
                round
                class="manager mouse-pointer"
                :src="item.userImage"
                width="40"
                height="40"
              />
            </van-col>
            <van-col span="20">
              <van-col span="24" class="post_user" style="margin-top: 10px;">{{item.userName}}</van-col>
              <van-col span="24">
                <div class="main_contents">
                  {{item.replyContents}}
                  <div style="margin-top:3px" @click.stop="imgFun(item)">
                    <span
                      v-for="childItem in item.replyImages"
                      :key="childItem.id"
                      style="margin-right:10px;"
                    >
                      <van-image width="60" height="60" :src="imagesUrl+childItem.picPath" alt />
                    </span>
                  </div>
                </div>
                <van-col
                  span="24"
                  style="text-align: left;ont-family: PingFangSC-Regular;font-size: 12px;color: #B0B0B0;letter-spacing: 0;"
                >{{item.replyTime}}</van-col>
              </van-col>
              <!-- <van-col span="24" class="post_reply" v-if="item.listReply.length>0">
                <div v-for="reItem in item.listReply" :key="reItem.id" class="post_review">
                  <span>{{reItem.userName}}：</span>
                  {{reItem.replyContents}}
                </div>
              </van-col>-->
              <!-- <van-col span="24" class="post_user">
                <van-col span="10" style="text-align: right">
                  <van-icon name="chat-o" style="font-size: 16px;" @click="openNewReply(item)" />
                </van-col>
              </van-col>-->
            </van-col>
          </van-row>
          <!-- <div class="new_post" v-if="newReply">
            <van-cell-group style="text-align: left;">
              <van-field
                v-model="item.replyContents"
                rows="3"
                autosize
                type="textarea"
                placeholder="请输入正文"
              />
            </van-cell-group>
            <van-row>
              <van-button type="default" style="width:50%" @click="cancel">取消</van-button>
              <van-button type="primary" style="width:50%" @click="saveReply(item)">发表</van-button>
            </van-row>
          </div>-->
        </div>
      </van-list>
      <div class="new_post" v-if="openNewPost">
        <van-cell-group style="text-align: left;">
          <van-field v-model="replyContents" rows="3" autosize type="textarea" placeholder="请输入内容" />
          <van-uploader
            :after-read="uploadFile"
            :before-delete="afterDelete"
            v-model="imageList.imageCloudId"
            class="uploader"
          >
            <div class="iconfont icon-xaingji xaingjidiv">
              <div>上传图片</div>
            </div>
          </van-uploader>
        </van-cell-group>
        <van-row>
          <van-button type="info" style="width:50%" @click="cancel">取消</van-button>
          <van-button
            type="info"
            style="width:50%;background: #128FEB;"
            @click="commentPublish"
            :disabled="disabled"
          >发表</van-button>
        </van-row>
      </div>
      <div v-if="!openNewPost && !newReply" class="new_post">
       <div v-if='riskEnevtData.riskEventDO.riskEventStatus!="RES06"'>
          <van-button type="info" style @click="openNewPost=true">评论</van-button>
       </div>
        <div v-if='riskEnevtData.riskEventDO.riskEventStatus=="RES06"'>
          <van-button type="info" style="width:50%" @click="openNewPost=true">评论</van-button>
        <van-button type="info" style="width:50%;" @click="confirmCloseRectification">确认整改</van-button>
        </div>
      </div>
      <div style="height:60px"></div>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import { ImagePreview } from "vant";
export default {
  name: "riskEventComment",
  computed: {
    ...mapGetters(["selectedPrj"])
  },
  data() {
    return {
      dealImgWidth: 600,
      disabled: false,
      offset: 1, //第几页
      mainPost: {},
      finished: false,
      openNewPost: false,
      newReply: false,
      loading: false,
      followPostList: [],
      limit: 5, //每页几条数据
      imageList: [],
      replyContents: "",
      replyType: "1",
      replyToReplyId: null,
      ownerCommunityImg: require("@/assets/imgs/moren.jpg"),
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      stepList: [],
      active: 0,
      inactiveIcon: require("../../assets/imgs/owner-images/icon_completed.png"),
      riskEnevtData: {
        riskEventDO: {
          projectName: "",
          amendProgress: 0
        },
        riskEventPicDO: [
          {
            picPath: ""
          }
        ],
        userDO: []
      },
      imgList: [],
      imgPicDo: []
    };
  },
  created() {
    this.riskEnevt();
    this.riskEventRepair();
    this.getListFollowReply();
  },
  methods: {
    // openNewReply(item) {
    //   console.log(item);
    //   this.newReply = true;
    //   this.followId = item.id;
    //   console.log(this.followId);
    // },
    //回复
    // saveReply(reItem) {
    //   console.log(reItem);
    //   const keywords = {
    //     replyToReplyId: this.replyToReplyId,
    //     followId: this.followId,
    //     mainId: this.riskEnevtData.riskEventDO.id,
    //     userId: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo)).userId,
    //     userName: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
    //       .username,
    //     projectId: this.$route.query.projectId,
    //     replyType: this.replyType,
    //     replyTopic: "",
    //     replyContents: reItem.replyContents
    //   };
    //   http.post("/forum/saveReply", keywords).then(res => {
    //     console.log(res);
    //     if (res.code == 0) {
    //       this.offset = 1;
    //       this.getListFollowReply();
    //       this.followContents = "";
    //       this.newReply = false;
    //     }
    //   });
    // },
    cancel() {
      this.openNewPost = false;
      (this.replyContents = ""), (this.imageList = []);
    },
    //图片预览
    imgFun(item) {
      let imgLists = [];
      item.replyImages.map((item1, index) => {
        imgLists.push(this.imagesUrl + item1.picPath);
      });
      // ImagePreview(imgLists);
      ImagePreview({
        images: imgLists,
        closeable: true,
        closeOnPopstate: true
      });
    },
    // 删除图片
    afterDelete(file, detail) {
      return this.imageList.splice(detail.index, 1);
    },
    //上传
    async uploadFile(param) {
      this.disabled = true;
      param.status = "uploading";
      param.message = "上传中";
      console.log("file", param.file);
      var toFile = param.file;
      if (toFile.type.startsWith("image") && toFile.size > 1024 * 1024) {
        var _this = this;
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        );
        toFile = _this.$dataURLtoFile(base64, toFile.name);
      }
      let file = new FormData();
      console.log("大小", toFile);
      file.append("file", toFile);
      file.append("fileIcon", "forumPic");
      file.append("projectId", this.$route.query.projectId);
      let keepPic = {
        picType: "2",
        picName: "",
        picPath: "",
        picUidName: param.file.uid,
        projectId: this.$route.query.projectId
      };
      console.log("file", file.get("file"));
      http.post("/risk/riskEventRepairReply/upload", file).then(res => {
        if (res.code === 0) {
          keepPic.picPath = res.data.cloudDocId;
          keepPic.picUidName = res.data.uidFileName;
          this.imageList.push(keepPic);
          param.status = "done";
          this.disabled = false;
        } else {
          param.status = "failed";
          param.message = "上传失败";
          this.disabled = false;
        }
      });
    },
    // 将base64转化为文件
    dataURLtoFile(dataurl, filename) {
      var arr = dataurl.split(","),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new File([u8arr], filename, { type: mime });
    },
    // 压缩方法
    dealImage(base64, w) {
      return new Promise((resolve, reject) => {
        console.log(base64);
        var newImage = new Image();
        var quality = 1;
        newImage.src = base64;
        newImage.setAttribute("crossOrigin", "Anonymous");
        var imgWidth, imgHeight;
        newImage.onload = function() {
          imgWidth = this.width;
          imgHeight = this.height;
          var canvas = document.createElement("canvas");
          var ctx = canvas.getContext("2d");
          if (Math.max(imgWidth, imgHeight) > w) {
            if (imgWidth > imgHeight) {
              canvas.width = w;
              canvas.height = (w * imgHeight) / imgWidth;
            } else {
              canvas.height = w;
              canvas.width = (w * imgWidth) / imgHeight;
            }
          } else {
            canvas.width = imgWidth;
            canvas.height = imgHeight;
          }
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(this, 0, 0, canvas.width, canvas.height);
          var base64 = canvas.toDataURL("image/jpeg", quality);

          while (base64.length / 1024 > 1024) {
            quality -= 0.01;
            if (quality < 0.1) {
              break;
            }
            base64 = canvas.toDataURL("image/jpeg", quality);
            console.log("压缩大小，系数(xiao)", base64.length, quality);
          }
          // while(base64.length / 1024 < 50*1024) {
          //   quality += 0.01
          //   if(quality > 0.92) {
          //     break
          //   }
          //   base64 = canvas.toDataURL("image/jpeg", quality)
          //   console.log('压缩大小，系数(da)',base64.length, quality)
          // }
          console.log("压缩后大小", base64.length / 1024);
          resolve(base64);
        };
      });
    },
    //获取评论列表
    onLoad() {
      setTimeout(() => {
        this.offset += 1;
        const keywords = {
          offset: this.offset,
          limit: this.limit,
          replyTarget: this.riskEnevtData.riskEventDO.id
        };
        http
          .post("/risk/riskEventRepairReply/listReply", keywords)
          .then(res => {
            if (res.code == 0) {
              this.followPostList.push(...res.data.rows);
              // 加载状态结束
              // this.loading = false;
              // console.log(res.data.rows.length)
              // if (res.data.rows.length < 5) {
              //   this.finished = true;
              // }
            }
          });
      }, 500);
    },
    confirmCloseRectification() {
      const keywords = {
        id: this.$route.query.id,
        riskEventStatus: "RES08"
      };
      http.put("/risk/RiskEvent/repairConfirm", keywords).then(res => {
        if (res.code === 0) {
          this.$toast({ message: res.msg });
          this.onClickLeft()
        }
      });
    },
    // //获取贴子详情
    getListFollowReply() {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        replyTarget: this.$route.query.id + this.$route.query.projectId
      };
      http.post("/risk/riskEventRepairReply/listReply", keywords).then(res => {
        res.data.rows.map((item, index) => {
          if (item.listReply.length > 0) {
            item.flag = true;
          } else {
            item.flag = false;
          }
          if (item.replyImages != null) {
            item.replyImages.map((childItem, index1) => {
              childItem.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}&view=1`;
            });
          }
        });
        this.followPostList = res.data.rows;
        this.total = res.data.total;
      });
    },
    //图片缩略
    img() {
      if (this.imgList.length == 0) {
        // ImagePreview([this.ownerCommunityImg]);
        ImagePreview({
          images: [this.ownerCommunityImg],
          closeable: true,
          closeOnPopstate: true
        });
      } else {
        // ImagePreview(this.imgList);
        ImagePreview({
          images: this.imgList,
          closeable: true,
          closeOnPopstate: true
        });
      }
    },
    imgPic(item) {
      this.imgPicDo = [];
      if (item.length == 0) {
        // ImagePreview([this.ownerCommunityImg]);
        ImagePreview({
          images: [this.ownerCommunityImg],
          closeable: true,
          closeOnPopstate: true
        });
      } else {
        item.map((item1, idnex) => {
          this.imgPicDo.push(this.imagesUrl + item1.picPath);
        });
        // ImagePreview(this.imgPicDo);
        ImagePreview({
          images: this.imgPicDo,
          closeable: true,
          closeOnPopstate: true
        });
      }
    },
    //获取风险事件
    riskEnevt() {
      let _this = this;
      http.get("/risk/RiskEvent/", this.$route.query.id).then(res => {
        this.riskEnevtData.riskEventDO = res.data.riskEventDO;
        this.riskEnevtData.riskEventPicDO = res.data.riskEventPicDO;
        this.riskLevelList();
        if (this.riskEnevtData.riskEventDO.proposedAmendDeadline !== null) {
          this.riskEnevtData.riskEventDO.proposedAmendDeadline = this.riskEnevtData.riskEventDO.proposedAmendDeadline.split(
            " "
          )[0];
        }
        if (this.riskEnevtData.riskEventDO.createdDate !== null) {
          this.riskEnevtData.riskEventDO.createdDate = this.riskEnevtData.riskEventDO.createdDate.split(
            " "
          )[0];
        }
        if (this.riskEnevtData.riskEventDO.riskFoundTime !== null) {
          this.riskEnevtData.riskEventDO.riskFoundTime = this.riskEnevtData.riskEventDO.riskFoundTime.split(
            " "
          )[0];
        }
        _this.riskEnevtData.riskEventDO.amendProgress = Number(
          _this.riskEnevtData.riskEventDO.amendProgress
        );
        this.riskEnevtData.riskEventPicDO.map((item, index) => {
          this.imgList.push(this.imagesUrl + item.picPath);
        });
      });
    },
    riskLevelList() {
      JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_LEVEL.map(_data => {
        if (_data.dictKey == this.riskEnevtData.riskEventDO.riskLevel) {
          this.riskEnevtData.riskEventDO.riskLevel = _data.dictValue;
        }
      });
    },
    //获取事件整改
    riskEventRepair() {
      let _this = this;
      http
        .get("/risk/RiskEventRepair", {
          riskEventId: this.$route.query.id
        })
        .then(res => {
          this.stepList = res.data.rows;
          this.active = res.data.total + 1;
          this.stepList.map((item, index) => {
            if (item.createdDate !== null) {
              item.createdDate = item.createdDate.split(" ")[0];
            }
            item.amendProgress = Number(item.amendProgress);
            JSON.parse(
              localStorage.getItem(this.$getMobileData.baseSelects)
            ).IDI_PROJ_PROCESS.map(_data => {
              if (_data.dictKey == item.projectPhase) {
                item.projectPhase = _data.dictValue;
              }
            });
          });
        });
    },
    //事件详情
    riskDetails(type) {
      this.$router.push({
        path: "/riskEvevtsDetails",
        query: {
          id: this.riskEnevtData.riskEventDO.id,
          type: type
        }
      });
    },
    rectificationDetails(item, type) {
      this.$router.push({
        path: "/riskEvevtsDetails",
        query: {
          id: item.id,
          type: type
        }
      });
    },
    //发表评论
    commentPublish() {
      // 是否输入内容
      if (!this.replyContents) {
        this.$toast("请输入内容");
        return;
      }
      http
        .post("/risk/riskEventRepairReply/save", {
          userId: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
            .userId,
          userName: JSON.parse(
            localStorage.getItem(this.$getMobileData.userInfo)
          ).username,
          replyTarget: this.$route.query.id + this.$route.query.projectId,
          replyImages: this.imageList,
          replyContents: this.replyContents
        })
        .then(res => {
          if (res.code == 0) {
            this.replyContents = "";
            this.imageList = [];
            this.fileList = [];
            this.offset = 1;
            this.getListFollowReply();
            this.openNewPost = false;
            this.$toast({ message: "发表成功" });
          }
        });
    },

    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="less" scoped>
.right {
  padding-top: 3%;
  padding-bottom: 2%;
}
.van-cell {
  background: #f3f3f3;
  padding: 0 16/16rem;
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #595959;
  letter-spacing: 0;
  line-height: 22/16rem;
}
.van-cell__value {
  text-align: left;
}
.van-step--vertical .van-step__line {
  top: 21/16rem;
  background-color: #1989fa;
}
.title {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #000000;
  letter-spacing: 0;
  text-align: left;
  padding-bottom: 5%;
}
.family {
  font-family: PingFangSC-Semibold;
  font-size: 14/16rem;
  color: rgb(89, 89, 89);
  letter-spacing: 0px;
  line-height: 21/16rem;
  margin-top: 20/16rem;
  text-align: left;
  word-break: break-all;
  word-wrap: break-word;
}
.main_post {
  background-color: white;
  padding: 15/16rem 10/16rem 0 0;
  border-bottom: 1px solid #ebedf0;
}
.post_title {
  text-align: left;
  font-weight: bold;
  font-size: 16/16rem;
  margin-top: 8/16rem;
}
.post_user {
  text-align: left;
  color: #b4b8bf;
  font-size: 13/16rem;
}
.main_contents {
  text-align: left;
  padding: 5/16rem 5/16rem 5/16rem 0;
}
.interval-line {
  height: 10/16rem;
  background-color: #f3f3f3;
}
.new_post {
  position: fixed;
  bottom: 0;
  width: 100%;
  z-index: 2;
  left: 0;
  button {
    width: 100%;
    background: #128feb;
    font-size: 14/16rem;
  }
}
.post_reply {
  background-color: #f7f7f7;
  text-align: left;
  padding: 10/16rem;
}
.post_review {
  line-height: 25/16rem;
  span {
    color: #1271ce;
    font-weight: 500;
  }
}
.progress /deep/ .van-progress__pivot {
  left: 104/16rem !important;
}
.riskEnevt {
  text-align: left;
  width: 91.5%;
  background: rgba(0, 0, 0, 0.2);
  position: absolute;
  bottom: 2.5%;
  left: 5%;
  height: 36/16rem;
  font-family: PingFangSC-Medium;
  font-size: 10/16rem;
  color: #ffffff;
  letter-spacing: 0;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
}
.uploader {
  margin: 5/16rem 0/16rem 5/16rem 15/16rem;
}
.xaingjidiv {
  font-size: 30/16rem;
  text-align: center;
  border: 1px solid #c5c5c5;
  width: 78/16rem;
  height: 68/16rem;
  padding-top: 10/16rem;
  div {
    font-size: 15/16rem;
  }
}
.mc-navbar {
  div {
    font-size: 14/16rem;
  }
}
.cellriskEventName {
  padding-left: 2%;
  text-align: left;
  font-family: PingFangSC-Medium;
  font-size: 16/16rem;
  color: #313131;
  letter-spacing: 0;
}
.labelriskEventName {
  margin-top: 3/16rem;
  color: #969799;
  font-size: 12/16rem;
  line-height: 18/16rem;
}
.van-nav-bar__title {
  max-width: 80%;
}
</style>
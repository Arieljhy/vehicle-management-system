<template>
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
    </van-nav-bar>
    <van-row style="position: relative;">
      <!-- <van-swipe :autoplay="3000">
        <van-swipe-item v-for="(image, index) in images" :key="index">
          <img v-lazy="image" />
        </van-swipe-item>
      </van-swipe>-->
      <van-image :src="ownerCommunityImg" />
      <van-row type="flex" justify="center">
        <van-col span="22" class="content">
          <div
            style="line-height: 45px;height:45px;text-align:left;padding-left:16px"
          >{{prjBasicInfoDO.communityName+"-"+prjBasicInfoDO.projectChnStatus}}</div>
        </van-col>
      </van-row>
    </van-row>
    <div>
      <van-row>
        <van-cell-group :border="false">
          <van-cell
            title="地址："
            :value="prjBasicInfoDO.province+prjBasicInfoDO.city+prjBasicInfoDO.district+prjBasicInfoDO.address"
            title-class="titleClass"
            style="padding-top:20px"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell title="住宅性质：" :value="prjBasicInfoDO.buildingType" title-class="titleClass" />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="总建筑面积："
            :value="prjBasicInfoDO.totalFloorage!=null?prjBasicInfoDO.totalFloorage+'平方米':0+'平方米'"
            title-class="titleClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="建筑栋数："
            :value="prjBasicInfoDO.numOfBuilding!=null?prjBasicInfoDO.numOfBuilding+'栋':0+'栋'"
            title-class="titleClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell title="竣工日期：" :value="prjBasicInfoDO.reportDate" title-class="titleClass" />
        </van-cell-group>
        <van-cell-group>
          <van-cell
            title="总户数："
            :value="prjBasicInfoDO.totalUnits!=null?prjBasicInfoDO.totalUnits+'户':0+'户'"
            title-class="titleClass"
          />
        </van-cell-group>
        <van-cell-group>
          <van-cell title="保单号：" :value="prjBasicInfoDO.insContractNo" title-class="titleClass" />
        </van-cell-group>
        <van-cell-group>
          <van-cell title="签单日期：" :value="prjBasicInfoDO.signDate" title-class="titleClass" />
        </van-cell-group>
      </van-row>
      <van-row>
        <div style="padding-top: 10%;padding-bottom: 5%;text-align: left;padding-left: 10px;">
          <span class="blue font-bold name">项目概述</span>
        </div>
      </van-row>
      <van-row>
        <van-col span="24">
          <van-cell-group style="margin-bottom: 20%;margin-left:15px;margin-right:15px;">
            <van-field
              v-model="prjBasicInfoDO.projectInfo"
              rows="3"
              placeholder="无"
              autosize
              disabled
              type="textarea"
              style="background-color: #F2F2F2;border-radius:5px"
            />
          </van-cell-group>
        </van-col>
      </van-row>
    </div>
    <van-row span="24" class="informationBtn" v-if="prjBasicInfoDO.community=='Y'">
      <van-button type="info">已添加到我的项目</van-button>
    </van-row>
    <van-row span="24" class="informationBtn" @click="newRiskEvent" v-else>
      <van-button type="info">添加到我的项目</van-button>
    </van-row>
  </div>
</template>
<script>
import http from "@/common/request";
export default {
  data() {
    return {
      prjBasicInfoDO: {},
      images: [],
      ownerCommunityImg: require("@/assets/imgs/moren.jpg"),
      accountType: ""
    };
  },
  created() {
    this.construction();
    this.getAccountType();
  },
  methods: {
    newRiskEvent() {
      localStorage.setItem('eidi.selected_project', JSON.stringify(this.prjBasicInfoDO))
      http
        .post("/community/save", {
          projectId: this.prjBasicInfoDO.projectId
        })
        .then(res => {
          if (res.code == "0") {
            if (this.accountType === "OWN") {
              this.$router.push({
                path: "/ownerCommunity"
              });
              return;
            }
            this.$router.push({
              path: "/myToDoRisk",
              query: {
                // id: item.projectId,
                // item: item
                // item: JSON.stringify(item)
              }
            });
          }
        });
    },
    onClickLeft() {
      this.$router.go(-1);
    },
    // 获取账号类型
    getAccountType() {
      this.accountType = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).roleType;
    },
    //查询详情
    construction() {
      http
        .get("/project/PrjQueryInfo", {
         projectId: this.$route.query.item,
          offset: 1,
          limit: 1
        })
        .then(res => {
          this.prjBasicInfoDO = res.data.rows[0];
          if (this.prjBasicInfoDO.reportDate !== null) {
            this.prjBasicInfoDO.reportDate = this.prjBasicInfoDO.reportDate.split(
              " "
            )[0];
          }
          if (this.prjBasicInfoDO.signDate !== null) {
            this.prjBasicInfoDO.signDate = this.prjBasicInfoDO.signDate.split(
              " "
            )[0];
          }
          JSON.parse(
            localStorage.getItem(this.$getMobileData.baseSelects)
          ).IDI_PROJECT_TYPES.map(_data => {
            if (_data.dictKey == this.prjBasicInfoDO.buildingType) {
              this.prjBasicInfoDO.buildingType = _data.dictValue;
            }
          });
        });
    }
  }
};
</script>
<style lang="less" scoped>
.van-swipe {
  height: 238/16rem;
}
.van-swipe img {
  width: 100%;
  height: 100%;
}
.content {
  width: 100%;
  position: absolute;
  margin-top: -45px;
  height: 45px;
  background: rgba(0, 0, 0, 0.7);
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #ffffff;
  letter-spacing: 0;
}
.titleClass {
  max-width: 100/16rem;
  text-align: left;
  font-weight: 700;
}
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  max-width: 640/16rem;
  background: #128feb;
  bottom: 0/16rem;
}
.name {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #128feb;
  font-weight: 800;
  margin-bottom: 5%;
}
</style>
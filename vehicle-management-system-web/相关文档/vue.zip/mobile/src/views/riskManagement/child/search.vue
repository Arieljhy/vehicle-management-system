<template>
  <div style="background: #F2F3F5;">
    <van-row style="position:relative;background-color: #128feb">
      <van-col span="2" class="backIcon">
        <van-icon v-if="isDataList1" name="arrow-left" @click="onClickLeft" />
      </van-col>
      <van-col span="20">
        <van-search
          background="#128feb"
          shape="round"
          placeholder="输入项目名称、保单号"
          v-model="fitterData.fuzzyQuery"
          @search="onSearch"
          @focus="obtionFocus"
        />

        <div
          v-if="fitterData.fuzzyQuery==''"
          class="iconfont icon-yuyin"
          @click="openRecordDiolog"
          style=" position: absolute;top:23.5%;right:11%;color:#8E8E93;font-size: 25px;width: 50px;"
        ></div>
        <!-- <span
          v-else
          class="iconfont icon-shanchu"
          style=" position: absolute;top:22.5%;right:20%;color:#8E8E93;font-size: 25px;"
          @click="empty"
        ></span>-->
      </van-col>
      <van-col span="2" class="settingIcon">
        <van-icon name="setting-o" @click="jumpMy" />
      </van-col>
      <!-- <van-col span="2" style="line-height: 58px;" v-if="fitterData.fuzzyQuery==''">
        <van-icon name="setting-o" @click="jumpMy" />
      </van-col>-->
      <!-- <van-col span="2" style="text-align: left; margin-top: 4%;" v-if="!fitterData.fuzzyQuery==''" @click="onSearch">
        <span class="searchspan">搜索</span>
      </van-col>-->
    </van-row>
    <!-- 筛选 -->
    <div class="shaixuan">
      <div v-if="userType == 'INS'">
        <van-row type="flex" justify="center" class="selectTab">
          <van-col span="4" @click="sortEvent('riskEvent')">风险事件</van-col>
          <!-- 正序倒序高亮显示 -->
          <van-col span="1">
            <div class="upTriangle" :class="{selectTriangleUp:isRiskEvent}"></div>
            <div class="downTriangle" :class="{selectTriangleDown:!isRiskEvent}"></div>
          </van-col>

          <van-col span="4" @click="sortEvent('claim')">理赔</van-col>
          <van-col span="1" class="right-10">
            <div class="upTriangle" :class="{selectTriangleUp:isClaim}"></div>
            <div class="downTriangle" :class="{selectTriangleDown:!isClaim}"></div>
          </van-col>
          <van-col span="4" @click="sortEvent('meterCost')">平米造价</van-col>
          <van-col span="1">
            <div class="upTriangle" :class="{selectTriangleUp:isMeterCost}"></div>
            <div class="downTriangle" :class="{selectTriangleDown:!isMeterCost}"></div>
          </van-col>
          <van-col span="4" @click="sortEvent('rate')">费率</van-col>
          <van-col span="1" class="right-10">
            <div class="upTriangle" :class="{selectTriangleUp:isRate}"></div>
            <div class="downTriangle" :class="{selectTriangleDown:!isRate}"></div>
          </van-col>

          <van-col span="4" @click="isPopup=true">
            <span class="iconfont icon-shaixuan" style="font-size:14px;">筛选</span>
          </van-col>
        </van-row>
      </div>
      <div v-if="userType == 'BLD' || userType == 'TIS'">
        <van-row type="flex" style="font-size:14px;">
          <van-col span="7" @click="sortEvent('riskEvent')">风险事件</van-col>
          <!-- 正序倒序高亮显示 -->
          <van-col span="1">
            <div class="upTriangle" :class="{selectTriangleUp:isRiskEvent}"></div>
            <div class="downTriangle" :class="{selectTriangleDown:!isRiskEvent}"></div>
          </van-col>
          <van-col span="7" :offset="1" @click="sortEvent('signDate')">签单日期</van-col>
          <van-col span="1">
            <div class="upTriangle" :class="{selectTriangleUp:isSigningDate}"></div>
            <div class="downTriangle" :class="{selectTriangleDown:!isSigningDate}"></div>
          </van-col>
          <van-col span="4" :offset="5" @click="isPopup=true">
            <span class="iconfont icon-shaixuan" style="font-size:14px;">筛选</span>
          </van-col>
        </van-row>
      </div>
      <!-- 筛选 -->
      <van-popup
        v-model="isPopup"
        position="right"
        :style="{ width: '85%' }"
        @close="isPopup = false"
        @click-overlay="isPopup = false"
      >
        <filterSearch @filterData="filterData" />
      </van-popup>
    </div>
    <van-list
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad(fitterData)"
      :offset="5"
    >
      <van-cell
        v-for="(item,index) in superviseList"
        :key="item.id"
        style="width: 92%;
                margin: 0 auto 10px;
                padding: 0;
                background: #ffffff;
                box-shadow: 2px 2px 8px -2px rgba(155, 155, 155, 0.5);
                border-radius: 3%;
                position:relative"
        @click.stop="listFun(item)"
      >
        <van-col span="24" style="padding-left:8px;padding-right:8px">
          <van-col span="14">
            <div class="content">{{item.projectName}}</div>
          </van-col>
          <van-col span="10" class="academician">
            <span style="margin-right: 10%;font-size: 13px;">{{item.projectChnStatus}}</span>
          </van-col>
          <van-divider :style="{ color: '#1989fa', borderColor: '#ebedf0', padding: '10px 10px' }"></van-divider>
          <div class="leftRound"></div>
          <div class="rightRound"></div>
          <van-col
            span="7"
            class="contetImg"
            style="margin-bottom: 15px;margin-top:-6px;margin-left: 2%;"
          >
            <van-image :src="item.imgSrc" radius="5" />
          </van-col>
          <van-col
            span="16"
            style="background-color: #fff;margin-top: -10px;padding-left: 3%;text-align: left;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 1;overflow: hidden;"
          >
            <span class="name">地址：</span>
            <span class="valName">{{item.province+item.city+item.district+item.address}}</span>
          </van-col>
          <van-col
            span="15"
            style="background-color: #fff;text-align: left;padding-left: 3%;padding-top: 1%;"
          >
            <van-col span="7">
              <span class="name">承保方：</span>
            </van-col>
            <van-col span="17">
              <span class="valName classExtra">{{item.insOrgName}}</span>
            </van-col>
          </van-col>
          <van-col span="15" style="background-color: #fff;text-align: left;padding-left: 3%;">
            <span class="name">建筑栋数：</span>
            <span class="valName">{{item.numOfBuilding}}</span>
          </van-col>
          <van-col
            span="15"
            style="background-color: #fff;text-align: left;padding-left: 3%;margin-bottom: 6px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
          >
            <span class="name">保单号：</span>
            <span class="valName">{{item.insContractNo}}</span>
          </van-col>
          <!-- <van-col span="7" class="canceldiv" v-if="item.community=='Y'" @click.stop="follow(item)">
            <div class="quxaiodiv">
              <van-icon name="star-o" />
              <span class="quxiao">取消关注</span>
            </div>
          </van-col>-->
          <!-- <van-col span="19" @click.stop="noticeFun">
            <van-notice-bar
              text="通知内容"
              left-icon="volume-o"
              style="background-color: #fff;height: 20px;margin-left: -4%;"
            />
          </van-col>-->
        </van-col>
        <van-col
          span="24"
          class="titleName"
          style="position:relative"
          @click.stop="change(item,index)"
        >
          <van-col span="18">
            <van-collapse :border="false" v-model="activeNames">
              <van-collapse-item :name="index" :border="false">
                <div slot="title" style="color: red;font-size:12px;">
                  <van-icon name="volume-o" />
                  <span style="vertical-align:2%;padding-left:2px">{{item.messageNum}}条通知未读</span>
                </div>
                <van-row
                  v-for="(item1,index1) in notice[index]"
                  :key="index1"
                  @click.stop="noticeFun(item1,item)"
                >
                  <van-notice-bar
                    text="通知"
                    left-icon="volume-o"
                    :scrollable="false"
                    style="background-color: #fff;height: 20px;font-size:12px;"
                  >{{item1.message}}</van-notice-bar>
                </van-row>
              </van-collapse-item>
            </van-collapse>
          </van-col>
          <van-col span="6" class="canceldiv" v-if="item.community=='Y'" @click.stop="follow(item)">
            <div class="quxaiodiv">
              <van-icon name="star-o" />
              <span class="quxiao">取消关注</span>
            </div>
          </van-col>
        </van-col>
      </van-cell>
    </van-list>
    <van-overlay :show="show" @click="show = false" @click.stop="onBldingsConfirm">
      <div class="wrapper">
        <div class="block" id="contentSend"></div>
      </div>
    </van-overlay>
    <van-dialog
      v-model="openRecord"
      :show-confirm-button="showButton"
      :overlay="showOverlay"
      width="230px"
    >
      <div style="padding:35px;">
        <!-- <div
          class="mc-record"
          @touchstart="gotouchstart"
          @touchmove="gotouchmove"
          @touchend="gotouchend"
        >按住说话</div>-->
        <mcRecorder @handleStop="handelEndRecord" />
      </div>
    </van-dialog>
    <!-- 返回顶部 -->
    <div>
      <van-row id="top" class="top" style="display:none" @click="top">
        <span>top</span>
      </van-row>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import filterSearchVue from "../../supervise/child/filterSearch.vue";
import mcRecorder from "@/components/mcRecorder";
export default {
  components: {
    filterSearch: filterSearchVue,
    mcRecorder
  },
  data() {
    return {
      tis: "",
      flag: false,
      list: [],
      offset: 1,
      // 触底掉接口
      loading: false,
      value: "项目施工中",
      activeNames: [],
      PageIndex: 0,
      // 列表数据
      MyRecommendsData: [],
      ownerCommunityImg: require("@/assets/imgs/moren.jpg"),
      notice: [],
      show: false,
      message: "",
      accountType: "",
      // 判断是否搜索操作
      isSearch: false,
      iconSearch: require("@/assets/imgs/filter-search/icon_filter_search.png"),
      // 签单日期排序
      sort: "sign_date",
      order: "desc",
      // 排序三角提示是否点亮
      isRiskEvent: false,
      isClaim: false,
      isMeterCost: false,
      isRate: false,
      isSigningDate: false,
      tenantId: "",
      superviseList: [],
      fitterData: {
        // 搜索
        voice: "", //语音
        fuzzyQuery: "",
        limit: 5,
        offset: 1,
        province: this.$getMobileData.province,
        city: this.$getMobileData.city,
        district: "",
        minCostPerMeter: "",
        maxCostPerMeter: "",
        beginSignDate: "",
        endSignDate: "",
        buildingType: "",
        projectStatus: "",
        orgIds: [],
        isChecked: false,
        sort: "sign_date",
        order: "desc",
        // contractNotNull: ""
        isMainIns: ""
      },
      isPopup: false,
      finished: false,
      openRecord: false,
      timeOutEvent: 0,
      showButton: false,
      showOverlay: false
    };
  },
  computed: {
    ...mapGetters([
      "provinceList",
      "isDataList1",
      "limit",
      "province",
      "city",
      "district",
      "minCostPerMeter",
      "maxCostPerMeter",
      "beginSignDate",
      "endSignDate",
      "buildingType",
      "orgIds",
      "isChecked",
      "userType",
      "selectedPrj"
    ])
  },
  created() {
    this.tis = JSON.parse(localStorage.getItem(this.$getMobileData.userInfo));
    if (
      this.tis.roleType == "SGF" ||
      this.tis.roleType == "KC" ||
      this.tis.roleType == "JL" ||
      this.tis.roleType == "SJ"
    ) {
       this.fitterData.isChecked=true
    }
    this.fitterData.offset = 1;
    this.getUserType();
    this.superviseList = [];
    this.loading = false;
    this.getAccountType();
    http.post("/community/listIns", { isPage: false }).then(res => {
      if (res.code === 0) {
        if (res.data.length == 0) {
          this.isDataList(false);
        }
      }
    });
  },
  mounted() {
    //监听滚动事件
    window.addEventListener("scroll", this.onscroll);
  },
  methods: {
    ...mapActions([
      "getSuperviseList",
      "getUserType",
      "isDataList",
      "getProjectList"
    ]),
    openRecordDiolog() {
      this.openRecord = true;
      setTimeout(() => {
        this.openRecord = false;
      }, 10000);
    },
    handelEndRecord(param) {
      let reader = new FileReader();
      reader.readAsDataURL(param.mblob);
      this.openRecord = false;
      reader.onload = e => {
        this.msource = e.target.result.replace("data:audio/wav;base64,", "");
        const keywords = {
          speech: this.msource,
          format: "wav",
          channel: 1,
          rate: 16000,
          token: JSON.parse(localStorage.getItem("eidi_mobile.baiduTocken")),
          cuid: "baidu_eidi",
          dev_pid: 1537,
          len: param.mblob.size
        };
        http.post("/baidu/server_api", keywords).then(res => {
          if (res.err_no == 0) {
            this.fitterData.fuzzyQuery = res.result[0].replace(
              /[\ |\?|\。|\？]/g,
              ""
            );
            this.onSearch();
          }
        });
      };
    },
    gotouchstart() {
      let that = this;
      // clearTimeout(this.timeOutEvent); //清除定时器
      this.timeOutEvent = 0;
      // this.timeOutEvent = setTimeout(() => {
      // if (typeof androidApp !== "undefined") {
      //   androidApp.startRecord(
      //     JSON.parse(localStorage.getItem("eidi_mobile.baiduTocken"))
      //   );
      // }
      // }, 1000);
    },
    gotouchend() {
      // clearTimeout(this.timeOutEvent);
      if (this.timeOutEvent != 0) {
        console.log("结束事件！！");
        // if (typeof androidApp !== "undefined") {
        //   this.fitterData.fuzzyQuery = androidApp.stopRecord(true).result[0];
        // }
        this.onSearch();
        this.openRecord = false;
      }
    },
    gotouchmove() {
      console.log("取消事件！！");
      // clearTimeout(this.timeOutEvent);
      // if (typeof androidApp !== "undefined") {
      //   androidApp.stopRecord(true);
      // }
      // this.timeOutEvent = 0;
    },
    //取消关注
    follow(item) {
      http
        .post("/community/unAttention", {
          projectId: item.projectId
        })
        .then(res => {
          if (res.code == 0) {
            item.community = "N";
          }
        });
    },
    jumpMy() {
      this.$router.push("/personalSettings");
    },
    filterData(value) {
      this.fitterData = value;
      this.isPopup = false;
      this.superviseList = [];
      this.getprojectList(this.fitterData);
    },
    getprojectList(value) {
      http.get("/project/PrjQueryInfo", value).then(res => {
        if (res.code === 0) {
          let rows = res.data.rows;
          if (rows == null || rows.length === 0) {
            // 加载结束
            this.finished = true;
            return;
          }
          let projectIds = "";
          rows.map(item => {
            projectIds = projectIds + item.projectId + ",";
          });
          http
            .get("/project/concatImg/logos", { projectIds: projectIds })
            .then(res => {
              rows.map(item => {
                if (res.data[item.projectId.replace("-", "_")]) {
                  item.imgSrc =
                    "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                    res.data[item.projectId.replace("-", "_")];
                } else {
                  item.imgSrc = this.ownerCommunityImg;
                }
              });
              this.superviseList = rows;
            });
          if (res.data.rows.length < 5) {
            this.finished = true;
          } else {
            this.fitterData.offset += 1;
          }
        }
      });
    },
    onClickLeft() {
      if (this.accountType === "OWN") {
        this.$router.push({
          path: "/ownerCommunity"
        });
        return;
      }
      this.$router.push({
        path: "/myToDoRisk",
        query: {
          // projectId: item.projectId,
          // item: item
          // item: JSON.stringify(item)
        }
      });
    },
    listFun(item) {
      if (item.community == "Y") {
        localStorage.setItem("eidi.selected_project", JSON.stringify(item));
        this.$router.push({
          path: "/myToDoRisk",
          query: {
            item: item
          }
        });
      } else {
        this.$router.push({
          path: "/searchDetails",
          query: {
            item: item.projectId
          }
        });
      }
    },
    change(item, index) {
      let _this = this;
      http
        .get("/send/getPressMessage", {
          msgType: 2,
          msgTypeId: item.projectId,
          read: 0
        })
        .then(res => {
          _this.notice[index] = [];
          _this.notice[index] = JSON.parse(JSON.stringify(res.data));
          _this.$set(_this.notice, index, _this.notice[index]);
          // _this.$set(_this.notice[index])
          item.messageNum = res.msg;
        });
    },
    // 获取账号类型
    getAccountType() {
      this.accountType = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).roleType;
    },
    sortEvent(type) {
      const _this = this;
      if (type === "riskEvent") {
        // 风险事件排序
        _this.fitterData.sort = "aaaaa.riskEventTotal";
        _this.isRiskEvent = !_this.isRiskEvent;
        if (_this.isRiskEvent) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "claim") {
        // 理赔排序
        _this.fitterData.sort = "aaaaa.claimTotal";
        _this.isClaim = !_this.isClaim;
        if (_this.isClaim) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "meterCost") {
        // 平米造价排序
        _this.fitterData.sort = "aaaaa.cost_per_meter";
        _this.isMeterCost = !_this.isMeterCost;
        if (_this.isMeterCost) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "rate") {
        // 费率排序
        _this.fitterData.sort = "aaaaa.ratePremium";
        _this.isRate = !_this.isRate;
        if (_this.isRate) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "signDate") {
        // 签单日期排序
        _this.fitterData.sort = "aaaaa.sign_date";
        _this.isSigningDate = !_this.isSigningDate;
        if (_this.isSigningDate) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      }
      _this.fitterData.offset = 1;
      _this.superviseList = [];
      _this.getprojectList(this.fitterData);
    },
    obtionFocus() {
      this.flag = true;
    },
    //清空内容
    empty() {
      this.fitterData.fuzzyQuery = "";
      this.fitterData.offset = 1;
      this.superviseList = [];
      this.getprojectList(this.fitterData);
      this.flag = false;
    },
    // 搜索事件
    onSearch(value) {
      //语音
      this.fitterData.yuYinFlag = "1";
      this.fitterData.voice = "";
      this.fitterData.offset = 1;
      this.superviseList = [];
      this.getprojectList(this.fitterData);
    },
    //通知
    noticeFun(item1, item) {
      this.show = true;
      http.get("/send/getUserMessageById", { id: item1.id }).then(res => {
        document.getElementById("contentSend").innerHTML = res.data.message;
        this.change(item);
      });
    },
    //通知关闭
    onBldingsConfirm() {},
    onLoad() {
      let _this = this;
      _this.loading = true;
      setTimeout(() => {
        http.get("/project/PrjQueryInfo", this.fitterData).then(res => {
          if (res.code === 0) {
            let rows = res.data.rows;
            this.loading = false;
            if (rows == null || rows.length === 0) {
              // 加载结束
              this.finished = true;
              return;
            }
            let projectIds = "";
            rows.map(item => {
              projectIds = projectIds + item.projectId + ",";
            });
            http
              .get("/project/concatImg/logos", { projectIds: projectIds })
              .then(res => {
                rows.map(item => {
                  if (res.data[item.projectId.replace("-", "_")]) {
                    item.imgSrc =
                      "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                      res.data[item.projectId.replace("-", "_")];
                  } else {
                    item.imgSrc = this.ownerCommunityImg;
                  }
                });
                this.superviseList.push(...rows);
              });
            if (res.data.rows.length < 5) {
              this.finished = true;
            } else {
              this.fitterData.offset += 1;
            }
          }
        });
      }, 500);
    },
    // 从缓存里面获取省的id
    getTenantId() {
      const _this = this;
      _this.tenantId = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).tenantId;
    },
    // 按钮显示/隐藏
    onscroll() {
      if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
        document.getElementById("top").style.display = "block";
      } else {
        document.getElementById("top").style.display = "none";
      }
    },
    // 返回顶部
    top() {
      window.scrollTo(0, 0);
    }
  },
  //离开页面要移除监听的滚动事件
  destroyed() {
    window.removeEventListener("scroll", this.onscroll);
  }
};
</script>
<style lang="less" scoped>
.search {
  background: #ffffff;
  border-radius: 18/16rem;
  height: 4.8%;
}
.content {
  margin-top: 10/16rem;
  margin-left: 4.3%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-break: keep-all;
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #000000;
  letter-spacing: 0;
  font-weight: 800;
}
.van-image {
  width: 90/16rem;
  height: 90/16rem;
}
.van-cell__title .van-cell {
  color: red;
}
.academician {
  background-color: #fff;
  text-align: right;
  margin-top: 10/16rem;
  font-family: PingFangSC-Regular;
  font-size: 14/16rem;
  color: #128feb;
  letter-spacing: 0;
  text-align: right;
}
.leftRound,
.rightRound {
  width: 16/16rem;
  height: 16/16rem;
  background: #f2f2f2;
  border-radius: 50%;
}
.leftRound {
  position: absolute;
  top: 21%;
  left: -8/16rem;
}
.rightRound {
  position: absolute;
  top: 21%;
  right: -8/16rem;
}
.name,
.valName {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #595959;
  letter-spacing: 0;
  line-height: 24/16rem;
}
.valName {
  font-family: PingFangSC-Regular;
}
.classExtra {
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp:2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
}
.title {
  margin: 15/16rem 0;
  font-family: PingFangSC-Semibold;
  font-size: 16px;
  color: #000000;
  letter-spacing: 0;
  font-weight: 900;
}
.mc-list {
  width: 92%;
  margin: 30/16rem auto 0/16rem;
  padding: 0;
  background: #ffffff;
  box-shadow: 2px 2px 8px -2px rgba(155, 155, 155, 0.5);
  border-radius: 3%;
}
.van-icon-volume-o {
  color: red;
}
.van-notice-bar {
  padding: 0;
}
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}
.block {
  border-radius: 5%;
  width: 80%;
  background-color: #fff;
  text-align: left;
  padding: 20/16rem;
}
.van-popup {
  text-align: left;
  height: 100%;
}
.van-popup /deep/ .cant {
  margin: 20/16rem 20/16rem;
}
.right-10 {
  position: relative;
  right: 10/16rem;
}
// 筛选的上下三角
.upTriangle {
  width: 0;
  height: 0;
  border-right: 5/16rem solid transparent;
  border-left: 5/16rem solid transparent;
  border-bottom: 5/16rem solid #000;
  margin: 3/16rem 0;
}

.downTriangle {
  width: 0;
  height: 0;
  border-right: 5/16rem solid transparent;
  border-left: 5/16rem solid transparent;
  border-top: 5/16rem solid #000;
}
.selectTriangleUp {
  border-bottom: 5/16rem solid #f5a623;
}
.selectTriangleDown {
  border-top: 5/16rem solid #f5a623;
}
.quxiao {
  padding-left: 5/16rem;
  line-height: 30/16rem;
  font-size: 11/16rem;
}
.quxaiodiv {
  color: #ffff;
  padding: 0 2/16rem;
  i {
    position: relative;
    top: 2/16rem;
    left: 3/16rem;
  }
}
.canceldiv {
  background: #f5a623;
  border-radius: 6/16rem 0 0 0;
  height: 30/16rem;
  position: relative;
  margin-top: 11/16rem;
  // right: 0;
  // bottom: 0;
  // margin-left: 255/16rem;
}
.searchspan {
  font-size: 14/16rem;
}
.mc-record {
  font-size: 23px;
  user-select: none;
  background-color: #e6e0e0;
}
.van-dialog {
  background: rgba(20, 35, 54, 0.5);
}
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  background: #ccc;
  border: 1/16rem solid #ccc;
  color: #ffffff;
  border-radius: 25/16rem;
  right: 20/16rem;
  bottom: 40/16rem;
  &:hover {
    cursor: pointer;
  }
  span {
    line-height: 30/16rem;
  }
}
.van-search {
  height: 46/16rem;
}
.backIcon,
.settingIcon {
  font-size: 20/16rem;
  color: #ffffff;
  margin-top: 12/16rem;
}
.shaixuan {
  margin: 10/16rem 10/16rem;
  .selectTab {
    font-size: 14/16rem;
  }
}
.van-collapse /deep/ .van-cell__right-icon {
  display: none;
}
.van-collapse /deep/ .van-collapse-item__title {
  padding: 10/16rem 16/16rem 0 16/16rem;
}
</style>
<template>
  <div style="text-align: left;background: rgb(242, 243, 245);" v-if="tis=='TIS' || tis=='INS' || tis=='GOV'
   || tis=='OP'|| tis=='BLD' || tis=='SGF'|| tis=='JL' || tis=='KC' || tis=='SJ'">
    <div style="padding: 0 15px">
      <div class="title">{{title}}</div>
      <div v-if="finalRiskData.startWorkDate">
        <van-row
          style="background: #FFFFFF;box-shadow: 2px 2px 8px -2px rgba(155,155,155,0.50);border-radius: 5px;"
        >
          <van-col span="24" style="padding-left: 5%;">
            <van-row class="reportTitle" style="margin-top:20px">
              <van-col span="8">最终检查报告：</van-col>
              <van-col span="16">
                <van-cell class="finalRiskData">{{finalRiskData.fileName}}</van-cell>
              </van-col>
            </van-row>
            <van-row class="reportTitle">
              <van-col span="6" class="name">报告人：</van-col>
              <van-col span="14" class="name">{{finalRiskData.createdName}}</van-col>
              <van-col span="3" class="see" @click="riskAssessmentReport('final')">查看</van-col>
            </van-row>
            <van-row class="reportTime">
              <van-col span="6">介入时间：</van-col>
              <van-col span="8">{{finalRiskData.startWorkDate}}</van-col>
            </van-row>
          </van-col>
        </van-row>
      </div>
      <div v-else>
        <van-row class="visitTitle">
          <van-col span="14">
            <p
              class="iconfont icon-gantanhao"
              style="margin-left: 80%;font-size:30px;color: #bfbfbf;margin-top: 20%;"
            ></p>
            <p style="margin-left: 79%;color: #bfbfbf; margin-top: 7%">暂无</p>
          </van-col>
        </van-row>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "FinalRiskReport",
  props: {
    title: {
      default: String,
      required: false
    }
  },
  data() {
    return {
      value: "逾期整改",
      riskEventName: "",
      date: undefined,
      tis: undefined
    };
  },
  computed: {
    ...mapGetters(["finalRiskData"])
  },
  created() {
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
  },
  methods: {
    //跳转到风险评估报告管理
    riskAssessmentReport(final) {
      this.$router.push({
        path: "/reportDetails",
        query: {
          type: final,
          projectId: this.finalRiskData.projectId,
          // item: item
          // item: JSON.stringify(item)
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.see {
  margin-left: 5/16rem;
  font-family: PingFangSC-Medium;
  font-size: 12/16rem;
  color: #128feb;
  letter-spacing: 0;
}
.name {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  line-height: 24/16rem;
}
.title {
  margin: 15/16rem 0;
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #000000;
  letter-spacing: 0;
  font-weight: 900;
}
.reportTitle {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  line-height: 24/16rem;
}
.reportTime {
  margin: 20/16rem 0;
  font-family: PingFangSC-Medium;
  font-size: 12/16rem;
  color: #595959;
  letter-spacing: 0;
}
.visitTitle {
  background: rgb(255, 255, 255);
  width: 100%;
  box-shadow: rgba(155, 155, 155, 0.5) 2px 2px 8px -2px;
  border-radius: 5/16rem;
  height: 150/16rem;
}
.finalRiskData {
  padding: 0 0;
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
   line-height: 24/16rem;
}
</style>
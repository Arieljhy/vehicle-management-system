<template>
  <div>
    <div>
      <van-row>
        <van-swipe :autoplay="3000">
          <van-swipe-item v-for="(image, index) in images" :key="index">
            <img v-lazy="image.imageUrl" />
          </van-swipe-item>
        </van-swipe>
      </van-row>
      <van-row type="flex" justify="center" style="border-radius: 5px;">
        <van-col span="22" class="content">
          <van-cell-group style="border-radius:5px ;">
            <van-cell
              :title="listRiskTis.district"
              :value="listRiskTis.projectChnStatus"
              title-class="leftTitle"
              value-class="rightValue"
              style="background:#f2f2f2;border-radius:5px 5px 0 0;padding: 0 12px;height:50px;line-height:50px;"
            />
            <van-cell
              style="padding:10px 20px;"
              class="policyNum"
              title="保单号："
              :value="listRiskTis.insContractNo"
              title-class="classTitle"
              value-class="classValue"
            />
            <van-cell
              style="padding:10px 20px;"  
              title="风险事件总数："
              :value="listRiskTis.totalRectification"
              title-class="classTitle"
              value-class="classValue"
            />
            <van-cell
              style="padding:10px 20px;"
              title="已关闭风险事件："
              :value="listRiskTis.noRectificationNum"
              title-class="classTitle"
              value-class="classValue"
            />
            <div v-if="openFlag">
              <van-cell
                style="padding:10px 20px;"
                title="开始介入日期："
                :value="listRiskTis.startWorkDate"
                title-class="classTitle"
                value-class="classValue"
              />
              <van-cell
                style="padding:10px 20px;"
                title="竣工检查日期："
                :value="listRiskTis.reportDate"
                title-class="classTitle"
                value-class="classValue"
              />
            </div>
            <van-cell @click="openfun" v-if="!openFlag" class="center">
              <van-icon name="arrow-down" />
            </van-cell>
            <van-cell @click="closeFun" v-else class="center">
              <van-icon name="arrow-down" />
            </van-cell>
          </van-cell-group>
        </van-col>
      </van-row>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "RiskHead",
  props: {
    title: {
      default: String,
      required: false
    }
  },
  computed: {
    ...mapGetters(["listRiskTis", "images", "listInsList"])
  },
  data() {
    return {
      openFlag: false,
      activeNames: [],
      tis: undefined
    };
  },
  created() {
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
  },
  methods: {
    openfun() {
      this.openFlag = true;
    },
    closeFun() {
      this.openFlag = false;
    }
  }
};
</script>

<style lang="less" scoped>
.van-swipe {
  height: 238/16rem;
}
.van-swipe img {
  width: 100%;
  height: 100%;
}
.content {
  margin-top: -50px;
  opacity: 0.9;
  background: #ffffff;
  box-shadow: 2px 2px 8px -2px rgba(155, 155, 155, 0.5);
  border-radius: 5px 5px 0px 0px;
}
.van-cell-group__title {
  text-align: left;
  font-size: 24/16rem;
}
.van-cell__title {
  text-align: left;
}
.policyNum .van-cell__title {
  max-width: 25%;
}
.van-cell:not(:last-child)::after {
  right: 10/16rem;
}
.van-collapse /deep/ .van-cell__right-icon {
  margin: 0 auto;
}
.content /deep/.van-collapse-item__content {
  padding: 0;
}
.leftTitle {
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #000000;
  letter-spacing: 0;
  font-weight: bold
}
.rightValue {
  font-family: PingFangSC-Medium;
  font-size: 13/16rem;
  color: #008a7b;
  letter-spacing: 0;
  text-align: right;
}
.center /deep/ .van-cell__value--alone {
  text-align: center !important;
}
.classTitle {
  font-family: PingFangSC-Semibold;
  font-size: 14/16rem;
  color: #000000;
  letter-spacing: 0;
}
.classValue {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  letter-spacing: 0;
  text-align: right;
}
</style>
<template>
  <div style="text-align: left;">
    <div style="padding: 0 15px">
      <div class="title">{{title}}</div>
      <div v-if="listRiskEvent.length>0">
        <van-row
          style="position:relative;background: #FFFFFF;box-shadow: 2px 2px 8px -2px rgba(155,155,155,0.50);border-radius: 5px;margin-bottom: 5%;"
          v-for="(item,index) in listRiskEvent"
          :key="index"
        >
          <van-col span="24" @click.stop="goComment(item)">
            <van-col span="16">
              <div class="content">{{item.riskEventName}}</div>
            </van-col>
            <van-col span="8" class="academician">
              <span
                :class="item.riskEventStatus=='整改完成'?'lvse':item.riskEventStatus=='整改逾期'?'red':'lan'"
              >{{item.riskEventStatus}}</span>
            </van-col>
            <van-divider
              :style="{ color: '#1989fa', borderColor: '#ebedf0', padding: '15px 10px' }"
            ></van-divider>
            <div class="leftRound"></div>
            <div class="rightRound"></div>
            <van-col
              span="8"
              class="contetImg"
              style="margin-top: -6px;padding-left: 14px;margin-right: 3%;"
            >
              <van-image
                radius="5"
                fit="cover"
                :src="item.riskEventPicDO.length>0 ? imagesUrl+item.riskEventPicDO[0].picPath:ownerCommunityImg"
              />
            </van-col>
            <van-col span="15" style="background-color: #fff;margin-top: -10px;">
              <span class="name">风险等级：</span>
              <span class="valName">{{item.riskLevel}}</span>
            </van-col>
            <van-col span="15" style="background-color: #fff;margin-top: 0px;">
              <span class="name">发生时间：</span>
              <span class="valName">{{item.riskFoundTime}}</span>
            </van-col>
            <van-col span="15" style="background-color: #fff;margin-top: 0px;">
              <span class="name">建议截止时间：</span>
              <span
                :class="item.riskEventStatus=='整改逾期'?'valNameRed':'valName'"
              >{{item.proposedAmendDeadline}}</span>
            </van-col>
            <van-col span="15" style="background-color: #fff;margin-top: 0px;margin-bottom: 5px;">
              <span class="name">整改进度(%)：</span>
              <van-progress
                :percentage="Number(item.amendProgress)"
                stroke-width="12"
                :color="item.riskEventStatus=='整改完成'?amendProgressLvse:item.riskEventStatus=='整改逾期'?amendProgressRed:amendProgressLan"
                class="progressBar"
                track-color="#e5e5e5"
              />
            </van-col>
          </van-col>
          <van-col span="24" class="titleName" v-if="tis=='TIS' || tis=='INS' ||tis=='SGF' || tis=='KC'|| tis=='JL'|| tis=='SJ'|| tis=='BLD'" @click.stop="changeFfun(item,index)">
            <van-collapse v-model="activeNames">
              <van-collapse-item :name="index">
                <div slot="title" style="color: red;font-size:12px;">
                  <van-icon name="volume-o"/>
                  <span style="vertical-align:10%;padding-left:2px">{{item.messageNum}}条通知/未读</span>
                </div>
                <van-row
                  v-for="(item1,index1) in notice[index]"
                  :key="index1"
                  @click.stop="noticeFun(item1,item)"
                >
                  <van-notice-bar
                    style="font-size:12px;"
                    text="通知"
                    left-icon="volume-o"
                    :scrollable="false"
                    class="noticeBar"
                  >{{item1.message}}</van-notice-bar>
                </van-row>
              </van-collapse-item>
            </van-collapse>
          </van-col>
          <van-col span="24" v-if="tis=='TIS' || tis=='SGF' || tis=='KC'|| tis=='JL'|| tis=='SJ'|| tis=='BLD'" class="reportRct">
            <div
              @click.stop="rectification(item)"
              v-if="item.sqlStatus!==0 &&item.riskEventStatus!=='已关闭'"
            >
              <span class="iconfont icon-xiugaixinxi reportRcticonfont" ></span>
              <span class="reportRctspan">报告整改</span>
            </div>
          </van-col>
          <van-col
            span="24"
            style="background-color: #fff;margin-top: 0px;margin-bottom: 5px;"
            v-if="tis=='INS'"
          >
            <div
              style="text-align: right;margin-right: 5%;height: 30px;color: #858383;"
              v-if="item.completeType!=1"
            >
              <span class="colse" @click.stop="urgeFun(item)">催办</span>
              <span class="colse" style="padding-left: 10%;" @click.stop="closedFun(item)">关闭</span>
            </div>
            <div
              style="text-align: right;margin-right: 5%;height: 30px;color: #858383;"
              v-if="item.completeType==1"
            >
              <span class="colse" style="color: #BBBBBB;">催办</span>
              <span style="padding-left: 10%;color: #BBBBBB;" class="colse">已关闭</span>
            </div>
          </van-col>
        </van-row>
        <van-row>
          <van-col span="24">
            <van-pagination
              v-model="currentPage"
              :total-items="this.listRiskEvent.total"
              :show-page-size="5"
              force-ellipses
              :items-per-page="this.limit"
              mode="simple"
              @change="changes"
            />
          </van-col>
        </van-row>
      </div>
      <div v-else>
        <van-row class="visitTitle">
          <van-col span="14">
            <p
              class="iconfont icon-gantanhao"
              style="margin-left: 80%;font-size:30px;color: #bfbfbf;margin-top: 20%;"
            ></p>
            <p style="margin-left: 79%;color: #bfbfbf; margin-top: 7%">暂无</p>
          </van-col>
        </van-row>
      </div>
    </div>
    <van-overlay :show="show" @click="show = false">
      <div class="wrapper">
        <div class="block" id="contentSend"></div>
      </div>
    </van-overlay>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "RiskEvent",
  props: {
    title: {
      default: String,
      required: false
    }
  },
  computed: {
    ...mapGetters(["listRiskEvent", "selectedPrj"]),
  },
  watch:{
    selectedPrj(){
        this.currentPage=1
    }
  },
  data() {
    return {
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      ownerCommunityImg: require("@/assets/imgs/moren.jpg"),
      value: "逾期整改",
      activeNames: [],
      currentPage: 1, //当前页
      limit: 3, //弹窗展示数据
      offset: 1, //第几页
      show: false,
      notice: [],
      amendProgressRed: "#ee0a24", 
      amendProgressLvse: "#008a7b",
      amendProgressLan: "#128feb",
      tis: undefined,
      success: false
    };
  },
  created() {
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
    setTimeout(() => {
      this.listRiskEvent.map((item, index) => {
        JSON.parse(
          localStorage.getItem(this.$getMobileData.baseSelects)
        ).IDI_RISK_EVENT_LEVEL.map(_data => {
          if (_data.dictKey == item.riskLevel) {
            item.riskLevel = _data.dictValue;
          }
        });
      });
    }, 500);
  },
  methods: {
    ...mapActions(["riskEventList"]),
    changes() {
      this.tis = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).roleType;
      if (this.tis == "TIS") {
        this.riskEventList({
          projectId: this.selectedPrj.projectId,
          limit: 3,
          offset: this.currentPage
        });
      } else {
        this.riskEventList({
          projectId: this.selectedPrj.projectId,
          limit: 3,
          offset: this.currentPage,
          sqlStatus: 1
        });
      }
    },
    //通知
    noticeFun(item1, item) {
      this.show = true;
      http.get("/send/getUserMessageById", { id: item1.id }).then(res => {
        document.getElementById("contentSend").innerHTML = res.data.message;
        this.changeFfun(item);
      });
    },
    changeFfun(item,index) {
      let _this = this;
      http
        .get("/send/getPressMessage", {
          msgType: 1,
          msgTypeId: item.id,
          read: 0
        })
        .then(res => {
          _this.notice[index] = res.data;
          _this.$set(_this.notice,index,_this.notice[index])
          item.messageNum = res.msg;
        });
    },
    rectification(item) {
      this.$router.push({
        path: "/rectificationReport",
        query: {
          projectId: item.projectId,
          projectName: item.projectName,
          id: item.id
        }
      });
    },
    //进入评论
    goComment(item) {
      this.$router.push({
        path: "/riskEventComment",
        query: {
          projectId: item.projectId,
          id: item.id
        }
      });
    },
    //催办
    urgeFun(item) {
      http
        .post("/send/pressMessage", {
          eventId: item.id,
          riskEvent: item.riskEventName
        })
        .then(res => {
          if (res.code == 0) {
            this.$toast(res.msg);
          }
        });
    },
    //关闭风险事件
    closedFun(item) {
      http
        .put("/risk/RiskEvent/completeType", {
          completeType: 1,
          id: item.id
        })
        .then(res => {
          if (res.code == 0) {
            this.$toast(res.msg);
            this.changes();
          }
        });
    }
  }
};
</script>
<style lang="less" scoped>
.content {
  margin-top: 10/16rem;
  margin-left: 16/16rem;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-break: keep-all;
  font-size: 16/16rem;
}
.van-cell__title .van-cell {
  color: red;
}
.academician {
  background-color: #fff;
  text-align: right;
  margin-top: 10/16rem;
  span {
    margin-right: 16/16rem;
    font-size: 13/16rem;
  }
}
.leftRound,.rightRound{
  width: 16/16rem;
  height: 16/16rem;
  background: #f2f2f2;
  border-radius: 50%;
}
.leftRound{
  position: absolute;
  top: 21%;
  left: -8/16rem;
}
.rightRound{
  position: absolute;
  top: 21%;
  right: -8/16rem;
}
.name {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  line-height: 24/16rem;
}
.valName {
  font-family: PingFangSC-Regular;
  font-size: 14/16rem;
  color: #a2a2a2;
  letter-spacing: 0;
  line-height: 24/16rem;
}
.valNameRed {
  font-family: PingFangSC-Regular;
  font-size: 14/16rem;
  color: #ee0a24;
  letter-spacing: 0;
  line-height: 24/16rem;
}
.progressBar{
  display: inline-block;
  width: 110/16rem;
}
.title {
  margin: 15/16rem 0;
  font-family: PingFangSC-Semibold;
  font-size: 16/16rem;
  color: #000000;
  letter-spacing: 0;
  font-weight: 900;
}
.titleName {
  background-color: #fff;
  margin-top: 0/16rem;
  margin-bottom: 5/16rem;
}
.van-cell:not(:last-child)::after {
  right: 10/16rem;
}
.van-notice-bar {
  padding: 0;
}
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.block {
  border-radius: 5%;
  width: 80%;
  background-color: #fff;
  text-align: left;
  padding: 20/16rem;
}
.red {
  color: #ee0a24;
}
.lan {
  color: #128feb;
}
.lvse {
  color: #008a7b;
}
.colse {
  font-family: PingFangSC-Semibold;
  font-size: 12/16rem;
  color: #858383;
  letter-spacing: 0;
  text-align: center;
}
.visitTitle {
  background: rgb(255, 255, 255);
  width: 100%;
  box-shadow: rgba(155, 155, 155, 0.5) 2px 2px 8px -2px;
  border-radius: 5/16rem;
  height: 150/16rem;
}
.van-image {
  width: 90/16rem;
  height: 90/16rem;
}
.noticeBar {
  background-color: #fff;
  height: 20/16rem;
}
.reportRct {
  background-color: #fff;
  margin-top: 0/16rem;
  margin-bottom: 5/16rem;
  div {
    text-align: right;
    margin-right: 5%;
    height: 30/16rem;
    color: #858383;
  }
}
.reportRctspan{
  font-size: 12/16rem;
  vertical-align:8%;
}
.reportRcticonfont{
   position: relative;
      top: 2/16rem;
  font-size: 20/16rem;
}
</style>
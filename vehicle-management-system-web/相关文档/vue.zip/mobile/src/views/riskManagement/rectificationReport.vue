<template>
  <div>
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style=" overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >{{$route.query.projectName}}</div>
    </van-nav-bar>
    <div style="padding:0 15px">
      <div style="padding-top: 10px;padding-bottom: 10px;text-align: left;">
        <div class="ertivcalLine"></div>
        <span
          style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;font-weight: 800;vertical-align:10%"
        >报告整改信息</span>
      </div>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="整改时间："
            required
            readonly
            v-model="caseDetails.riskPepairTime"
            placeholder="年/月/日"
            @focus="rectificationTime('riskPepairTime')"
          />
        </van-cell-group>
      </van-col>
      <van-dialog
        v-model="proposedAmendDeadlineShow"
        title="选择时间"
        show-cancel-button
        @confirm="proposedAmendDeadlineConfirm"
      >
        <van-datetime-picker
          :min-date="minDate"
          :max-date="maxDate"
          v-model="currentDate"
          type="date"
          @change="getValues(currentDate)"
          :formatter="formatter"
          :show-toolbar="false"
        />
      </van-dialog>
      <van-row style="margin-bottom: 10px;">
        <van-col span="7" class="name" style="padding-top: 10px;padding-left: 10px;">
          <span style="color:red">*</span>整改进度：
        </van-col>
        <van-col span="15">
          <van-slider
            v-model="caseDetails.amendProgress"
            active-color="#128FEB"
            class="slider"
            bar-height="10px"
          >
            <div slot="button" class="custom-button">{{ caseDetails.amendProgress }}%</div>
          </van-slider>
        </van-col>
      </van-row>
      <van-col span="24">
        <van-cell-group>
          <van-field
            style="text-align: left;"
            label="项目阶段："
            readonly
            v-model="projectPhase"
            placeholder="项目阶段"
            :value="construction"
            @click="constructionStagePicker = true"
          />
          <van-popup v-model="constructionStagePicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="eventTypeList"
              @cancel="constructionStagePicker = false"
              @confirm="onConstructionStage"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            label="形象进度："
            style="text-align: left;"
            v-model="caseDetails.projectVisualProgress"
            placeholder="形象进度"
            class="frame"
          />
        </van-cell-group>
      </van-col>
      <van-row>
        <van-col span="7" class="name">检查方式：</van-col>
        <van-col span="16" style="margin-left: 10px;">
          <van-checkbox-group v-model="result" @change="singleChecked()">
            <van-checkbox
              class="checkStyle"
              style="width: 50%;margin-right: 0;"
              v-for="(item,index) in resultList"
              :key="index"
              :name="item.dictKey"
              shape="square"
            >{{item.dictValue}}</van-checkbox>
          </van-checkbox-group>
        </van-col>
      </van-row>
      <van-col span="24">
        <van-cell-group>
          <van-field
            label="检查人："
            style="text-align: left;"
            readonly
            v-model="userNamed"
            placeholder="检查人"
            :value="station"
            @click="userName"
          />
          <van-popup v-model="showPicker" position="bottom">
            <van-picker
              show-toolbar
              :columns="defaultAddress"
              @change="onChange"
              @cancel="showPicker = false"
              @confirm="onConfirm"
            />
          </van-popup>
        </van-cell-group>
      </van-col>
      <van-col span="24">
        <van-cell-group>
          <van-field
            label="整改描述："
            style="text-align: left;"
            v-model="caseDetails.amendActionDesc"
            rows="1"
            :autosize=" {minRows: 2}"
            type="textarea"
            placeholder="整改描述"
            class="textarea"
          />
        </van-cell-group>
      </van-col>
      <van-row>
        <van-col span="7" class="name">
          <span>整改图片：</span>
        </van-col>
        <van-col span="17">
          <div v-for="(item, index) in caseDetails.imagePathList" :key="index" style="height: 1px;">
            <van-col span="8" class="divcol">
              <img :src="imagesUrl+item.picPath" @click="img(imagesUrl+item.picPath)" />
              <van-col class="imgcol" @click.stop="imgDelete(item,index)">
                <van-icon name="cross" />
              </van-col>
            </van-col>
            <van-col span="13" class="textareacol">
              <van-cell-group>
                <van-field
                  style="background: #f2f3f5;"
                  v-model="item.picDescription"
                  rows="2"
                  :autosize="{ maxHeight:25, minHeight: 20 }"
                  type="textarea"
                  placeholder="图片描述"
                  class="textarea"
                />
              </van-cell-group>
            </van-col>
          </div>
          <van-uploader :after-read="afterRead" style="padding-right: 65%;">
            <div class="iconfont icon-xaingji xiangji">
              <div>上传图片</div>
            </div>
          </van-uploader>
        </van-col>
      </van-row>
      <van-row>
        <van-col span="22" style="margin-left: 4.5%;margin-top: 15%;" @click="submissionRisk">
          <van-button
            type="info"
            size="large"
            class="btnName"
            style="border-radius: 24.5px;"
            :disabled="disabled"
          >提交</van-button>
        </van-col>
      </van-row>
      <van-dialog
        v-model="riskBldingsShow"
        title="确认整改信息"
        show-cancel-button
        :beforeClose="onBldingsConfirm"
      ></van-dialog>
    </div>
  </div>
</template>

<script>
import http from "@/common/request";
import { ImagePreview } from "vant";
export default {
  name: "newRiskEvents",
  data() {
    return {
      riskBldingsShow: false,
      dealImgWidth: 600,
      disabled: false,
      minDate: new Date(1900, 0, 1),
      maxDate: new Date(2100, 10, 1),
      station: "",
      showPicker: false,
      defaultAddress: [
        {
          values: [],
          className: "column1"
        },
        {
          values: [],
          className: "column2",
          defaultIndex: 0
        }
      ],
      selected: [],
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      result: [],
      resultList: [],
      currentDate: new Date(),
      proposedAmendDeadlineShow: false,
      riskPepairTime: "",
      projectPhase: "",
      constructionStagePicker: false,
      fileListImg: false,
      eventTypeList: [],
      construction: "",
      caseDetails: {
        projectPhase: "",
        amendActionDesc: "", //整改描述
        riskPepairTime: "",
        projectVisualProgress: "",
        checkMethods: [],
        checkPtcp: "",
        imagePathList: [],
        amendProgress: 0
      },
      userNamed: "",
      tis: undefined
    };
  },
  created() {
    this.getRiskEventType();
    this.inspectionMode();
    this.riskEvntOrg();
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
  },
  methods: {
    //参与人
    userName() {
      this.showPicker = true;
    },
    onChange(picker, values) {
      let childColumn = [];
      this.username.map(item => {
        if (values[0] == item.orgPname) {
          childColumn = this.getColumns(item.userList, 2);
        }
      });
      picker.setColumnValues(1, childColumn);
      //获取列中的值
      // this.selected = picker.getColumnValue(0);
    },
    onConfirm(value) {
      this.username.map((item, index) => {
        if (value[0] == item.orgPname) {
          item.userList.map(item2 => {
            if (value[1] == item2.username) {
              this.selected = item2;
              return;
            }
          });
        }
      });
      this.caseDetails.checkPtcp = this.selected.username;
      this.userNamed = this.selected.username;
      this.showPicker = false;
    },
    getColumns(lists, flag) {
      const column = [];
      lists.map(item => {
        if (flag == 1) column.push(item.orgPname);
        if (flag == 2) column.push(item.username);
      });
      return column;
    },
    riskEvntOrg() {
      let _this = this;
      http
        .get("/risk/RiskEventRepair/org/", _this.$route.query.projectId)
        .then(res => {
          _this.username = res.data;
          _this.defaultAddress[0].values = _this.getColumns(_this.username, 1);
          _this.defaultAddress[1].values = _this.getColumns(
            _this.username[0].userList,
            2
          );
          // (_this.riskEventDO.riskEventPtcp = _this.getColumns(
          //   _this.username[0].userList
          // )[0]),
          //   2;
        });
    },
    //图片缩略
    img(item) {
      // ImagePreview([item]);
      ImagePreview({
        images: [item],
        closeable: true,
        closeOnPopstate: true
      });
    },
    // 获取事件类型字典表
    getRiskEventType() {
      this.eventTypeList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PROJ_PROCESS;
      this.eventTypeList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    // 获取检查方式字典表
    inspectionMode() {
      this.resultList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_RISK_EVENT_CHECK;
      this.resultList.map(_text => {
        _text.text = _text.dictValue;
      });
    },
    setCode() {
      this.eventTypeList.map((item, index) => {
        if (item.dictValue == this.projectPhase) {
          this.caseDetails.projectPhase = item.dictKey;
        }
      });
    },
    //保存
    submissionRisk() {
      if (this.caseDetails.riskPepairTime == "") {
        this.$toast("整改时间不能为空");
        return false;
      }
      // alert(this.caseDetails.amendProgress)
      if (this.caseDetails.amendProgress == "") {
        this.$toast("整改进度不能为0%");
        return false;
      }
      this.setCode();
      this.caseDetails.sqlStatus = 1;
      this.caseDetails.projectId = this.$route.query.projectId;
      this.caseDetails.riskEventId = this.$route.query.id;
      this.$toast("提交中");
      if (this.tis != "TIS") {
        http.post("/risk/RiskEventRepair", this.caseDetails).then(res => {
          if (res.code == 0) {
            this.onClickLeft();
          }
        });
      } else {
        if (this.caseDetails.amendProgress != 100) {
          http.post("/risk/RiskEventRepair", this.caseDetails).then(res => {
            if (res.code == 0) {
              this.onClickLeft();
            }
          });
        } else {
          http.post("/risk/RiskEventRepair", this.caseDetails).then(res => {
            if (res.code == 0) {
              this.riskBldingsShow = true;
            }
          });
        }
      }
    },
    onBldingsConfirm(action, done) {
      if (action === "cancel") {
        //取消按钮
        done();
        this.onClickLeft();
      } else if (action === "confirm") {
        //确定按钮
        const keywords = {
          id: this.$route.query.id,
          riskEventStatus: "RES08"
        };
        http.put("/risk/RiskEvent/repairConfirm", keywords).then(res => {
          if (res.code === 0) {
            this.$toast({ message: res.msg });
          }
        });
        done();
        this.onClickLeft();
      }
    },
    singleChecked() {
      this.caseDetails.checkMethods = this.result;
    },
    onConstructionStage(item) {
      this.projectPhase = item.text;
      this.selectId = item.id;
      this.constructionStagePicker = false;
    },
    rectificationTime(val) {
      if (val == "riskPepairTime") {
        this.proposedAmendDeadlineShow = true;
      }
    },
    proposedAmendDeadlineConfirm() {
      this.caseDetails.riskPepairTime = this.formatDate(this.currentDate);
    },
    onClickLeft() {
      this.$router.go(-1);
    },
    //改变时间，输出选中事件
    getValues(data) {
      console.log(this.formatDate(data));
    },
    //转化时间格式
    formatDate(now) {
      var year = now.getFullYear();
      var month = now.getMonth() + 1;
      var date = now.getDate();
      return year + "-" + month + "-" + date;
    },
    //过滤面板时间
    formatter(type, value) {
      if (type === "year") {
        return `${value}年`;
      } else if (type === "month") {
        return `${value}月`;
      } else if (type === "day") {
        return `${value}日`;
      }
      return value;
    },
    //选中
    toggle(index) {
      this.$refs.checkboxes[index].toggle();
    },
    // 删除图片
    imgDelete(item, index) {
      this.caseDetails.imagePathList.splice(index, 1);
    },
    //上传
    async afterRead(param) {
      param.status = "uploading";
      param.message = "上传中";
      this.disabled = true;
      var toFile = param.file;
      if (toFile.type.startsWith("image") && toFile.size > 1024 * 1024) {
        var _this = this;
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        );
        toFile = _this.$dataURLtoFile(base64, toFile.name);
      }
      // 此时可以自行将文件上传至服务器
      let file = new FormData();
      file.append("file", toFile);
      file.append("fileIcon", "riskEventRepairPic");
      file.append("projectId", this.$route.query.projectId);
      http.post("/processDoc/uploadProcessPicsTmp", file).then(res => {
        if (res.code === 0) {
          this.caseDetails.imagePathList.push({
            picPath: res.data.cloudDocIdTmp,
            picUidName: res.data.picUidName,
            picType: "2",
            picDescription: ""
          });
          this.disabled = false;
          param.status = "done";
        } else {
          this.disabled = true;
          param.status = "failed";
          param.message = "上传失败";
        }
      });
    }
  }
};
</script>
<style scoped lang="less">
.ertivcalLine {
  width: 4px;
  background: #128feb;
  height: 15px;
  float: left;
  margin-top: 1%;
  margin-right: 2%;
}
.name {
  font-family: PingFangSC-Medium;
  font-size: 14px;
  color: #313131;
  letter-spacing: 0;
  text-align: left;
  padding-left: 15px;
}
.frame {
  height: 40px;
  // background: #f2f3f5;
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.textarea {
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.btnName {
  font-family: PingFangSC-Medium;
  font-size: 16/16rem;
  color: #ffffff;
  letter-spacing: 0;
  text-align: center;
}
.nameImg {
  font-family: PingFangSC-Medium;
  font-size: 14/16rem;
  color: #313131;
  letter-spacing: 0;
  padding-top: 18/16rem;
}
.slider {
  margin-top: 15/16rem;
  margin-bottom: 10/16rem;
  text-align: left;
  margin-left: 20/16rem;
  margin-right: 10/16rem;
}
.custom-button {
  width: 35/16rem;
  color: #fff;
  font-size: 10/16rem;
  line-height: 18/16rem;
  text-align: center;
  background-color: #128feb;
  border-radius: 100/16rem;
}
.van-checkbox-group .van-checkbox {
  float: left;
  margin-right: 9/16rem;
  margin-bottom: 10/16rem;
}
// .van-checkbox:nth-child(4) {
//   margin-left: 16px;
// }
// .van-checkbox:nth-child(2) {
//   margin-left: 48px;
// }
.imgTextarea {
  background: #f2f3f5;
  border-radius: 4/16rem;
}
.divcol {
  position: relative;
  padding-left: 7/16rem;
  img {
    width: 76/16rem;
    height: 66/16rem;
  }
}
.imgcol {
  height: 19/16rem;
  position: absolute;
  top: -10%;
  right: -4/16rem;
  color: rgb(150, 151, 153);
  font-size: 18/16rem;
  background-color: rgb(255, 255, 255);
  border-radius: 100%;
}
.xiangji {
  font-size: 30/16rem;
  text-align: center;
  border: 1px solid #c5c5c5;
  width: 64/16rem;
  height: 64/16rem;
  div {
    font-size: 10/16rem;
  }
}
.textareacol {
  margin: 15/16rem 0/16rem 15/16rem 1.2rem;
}
.checkStyle {
  font-size: 14/16rem;
}
.van-nav-bar__title {
  max-width: 80%;
}
</style>

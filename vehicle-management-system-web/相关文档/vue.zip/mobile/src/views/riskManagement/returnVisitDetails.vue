<template>
  <div style="background: #F2F3F5;">
    <van-nav-bar left-text="返回" left-arrow class="mc-navbar">
      <van-icon name="arrow-left" slot="left" @click="onClickLeft" />
      <div
        name="search"
        slot="title"
        class="word-navbar"
        style="overflow: hidden;text-overflow: ellipsis; white-space: nowrap;"
      >{{communityName}}</div>
    </van-nav-bar>
    <div style="padding: 0 15px">
      <van-row>
        <div style="padding-top: 10px;padding-bottom: 10px;text-align: left;">
          <div class="ertivcalLine"></div>
          <span
            style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;font-weight: 800;"
            class="blue font-bold"
          >回访报告</span>
        </div>
        <van-row class="title">
          <van-col span="23" style="margin-left: 0.5%;">
            <van-col span="24">
              <van-cell-group>
                <van-field
                  v-model="riskCheckReportDO.reportScope"
                  rows="1"
                  autosize
                  label="本报告所涉及的承保范围："
                  type="textarea"
                  disabled
                  label-width="100"
                  label-align="left"
                  style="text-align: left;padding-left: 5%;"
                  input-align="right"
                />
              </van-cell-group>
            </van-col>
            <van-col span="24">
              <van-cell-group>
                <van-field
                  v-model="riskCheckReportDO.surveyDate"
                  rows="1"
                  autosize
                  label="回访时间："
                  type="textarea"
                  disabled
                  label-width="130"
                  input-align="right"
                  label-align="left"
                  style="text-align: left;padding-left: 5%;"
                />
              </van-cell-group>
            </van-col>
            <van-col span="24">
              <van-cell-group>
                <van-field
                  class="file-name"
                  @click="checkPdf(riskCheckReportDO.revistReportFile)"
                  v-model="riskCheckReportDO.fileName"
                  rows="1"
                  autosize
                  label="风险回访报告："
                  type="textarea"
                  placeholder="未上传"
                  disabled
                  label-width="130"
                  label-align="left"
                  input-align="right"
                />
              </van-cell-group>
            </van-col>
            <!-- <van-col span="5">
              <van-button @click="checkPdf(riskCheckReportDO.revistReportFile)">预览</van-button>
            </van-col>-->
          </van-col>
        </van-row>
        <!-- 回访小结 -->
        <div style="padding: 20px 0;">
          <span
            style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;margin-left: -70%;"
            class="blue font-bold"
          >回访小结</span>
        </div>
        <van-row class="title">
          <van-col span="24" style="padding: 0 5%;">
            <van-cell>
              <div>
                <div>{{riskCheckReportDO.revistSummary}}</div>
              </div>
            </van-cell>
          </van-col>
        </van-row>
        <!-- 风险条款 -->
        <div style="padding: 20px 0;">
          <span
            style=" font-family: PingFangSC-Semibold;font-size: 16px;color: #128FEB;margin-left: -70%;"
            class="blue font-bold"
          >风险条款</span>
        </div>
        <van-row class="visitTitle" v-if="visitDisplay">
          <van-col span="14">
            <p
              class="iconfont icon-gantanhao"
              style="margin-left: 80%;font-size:30px;color: #bfbfbf;margin-top: 20%;"
            ></p>
            <p style="margin-left: 79%;color: #bfbfbf; margin-top: 7%">暂无</p>
          </van-col>
        </van-row>
        <van-row class="title">
          <van-col span="23" style="padding-left: 5%;">
            <van-cell v-for="(item,index) in riskCheckReportItemDO" :key="index">
              <div>
                <div>
                  条款名称:
                  <span style="padding-left: 5%">{{item.clause}}</span>
                </div>
                <div>
                  保险期限:
                  <span style="padding-left: 5%">{{item.deadline}}年</span>
                </div>
                <div>
                  保险类型:
                  <span style="padding-left: 5%">{{item.type}}</span>
                </div>
                <div>
                  <div style="width: 20%;float: left;">建&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;议:</div>
                  <div style="width: 75%;float: right;">{{item.insRemark}}</div>
                </div>
              </div>
            </van-cell>
          </van-col>
        </van-row>
      </van-row>
      <div style="height: 30px;"></div>
    </div>
    <div v-if="showPdf">
      <mcPdf :pushurl="pdfurl" :cloudDocId="cloudDocId" @goBack="goBack" v-if="fileType=='pdf'" />
    </div>
    <van-overlay :show="show">
      <div class="wrapper">
        <van-loading size="24px" vertical style="position: absolute;top: 50%; left: 43%;">加载中...</van-loading>
      </div>
    </van-overlay>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import mcPdf from "@/components/mcPdf";
import { ImagePreview } from "vant";
export default {
  name: "newRiskEvents",
  data() {
    return {
      show: false,
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      title: "",
      type: "1",
      riskCheckReportDO: {},
      riskCheckReportItemDO: [],
      visitDisplay: false,
      showPdf: false,
      fileType: "",
      pdfurl: "",
      cloudDocId: "",
      communityName: ""
    };
  },
  components: { mcPdf },
  computed: {
    // ...mapGetters(["selectedPrj"])
  },
  created() {
    this.riskVisitReport();
    this.communityName = JSON.parse(
      localStorage.getItem("eidi.selected_project")
    ).communityName;
    // this.getProjectList({ isPage: false });
  },
  methods: {
    ...mapActions(["getProjectList"]),
    onClickLeft() {
      this.$router.go(-1);
    },
    goBack() {
      this.showPdf = false;
    },
    //回访报告详情
    riskVisitReport() {
      http.get("/risk/RiskCheckReport/", this.$route.query.id).then(res => {
        this.riskCheckReportDO = res.data.riskCheckReportDO;
        if (this.riskCheckReportDO.surveyDate !== null) {
          this.riskCheckReportDO.surveyDate = this.riskCheckReportDO.surveyDate.split(
            " "
          )[0];
        }
        this.riskCheckReportItemDO = res.data.riskCheckReportItemDO;
        this.riskCheckReportItemDO.map((item, index) => {
          JSON.parse(
            localStorage.getItem(this.$getMobileData.baseSelects)
          ).IDI_LIABILITIES_TYPE.map(_data => {
            if (_data.dictKey == item.type) {
              item.type = _data.dictValue;
            }
          });
        });
        if (this.riskCheckReportItemDO.length == 0) {
          this.visitDisplay = true;
        } else {
          this.visitDisplay = false;
        }
      });
    },
    checkPdf(docId) {
      this.show = true;
      const keys = {
        cloudDocId: docId,
        pageSize: 1,
        pageNum: 1,
        lesseeId: this.$getMobileData.lesseeId
      };
      //9000未不支持文件格式，9001为图片，为空就是没有数据，存在数据，为pdf数据
      http.get("/processDoc/viewFile", keys).then(res => {
        if (res) {
          if (res.code == "9000") {
            this.show = false;
            this.$toast("不支持此格式文件预览");
          } else if (res.code == "9002") {
            this.show = false;
            this.$toast("该文件不存在");
          } else if (res.code == "9001") {
            this.show = false;
            // ImagePreview([this.imagesUrl + docId]);
            ImagePreview({
              images: [this.imagesUrl+docId],
              closeable: true,
              closeOnPopstate: true           
            });
          } else {
            var binaryData = [];
            binaryData.push(res);
            this.cloudDocId = docId;
            this.pdfurl =
              "/api/processDoc/viewFile?cloudDocId=" +
              docId +
              "&pageSize=1&pageNum=1&lesseeId=" +
              this.$getMobileData.lesseeId;
            this.fileType = "pdf";
            this.show = false;
            this.showPdf = true;
            console.log("pdf数据");
          }
        } else {
          console.log("没数据");
        }
      });
    }
  }
};
</script>
<style scoped lang="scss">
.ertivcalLine {
  width: 4px;
  background: #128feb;
  height: 15px;
  float: left;
  margin-top: 1%;
  margin-right: 2%;
}
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  max-width: 640px;
  background: #128feb;
  bottom: 0px;
}
.title {
  margin: 0 auto;
  background: #ffffff;
  box-shadow: 2px 2px 8px -2px rgba(155, 155, 155, 0.5);
  border-radius: 5px;
}
.content {
  font-family: PingFangSC-Medium;
  font-size: 14px;
  color: #313131;
  letter-spacing: 0;
  text-align: left;
  padding-left: 9.3%;
  padding-top: 15px;
}
.academician {
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #595959;
  letter-spacing: 0;
  text-align: right;
  padding-right: 7.4%;
  padding-top: 15px;
}
.van-field__body.van-field__control {
  text-align: right;
}
.engineering {
  margin-left: -5%;
}
.van-cell {
  padding: 10px 0;
}
[class*="van-hairline"]::after {
  right: -54%;
}
.van-cell:not(:last-child)::after {
  right: 15px;
}
.visitTitle {
  background: rgb(255, 255, 255);
  width: 100%;
  box-shadow: rgba(155, 155, 155, 0.5) 2px 2px 8px -2px;
  border-radius: 5px;
  height: 150px;
  margin: 0 auto;
}
.van-nav-bar__title{
  max-width: 80%;
}
</style>

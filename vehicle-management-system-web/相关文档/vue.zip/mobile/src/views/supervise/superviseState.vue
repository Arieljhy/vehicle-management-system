<template>
  <div style="background: #128feb">
    <!-- 顶部导航 -->
    <van-nav-bar class="mc-navbar">
      <van-icon name="search" slot="left" @click="search" />
      <van-icon name="setting-o" slot="right" @click="jump" />
    </van-nav-bar>
    <!-- tab栏 -->
    <van-row class="header">
      <van-col span="8">
        <van-button @click="$router.push('/statistics')">项目状态</van-button>
      </van-col>
      <van-col span="8">
        <van-button
          color="linear-gradient(to right, rgba(135,206,250,0.57) , rgba(135,206,250,0.8))"
          @click="$router.push('/superviseProjectArea')"
        >项目区域</van-button>
      </van-col>
      <van-col span="8">
        <van-button
          color="linear-gradient(to right, rgba(135,206,250,0.57) , rgba(135,206,250,0.8))"
          @click="$router.push('/superviseTrade')"
        >行业监管</van-button>
      </van-col>
    </van-row>
    <!-- 主体内容 -->
    <div class="content">
      <!-- 原代码新保单 -->
      <!-- <van-list v-if="news"> -->
      <!-- 现所有保单 -->
      <div>
        <van-row class="nav">
          <van-row class="navTitle">
            <!-- <van-col span="12">新保单</van-col> -->
            <van-col span="12">所有</van-col>
            <van-col span="12" style="text-align:right">
              <span @click="date">
                <span style="color:#595959;">签单日期</span>
                <!-- 倒三角 -->
                <span class="cornerDown"></span>
                <!-- <van-icon name="arrow-down" /> -->
              </span>
            </van-col>
            <van-dialog v-model="dateShow" show-cancel-button :before-close="onBldingsConfirm">
              <!-- 根据签单年份筛选保单——选择年份 -->
              <van-checkbox-group v-model="result">
                <van-cell-group>
                  <van-cell
                    v-for="(item, index) in resultList"
                    clickable
                    :key="item"
                    :title="`${item}`"
                    @click="toggle(item,index)"
                  >
                    <van-checkbox :name="item" ref="checkboxes" slot="right-icon" shape="square" />
                  </van-cell>
                </van-cell-group>
              </van-checkbox-group>
            </van-dialog>
          </van-row>
          <van-row class="echart">
            <div v-show="variable" class="newclass">
              <span>{{this.echartTitle}}</span>
            </div>
            <chart ref="chart"></chart>
          </van-row>
        </van-row>
      </div>
      <!-- 老保单 -->
      <!-- <div v-if="!news">
        <van-row class="nav">
          <van-row class="navTitle">
            <van-col span="12">老保单</van-col>
            <van-col span="12" style="text-align:right">
              <span @click="date">
                签单日期
                <van-icon name="arrow-down" />
              </span>
            </van-col>
            <van-dialog v-model="dateShow" show-cancel-button>
              <p>222</p>
              <p>222</p>
            </van-dialog>
          </van-row>
          <van-row class="echart">
            <chart ref="chart"></chart>
          </van-row>
        </van-row>
      </div>-->
      <!-- 新保单 -->
      <!-- <van-row v-if="ins">
        <van-col offset="11" />
        <van-col class="circle" @click="bu=btn(1)" />
        <van-col class="circle circles" @click="btn(2)" />
      </van-row>-->
      <!-- 老保单 -->
      <!-- <van-row v-if="!ins">
        <van-col offset="11" />
        <van-col class="circle circles" @click="bu=btn(1)" />
        <van-col class="circle" @click="btn(2)" />
      </van-row>-->
      <!-- 保单列表 -->
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
        :offset="5"
      >
        <van-row class="detail" v-for="(item,index) of superviseList" :key="index" >
          <van-row class="details">
            <van-col span="17" class="detailsTitle one">{{item.projectName}}</van-col>
            <van-col span="7" style="text-align:right">
              <span class="attent" v-if="item.community=='N'" @click="attention(item,index)">
                <van-icon name="plus" class="plusStyle" />关注
              </span>
              <span class="attent" v-else @click="unAttention(item,index)">取消关注</span>
            </van-col>
          </van-row>
          <van-row @click="goGovePrj(item)">
            <van-col span="6" offset="1" class="list-left">
              <span class="leftRound"></span>
              <span class="rightRound"></span>
              <van-image width="70" height="70" radius="10" ref="imgRefs" :src="item.imgSrc" />
            </van-col>
            <van-col span="16">
              <div class="subhead">
                <van-col span="24">
                  <span class="detailsTitle">项目状态：</span>
                  <span style="color:#595959">{{item.projectChnStatus}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">地址：</span>
                  <span style="color:#595959">{{item.city + item.district + item.address}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">承保方：</span>
                  <span style="color:#595959">{{item.insOrgName}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">签单日期：</span>
                  <span style="color:#595959">{{item.signDate|filterDate('yyyy-MM-dd')}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">小区名称：</span>
                  <span style="color:#595959">{{item.communityName}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">总风险事件数/已关闭：</span>
                  <span
                    style="color:#595959"
                  >{{item.riskEventTotal}} / {{item.closedRiskEventTotal}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">理赔数：</span>
                  <span style="color:#595959">{{item.claimTotal}}</span>
                </van-col>
                <van-col span="24">
                  <van-col span="7">
                    <span class="detailsTitle">保单号：</span>
                  </van-col>
                  <van-col
                    span="17"
                    style="color:#595959;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;"
                  >{{item.insContractNo}}</van-col>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">保险费：</span>
                  <span style="color:#595959">{{item.totalPremium | numberFormat()}}</span>
                </van-col>
                <van-col span="24">
                  <span class="detailsTitle">平米造价：</span>
                  <span style="color:#595959">{{item.costPerMeter | numberFormat()}}</span>
                </van-col>
                <van-col span="7" class="attented" v-if="item.community=='Y'">
                  <div style="color: #ffff;">
                    <van-icon name="star-o" />
                    <span>已关注</span>
                  </div>
                </van-col>
              </div>
            </van-col>
          </van-row>
          <div class="hint" v-if="item.description !=null&&item.description !=''">
            <div @click="hint(item)">
              <span class="iconStyle">
                <van-icon name="question-o" size="18" />
              </span>
              <span class="hintText">提示</span>
            </div>
          </div>
        </van-row>
        <van-dialog v-model="hintShow" class="hintWord">
          <p>{{hintWords}}</p>
        </van-dialog>
      </van-list>
    </div>
    <!-- 返回顶部 -->
    <div>
      <van-row id="top" class="top" style="display:none" @click="top">
        <span>top</span>
      </van-row>
    </div>
  </div>
</template>

<script>
import chart from "@/components/charts";
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import { numberFormat } from "@/utils";
export default {
  name: "superviseState",
  components: {
    chart
  },
  data() {
    return {
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      imgRows: false,
      projectImg: "",
      ownerCommunityImg: require("@/assets/imgs/moren.jpg"),
      // ins: true,
      // news: true,
      active: 0,
      dateShow: false,
      hintShow: false,
      echarts: [],
      superviseList: [],
      offset: 1,
      total: 0,
      pie_option: {
        tooltip: {
          triggrer: "item",
          formatter: "{b}:{c} ({d}%)"
        },
        //图例
        legend: {
          selectedMode: false,
          orient: "horizontal", //方向：垂直
          icon: "circle", //图例中图标的形状
          bottom: "20", //图例放在下边
          left: "3",
          align: "left", //图例放在左边
          // 图例中文字的样式
          textStyle: {
            fontSize: 10, //字体大小
            fontWeight: "bold" //字体加粗
          },
          // formatter: function(params) {
          //   var legendIndex = 0;
          //   data.forEach(function (v, i) {
          //     if (v.name == params) {
          //       legendIndex = i;
          //       }
          //     });
          //     return params + " " + data[legendIndex].value;
          //   },
          itemWidth: 10, //图例每一项的宽度
          itemHeight: 10, //图例每一项的高度
          itemGap: 5 //图例每一项之间的间隙（距离）
        },
        series: [
          {
            name: "",
            type: "pie",
            radius: ["45%", "55%"],
            center: ["50%", "35%"],
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: "20",
                  align: "center"
                },
                formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                rich: {
                  a: {
                    fontSize: "23",
                    align: "center",
                    fontWeight: "400"
                  },
                  b: {
                    fontSize: "12",
                    align: "center",
                    fontWeight: "900",
                    color: "#68615f"
                  }
                }
              }
            },
            labelLine: {
              normal: {
                show: true,
                smooth: 0.2,
                length: 5,
                length2: 10
              }
            },
            data: [
              // { value: 335, name: '直接访问' },
              // { value: 310, name: '邮件营销' },
              // { value: 234, name: '联盟广告' },
              // { value: 135, name: '视频广告' },
              // { value: 1548, name: '搜索引擎' }
            ]
          }
        ]
      },
      loading: false,
      finished: false,
      result: [],
      resultList: [],
      riskBldings: [],
      dates: "",
      hintWords: "",
      variable: false,
      echartTitle: ""
    };
  },
  computed: {
    ...mapGetters([
      "provinceList",
      "limit",
      "province",
      "city",
      "district",
      "minCostPerMeter",
      "maxCostPerMeter",
      "beginSignDate",
      "endSignDate",
      "buildingType",
      "projectStatus",
      "orgIds",
      "isChecked",
      "isPopup"
    ])
  },
  created() {
    this.getProvince();
    this.getLists();
    this.Echarts(); //echarts接口调用
    // 返回顶部
    // onscroll = function() {
    //   // debugger
    //   if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
    //     document.getElementById("top").style.display = "block";
    //   } else {
    //     document.getElementById("top").style.display = "none";
    //   }
    // };
  },
  filters: {
    tatusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "info",
        deleted: "danger"
      };
      return statusMap[status];
    },
    numberFormat
  },
  mounted() {
    // this.Echarts() //echarts接口调用
    //监听滚动事件
    window.addEventListener("scroll", this.onscroll);
  },
  methods: {
    ...mapActions(["getProvince"]),
    goGovePrj(item) {
      if(item.community=='N'){
         this.$toast("请先关注项目");  
       }else{
          localStorage.setItem("eidi.selected_project", JSON.stringify(item));
        this.$router.push({
          path: "/governmentCommunity",
        });
       }
    },
    // 返回顶部
    onscroll() {
      if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
        document.getElementById("top").style.display = "block";
      } else {
        document.getElementById("top").style.display = "none";
      }
    },
    toggle(item, index) {
      this.$refs.checkboxes[index].toggle();
      // 将选中的添加到 blidings 数组内
      if (this.$refs.checkboxes[index].checked == false) {
        this.riskBldings.push(item);
      } else if (this.$refs.checkboxes[index].checked == true) {
        // 如果复选框为打开状态时，则关闭，删除所选
        // 使用findIndex获取索引值
        let inx = this.riskBldings.findIndex(_name => {
          return _name == item;
        });
        this.riskBldings.splice(inx, 1);
      }
    },
    // 确认后
    onBldingsConfirm(action, done) {
      if (action === "cancel") {
        done();
      } else if (action === "confirm") {
        this.dates = this.riskBldings.toString();
        this.offset = 1;
        this.finished = false;
        (this.superviseList = []), this.getLists();
        this.$refs.chart.destroy(); //销毁
        this.pie_option.series[0].data = [];
        setTimeout(() => {
          this.Echarts();
        });
        this.variable = false;
      }
      done();
    },
    //签单日期
    date() {
      this.dateShow = true;
      this.getYear();
    },
    //提示
    hint(item) {
      this.hintWords = item.description;
      this.hintShow = true;
    },
    // 搜索
    search() {
      this.$router.push({
        path: "/superviseSelect",
        query: {}
      });
    },
    //静态获取echart图表
    // async Echarts() {
    //   // const { data } = await this.$api.echarts();
    //   this.$refs.chart.initChart(this.pie_option)
    // },
    //动态获取echart图表
    async Echarts() {
      const keywords = {
        signYear: this.dates
      };
      http
        .get("/echart/getEchartById/project_status_distribution", keywords)
        .then(res => {
          if (res.code === 0) {
            if (res.data.data.length == 0) {
              this.variable = true;
              this.echartTitle = res.data.title;
            } else {
              this.pie_option = JSON.parse(JSON.stringify(this.pie_option));
              for (let n of res.data.data) {
                this.pie_option.series[0].data.push({
                  name: n.name,
                  value: n.value
                });
              }
              this.$refs.chart.initChart(this.pie_option);
              this.$refs.chart.editEcahrt(this.pie_option, this.$refs.chart.id);
            }
          }
        });
    },
    //获取年份列表
    getYear() {
      http.get("/insurance/InsBasicInfo/signYear").then(res => {
        if (res.code === 0) {
          this.resultList = res.data;
        }
      });
    },
    //获取列表
    getLists() {
      const keywords = {
        signYear: this.dates,
        offset: this.offset,
        limit: 5
      };
      http.get("/project/PrjQueryInfo", keywords).then(res => {
        let rows = res.data.rows;
        this.loading = false;
        this.total = res.data.total;
        if (rows == null || rows.length === 0) {
          // 加载结束
          this.finished = true;
          return;
        }
        let projectIds = "";
        rows.map(item => {
          projectIds = projectIds + item.projectId + ",";
        });
        http
          .get("/project/concatImg/logos", { projectIds: projectIds })
          .then(res => {
            rows.map(item => {
              if (res.data[item.projectId.replace("-", "_")]) {
                item.imgSrc =
                  "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                  res.data[item.projectId.replace("-", "_")];
              } else {
                item.imgSrc = this.ownerCommunityImg;
              }
            });
            this.superviseList = this.superviseList.concat(rows);
            if (this.superviseList.length >= this.total) {
              this.finished = true;
            }
          });
      });
      //   this.superviseList = this.superviseList.concat(rows);
      //   if (this.superviseList.length >= this.total) {
      //     this.finished = true;
      //   }
      //   if (!this.finished) {
      //     rows.map((item, index) => {
      //       this.projectImg = rows[index].projectId;
      //       this.getImgPictures(this.projectImg);
      //     });
      //   }
      // });
    },
    //获取图片
    async getImgPictures(data) {
      const rid = data;
      const res = await this.$api.getImgPictures(rid);
      this.superviseList.map((item1, index) => {
        if (res.data != null && item1.projectId == res.data.projectId) {
          this.$refs.imgRefs.src = this.imagesUrl + res.data.imageUri;
          // this.superviseList[index].imgRows = this.imgRows;
          // this.superviseList[index].imageUri = res.data.imageUri;
        } else {
          // this.$refs.imgRefs.src = this.ownerCommunityImg;
          // this.superviseList[index].imgRows = this.imgRows;
        }
      });
    },
    //触底加载
    onLoad() {
      this.offset++;
      this.getLists();
    },
    //跳转到个人设置
    jump() {
      this.$router.push({
        path: "/personalSettings"
      });
    },
    //用于点击新老保单切换
    btn(flag) {
      if (flag == 1) {
        this.ins = true;
        this.news = true;
      } else if (flag == 2) {
        this.ins = false;
        this.news = false;
      }
    },
    //添加关注
    attention(value) {
      const _this = this;
      const keywords = { projectId: value.projectId };
      http.post("/community/save", keywords).then(res => {
        if (res.code === 0) {
          return (value.community = "Y");
        }
      });
    },
    //取消关注
    unAttention(value) {
      const _this = this;
      const keywords = { projectId: value.projectId };
      http.post("/community/unAttention/", keywords).then(res => {
        if (res.code === 0) {
          return (value.community = "N");
        }
      });
    },
    // 返回顶部
    top() {
      window.scrollTo(0, 0);
    }
  },
  //离开页面要移除监听的滚动事件，否则会报错
  destroyed() {
    window.removeEventListener("scroll", this.onscroll);
  }
};
</script>
<style scoped lang="less">
.van-hairline--bottom::after {
  border-bottom-width: 0;
}
.newclass {
  height: 430/16rem;
  background: url(../../assets/imgs/noData.png);
  background-size: 200/16rem 200/16rem;
  background-repeat: no-repeat;
  background-position: 67/16rem 100/16rem;
}
.newclass /deep/ span {
  font-size: 17/16rem;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 10/16rem;
  left: 15/16rem;
}
.header {
  margin: 10/16rem 10.5/16rem 15/16rem 10.5/16rem;
}
.header /deep/ .van-button {
  width: 93%;
  font-family: PingFangSC-Semibold;
  // font-size: 18/16rem;
  font-weight: 700;
  border-radius: 10/16rem;
  color: #128feb;
}
.nav {
  background: #fff;
  margin: 0 15/16rem;
  border-radius: 15/16rem;
  text-align: left;
}
.nav /deep/ .navTitle {
  font-size: 18/16rem;
  font-weight: 700;
  background: #f2f2f2;
  padding: 12/16rem 13/16rem;
  border-radius: 13/16rem 13/16rem 0 0;
}
.cornerDown {
  display: inline-block;
  padding-bottom: 5/16rem;
  margin: 0 0 0 10/16rem;
  border-right: 5/16rem solid transparent;
  border-left: 5/16rem solid transparent;
  border-top: 5/16rem solid #858484;
  border-radius: 3/16rem 3/16rem 3/16rem 0;
}
.nav /deep/ .navTitles {
  padding: 15/16rem 13/16rem;
  border-radius: 15/16rem 15/16rem 0 0;
}
.echart {
  position: relative;
  height: 335/16rem;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 0 0 13/16rem 13/16rem;
  padding: 0 10/16rem;
}
.detail {
  position: relative;
  background: #fff;
  // margin: 0 15/16rem;
  margin: 12/16rem 15/16rem;
  border-radius: 10/16rem;
  text-align: left;
}
.leftRound,
.rightRound {
  display: inline-block;
  width: 16/16rem;
  height: 16/16rem;
  border-radius: 50%;
  background: #128feb;
}
.leftRound {
  position: absolute;
  top: 3%;
  left: -16/16rem;
}
.rightRound {
  position: absolute;
  top: 3%;
  right: -304.5%;
}
.detailsTitle {
  font-weight: 700;
}
.one {
  font-size: 18/16rem;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.detail /deep/ .details {
  position: relative;
  background: #ffffff;
  margin: 15/16rem 15/16rem;
  padding: 15/16rem 0;
  border-bottom: 0.5/16rem solid #f5f5f5;
  border-radius: 15/16rem 15/16rem 0 0;
}
.detail /deep/ .details /deep/ .attent {
  position: relative;
  font-size: 12/16rem;
  border: 1/16rem #128feb solid;
  border-radius: 20/16rem;
  padding: 5/16rem 10/16rem;
  color: #128feb;
}
.detail /deep/ .subhead {
  line-height: 28/16rem;
}
.hint {
  width: 68/16rem;
  height: 25/16rem;
  line-height: 25/16rem;
  color: #128feb;
  // border: 2/16rem #128FEB  solid;
  background: rgba(204, 204, 204,0.2);
  border-top: 2/16rem #128feb solid;
  border-right: 2/16rem #128feb solid;
  border-bottom: 2/16rem #128feb solid;
  border-radius: 0 15/16rem 15/16rem 0;
  padding-bottom: 2/16rem;
  position: absolute;
  top: 50%;
  .hintText{
    display: inline-block;
    height: 26/16rem;
    line-height: 26/16rem;
    padding-left: 5/16rem;
  }
  .iconStyle {
    position: relative;
    top: 4/16rem;
    left: 2/16rem;
  }
}
.hintWord {
  background: #fff !important;
}
.hintWord p {
  padding: 0 10/16rem;
}
// .circle {
//   width: 8/16rem;
//   height: 8/16rem;
//   border-radius: 15/16rem;
//   margin: 5/16rem;
//   margin-top: 15/16rem;
//   background: #fff;
// }
// .circles {
//   background: rgba(255, 255, 255, 0.42);
// }
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  border: 1/16rem solid #ccc;
  color: #fff;
  border-radius: 25/16rem;
  background: #ccc;
  right: 25/16rem;
  bottom: 40/16rem;
}
.top:hover {
  cursor: pointer;
}
.top /deep/ span {
  line-height: 30/16rem;
}
.plusStyle {
  position: relative;
  top: 1/16rem;
  right: 2/16rem;
}
.list-left {
  text-align: center;
  margin: 6/16rem 0 15/16rem 6/16rem;
  border-radius: 10/16rem;
  position: relative;
}
.attented {
  background: #f5a623;
  border-radius: 10/16rem 0;
  height: 30/16rem;
  margin-left: 80.8%;
  text-align: center;
  .van-icon {
    position: relative;
    top: 1/16rem;
  }
  span {
    line-height: 30/16rem;
    font-size: 11/16rem;
  }
}
</style>

<template>
  <div>
    <van-row style="position:relative;background-color: #128feb">
      <van-col span="2" class="backIcon">
        <van-icon name="arrow-left" @click="goBack" />
      </van-col>
      <van-col span="20" style="position:relative">
        <van-search
          background="#128feb"
          shape="round"
          placeholder="请输入项目名称 / 保单号查询"
          v-model="fitterData.fuzzyQuery"
          @search="onSearch"
        />
        <div
          v-if="fitterData.fuzzyQuery==''"
          class="iconfont icon-yuyin"
          @click="openRecordDiolog"
          style=" position: absolute;top:23.5%;right:2%;color:#8E8E93;font-size: 25px;width: 50px;"
        ></div>
      </van-col>
      <van-col span="2" class="settingIcon">
        <van-icon name="setting-o" @click="jumpMy" />
      </van-col>
    </van-row>
    <!-- 筛选 -->
    <div class="shaixuan">
      <van-row type="flex" justify="center" class="selectTab">
        <van-col span="4" @click="sortEvent('riskEvent')">风险事件</van-col>
        <!-- 正序倒序高亮显示 -->
        <van-col span="1">
          <div class="upTriangle" :class="{selectTriangleUp:isRiskEvent}"></div>
          <div class="downTriangle" :class="{selectTriangleDown:!isRiskEvent}"></div>
        </van-col>
        <van-col span="4" @click="sortEvent('claim')">理赔</van-col>
        <van-col span="1" class="right-10">
          <div class="upTriangle" :class="{selectTriangleUp:isClaim}"></div>
          <div class="downTriangle" :class="{selectTriangleDown:!isClaim}"></div>
        </van-col>
        <van-col span="4" @click="sortEvent('meterCost')">平米造价</van-col>
        <van-col span="1">
          <div class="upTriangle" :class="{selectTriangleUp:isMeterCost}"></div>
          <div class="downTriangle" :class="{selectTriangleDown:!isMeterCost}"></div>
        </van-col>
        <van-col span="4" @click="sortEvent('rate')">费率</van-col>
        <van-col span="1" class="right-10">
          <div class="upTriangle" :class="{selectTriangleUp:isRate}"></div>
          <div class="downTriangle" :class="{selectTriangleDown:!isRate}"></div>
        </van-col>
        <van-col span="4" @click="isPopup = true">
          <span class="iconfont icon-shaixuan shaixuan-btn"> 筛选</span>
        </van-col>
      </van-row>
      <!-- 筛选 -->
      <van-popup
        v-model="isPopup"
        position="right"
        :style="{ width: '85%' }"
        @close="isPopup = false"
        @click-overlay="isPopup = false"
      >
        <filterSearch @filterData="filterData" />
      </van-popup>
    </div>
    <!-- 内容 -->
    <div class="content">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad(fitterData)"
        :offset="5"
      >
        <van-row class="detail" v-for="(item,index) of superviseList" :key="index">
          <van-row class="details">
            <van-col span="16">{{item.projectName}}</van-col>
            <van-col span="8" style="text-align:right">
              <span class="attent" v-if="item.community=='N'" @click.stop="attention(item,index)">+关注</span>
              <span class="attent" v-else @click="unAttention(item,index)">取消关注</span>
            </van-col>
          </van-row>
          <van-row @click.stop="goGovePrj(item)">
            <van-col span="7" class="imgStyle">
              <van-image width="85" radius="7" height="85" :src="item.imgSrc" />
            </van-col>
            <van-col span="15">
              <div class="subhead">
                <van-col span="24">
                  项目状态：
                  <span>{{item.projectChnStatus}}</span>
                </van-col>
                <van-col span="24">
                  <!-- TODO：非北京市地址显示为{{item.province + item.city + item.district + item.address}} -->
                  地址：
                  <span>{{item.city + item.district + item.address}}</span>
                </van-col>
                <van-col span="24">
                  <van-col span="7">
                    <span>承保方：</span>
                  </van-col>
                  <van-col span="17">
                    <span>{{item.insOrgName}}</span>
                  </van-col>
                </van-col>
                <van-col span="24">
                  签单日期：
                  <span>{{item.signDate}}</span>
                </van-col>
                <van-col span="24">
                  小区名称：
                  <span>{{item.communityName}}</span>
                </van-col>
                <van-col span="24">
                  总风险事件数/已关闭：
                  <span>{{item.riskEventTotal}} / {{item.closedRiskEventTotal}}</span>
                </van-col>
                <van-col span="24">
                  理赔数：
                  <span>{{item.claimTotal}}</span>
                </van-col>
                <van-col span="24">
                  保单号：
                  <span>{{item.insContractNo}}</span>
                </van-col>
                <van-col span="24">
                  保险费：
                  <span>{{item.totalPremium | numberFormat()}}</span>
                </van-col>
                <van-col span="24">
                  平米造价：
                  <span>{{item.costPerMeter | numberFormat()}}</span>
                </van-col>
                <div class="hint" v-if="item.description !=null&&item.description !=''">
                  <div @click.stop="hint(item)">
                    <span class="hint-top">
                      <van-icon name="question-o" size="18" />
                    </span>
                    <span class="hintText">提示</span>
                  </div>
                </div>
                <van-col span="7" class="attended" v-if="item.community=='Y'">
                  <div style="color: #ffff;">
                    <van-icon name="star-o" />
                    <span>已关注</span>
                  </div>
                </van-col>
              </div>
            </van-col>
          </van-row>
        </van-row>
        <van-dialog v-model="hintShow" class="hintWord">
          <p>{{hintWords}}</p>
          <!-- <p v-if="hintWords">{{hintWords}}</p> -->
          <!-- <p v-else>暂无内容</p> -->
        </van-dialog>
      </van-list>
    </div>
    <!--  -->
    <div class="box"></div>
    <van-row span="24" class="informationBtn">
      <van-button type="info" @click="goBack">返回主页</van-button>
    </van-row>
    <van-dialog
      v-model="openRecord"
      :show-confirm-button="showButton"
      :overlay="showOverlay"
      width="230px"
    >
      <div style="padding:35px;">
        <!-- <div class="iconfont icon-yuyin" style="font-size:70px;margin-bottom:15px"></div> -->
        <!-- <div
          class="mc-record"
          @touchstart="gotouchstart"
          @touchmove="gotouchmove"
          @touchend="gotouchend"
        >按住说话</div> -->
        <mcRecorder @handleStop="handelEndRecord" />
      </div>
    </van-dialog>
    <!-- 返回顶部 -->
    <div>
      <van-row id="top" class="top" style="display:none" @click="top">
        <span>top</span>
      </van-row>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import filterSearch from "./child/filterSearch";
import { numberFormat } from "@/utils";
import mcRecorder from "@/components/mcRecorder";
export default {
  name: "superviseFilterSelect",
  components: {
    filterSearch: filterSearch,
    mcRecorder
  },
  data() {
    return {
      ownerCommunityImg: require("@/assets/imgs/moren.jpg"),
      // 搜索
      fuzzyQuery: "",
      // 提示
      hintShow: false,
      // 触底掉接口
      loading: false,
      finished: false,
      tenantId: "",
      // 排序
      sort: "sign_date",
      order: "desc",
      // 排序三角提示是否点亮
      isRiskEvent: false,
      isClaim: false,
      isMeterCost: false,
      isRate: false,
      offset: false,
      hintWords: "",
      // 展示数据
      superviseList: [],
      fitterData: {
        voice: "", //语音
        fuzzyQuery: "",
        limit: 5,
        offset: 1,
        province: this.$getMobileData.provinceie,
        city: this.$getMobileData.city,
        district: "",
        minCostPerMeter: "",
        maxCostPerMeter: "",
        beginSignDate: "",
        endSignDate: "",
        buildingType: "",
        projectStatus: "",
        orgIds: [],
        isChecked: false,
        sort: "",
        order: "",
        // contractNotNull: ""
        isMainIns: ""
      },
      isPopup: false,
      openRecord: false,
      timeOutEvent: 0,
      showButton: false,
      showOverlay: false
    };
  },
  computed: {
    ...mapGetters([
      "provinceList",
      "limit",
      "province",
      "city",
      "district",
      "minCostPerMeter",
      "maxCostPerMeter",
      "beginSignDate",
      "endSignDate",
      "buildingType",
      "projectStatus",
      "orgIds",
      "isChecked",
      "userType"
    ])
  },
  created() {
    this.fitterData.offset = 1;
    this.getUserType();
    this.superviseList = [];
  },
  filters: {
    tatusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "info",
        deleted: "danger"
      };
      return statusMap[status];
    },
    numberFormat
  },
  mounted() {
    //监听滚动事件
    window.addEventListener("scroll", this.onscroll);
  },
  methods: {
    ...mapActions(["getSuperviseList", "setFinished", "getUserType"]),
    openRecordDiolog() {
      this.openRecord = true;
      setTimeout(() => {
        this.openRecord = false;
      }, 10000);
    },
     goGovePrj(item) {
       if(item.community=='N'){
         this.$toast("请先关注项目");  
       }else{
          localStorage.setItem("eidi.selected_project", JSON.stringify(item));
        this.$router.push({
          path: "/governmentCommunity",
        });
       }
    },
       handelEndRecord(param) {
      let reader = new FileReader();
      reader.readAsDataURL(param.mblob);
      reader.onload = e => {
        this.msource = e.target.result.replace("data:audio/wav;base64,", "");
        const keywords = {
          speech: this.msource,
          format: "wav",
          channel: 1,
          rate: 16000,
          token: JSON.parse(localStorage.getItem("eidi_mobile.baiduTocken")),
          cuid: "baidu_eidi",
          dev_pid: 1537,
          len: param.mblob.size
        };
        http.post("/baidu/server_api", keywords).then(res => {
          if (res.err_no == 0) {
            this.fitterData.fuzzyQuery = res.result[0].replace(/[\ |\?|\。|\？]/g,"");
            this.onSearch();
            this.openRecord = false;
          }
        });
      };
    },
    // gotouchstart() {
    //   let that = this;
    //   clearTimeout(this.timeOutEvent); //清除定时器
    //   this.timeOutEvent = 0;
    //   this.timeOutEvent = setTimeout(() => {
    //     console.log("执行长恩操作！");
    //     if (typeof androidApp !== "undefined") {
    //       androidApp.startRecord(
    //         JSON.parse(localStorage.getItem("eidi_mobile.baiduTocken"))
    //       );
    //     }
    //   }, 1000);
    // },
    // gotouchend() {
    //   clearTimeout(this.timeOutEvent);
    //   if (this.timeOutEvent != 0) {
    //     console.log("结束事件！！");
    //     if (typeof androidApp !== "undefined") {
    //       this.fitterData.fuzzyQuery = androidApp.stopRecord(true).result[0];
    //     }
    //     this.onSearch();
    //     this.openRecord = false;
    //   }
    // },
    // gotouchmove() {
    //   console.log("取消事件！！");
    //   clearTimeout(this.timeOutEvent);
    //   if (typeof androidApp !== "undefined") {
    //     androidApp.stopRecord(true);
    //   }
    //   this.timeOutEvent = 0;
    // },
    // 返回上一级
    goBack() {
      this.$router.go(-1);
    },
    jumpMy() {
      this.$router.push("/personalSettings");
    },
    hint(item) {
      this.hintWords = item.description;
      this.hintShow = true;
    },
    // 添加关注
    attention(value) {
      const _this = this;
      const keywords = { projectId: value.projectId };
      http.post("/community/save", keywords).then(res => {
        if (res.code === 0) {
          return (value.community = "Y");
        }
      });
    },
    // 取消关注
    unAttention(value) {
      const _this = this;
      const keywords = { projectId: value.projectId };
      http.post("/community/unAttention/", keywords).then(res => {
        if (res.code === 0) {
          return (value.community = "N");
        }
      });
    },

    filterData(value) {
      this.fitterData = value;
      // this.finished = false;
      this.isPopup = false;
      this.superviseList = [];
      this.getprojectList(this.fitterData);
      
      // this.isMainIns='';
    },
    getprojectList(value) {
      http.get("/project/PrjQueryInfo", value).then(res => {
        if (res.code === 0) {
          // this.superviseList = res.data.rows;
          this.finished = false;
          let rows = res.data.rows;
          if (rows == null || rows.length === 0) {
            // 加载结束
            this.finished = true;
            return;
          }
          let projectIds = "";
          rows.map(item => {
            projectIds = projectIds + item.projectId + ",";
          });
          // alert(projectIds);
          http
            .get("/project/concatImg/logos", { projectIds: projectIds })
            .then(res => {
              rows.map(item => {
                if (res.data[item.projectId.replace("-", "_")]) {
                  item.imgSrc =
                    "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                    res.data[item.projectId.replace("-", "_")];
                } else {
                  item.imgSrc = this.ownerCommunityImg;
                }
              });
              this.superviseList = rows;
            });
          this.finished = false;

          if (res.data.rows.length < 5) {
            this.finished = true;
          } else {
            this.fitterData.offset += 1;
          }
        }
        // let rows = res.data.rows;
        // this.loading = false;
        // this.total = res.data.total;
        // if (rows == null || rows.length === 0) {
        //   // 加载结束
        //   this.finished = true;
        //   return;
        // }
        // let projectIds = "";
        // rows.map(item => {
        //   projectIds = projectIds + item.projectId + ",";
        // });
        // // alert(projectIds);
        // http
        //   .get("/project/concatImg/logos", { projectIds: projectIds })
        //   .then(res => {
        //     rows.map(item => {
        //       if(res.data[item.projectId.replace("-", "_")]) {
        //           item.imgSrc = "/api/processDoc/downloadProcessDoc?cloudDocId=" + res.data[item.projectId.replace("-", "_")];
        //       }else {
        //         item.imgSrc = this.ownerCommunityImg
        //       }

        //     });
        //     this.superviseList = this.superviseList.concat(rows);
        //     if (this.superviseList.length >= this.total) {
        //       this.finished = true;
        //     }
        //   });
      });
    },
    sortEvent(type) {
      const _this = this;
      if (type === "riskEvent") {
        // 风险事件排序
        _this.fitterData.sort = "aaaaa.riskEventTotal";
        _this.isRiskEvent = !_this.isRiskEvent;
        if (_this.isRiskEvent) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "claim") {
        // 理赔排序
        _this.fitterData.sort = "aaaaa.claimTotal";
        _this.isClaim = !_this.isClaim;
        if (_this.isClaim) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "meterCost") {
        // 平米造价排序
        _this.fitterData.sort = "aaaaa.cost_per_meter";
        _this.isMeterCost = !_this.isMeterCost;
        if (_this.isMeterCost) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      } else if (type === "rate") {
        // 费率排序
        _this.fitterData.sort = "aaaaa.ratePremium";
        _this.isRate = !_this.isRate;
        if (_this.isRate) {
          _this.fitterData.order = "desc";
        } else {
          _this.fitterData.order = "asc";
        }
      }
      _this.fitterData.offset = 1;
      _this.superviseList = [];
      // _this.finished = false;
      _this.getprojectList(this.fitterData);
    },
    // 搜索事件
    onSearch(value) {
      this.fitterData.yuYinFlag = "1";
      this.fitterData.offset = 1;
      this.superviseList = [];
      // this.finished = false;
      //语音
      this.fitterData.voice = "";
      this.getprojectList(this.fitterData);
    },
    onLoad() {
      // 下拉加载数据
      let _this = this;
      _this.loading = true;
      setTimeout(() => {
        http.get("/project/PrjQueryInfo", this.fitterData).then(res => {
          if (res.code === 0) {
            let rows = res.data.rows;
            this.loading = false;
            if (rows == null || rows.length === 0) {
              // 加载结束
              this.finished = true;
              return;
            }
            let projectIds = "";
            rows.map(item => {
              projectIds = projectIds + item.projectId + ",";
            });
            http
              .get("/project/concatImg/logos", { projectIds: projectIds })
              .then(res => {
                rows.map(item => {
                  if (res.data[item.projectId.replace("-", "_")]) {
                    item.imgSrc =
                      "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                      res.data[item.projectId.replace("-", "_")];
                  } else {
                    item.imgSrc = this.ownerCommunityImg;
                  }
                });
                this.superviseList.push(...rows);
              });
            if (res.data.rows.length < 5) {
              this.finished = true;
            } else {
              this.fitterData.offset += 1;
            }
          }
        });
      }, 500);
    },
    // 从缓存里面获取省的id
    getTenantId() {
      const _this = this;
      _this.tenantId = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).tenantId;
    },
    // 按钮显示/隐藏
    onscroll() {
      if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
        document.getElementById("top").style.display = "block";
      } else {
        document.getElementById("top").style.display = "none";
      }
    },
    // 返回顶部
    top() {
      window.scrollTo(0, 0);
    }
  },
  //离开页面要移除监听的滚动事件
  destroyed() {
    window.removeEventListener("scroll", this.onscroll);
  }
};
</script>
<style lang="less" scoped>
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  max-width: 640/16rem;
  background: #128feb;
  bottom: 0;
}
.detail {
  margin: 20/16rem 0;
  background: #ffffff;
  box-shadow: 2/16rem 2/16rem 8/16rem -2/16rem rgba(155, 155, 155, 0.5);
  position: relative;
  background: #fff;
  text-align: left;
}
.detail /deep/ .details {
  color: #128feb;
  padding: 15/16rem 15/16rem;
  border-bottom: 1/16rem #ccc solid;
  font-weight: bold;
}
.detail /deep/ .details /deep/ .attent {
  border: 1/16rem #128feb solid;
  border-radius: 17/16rem;
  padding: 1/16rem 10/16rem;
  color: #128feb;
  font-size: 14/16rem;
  font-weight: normal;
}
.detail /deep/ .subhead {
  margin: 10/16rem 0;
  line-height: 26/16rem;
  font-size: 15/16rem;
  position: relative; //固定提示
}
.hint {
  width: 68/16rem;
  height: 25/16rem;
  line-height: 25/16rem;
  background: rgba(204, 204, 204,0.2);
  color: #128feb;
  border-top: 2/16rem #128feb solid;
  border-right: 2/16rem #128feb solid;
  border-bottom: 2/16rem #128feb solid;
  border-radius: 0 15/16rem 15/16rem 0;
  position: absolute;
  padding-bottom: 3/16rem;
  top: 8rem; //固定提示
  left: -6.9rem;
  .hintText{
    display: inline-block;
    height: 26/16rem;
    line-height: 26/16rem;
    padding-left: 5/16rem;
  }
}
.hint-top {
  position: relative;
  top: 4/16rem;
  left: 2/16rem;
}
.van-popup {
  text-align: left;
  height: 100%;
}
.van-popup /deep/ .cant {
  margin: 20/16rem 20/16rem;
}
.city {
  margin: 20/16rem 0;
}
.van-dropdown-menu /deep/ .van-dropdown-menu__item {
  background: #f2f3f5;
  height: 34/16rem;
}
// 下拉框
.van-dropdown-menu /deep/ .van-dropdown-menu__title::after {
  position: absolute;
  top: 50%;
  right: -90/16rem;
  // margin-top: px;
}
.filter_title {
  font-weight: 600;
  padding-top: 8/16rem;
  padding-bottom: 8/16rem;
  font-size: 15/16rem;
}
.filter_title1 {
  font-weight: normal;
  padding-top: 8/16rem;
  padding-bottom: 8/16rem;
  font-size: 15/16rem;
}
.frame {
  height: 40/16rem;
  background: #f2f3f5;
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.line {
  text-align: center;
  margin-top: 10/16rem;
}
.inline-block {
  display: inline-block;
}
.area {
  color: rgba(62, 58, 57, 1);
  background: #f2f3f5;
  padding: 2/16rem 6/16rem;
  margin: 0 12.5/16rem 8.5/16rem 0;
  border-radius: 8/16rem;
}

.checked {
  background-color: #297ae3;
  color: #fff !important;
  border-radius: 8/16rem;
}
.footer {
  position: absolute;
  bottom: 0%;
  height: 40/16rem;
  width: 100%;
}
.footer /deep/ .van-button {
  color: #fff;
  border: 0;
}
.right-10 {
  position: relative;
  right: 10/16rem;
}
// 筛选的上下三角
.upTriangle {
  width: 0;
  height: 0;
  border-right: 5/16rem solid transparent;
  border-left: 5/16rem solid transparent;
  border-bottom: 5/16rem solid #000;
  margin: 3/16rem 0;
}

.downTriangle {
  width: 0;
  height: 0;
  border-right: 5/16rem solid transparent;
  border-left: 5/16rem solid transparent;
  border-top: 5/16rem solid #000;
}
.selectTriangleUp {
  border-bottom: 5/16rem solid #f5a623;
}
.selectTriangleDown {
  border-top: 5/16rem solid #f5a623;
}
.hintWord {
  background: #fff !important;
}
.hintWord p {
  padding: 0 10/16rem;
}
.yuyin {
  position: absolute;
  top: 20/16rem;
  right: 30/16rem;
  color: #ccc;
}
.van-search {
  height: 46/16rem;
}
.backIcon,.settingIcon{
  font-size: 20/16rem;
  color: #ffffff;
  margin-top: 12/16rem;
}
.shaixuan-btn {
  font-size: 14/16rem;
}
.shaixuan {
  margin: 10/16rem 10/16rem;
  .selectTab {
    font-size: 14/16rem;
  }
}
.imgStyle {
  text-align: center;
  margin-top: 15/16rem;
}
.attended {
  background: #f5a623;
  border-radius: 6/16rem 0 0 0;
  height: 30/16rem;
  margin-left: 84.2%;
  .van-icon {
    position: relative;
    top: 1/16rem;
  }
  span {
    padding: 0 5/16rem;
    line-height: 30/16rem;
    font-size: 11/16rem;
  }
}
.box {
  height: 70/16rem;
}
.mc-record {
  font-size: 23px;
  user-select: none;
  background-color: #e6e0e0;
}
.van-dialog {
  background: rgba(20, 35, 54, 0.5);
}
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  background: #ccc;
  border: 1/16rem solid #ccc;
  color: #ffffff;
  border-radius: 25/16rem;
  right: 15/16rem;
  bottom: 70/16rem;
  &:hover {
    cursor: pointer;
  }
  span {
    line-height: 30/16rem;
  }
}
</style>

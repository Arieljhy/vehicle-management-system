<template>
  <div style="background: #F2F2F2;">
    <van-nav-bar class="mc-navbar" left-arrow @click-left="onClickLeft">
      <div slot="title" class="word-navbar">
      <span  @click="openSelect">
          {{selectedPrj.communityName}}
        <van-icon name="arrow-down" class="arrow-down" />
      </span>
      </div>
      <van-icon name="setting-o" slot="right" @click="jumpMy" class="jumpMy-size" />
    </van-nav-bar>
    <van-popup v-model="isDialog" position="bottom">
      <van-picker
        show-toolbar
        :columns="plotsList"
        @cancel="isDialog = false"
        :default-index="showNum"
        @confirm="onConfirm"
      />
    </van-popup>

    <!-- 轮播 -->
    <van-row>
      <van-swipe :autoplay="3000">
        <span v-if="images">
          <van-swipe-item v-for="(image, index) in images" :key="index">
            <img v-lazy="image.imageUrl" />
          </van-swipe-item>
        </span>
        <span v-else>
          <img :src="image" />
        </span>
      </van-swipe>
    </van-row>
    <!-- 内容 -->
    <div class="content">
      <van-row class="nav">
        <van-grid :border="false" :column-num="3">
          <van-grid-item
            :class="{ownerColor:setOwnerCommunity}"
            @click="setPic('/governmentCommunity')"
          >
            <img class="owner-btn" :src="ownerCommunityImg" />
            <span>承保</span>
          </van-grid-item>
          <van-grid-item :class="{ownerColor:setOwnerReport}" @click="setPic('/governmentReport')">
            <img class="owner-btn" :src="ownerReportImg" />
            <span>风控</span>
          </van-grid-item>
          <van-grid-item
            :class="{ownerColor:setOwnerClaims,tipPosition:isTip}"
            @click="setPic('/governmentClaims')"
          >
            <img class="owner-btn" :src="ownerClaimsImg" />
            <span>
              理赔
              <span class="tip" v-if="isTip">{{tips}}</span>
            </span>
          </van-grid-item>
        </van-grid>
      </van-row>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "owner",
  components: {},
  data() {
    return {
      communityName: "",
      title: "",
      baoan: {
        value: ""
      },
      radio: "1",
      isDialog: false,
      report: [],
      isTip: false,
      tips: 0,
      setOwnerCommunity: true,
      setOwnerReport: false,
      setOwnerClaims: false,
      ownerCommunityImg: require("@/assets/imgs/owner-images/icon_community_checked.png"),
      ownerReportImg: require("@/assets/imgs/owner-images/icon_report.png"),
      ownerClaimsImg: require("@/assets/imgs/owner-images/icon_claims.png")
    };
  },
  computed: {
    ...mapGetters(["plotsList", "selectedPrj", "images", "showNum"])
  },
  watch: {
    $route(to, from) {
      if (to.path == "/governmentCommunity") {
        this.ownerCommunityImg = require("@/assets/imgs/icon_chengbao_checked.png");
        this.ownerReportImg = require("@/assets/imgs/icon_fengkong.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims.png");
        this.setOwnerCommunity = true;
        this.setOwnerReport = false;
        this.setOwnerClaims = false;
      } else if (to.path == "/governmentReport") {
        this.ownerCommunityImg = require("@/assets/imgs/icon_chengbao.png");
        this.ownerReportImg = require("@/assets/imgs/icon_fengkong_checked.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims.png");
        this.setOwnerCommunity = false;
        this.setOwnerReport = true;
        this.setOwnerClaims = false;
      } else if (to.path == "/governmentClaims") {
        this.ownerCommunityImg = require("@/assets/imgs/icon_chengbao.png");
        this.ownerReportImg = require("@/assets/imgs/icon_fengkong.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims_checked.png");
        this.setOwnerCommunity = false;
        this.setOwnerReport = false;
        this.setOwnerClaims = true;
      }
    }
  },
  methods: {
    ...mapActions([
      "getProjectList",
      "getProjectData",
      "setProject",
      "getPlotsHousehold",
      "getImages",
      "setFinished",
      "setClaimsFinished",
      "getClaimTip",
      "getMainPostList",
      "postFinished",
      "riskReport",
      "riskEventList",
      "riskCheckReportList",
      "getProjectListZF",
      "setShowNum"
    ]),
    //监听路由变化，关闭筛选弹框

    // 打开选择小区
    openSelect() {
      // 不在此掉接口，初始化的时候掉接口
      // this.getProjectList({ isPage: false })
      this.isDialog = true;
    },
    onClickLeft() {
      this.$router.push("/statistics");
    },
    // 切换'小区','报案','理赔'图标样式更改
    setPic(type) {
      this.$router.push(type);
      if (type == "/governmentCommunity") {
        this.ownerCommunityImg = require("@/assets/imgs/icon_chengbao_checked.png");
        this.ownerReportImg = require("@/assets/imgs/icon_fengkong.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims.png");
        this.setOwnerCommunity = true;
        this.setOwnerReport = false;
        this.setOwnerClaims = false;
      } else if (type == "/governmentReport") {
        this.ownerCommunityImg = require("@/assets/imgs/icon_chengbao.png");
        this.ownerReportImg = require("@/assets/imgs/icon_fengkong_checked.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims.png");
        this.setOwnerCommunity = false;
        this.setOwnerReport = true;
        this.setOwnerClaims = false;
      } else if (type == "/governmentClaims") {
        this.ownerCommunityImg = require("@/assets/imgs/icon_chengbao.png");
        this.ownerReportImg = require("@/assets/imgs/icon_fengkong.png");
        this.ownerClaimsImg = require("@/assets/imgs/owner-images/icon_claims_checked.png");
        this.setOwnerCommunity = false;
        this.setOwnerReport = false;
        this.setOwnerClaims = true;
      }
    },
    // 选中小区点击‘确认’
    onConfirm(value, index) {
      if (value) {
        this.setProject(value);
        this.getImages(value.projectId);
        this.getProjectData(this.selectedPrj.projectId);
        this.getPlotsHousehold(this.selectedPrj.projectId);
        this.getMainPostList({
          offset: 1,
          limit: 5,
          projectId: this.selectedPrj.projectId
        });
        this.riskEventList({
          projectId: value.projectId,
          limit: 3,
          offset: 1,
          sqlStatus: 1
        });
        this.riskReport({
          projectId: value.projectId,
          limit: 3,
          offset: 1,
          reportType: 1
        });
        this.riskCheckReportList({
          projectId: value.projectId,
          limit: 3,
          offset: 1
        });
        this.postFinished(false);
        this.setTips();
        this.isDialog = false;
      }else {
        this.isDialog = false;
      }
    },
    // 跳转到_我的
    jumpMy() {
      this.$router.push("/personalSettings");
    },

    setTips() {
      // 理赔列表展示小红点
      this.getClaimTip({
        limit: 5,
        offset: 1,
        projectId: this.selectedPrj.projectId,
        sqlStatus: 1
        // caseReporter: this.selectedPrj.userId
      }).then(res => {
        if (res.code === 0) {
          this.tips = res.data.total;
          if (this.tips > 0) {
            this.isTip = true;
          } else if (this.tips == 0) {
            this.isTip = false;
          }
        }
      });
    }
  },

  created() {
    this.setPic(this.$route.path);
    this.getProjectListZF({ isPage: false }).then(res => {
      if (res.code === 0) {
        this.setProject(
          JSON.parse(localStorage.getItem("eidi.selected_project"))
        );
        let haveSelectedFlag = false;
        this.$store.state.ownerProject.plotsList.map((_params, index) => {
          _params.text = _params.communityName;
          if (JSON.parse(localStorage.getItem("eidi.selected_project"))) {
            if (
              JSON.parse(localStorage.getItem("eidi.selected_project"))
                .projectId == _params.projectId
            ) {
              this.setShowNum(index);
              haveSelectedFlag = true;
            }
          }
        });
        if (!haveSelectedFlag) {
          this.setShowNum(0);
        }
        // 初始化调取轮播,小区数组,该小区所属栋楼
        this.getImages(this.selectedPrj.projectId);
        this.getProjectData(this.selectedPrj.projectId);
        this.getPlotsHousehold(this.selectedPrj.projectId);
        this.setTips();
      }
    });
  }
};
</script>
<style lang="less" scoped>
.content {
  margin: 0 15/16rem;
  text-align: left;
}
.van-swipe {
  height: 238/16rem;
}
.van-swipe /deep/ img {
  width: 100%;
  height: 100%;
}
.nav {
  margin: 10.5/16rem 0;
  text-align: center;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.nav /deep/ img {
  width: 100%;
  height: 100%;
}
/deep/ .van-grid-item__content--center {
  border-radius: 6/16rem;
}
.home {
  margin: 10.5/16rem 0;
  text-align: left;
  height: 153/16rem;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.home /deep/ p {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.home /deep/ .subhead {
  line-height: 26/16rem;
}

.comment {
  text-align: left;
}
.comment /deep/ p {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.comments {
  text-align: left;
}
.comments /deep/ .title {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.comments /deep/ .news {
  // font-size:16px;
  // font-weight: bold;
  padding-left: 15/16rem;
}
.comments /deep/ .news /deep/ .newscont {
  padding: 0 35/16rem;
}
.owner-btn {
  width: 45/16rem !important;
  height: 45/16rem !important;
}
.ownerColor {
  color: #f99139;
}

// 右上角提示小圆点
.tipPosition {
  position: relative;
  // padding: 7px;
  // margin: 40px;
  display: inline-block;
}
.tip {
  display: block;
  background: #f00;
  border-radius: 50%;
  width: 18/16rem;
  height: 18/16rem;
  text-align: center;
  line-height: 18/16rem;
  position: absolute;
  top: 14/16rem;
  color: #fff;
  margin-left: 24/16rem;
  font-size: 12/16rem;
}
.word-navbar {
  font-size: 14/16rem;
}
.jumpMy-size {
  font-size: 20/16rem;
}
.arrow-down {
  margin-top: -1/16rem;
  font-size: 16/16rem;
}
.van-nav-bar__title {
  max-width: 80%;
}
</style>
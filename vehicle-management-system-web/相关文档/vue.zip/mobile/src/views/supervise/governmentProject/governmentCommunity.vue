<template>
  <div>
    <div style="background: #F2F2F2;">
      <!-- 内容 -->
      <div class="content">
        <!-- 保单信息 -->
        <van-row class="home">
          <van-col span="24">
            <p>保单信息</p>
            <div style="width:95%; margin: 0 auto">
              <van-divider />
            </div>
          </van-col>
          <van-col span="22" offset="1" @click="jumpPolicy">
            <div class="subhead">
              <!-- 点点--左 -->
              <i class="point-left" />
              <!-- 点点--右 -->
              <i class="point-right" />
              <van-col span="24">
                <span class="text-bold">项目名称：</span>
                <span class="project-text">{{selectedPrj.projectName}}</span>
              </van-col>
              <van-col span="24">
                <span class="text-bold">保单号：</span>
                <span class="project-text">{{selectedPrj.insContractNo}}</span>
              </van-col>
              <van-col span="24">
                <span class="text-bold">牵头保险公司：</span>
                <span class="project-text">{{projectData.orgName}}</span>
              </van-col>
              <!-- 只有运营方有保单文件 需加条件 v-if="yunying=='OP'" -->
              <van-col span="24">
                <span class="text-bold text-bold-orgName">保单文件：</span>
                <span style="color:#1989fa" class="project-text" @click.stop.self="checkPdf(projectData.insurancePolicy)">{{projectData.insurancePolicyName}}</span>
                <!-- <van-button class="detail-button" @click.stop.self="checkPdf(projectData.insurancePolicy)">预览</van-button> -->
              </van-col>
            </div>
          </van-col>
        </van-row>
      </div>
      <!-- 论坛 -->
      <van-nav-bar left-text="论坛" right-text="新增贴子" @click-right="addNewPost" class="add-post" />
      <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
        <div
          v-for="(item,index) in mainPostList"
          :key="index"
          class="main_post"
          @click="goToForumOpen(item)"
        >
          <van-row>
            <van-col span="5">
              <van-image
                round
                class="manager mouse-pointer"
                :src="item.userImage"
                width="40"
                height="40"
              />
            </van-col>
            <van-col span="19">
              <van-col span="24" class="post_title">{{item.mainTopic}}</van-col>
              <van-col span="24" class="post_user">{{item.userName}}</van-col>
            </van-col>
          </van-row>
          <van-row>
            <van-col span="19" offset="5">
              <div class="main_contents">
                {{item.mainContents}}
                <div class="contents-margin">
                  <span
                    v-for="childItem in item.forumPicDOList"
                    :key="childItem.id"
                    class="contents-right"
                  >
                    <van-image width="60" height="60" :src="childItem.imgUrl" @click.stop="clickImage(childItem)" alt />
                    <!-- 点击图片预览 -->
                    <!-- <van-image-preview v-model="previewShow" :images="imagesShow" @change="onChange">
                      <template v-slot:index>第{{ index }}页</template>
                    </van-image-preview> -->
                  </span>
                </div>
              </div>
            </van-col>
          </van-row>
        </div>
      </van-list>
      <div class="new_post" v-if="openNewPost">
        <van-cell-group style="text-align: left;">
          <van-field v-model="mainTopic" placeholder="请输入贴子标题" />
          <van-field v-model="mainContents" rows="3" autosize type="textarea" placeholder="请输入内容" />
          <van-uploader
            :after-read="uploadFile"
            :before-delete="afterDelete"
            v-model="imageList.imageCloudId"
            class="pictures-margin"
          >
            <div
              class="iconfont icon-xaingji pictures-porder"
              
            >
              <div class="upload-pictures">上传图片</div>
            </div>
          </van-uploader>
        </van-cell-group>

        <van-row>
          <van-button type="default" style="width:50%" @click="openNewPost=false">取消</van-button>
          <van-button type="info" style="width:50%" @click="saveMainPost" v-if="!showAddBtn" :disabled='disabled'>发表</van-button>
          <van-button
            loading
            type="info"
            style="width:50%"
            v-if="showAddBtn"
            loading-text="发表中..."
          />
        </van-row>
      </div>
    </div>
    <div v-if="showPdf">
      <mcPdf :pushurl="pdfurl" :cloudDocId="cloudDocId" @goBack = goBack v-if="fileType=='pdf'"/>
    </div>
    <van-overlay :show="show">
      <div class="wrapper">
         <van-loading size='24px' vertical style="position: absolute;top: 50%; left: 43%;" >加载中...</van-loading>
      </div>
    </van-overlay>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
import mcPdf from "@/components/mcPdf";
import { ImagePreview } from 'vant'
export default {
  name: "GovernmentCommunity",
  components: {
    mcPdf
  },
  data() {
    return {
      dealImgWidth: 600,
      disabled:false,
      show:false,
      showPdf:false,
      pdfurl:'',
      cloudDocId:'',
      // yunying:'',
      //预览
      previewShow:false,
      index:0,
      imagesShow:[],
      // 理赔数
      claims: "",
      // 结案数
      settle: "",
      // 报案电话
      reportPhone: "",
      // 我的小区图片
      myCommunityImg: "",
      policyNumber: 0,
      coverage: "全国",
      // 评论
      clientAvatar: "",
      offset: 0,
      limit: 5,
      mainTopic: "",
      mainContents: "",
      // mainPostList: [],
      loading: false,
      finished: false,
      openNewPost: false,
      imageList: [],
      // 展示承保公司的图标
      images: "",
      showAddBtn: false,
      imagesUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
    };
  },
  computed: {
    ...mapGetters([
      "plotsList",
      "projectData",
      "selectedPrj",
      "houseNum",
      "isDataList1",
      "mainPostList"
    ])
  },
  watch: {
    // 当小区详情发生改变则重新进行更改承保公司图片
    projectData(newVal, oldVal) {
      if (newVal.insOrgId === oldVal.insOrgId) {
        return;
      }
      this.setImages();
    }
  },
  created() {
    // this.yunying = JSON.parse(
    //   localStorage.getItem(this.$getMobileData.userInfo)
    // ).roleType;
    // 初次进入获取小区承保公司图片
    this.setImages();
    // 获取小区详情
    // this.getProjectListZF({ isPage: false }).then(res => {
    //   if (res.code === 0) {
    //     if (this.selectedPrj.projectId) {
    //       // 获取小区总户数接口
    //       this.getPlotsHousehold(this.selectedPrj.projectId);
    //       // this.getListMain(this.selectedPrj.projectId);
    //     }
    //   }
    // });
    this.clearMainPostList([]);
  },
  methods: {
    ...mapActions([
      "getPlotsHousehold",
      "getProjectList",
      "getMainPostList",
      "clearMainPostList",
      "getProjectListZF"
    ]),
    clickImage(item){
      // debugger
      // this.previewShow=true
      // ImagePreview([item.imgUrl])
      ImagePreview({
        images: [item.imgUrl],
        closeable: true,
        closeOnPopstate: true           
        });
    },
    goBack() {
      this.showPdf = false;
    },
    checkPdf(docId) {
       this.show=true
      const keys = {
        cloudDocId:docId,
        pageSize: 1,
        pageNum: 1,
        lesseeId: this.$getMobileData.lesseeId
        //  lesseeId: "eidi-yangquan"
    };
    //9000未不支持文件格式，9001为图片，为空就是没有数据，存在数据，为pdf数据
    http.get("/processDoc/viewFile", keys).then(res => {
      if (res) {
        if(res.code=="9000"){
            this.show=false
          this.$toast("不支持此格式文件预览");
        } else if (res.code == "9002") {
            this.show = false;
            this.$toast("该文件不存在");
          }else if(res.code=="9001"){
           this.show=false
          // ImagePreview([this.imagesUrl+docId]);
          ImagePreview({
            images: [this.imagesUrl+docId],
            closeable: true,
            closeOnPopstate: true           
          });
        }else{
          var binaryData = [];
          binaryData.push(res);
          this.cloudDocId = docId
          this.pdfurl = '/api/processDoc/viewFile?cloudDocId='+docId+'&pageSize=1&pageNum=1&lesseeId='+this.$getMobileData.lesseeId
          // this.pdfurl = '/api/processDoc/viewFile?cloudDocId='+docId+'&pageSize=1&pageNum=1&lesseeId=eidi-yangquan'
          this.fileType ="pdf"
           this.show=false
          this.showPdf = true
        }
      } else {
        console.log("没数据");
      } 
    });
    },
    onChange(index){
      this.index=index
    },
    addNewPost() {
      this.openNewPost = true;
    },
    jumpPolicy() {
      this.$router.push({
        path: "/policyDetail",
        query: this.selectedPrj,
      });
    },
    // 设置承保公司的图片
    setImages() {
      // 大地财险
      if (this.projectData.insOrgId == "1100030001") {
        this.images = require("@/assets/imgs/insurance-icon/Earth_icon.png");
      }
      // 人保财险
      if (this.projectData.insOrgId == "1100030002") {
        this.images = require("@/assets/imgs/insurance-icon/PICC_icon.png");
      }
      // 平安财险
      if (this.projectData.insOrgId == "1100030003") {
        this.images = require("@/assets/imgs/insurance-icon/AN_icon.png");
      }
      // 国寿财险
      if (this.projectData.insOrgId == "1100030004") {
        this.images = require("@/assets/imgs/insurance-icon/China_life_icon.png");
      }
      // 中华联合
      if (this.projectData.insOrgId == "1100030005") {
        this.images = require("@/assets/imgs/insurance-icon/China_united_icon.png");
      }
      // 太平洋财险
      if (this.projectData.insOrgId == "1100030006") {
        this.images = require("@/assets/imgs/insurance-icon/CPIC_icon.png");
      }
      // 太平财险
      if (this.projectData.insOrgId == "1100030007") {
        this.images = require("@/assets/imgs/insurance-icon/Taiping_icon.png");
      }
    },
    //获取小区主贴
    getListMain(projectId) {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        projectId: projectId
      };
      this.getMainPostList(keywords);
      // http.get("/forum/listMain", keywords).then(res => {
      //   if (res.code == 0) {
      //     res.data.rows.map(item => {
      //       item.forumPicDOList.map(childItem => {
      //         childItem.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}`;
      //       });
      //     });
      //     this.mainPostList = res.data.rows;
      //     if (res.data.rows.length < 5) {
      //       this.finished = true;
      //     }
      //   }
      // });
    },
    //跳转到论坛展开页面
    goToForumOpen(item) {
      this.$router.push({
        path: "/forumOpen",
        query: {
          mainId: item.id, //获取项目ID
          projectId: this.selectedPrj.projectId
        }
      });
    },
    // 删除图片
    afterDelete(file, detail) {
      return this.imageList.splice(detail.index, 1);
    },
    async uploadFile(param) {
      this.disabled=true
       param.status='uploading'
      param.message='上传中'
      var toFile = param.file
      if(toFile.type.startsWith("image") && toFile.size > 1024*1024) {
        var _this = this
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        )
        toFile = _this.$dataURLtoFile(base64, toFile.name)
      }

      let file = new FormData();
      file.append("file", toFile);
      file.append("fileIcon", "forumPic");
      file.append("projectId", this.selectedPrj.projectId);
      let keepPic = {
        picType: "1",
        picName: "",
        picPath: "",
        picUidName: param.file.uid,
        projectId: this.selectedPrj.projectId
      };
      http.post("/processDoc/uploadProcessPicsTmp", file).then(res => {
        if (res.code === 0) {
          keepPic.picPath = res.data.cloudDocId;
          keepPic.picUidName = res.data.uidFileName;
          this.imageList.push(keepPic);
          param.status='done'
           this.disabled=false
        }else{
           param.status='failed'
          param.message='上传失败'
           this.disabled=false
        }
      });
    },
    onLoad() {
      const that = this;
      setTimeout(() => {
        that.offset += 1;
        const keywords = {
          offset: that.offset,
          limit: that.limit,
          projectId: that.selectedPrj.projectId
        };
        http.get("/forum/listMain", keywords).then(res => {
          if (res.code == 0) {
            if (that.offset == 1) {
              this.clearMainPostList(res.data.rows);
            } else {
              res.data.rows.map(item => {
                item.forumPicDOList.map(childItem => {
                  childItem.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}`;
                });
              });
              that.mainPostList.push(...res.data.rows);
            }

            // 加载状态结束
            this.loading = false;
            if (res.data.rows.length < 5) {
              this.finished = true;
            }
          }
        });
      }, 500);
    },
    saveMainPost() {
      if (!this.mainTopic.replace(/\s*/g, "")) {
        this.$toast("请录入帖子标题！");
        return;
      }
      if (!this.mainContents.replace(/\s*/g, "")) {
        this.$toast("请录入帖子正文！");
        return;
      }

      const keywords = {
        userId: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo)).userId,
        userName: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .username,
        projectId: this.selectedPrj.projectId,
        mainTopic: this.mainTopic,
        mainContents: this.mainContents,
        forumPicDOList: this.imageList
      };
      this.showAddBtn = true;
      http.post("/forum/saveMain", keywords).then(res => {
        if (res.code == 0) {
          this.mainTopic = "";
          this.mainContents = "";
          this.forumPicDOList = [];
          this.imageList = [];
          this.offset = 1;
          this.showAddBtn = false;
          this.finished = false;
          this.getListMain(this.selectedPrj.projectId);
          this.openNewPost = false;
          this.$toast({ message: "发表成功" });
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.content {
  margin: 0 15/16rem;
  text-align: left;
}
.van-swipe {
  height: 238/16rem;
}
.van-swipe /deep/ img {
  width: 100%;
  height: 100%;
}
.nav {
  margin: 10.5/16rem 0;
  text-align: center;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.nav /deep/ img {
  width: 100%;
  height: 100%;
}
.home {
  margin: 10.5/16rem 0;
  text-align: left;
  // height: 160px;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6/16rem;
  box-shadow: 0 3/16rem 5/16rem #dfdfdf;
}
.home /deep/ p {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
  margin-bottom: -10/16rem;
}
.home /deep/ .subhead {
  line-height: 26/16rem;
}
.comment {
  text-align: left;
}
.comment /deep/ p {
  font-size: 16/16rem;
  font-weight: bold;
  padding-left: 15/16rem;
}
.new_post {
  position: fixed;
  bottom: 0;
  width: 100%;
  z-index: 2;
}
.van-cell__title {
  text-align: left;
  font-weight: bold;
}
.main_contents {
  text-align: left;
  padding: 5/16rem 16/16rem 5/16rem 0;
}
.van-cell:not(:last-child)::after {
  border-bottom: none;
}
.main_post {
  background-color: white;
  padding: 15/16rem 0;
  border-bottom: 1/16rem solid #ebedf0;
}
.post_title {
  text-align: left;
  font-weight: bold;
  font-size: 16/16rem;
}
.post_user {
  text-align: left;
  color: #b4b8bf;
  font-size: 13/16rem;
}

.point-left,
.point-right {
  display: inline-block;
  position: absolute;
  margin-top: 5/16rem;
  background-color: #f2f2f2;
  border-style: solid;
  border-width: 1/16rem;
  border-top-color: #dfdfdf;
  border-bottom-color: #dfdfdf;
}
// 点点
.point-left {
  width: 5/16rem;
  height: 13/16rem;
  left: 15/16rem;
  border-radius: 0 9/16rem 9/16rem 0;
  border-right-color: #dfdfdf;
  border-left-color: transparent;
}
.point-right {
  width: 5/16rem;
  height: 13/16rem;
  right: 15/16rem;
  border-radius: 9/16rem 0 0 9/16rem;
  border-left-color: #dfdfdf;
  border-right-color: transparent;
}
// 字体加粗
.text-bold {
  font-weight: bold;
}
.project-text {
  font-size: 14/16rem;
}
.a-text-color a {
  color: #128feb;
}
// 背景底色
.color-background {
  background: #f2f2f2;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.upload-pictures{
  font-size: 15/16rem;
}
.pictures-porder{
  font-size: 30/16rem; 
  text-align: center;
  border: 1/16rem solid #c5c5c5; 
  width: 78/16rem; 
  height: 68/16rem; 
  padding-top: 10/16rem;
}
.pictures-margin{
  margin:5/16rem 0 5/16rem 15/16rem;
}
.contents-margin{
   margin-top:3/16rem;
}
.contents-right{
  margin-right: 10/16rem;
}
.text-bold-orgName{
   margin-bottom:10/16rem;
   display: inline-block;
}
.text-bold-report{
   margin-bottom: 10/16rem;
   display: inline-block;
}
.detail-button{
  height: 30px;
  line-height: 30px;
  margin-left: 27px;
}
</style>
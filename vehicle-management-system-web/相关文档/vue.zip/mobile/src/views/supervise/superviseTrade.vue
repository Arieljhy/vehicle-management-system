<template>
  <div style="background: #128feb;">
    <van-nav-bar class="mc-navbar">
      <van-icon name="search" slot="left" @click="search" />
      <van-icon name="setting-o" slot="right" @click="jump" />
    </van-nav-bar>
    <!-- 导航 -->
    <van-row class="header">
      <van-col span="8">
        <van-button
          color="linear-gradient(to right, rgba(135,206,250,0.57) , rgba(135,206,250,0.8))"
          @click="$router.push('/statistics')"
        >项目状态</van-button>
      </van-col>
      <van-col span="8">
        <van-button
          color="linear-gradient(to right, rgba(135,206,250,0.57) , rgba(135,206,250,0.8))"
          @click="$router.push('/superviseProjectArea')"
        >项目区域</van-button>
      </van-col>
      <van-col span="8">
        <van-button @click="$router.push('/superviseTrade')">行业监管</van-button>
      </van-col>
    </van-row>
    <div class="ins" v-if="insurance">
      <!-- 保险公司 -->
      <div class="content">
        <van-row class="nav">
          <van-row class="navTitle">
            <van-col span="12">保险公司</van-col>
            <van-col span="12" @click="isPopup = true" style="text-align:right">
              <span class="iconfont icon-shaixuan shaixuan-btn"> 筛选</span>
            </van-col>
          </van-row>
          <!-- 保险公司筛选 -->
          <van-popup
            v-model="isPopup"
            position="right"
            :style="{ width: '85%' }"
            @close="isPopup = false"
            @click-overlay="isPopup = false"
          >
            <filterSearch @filterData="filterData" />
          </van-popup>
          <div class="gaine">
            <!-- 项目数 -->
            <van-row class="gaineLine">
              <van-col span="24">
                <span
                  class="projectNum"
                  @click="newAmount('projectNumber')"
                >{{projectLists_1.projectNumber}}</span>
                <br />
                <span class="text-style">项目数</span>
              </van-col>
            </van-row>
            <!-- 保费/额 -->
            <van-row class="gaineLine">
              <van-col span="12" class="leftCell">
                <span
                  class="dataStyle"
                  @click="amount('totalPremium')"
                >{{projectLists_4.totalPremium | numberFormatNew()}}</span>
                <br />
                <span class="text-style">保费</span>
              </van-col>
              <van-col span="12" class="leftLine">
                <span
                  class="dataStyle"
                  @click="amount('totalInsuredAmount')"
                >{{projectLists_4.totalInsuredAmount | numberFormatNew()}}</span>
                <br />
                <span class="text-style">保额</span>
              </van-col>
            </van-row>
            <!-- 正在理赔数/金 -->
            <van-row class="gaineLine">
              <van-col span="12" class="leftCell" @click="newAmount('totalClaimNumber')">
                <span class="dataStyle">{{projectLists_1.totalClaimNumber | numberFormatNewSys()}}</span>
                <br />
                <span class="text-style">正在理赔数</span>
              </van-col>
              <van-col span="12" class="leftLine">
                <span
                  class="dataStyle"
                  @click="amount('totalClaimAmount')"
                >{{projectLists_5.totalClaimAmount | numberFormatNew()}}</span>
                <br />
                <span class="text-style">正在理赔金额</span>
              </van-col>
            </van-row>
            <!-- 完成理赔数/金 -->
            <van-row class="gaineLine">
              <van-col span="12" class="leftCell" @click="newAmount('totalCompletedClaimNumber')">
                <span
                  class="dataStyle"
                >{{projectLists_1.totalCompletedClaimNumber | numberFormatNewSys()}}</span>
                <br />
                <span class="text-style">完成理赔数</span>
              </van-col>
              <van-col span="12" class="leftLine" @click="amount('totalCompletedClaimAmount')">
                <span
                  class="dataStyle"
                >{{projectLists_5.totalCompletedClaimAmount | numberFormatNew()}}</span>
                <br />
                <span class="text-style">完成理赔金额</span>
              </van-col>
            </van-row>
            <!-- 面积/造价 -->
            <van-row class="gaineLine lastLine">
              <van-col span="12" class="leftCell" @click="area('totalUnderwritingArea')">
                <span class="dataStyle">
                  {{projectLists_4.totalUnderwritingArea | numberFormatArea()}}
                  <!-- <span class="unitStyle">m²</span> -->
                </span>
                <br />
                <span class="text-style">承保面积(m²)</span>
              </van-col>
              <van-col class="leftLine" span="12" @click="amountAverage()">
                <span class="dataStyle" style="margin-right:0">
                  {{averageValue | numberFormatNew()}}/㎡
                  <!-- <span class="unitStyle">/平米/m²</span> -->
                </span>
                <br />
                <span class="text-style">平均造价(RMB/m²)</span>
              </van-col>
            </van-row>
          </div>
        </van-row>
        <van-row>
          <van-col offset="11" />
          <van-col class="circle" @click="switchGo(1)" />
          <van-col class="circle circles" @click="switchGo(2)" />
        </van-row>
        <!-- echart -->
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
          :offset="3"
        >
          <div v-for="(item,index) in insEcharts" :key="index">
            <div class="echart">
              <div v-show="item.variable" class="newclass">
                <span>{{item.title}}</span>
              </div>
              <chart :ref="item.echartId" v-show="!item.variable" style="width:100%;height:100%"></chart>
            </div>
          </div>
        </van-list>
      </div>
      <van-dialog v-model="amountDialog" :beforeClose="onAccountExists" class="vanDialog">
        <van-row v-for="(item2,index) in getNum" :key="index" class="dialogStyle">
          <van-col span="16" style="text-align:left;">{{item2.name}}</van-col>
          <van-col span="8" style="text-align:right">{{item2.value | numberFormatNew()}}</van-col>
        </van-row>
      </van-dialog>
      <van-dialog v-model="areaDialog" :beforeClose="onAccountExists" class="vanDialog">
        <van-row v-for="(item6,index) in getArea" :key="index" class="dialogStyle">
          <van-col span="16" style="text-align:left;">{{item6.name}}</van-col>
          <van-col span="8" style="text-align:right">{{item6.value | numberFormatArea()}}</van-col>
        </van-row>
      </van-dialog>
      <van-dialog v-model="newAmountDialog" :beforeClose="onAccountExists" class="vanDialog">
        <van-row v-for="(item3,index) in newGetNum" :key="index" class="dialogStyle">
          <van-col span="16" style="text-align:left;">{{item3.name}}</van-col>
          <van-col span="8" style="text-align:right">{{item3.value | numberFormatSystem()}}</van-col>
        </van-row>
      </van-dialog>
    </div>
    <div class="ins" v-if="!insurance">
      <!-- TIS -->
      <div class="content">
        <van-row class="nav">
          <van-row class="navTitle">
            <van-col span="12">TIS机构</van-col>
            <van-col span="12" @click="isTisPopup = true" style="text-align:right">
              <span class="iconfont icon-shaixuan shaixuan-btn"> 筛选</span>
            </van-col>
          </van-row>
          <!-- TIS公司筛选 -->
          <van-popup
            v-model="isTisPopup"
            position="right"
            :style="{ width: '85%' }"
            @close="isTisPopup = false"
            @click-overlay="isTisPopup = false"
          >
            <filterSearch @filterData="filterData" />
          </van-popup>
          <div class="gaine">
            <!-- 项目数 -->
            <van-row class="gaineLine">
              <van-col span="24">
                <span
                  class="projectNum"
                  @click="newAmount('projectNumber')"
                >{{projectLists_1.projectNumber}}</span>
                <br />
                <span class="text-style">项目数</span>
              </van-col>
            </van-row>
            <!-- 风险 -->
            <van-row class="gaineLine">
              <van-col span="12" class="leftCell" @click="newAmount('totalRiskEventMonthNumber')">
                <span class="dataStyle">{{projectLists_2.totalRiskEventMonthNumber}}</span>
                <br />
                <span class="text-style">本月风险事件数</span>
              </van-col>
              <van-col span="12" @click="newAmount('totalRiskEventQuarterNumber')" class="leftLine">
                <span class="dataStyle">{{projectLists_2.totalRiskEventQuarterNumber}}</span>
                <br />
                <span class="text-style">本季度风险事件数</span>
              </van-col>
            </van-row>
            <!-- 正在理赔数/金 -->
            <van-row class="gaineLine">
              <van-col span="12" @click="newAmount('totalConstructionProjectNumber')" class="leftCell">
                <span class="dataStyle">{{projectLists_4.totalConstructionProjectNumber}}</span>
                <br />
                <span class="text-style">施工中项目数</span>
              </van-col>
              <van-col class="leftLine" span="12" @click="newAmount('totalRiskAssessmentNumber')">
                <span class="dataStyle">{{projectLists_3.totalRiskAssessmentNumber}}</span>
                <br />
                <span class="text-style">风险评估报告数</span>
              </van-col>
            </van-row>
            <van-row class="gaineLine">
              <van-col span="12" @click="newAmount('totalRiskEventNumber')" class="leftCell">
                <span class="dataStyle">{{projectLists_2.totalRiskEventNumber}}</span>
                <br />
                <span class="text-style">风险事件数</span>
              </van-col>
              <van-col span="12" @click="newAmount('totalSeriousRiskEventNumber')" class="leftLine">
                <span class="dataStyle">{{projectLists_2.totalSeriousRiskEventNumber}}</span>
                <br />
                <span class="text-style">严重风险事件数</span>
              </van-col>
            </van-row>
            <!-- 面积/造价 -->
            <van-row class="gaineLine lastLine">
              <van-col span="12" class="leftCell" @click="tisArea('totalUnderwritingArea')">
                <span class="dataStyle">
                  {{projectLists_4.totalUnderwritingArea | numberFormatArea()}}
                  <!-- <span class="unitStyle">m²</span> -->
                </span>
                <br />
                <span class="text-style">承保面积(m²)</span>
              </van-col>
              <van-col span="12" class="leftLine" @click="amountAverage()">
                <span class="dataStyle" style="margin-right:0">
                  {{averageValue | numberFormatNew()}}/㎡
                  <!-- <span class="unitStyle">RMB/m²</span> -->
                </span>
                <br />
                <span class="text-style">平均造价(RMB/m²)</span>
              </van-col>
            </van-row>
          </div>
        </van-row>
        <van-row>
          <van-col offset="11" />
          <van-col class="circle circles" @click="switchGo(1)" />
          <van-col class="circle" @click="switchGo(2)" />
        </van-row>
        <!-- echart -->
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
          :offset="1"
        >
          <div v-for="(item,index) in tisEcharts" :key="index">
            <div class="echart">
              <div v-show="item.variable" class="newclass">
                <span>{{item.title}}</span>
              </div>
              <chart :ref="item.echartId" v-show="!item.variable" style="width:100%;height:100%"></chart>
            </div>
          </div>
        </van-list>
      </div>
    </div>
    <van-dialog v-model="tisAreaDialog" :beforeClose="onAccountExists" class="vanDialog">
      <van-row v-for="(item4,index) in tisNum" :key="index" class="dialogStyle">
        <van-col span="16" style="text-align:left;">{{item4.name}}</van-col>
        <van-col span="8" style="text-align:right">{{item4.value | numberFormatArea()}}</van-col>
      </van-row>
      <!-- <span class="dialogStyle">{{tisNum | numberFormat()}}</span> -->
    </van-dialog>
    <van-dialog v-model="newAmountDialog" :beforeClose="onAccountExists" class="vanDialog">
      <van-row v-for="(item3,index) in newGetNum" :key="index" class="dialogStyle">
        <van-col span="16" style="text-align:left;">{{item3.name}}</van-col>
        <van-col span="8" style="text-align:right">{{item3.value | numberFormatSystem()}}</van-col>
      </van-row>
      <!-- <span class="dialogStyle">{{newGetNum | numberFormatSystem()}}</span> -->
    </van-dialog>
    <van-dialog v-model="amountAverageDialog" :beforeClose="onAccountExists" class="vanDialog">
      <van-row v-for="(item5,index) in averageCasts" :key="index" class="dialogStyle">
        <van-col span="14" style="text-align:left;">{{item5.name}}</van-col>
        <van-col span="10" style="text-align:right">{{item5.value | numberFormatNew()}}/㎡</van-col>
      </van-row>
    </van-dialog>
    <!-- 返回顶部 -->
    <div>
      <van-row id="top" class="top" style="display:none" @click="top">
        <span>top</span>
      </van-row>
    </div>
  </div>
</template>

<script>
import chart from "@/components/charts";
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
import {
  numberFormatNew,
  numberFormat,
  numberFormatSystem,
  numberFormatNewSys,
  numberFormatArea
} from "@/utils";
import { Toast } from 'vant';
import filterSearch from "./child/filterSearch";
export default {
  name: "superviseTrade",
  components: {
    filterSearch: filterSearch,
    chart
  },
  data() {
    return {
      isPopup: false,
      isTisPopup: false,
      fitterData: {
          province: this.$getMobileData.provinceie,
          city: this.$getMobileData.city,
          district: "",
          minCostPerMeter: "",
          maxCostPerMeter: "",
          buildingType: "",
          projectStatus: "",
          orgIds: "",
          isChecked: false,
      },
      charts: {
        maanshan: maanshan,
        beijing: beijing,
        shanghai: shanghai,
        yangquan: yangquan
      },
      getArea: [
        {
          name: "",
          value: null
        }
      ],
      getNum: [
        {
          name: "",
          value: null
        }
      ],
      newGetNum: [
        {
          name: "",
          value: null
        }
      ],
      tisNum: [
        {
          name: "",
          value: null
        }
      ],
      amountDialog: false,
      areaDialog: false,
      newAmountDialog: false,
      tisAreaDialog: false,
      amountAverageDialog: false,
      insurance: true,
      echarts: [],
      // 折线图
      // category_option: {
      //   title: {
      //     text: "",
      //     x: "10",
      //     y: "15",
      //     textStyle: {
      //       fontSize: "17",
      //       fontWeight: "bold",
      //       fontFamily: "Source Han Sans CN"
      //     }
      //   },
      //   tooltip: {
      //     trigger: "axis",
      //     position:function(pos,params,dom,rect,size){
      //       var obj = {top:60};
      //       obj[['left','right'][+(pos[0]<size.viewSize[0]/2)]]=5;
      //       return obj;
      //     }
      //   },
      //   xAxis: {
      //     axisLabel: {
      //       interval: 0,
      //       rotate: 30
      //     },
      //     type: "category",
      //     data: []
      //   },
      //   yAxis: {
      //     splitNumber: "4",
      //     scale: true
      //   },
      //   series: [
      //     {
      //       data: [],
      //       type: "line"
      //     }
      //   ],
      //   grid: {
      //     //Y轴显示不全
      //     left: 52
      //   }
      // },
      // 圆形扇形图
      pie_option: {
        title: {
          text: "",
          x: "10",
          y: "10",
          textStyle: {
            fontSize: "17",
            fontWeight: "bold",
            fontFamily: "Source Han Sans CN"
          }
        },
        tooltip: {
          triggrer: "item",
          formatter: "{b}:{c} ({d}%)",
          position: [10, "20%"]
        },
        legend: {
          selectedMode: false,
          borderRadius: 10,
          orient: "horizontal",
          icon: "circle",
          bottom: "0",
          left: "0",
          align: "left",
          textStyle: {
            fontSize: 10,
            fontWeight: "bold"
          },
          itemWidth: 10, //图标宽
          itemHeight: 10, //图标高
          itemGap: 10 //间距
        },
        color: [
          "#C81812",
          "#EFB70C",
          "#9F77FA",
          "#FB5277",
          "#297AE3",
          "#3CD323",
          "#E5E5E5",
          "#8C8C8C",
          "#FF33FF",
          "#CAFF70",
          "#3399FF",
          "#3366FF",
          "#CCCCFF",
          "#99FFCC",
          "#663333",
          "#00FFFF"
        ],
        series: [
          {
            name: "",
            type: "pie",
            radius: ["45%", "55%"],
            center: ["50%", "50%"],
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: "20",
                  align: "center"
                },
                formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                rich: {
                  a: {
                    fontSize: "23",
                    align: "center",
                    fontWeight: "400"
                  },
                  b: {
                    fontSize: "12",
                    align: "center",
                    fontWeight: "900",
                    color: "#68615f"
                  }
                }
              }
            },
            labelLine: {
              normal: {
                show: true,
                smooth: 0.2,
                length: 5,
                length2: 10
              }
            },
            data: []
          }
        ]
      },
      // 柱状图
      axas_option: {
        title: {
          text: "",
          x: "10",
          y: "10",
          textStyle: {
            fontSize: "17",
            fontWeight: "bold",
            fontFamily: "Source Han Sans CN"
          }
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          left: "1%",
          right: "1%",
          bottom: "1%",
          containLabel: true
        },
        xAxis: {
          type: "category",
          data: [],
          axisLabel: {
            interval: 0,
            rotate: 30
          }
        },
        yAxis: {
          type: "value"
        },
        series: [
          {
            type: "bar",
            // barWidth: "35", //固定柱子宽度
            label: {
              normal: {
                show: true,
                position: "insideRight"
              }
            },
            data: []
          }
        ]
      },
      // 横向柱状图
      // Yaxas_option: {
      //   title: {
      //     text: "",
      //     x: "10",
      //     y: "15",
      //     textStyle: {
      //       fontSize: "17",
      //       fontWeight: "bold",
      //       fontFamily: "Source Han Sans CN"
      //     }
      //   },
      //   tooltip: {
      //     trigger: "axis",
      //     axisPointer: {
      //       // 坐标轴指示器，坐标轴触发有效
      //       type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
      //     }
      //   },
      //   grid: {
      //     left: "1%",
      //     right: "1%",
      //     bottom: "1%",
      //     containLabel: true
      //   },
      //   xAxis: {
      //     type: "value",
      //     axisLabel: {
      //       interval: 0,
      //       rotate: 30
      //     }
      //   },
      //   yAxis: {
      //     type: "category",
      //     data: []
      //   },
      //   series: [
      //     {
      //       type: "bar",
      //       barWidth: "35", //固定柱子宽度
      //       color: "#0D9DAD",
      //       label: {
      //         normal: {
      //           show: true,
      //           position: "insideLeft" //value的位子
      //         }
      //       },
      //       data: []
      //     }
      //   ]
      // },
      variable: false,
      result: [],
      limit: 3,
      offset: 1,
      total: 0,
      userId: "",
      insOrgId: "",
      projectLists_1: {}, // 项目数列表
      projectLists_2: {}, // 项目数列表
      projectLists_3: {}, // 项目数列表
      projectLists_4: {}, // 项目数列表
      projectLists_5: {}, // 项目数列表
      tisEcharts: [], // tis下echart
      insEcharts: [], //ins下echart
      loading: false,
      finished: false,
      averageCasts: [
        {
          name: "",
          value: null
        }
      ],
      averageValue: Number
    };
  },
  computed: {
    ...mapGetters([
      "provinceList",
      "province",
      "city",
      "district",
      "minCostPerMeter",
      "maxCostPerMeter",
      "buildingType",
      "projectStatus",
      "orgIds",
      "isChecked",
      "userType"
    ])
  },
  mounted() {
    this.EchartsList();
    window.addEventListener("scroll", this.onscroll);
  },
  created() {
    this.getUserId();
    this.getInsOrgId();
    this.projectList();
    this.getAverageCast();
    // 返回顶部
    // onscroll = function() {
    //   if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
    //     document.getElementById("top").style.display = "block";
    //   } else {
    //     document.getElementById("top").style.display = "none";
    //   }
    // };
  },
  filters: {
    tatusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "info",
        deleted: "danger"
      };
      return statusMap[status];
    },
    numberFormatNew,
    numberFormat,
    numberFormatSystem,
    numberFormatNewSys,
    numberFormatArea
  },
  computed: {
    ...mapGetters(["claimsFinished"])
  },
  methods: {
    filterData(value) {
      this.fitterData = value;
      if(this.insurance){
        this.isPopup = false;
      }else{
        this.isTisPopup = false;
      }
      this.projectList(this.fitterData);
      this.getAverageCast(this.fitterData);
    },
    // 返回顶部
    onscroll() {
      if (document.documentElement.scrollTop + document.body.scrollTop > 200) {
        document.getElementById("top").style.display = "block";
      } else {
        document.getElementById("top").style.display = "none";
      }
    },
    amount(value) {
      // this.getNum = value;
      const keyword = { type: value,query:this.fitterData };
      Toast.loading({message:'加载中'})
      http
        .post("/project/PrjQueryInfo/gov/aggregateDataInfo", keyword)
        .then(res => {
          if(res.code==0){
            this.getNum = res.data;
            this.amountDialog = true;
            Toast.clear()
          }
        });
    },
    area(value) {
      const keyword = { type: value,query:this.fitterData };
      Toast.loading({message:'加载中'})
      http
        .post("/project/PrjQueryInfo/gov/aggregateDataInfo", keyword)
        .then(res => {
          if(res.code==0){
            this.getArea = res.data;
            this.areaDialog = true;
            Toast.clear()
          }
        });
    },
    newAmount(value) {
      // this.newGetNum = value;
      const keyword = { type: value,query:this.fitterData };
      Toast.loading({message:'加载中'})
      http
        .post("/project/PrjQueryInfo/gov/aggregateDataInfo", keyword)
        .then(res => {
          if(res.code==0){
            this.newGetNum = res.data;
            this.newAmountDialog = true;
            Toast.clear()
          }
        });
    },
    tisArea(value) {
      // this.tisNum = value;
      const keyword = { type: value,query:this.fitterData };
      Toast.loading({message:'加载中'})
      http
        .post("/project/PrjQueryInfo/gov/aggregateDataInfo", keyword)
        .then(res => {
          if(res.code==0){
           this.tisNum = res.data;
           this.tisAreaDialog = true;
           Toast.clear()
          }
        });
    },
    amountAverage() {
      this.amountAverageDialog = true;
    },
    onAccountExists(action, done) {
      if (action === "confirm") {
        done();
      }
    },
    // 获取 userId
    getUserId() {
      this.userId = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).userId;
    },
    // 获取 orgId
    getInsOrgId() {
      this.insOrgId = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ).insOrgId;
    },
    // 查询数据
    projectList() {
      for(var i = 1;i<6;i++){
        this.getProjectList(String(i));
      }
    },
    async getProjectList(flag){
      const data = await http.post("/project/PrjQueryInfo/gov/aggregateData",{s:flag,query:this.fitterData});
      this["projectLists_"+flag] = data.data?data.data:{};
    },
    // 平均造价求均值
    getAverageCast() {
      const keyword = { type: "AverageCost",query:this.fitterData };
      http
        .post("/project/PrjQueryInfo/gov/aggregateDataInfo", keyword)
        .then(res => {
          if(res.code==0){
            this.averageCasts = res.data?res.data:[];
            let sum = 0;
            if(this.averageCasts.length>0){
              for (let i = 0; i < this.averageCasts.length; i++) {
                sum = sum + parseFloat(this.averageCasts[i].value);
                this.averageValue = sum / (i + 1);
              }              
            }else{
              this.averageValue = 0.00;
            }
          }
        });
    },
    // echart
    async EchartsList() {
      const keywords = {
        userId: this.userId,
        orgId: this.insOrgId,
        city: this.$getMobileData.city,
        province: this.$getMobileData.provinceie,
        offset: this.offset,
        limit: this.limit,
        bizType: this.insurance ? "INS" : "TIS"
      };
      const { data } = await http.get("/echart/all", keywords);
      this.echarts = data.echartDataList;
      let rows = data.echartDataList;
      this.loading = false;
      this.total = data.total;
      this.echarts.map(index => {
        // 当为ins时
        if (index.orgType == "ins" || index.orgType == "prj") {
          this.insEcharts.push(index);
        }
        // 当为tis时
        if (index.orgType == "tis") {
          this.tisEcharts.push(index);
        }
      });
      // 图表数据
      for (let [i, item] of this.echarts.entries()) {
        if (item.data.length == 0) {
          item.variable = true; // 无数据时
        }
        if (item.echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: item.title,
              x: "10",
              y: "10",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            xAxis: {
              axisLabel: {
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 52
            }
          };
          for (let n of item.data) {
            if (typeof n.value !== "number") {
              continue; //当为null时
            }
            category_option.xAxis.data.push(n.name);
            category_option.series[0].data.push(n.value);
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(category_option);
          }, 10);
        } else if (item.echartType === "sector") {
          // 圆形扇形图
          item.pie_option = JSON.parse(JSON.stringify(this.pie_option));
          item.pie_option.title.text = item.title;
          for (let n of item.data) {
            item.pie_option.series[0].data.push({
              name: n.name,
              value: n.value
            });
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(item.pie_option);
            this.$refs[item.echartId][0].editEcahrt(
              item.pie_option,
              this.$refs[item.echartId][0].id
            );
          }, 10);
        } else if (item.echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: item.title,
              x: "10",
              y: "10",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getMobileData.city,
                type: "map",
                mapType: this.$getMobileData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [{}], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                }
              }
            ]
          };
          for (let n of item.data) {
            map_option.series[0].data.push({ name: n.name, value: n.value });
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(map_option, {
              name: this.$getMobileData.city,
              map: this.charts[this.$getMobileData.control]
            });
          }, 10);
        } else if (item.echartType === "columnar") {
          // 柱状图
          item.axas_option = JSON.parse(JSON.stringify(this.axas_option));
          item.axas_option.title.text = item.title;
          for (let n of item.data) {
            item.axas_option.xAxis.data.push(n.name);
            item.axas_option.series[0].data.push(n.value);
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(item.axas_option);
          }, 10);
        } else if (item.echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: item.title,
              x: "10",
              y: "10",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                // barWidth: "35", //固定柱子宽度
                // color: "#0D9DAD",
                label: {
                  normal: {
                    show: true,
                    position: "insideLeft" //value的位子
                  }
                },
                data: [],
                itemStyle: {
                    normal:{//每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                        color: function (params){
                            var colorList=[];
                            for(var aa=0;aa<item.data.length;aa++){
                              colorList.push(`#${Math.floor(Math.random()*0xffffff).toString(16)}`); 
                            }
                          return colorList[params.dataIndex];
                        }
                    },
                    //鼠标悬停时：
                    emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
              }
            ]
          };
          // item.Yaxas_option = JSON.parse(JSON.stringify(this.Yaxas_option));
          // item.Yaxas_option.title.text = item.title;
          for (let n of item.data) {
            Yaxas_option.yAxis.data.push(n.name);
            Yaxas_option.series[0].data.push(n.value);
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(Yaxas_option);
          }, 10);
        } else if (item.echartType === "boxplot") {
          // 盒须图
          // debugger;

          let boxDataList = [];
          let boxDataName = [];
          for (let n of item.data) {
            boxDataList.push(n.value);
            boxDataName.push(n.name);
          }
          let data = echarts.dataTool.prepareBoxplotData(boxDataList);
          let boxplot_option = {
            title: [
              {
                text: item.title,
                left: "10",
                top: "10",
                textStyle: {
                  fontSize: "17",
                  fontWeight: "bold",
                  fontFamily: "Source Han Sans CN"
                }
              }
            ],
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "cross"
              },
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            grid: {
              left: "12%",
              right: "2%"
              // bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: boxDataName,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              axisLabel: {
                formatter: "{value}"
              },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              name: "",
              splitArea: {
                show: true
              },
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: data.boxData,
                tooltip: {
                  formatter: function(param) {
                    return [
                      "Experiment " + param.name + ": ",
                      "upper: " + param.data[5],
                      "Q3: " + param.data[4],
                      "median: " + param.data[3],
                      "Q1: " + param.data[2],
                      "lower: " + param.data[1]
                    ].join("<br/>");
                  }
                }
              },
              {
                name: "outlier",
                type: "scatter",
                data: data.outliers
              }
            ]
          };

          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(boxplot_option);
          }, 10);
        } else if (item.echartType === "lines") {
          // 多折线图
          let dateArr = [];
          let dateYM = new Date();
          let currentYear = dateYM.getFullYear();
          dateYM.setMonth(dateYM.getMonth() + 1, 1);
          for (let i = 0; i < 12; i++) {
            dateYM.setMonth(dateYM.getMonth() - 1);
            let dateM = dateYM.getMonth() + 1;
            dateM = dateM < 10 ? "0" + dateM : dateM;
            let dateArrItem = {
              name: dateYM.getFullYear() + "-" + dateM,
              value: 0
            };
            dateArr.unshift(dateArrItem);
          }
          let x_data = [];
          dateArr.map(arrItem => {
            x_data.push(arrItem.name);
          });
          let categorys_option = {
            title: {
              text: item.title,
              x: "10",
              y: "10",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              // formatter: '{c}' //鼠标滑过时候的显示
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            legend: {
              selectedMode: false,
              bottom: "13",
              left: "10",
              align: "left",
              orient: "horizontal",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemGap: 10 //间距
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: x_data
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54,
              bottom: 90
            }
          };
          item.data.map(itemChild => {
            itemChild.name = itemChild.name;
            itemChild.type = "line";
            // itemChild.stack = "df";
            itemChild.data = [0,0,0,0,0,0,0,0,0,0,0,0];
            itemChild.result.map(resultChild => {
              dateArr.map((arrItem,num) => {
                if (arrItem.name == resultChild.name) {
                  arrItem.value = resultChild.value;
                  itemChild.data.map((list,i)=>{
                    if(num==i){itemChild.data.splice(i,1,arrItem.value)}
                  })
                } 
              });
            });
          });
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(categorys_option);
          }, 10);
        } else if (item.echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: item.title,
              x: "10",
              y: "10",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              },
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 150 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            // legend: {
            //   top: "10%",
            //   right: "13",
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: "bold"
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              // data: ["统计"]
              data: item.yList
            },
            series: item.data
          };
          item.data.map((itemChild, num) => {
            itemChild.type = "bar";
            itemChild.stack = "df";
            // itemChild.barWidth = "35";
            itemChild.data = [];
            item.yList.map(itemYear => {
              if (itemChild.value[itemYear]) {
                itemChild.data.push(itemChild.value[itemYear]);
              } else {
                itemChild.data.push(0);
              }
            });
          });
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(Yaxass_option);
          }, 10);
        } else if (item.echartType === "specialSector") {
          // 特殊扇形
          const datas = item.data;
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverOffset: 0, //鼠标移入变大
                radius: [60 - i * 8 + "%", 52 - i * 8 + "%"], // 形状
                center: ["50%", "50%"], //位置
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "20",
                      align: "center"
                    },
                    formatter: ["{a| {c}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "900",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value.toFixed(2),
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: item.title,
              x: "10",
              y: "10",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c}",
              position: [10, "50%"]
            },
            legend: {
              selectedMode: false,
              borderRadius: 10,
              orient: "horizontal",
              borderRadius: 10,
              icon: "circle",
              left: "10",
              bottom: "13",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                fontWeight: "bold"
                // font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(spie_option);
          }, 10);
        }
      }
      // 触底加载
      if (rows == null || rows.length === 0) {
        console.log("加载完成！此console代码不可删除"); //不可删除此行代码
        // 加载结束
        this.finished = true;
        return;
      }
      this.echarts = this.echarts.concat(rows);
      if (this.echarts.length >= this.total) {
        this.finished = true;
      }
    },
    // 触底加载
    onLoad() {
      this.offset++;
      this.EchartsList();
    },
    // 搜索
    search() {
      this.$router.push({
        path: "/superviseSelect",
        query: {}
      });
    },
    jump() {
      this.$router.push({
        path: "/personalSettings"
      });
    },
    switchGo(flag) {
      if (flag == 1) {
        this.insurance = true;
        this.insEcharts = []; //先清空
        this.finished = false;
        this.offset = 1;
        this.EchartsList();
      } else if (flag == 2) {
        this.insurance = false;
        this.tisEcharts = []; //先清空
        this.finished = false;
        this.offset = 1;
        this.EchartsList();
      }
    },
    // 返回顶部
    top() {
      window.scrollTo(0, 0);
    }
  },
  destroyed() {
    window.removeEventListener("scroll", this.onscroll);
  }
};
</script>
<style scoped lang="less">
.top {
  position: fixed;
  width: 35/16rem;
  height: 35/16rem;
  border: 1px solid #ccc;
  color: #fff;
  border-radius: 25/16rem;
  background: #ccc;
  right: 25/16rem;
  bottom: 40/16rem;
}
.top:hover {
  cursor: pointer;
}
.top /deep/ span {
  line-height: 30/16rem;
}
.van-hairline--bottom::after {
  border-bottom-width: 0;
}
.header {
  margin: 10/16rem 10.5/16rem 15/16rem 10.5/16rem;
}
.header /deep/ .van-button {
  width: 93%;
  font-family: PingFangSC-Semibold;
  // font-size: 18/16rem;
  font-weight: 700;
  border-radius: 10/16rem;
  color: #128feb;
}
.nav {
  background: #35abfe;
  margin: 0 15/16rem;
  border-radius: 13/16rem;
  text-align: left;
}
.nav /deep/ .navTitle {
  font-size: 18/16rem;
  font-weight: 700;
  background: #66d2fb;
  color: #fff;
  padding: 12/16rem 13/16rem;
  border-radius: 10/16rem 10/16rem 0 0;
}
.circle {
  width: 10/16rem;
  height: 10/16rem;
  border-radius: 15/16rem;
  margin: 5/16rem;
  margin-top: 10/16rem;
  background: #fff;
}
.circles {
  background: rgba(255, 255, 255, 0.42);
}
.gaine {
  background: linear-gradient(to bottom, #2dbdf7, #35abfe);
  text-align: left;
}
.gaine /deep/ .gaineLine {
  border-bottom: 1/16rem #45bfff solid;
  padding: 5/16rem 0;
}
.gaine /deep/ span {
  // font-family: PingFangSC-Semibold;
  // font-size: 22/16rem;
  color: #ffffff;
  margin: 0 15/16rem;
}
.content_list {
  position: relative;
  padding: 0 13/16rem;
}
.echart {
  margin: 10/16rem 15/16rem;
  background: rgb(255, 255, 255);
  box-shadow: rgba(155, 155, 155, 0.5) 2/16rem 2/16rem 8/16rem -2/16rem;
  position: relative;
  height: 360/16rem;
  border-radius: 6/16rem;
}
.newclass {
  height: 360/16rem;
  background: url(../../assets/imgs/noData.png);
  background-size: 200/16rem 200/16rem;
  background-repeat: no-repeat;
  background-position: 50% 50%;
}
.newclass /deep/ span {
  font-size: 17/16rem;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 10/16rem;
  left: 15/16rem;
}
.gaine .gaineLine .text-style,
.gaine .gaineLine .unitStyle {
  font-size: 12/16rem;
  color: #b5dcf6;
}
.gaine .gaineLine .unitStyle {
  margin-left: 1/16rem;
}
.projectNum,
.dataStyle {
  font-family: Bahnschrift SemiBold;
}
.projectNum {
  font-size: 22/16rem;
}
.dataStyle {
  font-size: 18/16rem;
}
.leftLine {
  border-left: 1/16rem #45bfff solid;
  height: 45px;
}
.leftCell {
  height: 45px; 
}
.vanDialog {
  padding-top: 30/16rem;
  border-radius: 6/16rem;
}
.dialogStyle {
  width: 82%;
  display: inline-block;
  padding-bottom: 15/16rem;
}
.lastLine {
  margin-bottom: 30/16rem;
}
.van-popup {
  text-align: left;
  height: 100%;
  /deep/ .cant {
  margin: 20/16rem 20/16rem;
  }
}
</style>

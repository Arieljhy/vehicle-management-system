<template>
  <!-- 筛选 -->
  <div>
    <div class="cant">
      <van-row>
        <van-col :span="19">项目区域</van-col>
        <!-- <van-col :span="5"  style="text-align:right"><van-icon name="location-o" /> 定位</van-col> -->
      </van-row>
      <van-row class="city">
        <van-col :span="24">
          <van-dropdown-menu :overlay="false">
            <van-dropdown-item
              :overlay="false"
              active-color="red"
              v-model="provinceies"
              :options="provinces"
            />
          </van-dropdown-menu>
        </van-col>
        <van-col :span="24">
          <van-dropdown-menu :overlay="false">
            <van-dropdown-item
              :overlay="false"
              active-color="red"
              v-model="citys"
              :options="cityList"
              @change="handleCityChange"
            />
          </van-dropdown-menu>
        </van-col>
        <van-col :span="24">
          <van-dropdown-menu :overlay="false">
            <van-dropdown-item
              :overlay="false"
              active-color="red"
              v-model="districts"
              :options="districtList"
            />
          </van-dropdown-menu>
        </van-col>
      </van-row>
      <van-col span="24" v-if="$route.path!='/superviseTrade'" class="filter_title">平米平均造价</van-col>
      <van-col span="24" v-if="$route.path!='/superviseTrade'">
        <van-col span="11">
          <van-field v-model="lowestPrice" type="number" class="frame" placeholder="最低价" clearable />
        </van-col>
        <van-col class="line" span="2">至</van-col>
        <van-col span="11">
          <van-field
            v-model="highestPrice"
            type="number"
            class="frame"
            placeholder="最高价"
            clearable
          />
        </van-col>
      </van-col>
      <van-col span="24" class="filter_title">签单日期</van-col>
      <van-col span="24">
        <van-col span="11">
          <van-cell-group>
            <van-field
              v-model="startTime"
              placeholder="年/月/日"
              class="frame"
              clearable
              @focus="rectificationTime('startTime')"
            />
          </van-cell-group>
        </van-col>
        <van-dialog v-model="startTimeShow" title="选择时间" show-cancel-button @confirm="startDate">
          <van-datetime-picker
            v-model="startTimeDate"
            type="date"
            :max-date="maxDate"
            @change="getValues(startTimeDate)"
            :formatter="formatter"
            :show-toolbar="false"
          />
        </van-dialog>
        <van-col class="line" span="2">至</van-col>
        <van-col span="11">
          <van-cell-group>
            <van-field
              v-model="endTime"
              placeholder="年/月/日"
              class="frame"
              clearable
              @focus="rectificationTime('endTime')"
            />
          </van-cell-group>
        </van-col>
        <van-dialog v-model="endTimeShow" title="选择时间" show-cancel-button @confirm="endDate">
          <van-datetime-picker
            v-model="currentDate"
            type="date"
            :min-date="startTimeDate"
            :max-date="maxDate"
            @change="getValues(currentDate)"
            :formatter="formatter"
            :show-toolbar="false"
          />
        </van-dialog>
      </van-col>
      <van-col v-if="userType != 'TIS'&&$route.path!='/superviseTrade'" span="24" class="filter_title">是否主承</van-col>
      <van-col v-if="userType != 'TIS'&&$route.path!='/superviseTrade'" span="24">
        <van-field prop="isMainInsValue" label="非主承：" label-width="70px" class="field_label">
          <template #input>
            <van-checkbox v-model="isMainIns" shape="square" style="width:30px" />
          </template>
        </van-field>
      </van-col>
      <van-col span="24" class="filter_title">住宅性质</van-col>
      <van-col span="24">
        <div
          class="inline-block area mouse-pointer"
          @click="setResidential(item, index)"
          :class="{'checked': item.check}"
          v-for="(item,index) of residentialList"
          :key="item.code"
        >{{item.name}}</div>
      </van-col>
      <!-- 筛选条件展示 -->
      <div v-if="userType === 'INS' || userType == 'BLD'">
        <van-col span="24" class="filter_title">项目进度</van-col>
        <van-col span="24">
          <div
            class="inline-block area mouse-pointer"
            @click="setProject(item, index)"
            :class="{'checked': item.check}"
            v-for="(item, index) of projectList"
            :key="item.code"
          >{{item.name}}</div>
        </van-col>
      </div>
       <van-col span="24" class="filter_title">是否含有旧保单</van-col>
       <van-col span="24" class="filter_title filter_title1">
          <!-- <van-radio-group v-model="checkBoxResult">
            <van-radio  shape="square"  @click="a">含旧保单</van-radio>
          </van-radio-group> -->
          <van-field prop="checkBoxResult" label="含旧保单：" label-width="80px" class="field_label">
          <template #input>
            <van-checkbox v-model="checkBoxResult" shape="square" style="width:30px" />
          </template>
        </van-field>
        </van-col>
      <div v-if="userType !== 'INS'">
        <van-col span="16" class="filter_title">承保公司</van-col>
        <van-col span="24">
          <div
            class="inline-block area mouse-pointer"
            @click="setCompany(item, index)"
            :class="{'checked': item.check}"
            v-for="(item, index) of underwritingCompany"
            :key="item.code"
          >{{item.name}}</div>
        </van-col>
      </div>
    </div>
    <div class="footer">
      <van-button class="reset-button" @click="reset">重置</van-button>
      <van-button class="confirm-button" @click="filterMytodo()">确定</van-button>
    </div>
  </div>
</template>
<script>
import { mapActions, mapGetters } from "vuex";
import http from "@/common/request";
export default {
  name: "superviseSelect",
  data() {
    return {
      isMainIns: false,
      isMainInsValue: "",
      // 平米造价
      lowestPrice: "",
      highestPrice: "",
      // 选择地址
      provinceies: this.$getMobileData.province,
      citys: this.$getMobileData.city,
      districts: "",
      // 签单时间
      startTime: "",
      startTimeDate: new Date(),
      startTimeShow: false,
      endTime: "",
      endMinDate: new Date(),
      endTimeShow: false,
      // 最大时间限制
      maxDate: new Date(),
      currentDate: new Date(),
      // 住宅性质-展示列表
      residentialList: [],
      // 住宅性质-选中
      residential: [],
      // 项目进度
      projectList: [
        // { name: "项目理赔终止", check: false },
        { name: "施工许可证待审核", check: false },
        { name: "项目施工中", check: false },
        { name: "项目已竣工", check: false },
        { name: "项目理赔中", check: false }
      ],
      // 项目进度-选中
      project: [],
      // 承保公司
      underwritingCompany: [],
      // 项目进度-选中
      company: [],
      // 是否含有老保单
      checkBoxResult:false,
      cityList: [],
      districtList: [],
      offset: 1
    };
  },
  computed: {
    ...mapGetters([
      "provinceList",
      "limit",
      "province",
      "city",
      "district",
      "minCostPerMeter",
      "maxCostPerMeter",
      "beginSignDate",
      "endSignDate",
      "buildingType",
      "projectStatus",
      "orgIds",
      "isChecked",
      "userType",
    ]),
    // 设置省市县
    provinces() {
      this.handleProvinceChange();
      this.handleCityChange();
      return this.provinceList.map(item => {
        item.text = item.province;
        item.value = item.province;
        return item;
      });
    }
  },
  created() {
    this.getHouseType();
    this.getCompanyList();
    this.getUserType();
  },
  methods: {
    ...mapActions([
      "getSuperviseList",
      "setFilterData",
      "clearSuperviseList",
      "setFinished",
      "setPopup",
      "getUserType"
    ]),
    // 设置省市县
    handleProvinceChange() {
      const { city } = this.provinceList.filter(
        item => item.province === this.province
      )[0] || { city: [] };
      const first = city.shift() || { text: "" };
      city.unshift(first);
      // first.text !== "请选择" &&
      //   city.unshift({ text: "请选择", name: "", area: [] });
      first.text !== "" && city.unshift({ text: "", name: "", area: [] });
      this.cityList = city.map(item => {
        item.text = item.text ? item.text : item.name;
        item.value = item.value ? item.value : item.name;
        return item;
      });
    },
    handleCityChange(val) {
      const { area } = this.cityList.filter(
        item => item.name === (val == undefined ? this.city : val)
      )[0] || {
        area: []
      };
      const first = area.shift() || { text: "" };
      area.unshift(first);
      // first.text !== "请选择" && area.unshift({ text: "请选择", value: "" });
      first.text !== "" && area.unshift({ text: "", value: "" });
      this.districtList = area.map(item => {
        item.text = item.text ? item.text : item.district;
        item.value = item.value ? item.value : item.district;
        return item;
      });
    },
    rectificationTime(val) {
      if (val == "startTime") {
        this.startTimeShow = true;
      } else if (val == "endTime") {
        this.endTimeShow = true;
      }
    },
    startDate() {
      this.startTime = this.formatDate(this.startTimeDate);
    },
    endDate() {
      this.endTime = this.formatDate(this.currentDate);
    },
    //改变时间，输出选中事件
    getValues(data) {
      console.log(this.formatDate(data));
    },
    //转化时间格式
    formatDate(now) {
      var year = now.getFullYear();
      var month = now.getMonth() + 1;
      var date = now.getDate();
      return year + "-" + month + "-" + date;
    },
    //过滤面板时间
    formatter(type, value) {
      if (type === "year") {
        return `${value}年`;
      } else if (type === "month") {
        return `${value}月`;
      } else if (type === "day") {
        return `${value}日`;
      }
      return value;
    },
    reset() {
      // 平米造价
      this.lowestPrice = "";
      this.highestPrice = "";
      // 选择地址
      this.provinceies = this.$getMobileData.province;
      this.citys = this.$getMobileData.city;
      this.districts = "";
      // 签单时间
      this.startTime = "";
      this.endTime = "";
      //是否主承
      this.isMainIns = false;
      this.isMainInsValue = "";
      // 住宅性质-选中
      this.residential = [];
      // 项目进度
      this.projectList = [
        // { name: '项目理赔终止', check: false },
        { name: "施工许可证待审核", check: false },
        { name: "项目施工中", check: false },
        { name: "项目已竣工", check: false },
        { name: "项目理赔中", check: false }
      ];
      // 项目进度-选中
      this.project = [];
      // 项目进度-选中
      this.company = [];
      // 是否含有老保单
      this.checkBoxResult = false;
      this.getHouseType();
      this.getCompanyList();
    },
    filterMytodo() {
      const _this = this;
      // 将选中的数组进行转换成字符串
      let residentials = this.residential.toString();
      let projects = this.project.toString();
      let companysList = [];
      _this.underwritingCompany.map(id => {
        _this.company.map(_text => {
          if (id.orgName === _text) {
            companysList.push(id.orgId);
          }
        });
      });
      let companys = companysList.toString();
      // this.isMainInsValue="";
      if (this.isMainIns == false) {
        this.isMainInsValue = "Y";
      } else {
        this.isMainInsValue = "N";
      }
      let keyObj = {};
      if(this.$route.path!='/superviseTrade'){
        keyObj = {
          limit: 5,
          offset: this.offset,
          province: this.provinceies,
          city: this.citys,
          district: this.districts,
          minCostPerMeter: this.lowestPrice,
          maxCostPerMeter: this.highestPrice,
          beginSignDate: this.startTime,
          endSignDate: this.endTime,
          // 住宅性质
          buildingType: residentials,
          // 项目进度
          projectStatus: projects,
          // 承保公司
          orgIds: companys,
          // 是否含有老保单
          isChecked: this.checkBoxResult,
          sort: "sign_date",
          older: "desc",
          // contractNotNull: "",
          //是否主承
          isMainIns: this.isMainInsValue
        }
      }else{
        keyObj = {
          province: this.provinceies,
          city: this.citys,
          district: this.districts,
          beginSignDate: this.startTime,
          endSignDate: this.endTime,
          // 住宅性质
          buildingType: residentials,
          // 项目进度
          projectStatus: projects,
          // 承保公司
          orgIds: companys,
          // 是否含有老保单
          isChecked: this.checkBoxResult,      
        }
      }
      this.$emit("filterData", keyObj);

      // 清空加载数据
      // this.clearSuperviseList()
      // 将分页还原成0
      // this.offset = 0
      // this.setFinished(false)
      // this.setPopup(false)
    },
    // 获取住宅性质
    getHouseType() {
      this.residentialList = JSON.parse(
        localStorage.getItem(this.$getMobileData.baseSelects)
      ).IDI_PROJECT_TYPES;
      this.residentialList.map(_data => {
        _data.name = _data.dictValue;
        this.$set(_data, "check", false);
      });
    },
    // 承保公司
    getCompanyList() {
      const _this = this;
      const keywords = { orgLevel: "二级", orgType: "INS" };
      http.get("/sysconfig/Org/likelist", keywords).then(res => {
        if (res.code === 0) {
          _this.underwritingCompany = res.data.rows;
          _this.underwritingCompany.map(_data => {
            _data.name = _data.orgName;
            this.$set(_data, "check", false);
          });
        }
      });
    },
    // 选中住宅地址
    setResidential(item, index) {
      item.check = !item.check;
      if (item.check == true) {
        this.residential.push(item.name);
      } else if (item.check == false) {
        let inx = this.residential.findIndex(_name => {
          return _name == item.dictValue;
        });
        this.residential.splice(inx, 1);
      }
    },
    // 选中的项目进度
    setProject(item, index) {
      item.check = !item.check;
      if (item.check == true) {
        this.project.push(item.name);
      } else if (item.check == false) {
        let inx = this.project.findIndex(_name => {
          return _name == item.name;
        });
        this.project.splice(inx, 1);
      }
    },
    // 选中的承保公司
    setCompany(item, index) {
      item.check = !item.check;
      if (item.check == true) {
        this.company.push(item.name);
      } else if (item.check == false) {
        let inx = this.company.findIndex(_name => {
          return _name == item.name;
        });
        this.company.splice(inx, 1);
      }
    }
  }
};
</script>
<style scoped lang="less">
.informationBtn {
  position: fixed;
  z-index: 40;
  width: 100%;
  max-width: 640/16rem;
  background: #128feb;
  bottom: 0;
}
.detail {
  position: relative;
  background: #fff;
  text-align: left;
}
.detail /deep/ .details {
  color: #128feb;
  padding: 15/16rem 15/16rem;
  border-bottom: 1/16rem #ccc solid;
}
.detail /deep/ .details /deep/ .attent {
  border: 2/16rem #128feb solid;
  border-radius: 15/16rem;
  padding: 5/16rem 10/16rem;
  color: #128feb;
}
.detail /deep/ .subhead {
  margin: 15/16rem 0;
  line-height: 28/16rem;
}

.van-popup {
  text-align: left;
  height: 100%;
}
.van-popup /deep/ .cant {
  margin: 20/16rem 20/16rem;
}
::after {
  // 清除浮动,自动获取高度
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.city {
  margin: 20/16rem 0;
}
.van-dropdown-menu /deep/ .van-dropdown-menu__item {
  background: #f2f3f5;
  height: 34/16rem;
}
// 下拉框
.van-dropdown-menu /deep/ .van-dropdown-menu__title::after {
  position: absolute;
  top: 50%;
  right: -90/16rem;
  // margin-top: px;
}
.filter_title {
  font-weight: 600;
  padding-top: 8/16rem;
  padding-bottom: 8/16rem;
  font-size: 15/16rem;
}
.filter_title1 {
  font-weight: normal;
  padding-top: 8/16rem;
  padding-bottom: 8/16rem;
  font-size: 15/16rem;
}
.frame {
  padding-top: 5/16rem;
  padding-bottom: 5/16rem;
  height: 40/16rem;
  line-height: 40/16rem;
  background: #f2f3f5;
  border-radius: 4/16rem;
  margin-bottom: 10/16rem;
}
.line {
  text-align: center;
  margin-top: 10/16rem;
}
.inline-block {
  display: inline-block;
}
.area {
  color: #3e3a39;
  background: #f2f3f5;
  padding: 2/16rem 6/16rem;
  margin: 0 12.5/16rem 8.5/16rem 0;
  border-radius: 5/16rem;
}

.checked {
  background-color: #297ae3;
  color: #fff !important;
  border-radius: 5/16rem;
}
.footer {
  // 按钮固定在下,暂时取消
  // position: sticky;
  bottom: 0;
  // height: 40/16rem;
  width: 100%;
}
.footer /deep/ .van-button {
  color: #fff;
  border: 0;
}
/deep/ .van-dropdown-item__content {
  width: 90%;
  margin-left: 5%;
  border: 1/16rem solid #f6f6f6;
  box-shadow: 0/16rem 3/16rem 10/16rem #888888;
}
.reset-button {
  width: 50%;
  background: #dddddd;
  color: #595959;
  // position: relative;
  // bottom: 0;
}
.confirm-button {
  width: 50%;
  background: #f5a623;
  // position: relative;
  // bottom: 0;
}
.field_label {
  font-size: 16/16rem;
  color: #3e3a39;
  padding-left: 6/16rem;
  padding-top: 5/16rem;
}
</style>

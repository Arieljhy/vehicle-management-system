<template>
  <div>
    治安搜索-筛选
  </div>
</template>

<script>
export default {
  name: "superviseScreen",
  data() {
    return {
    }
  }
};
</script>
<style scoped lang="less">

</style>

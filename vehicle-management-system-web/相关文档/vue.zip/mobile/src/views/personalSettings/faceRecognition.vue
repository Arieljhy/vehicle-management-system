<template>
  <div class="content">
     <!-- <van-nav-bar class="mc-navbar" title="人脸登陆" left-arrow @click-left="onClickLeft" /> -->
    <van-nav-bar
      title="面部识别"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    />
    <video id="video" width="350" height="400" preload autoplay loop muted></video>
    <div class="canvas_div">
    <canvas id="canvas" width="350" height="400"></canvas>
      <div
        style="color: #cdcccc;position: absolute;text-align: center;width: 100%;font-size:16px;top: 73px;"
      >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
    </div>
    <!-- <div>{{num}}</div> -->
  </div>
</template>
<script>
import "@/assets/js/tracking.js";
import "@/assets/js/face-min.js";
import "@/assets/js/mouth-min.js";
import http from "@/common/request";
import $ from "jquery";
export default {
  name: "FaceRecognition",

  data() {
    return {
      num: 0,
      bdTocken: "",
      txHeader: "",
      video:"",
      trackerTask: null,
    };
  },
  mounted() {
    // this.getTocken();
    this.openCamera();
  },
  methods: {
    getTocken() {
      //百度获取tocken
      http.get("/common/config/bdFaceToken").then(res => {
        this.bdTocken = res.bdFaceApiToken;
        this.openCamera();
      });
      //腾讯获取tocken
      // http.get("/common/config/txFaceApiHeader").then(res => {
      //   this.txHeader = res.txFaceApiHeader;
      //   this.openCamera();
      //   console.log(res);
      // });
    },
    //打开相机
    openCamera() {
      let that = this;
      this.video = document.getElementById("video");
      var canvas = document.getElementById("canvas");
      var context = canvas.getContext("2d");
      var tracker = new tracking.ObjectTracker("face");
      tracker.setInitialScale(4);
      tracker.setStepSize(2);
      tracker.setEdgesDensity(0.1);
      this.trackerTask = tracking.track("#video", tracker, { camera: true });
      var flag = true;
      tracker.on("track", function(event) {
        context.clearRect(0, 0, canvas.width, canvas.height);
        // event.data.forEach(function(rect) {
        //   context.strokeStyle = "#a64ceb";
        //   context.strokeRect(rect.x, rect.y, rect.width, rect.height);
        //   context.font = "11px Helvetica";
        //   context.fillStyle = "#fff";
        //   context.fillText(
        //     "x: " + rect.x + "px",
        //     rect.x + rect.width + 5,
        //     rect.y + 11
        //   );
        //   context.fillText(
        //     "y: " + rect.y + "px",
        //     rect.x + rect.width + 5,
        //     rect.y + 22
        //   );
        // });
        if (flag) {
          that.getPhoto();
          flag = false;
          setTimeout(function() {
            flag = true;
          }, 3000);
        }
      });
    },
    //截取图片
    saveAsPNG(canvas) {
      return canvas
        .toDataURL("image/png")
        .replace("data:image/png;base64,", "");
    },
    //拍照
    getPhoto() {
      const c = document.getElementById("canvas");
      const cxt = c.getContext("2d");
      cxt.drawImage(this.video, 0, 0,canvas.width, canvas.height);
      // this.num += 1;
      // this.getbdFace(c);
      this.gettxFace(c);
    },
    //百度采集人脸照片，如果没有采集过（bdFaceId为空），用（add）,如果更新，用（update）
    getbdFace(c) {
      console.log(this.saveAsPNG(c));
      const keywords = {
        image: this.saveAsPNG(c),
        user_id: JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .userId,
        group_id: 'eidi',
        // group_id: "yangquan",
        image_type: "BASE64"
      };
      let that = this;
      const bdFaceId = JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
        .bdFaceId;
      const newUrl =
        "https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/add?access_token=" +
        this.bdTocken;
      const updateUrl =
        "https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/update?access_token=" +
        this.bdTocken;
      $.ajax({
        url: bdFaceId ? updateUrl : newUrl,
        type: "post",
        dataType: "json",
        data: keywords,
        contentType: "application/json;charset=utf-8",
        success: function(res) {
          // console.log(res);
          if (res.result) {
            that.$router.go(-1);
          }
        }
      });
    },
    //腾讯采集人脸
    gettxFace(c) {
      let keywords = {
        PersonId:JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
          .userId,
        Images: [this.saveAsPNG(c)]
      };
      // const txFaceId = JSON.parse(localStorage.getItem(this.$getMobileData.userInfo))
      //   .txFaceId;
      http.post("/common/tencentApi/registeredFace", keywords).then(res => {
        if (res.code == 0) {
          http
            .post("/sys/user/AddUserFaceId", {
              txFaceId: res.data.CreatePersonFaceId
            })
            .then(res => {
              this.$toast("设置成功！");
              const that = this;
              setTimeout(function() {
                that.$router.go(-1);
              }, 1000);
              // this.$router.go(-1);
            });
        }
      });
    },
    onClickLeft() {
      this.$router.go(-1);
    }
  },
  destroyed() {
      // 停止侦测
    this.trackerTask.stop();
    // 关闭摄像头
    window.stream.getTracks().forEach((track) => track.stop());
  }
};
</script>
<style lang="less" scoped>
@font_title: PingFangSC-Medium;
.content {
  // background-image: url("../../assets/imgs/bjlogin.jpg");
  padding: 0;
  background-size: cover;
  background-repeat: no-repeat;
  background-attachment: fixed;
  height: 100vh;
}
video {
  position: absolute;
  width: 100%;
  left: 0;
  height: 500px;
}
canvas {
  position: absolute;
  width: 100%;
  left: 0;
  top: -55px;
  height: 500px;
  display: none;
}
.canvas_div {
  left: 0;
  right: 0;
  top: 145px;
  position: absolute;
  height: 300px;
  width: 300px;
  margin: auto;
  border-radius: 50%;
  box-shadow: rgba(0, 0, 0, 1) 0px 0px 0px 500px;
  border: 2px solid gray;
}
.mc-navbar {
  z-index: 999;
}
.model-content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 350px;
}
.btn {
  width: 100px;
  margin: 15px 20px;
}
.wrapper {
  height: 60%;
}
.body-content {
  background: #fff;
  border: 1px solid #f2f2f2;
  border-radius: 5px;
}
.word-text {
  height: 300px;
  overflow: scroll;
  padding: 15px;
}
.padding-top {
  padding-top: 10px;
}
.word-text div {
  font-family: @font_title;
  text-align: left;
  font-size: 14px;
  text-indent: 20px;
}
.title {
  font-size: 14px;
  color: black;
  font-weight: bold;
  text-align: center !important;
  text-indent: 0px !important;
}
</style>
<template>
  <div class="gesture-password-setting">
    <van-nav-bar
      title="手势密码"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    />
    <gesture :topHeight="46" />
  </div>
</template>
<script>
import Gesture from "@/components/gesture";
export default {
  name: "GesturePassword",
  components: {
    Gesture
  },
  data() {
    return {};
  },
  created() {
    if (typeof androidApp !== "undefined") {
      androidApp.setRefresh(false); //手机消息推送配置
    }
  },
  methods: {
    onClickLeft() {
      if (typeof androidApp !== "undefined") {
        androidApp.setRefresh(true); //手机消息推送配置
      }
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="scss" scoped>
.gesture-password-setting{
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
}
</style>
<template>
  <div id="container" v-cloak>
    <van-row class="header">
      <van-col span="24">
        <van-col span="3" class="logo">
          <img :src="Logo" />
        </van-col>
      </van-col>
    </van-row>
    <div class="main">
      <van-row class="item">
        <van-col span="3">
          <span class="title">主题</span>
        </van-col>
        <van-col class="themeStyle" span="21">
          <span>{{informationDetails.topic}}</span>
        </van-col>
      </van-row>
      <van-row class="item">
        <van-col span="3">
          <span class="title">正文</span>
        </van-col>
        <van-col span="21">
          <span>
            <div class="contentStyle" id="content"></div>
          </span>
        </van-col>
      </van-row>
      <van-row>
        <van-button @click="close()">关闭</van-button>
      </van-row>
    </div>
  </div>
</template>

<script>
import Logo from "@/assets/imgs/logo-2.png";
import http from "@/common/request";
export default {
  name: "InformationDetail",
  data() {
    return {
      Logo,
      informationDetails: {}
    };
  },
  created() {
    this.getInfo();
  },
  methods: {
    getInfo() {
      const _this = this;
      // const id = this.$route.query.item.id;
      // const getInfoUrl = "/api/send/getUserMessageById/" + this.$route.query.id;
      http.get("/send/getUserMessageById/",{id:this.$route.query.id}).then(res => {
        _this.informationDetails = res.data;
        document.getElementById("content").innerHTML = res.data.message;
      });
    },
    close() {
      this.$router.go(-1);
    }
  }
};
</script>

<style lang="less" scoped>
[v-cloak]{
  display: none;
}
#container {
  font-family: Microsoft Yahei;
  font-size: 16/16rem;
  .header {
    background: #e3ebf5;
    width: 100%;
    .logo {
      img {
        width: 50/16rem;
        height: 100%;
      }
    }
  }
  .main {
    padding: 10/16rem;
    text-align: left;
    position: relative;
    .item {
      padding: 10/16rem 0;
      .themeStyle,
      .contentStyle {
        border: 1/16rem #dad6d6 solid;
        border-radius: 4/16rem;
        background: rgba(181, 186, 196, 0.5);
        color: #3e3a39;
        padding: 5/16rem 10/16rem;
        font-size: 14/16rem;
      }
      .themeStyle {
        border: 1/16rem #c3c7cf solid;
      }
      .contentStyle {
        padding-bottom: 30/16rem;
        line-height: 1.6;
      }
      .title {
        font-size: 16/16rem;
        color: #408ce7;
      }
    }
    .van-button {
      position: absolute;
      bottom: -50/16rem;
      right: 20/16rem;
      color: #727483;
      border-radius: 10/16rem;
    }
  }
}
</style>

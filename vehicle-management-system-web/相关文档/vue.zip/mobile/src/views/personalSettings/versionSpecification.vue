<template>
  <div>
    <van-nav-bar
      title="版本说明"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    />
    <div class="cont-wrap">
      <p>{{$getMobileData.orgList}}</p>
      <p>平台协助政府主管部门进行IDI保险住宅项目的保险审核和施工许可证审批工作，为保险公司、风险管理机构（TIS）和建设单位提供全流程的风险管理功能。</p>
      <p>住宅交付使用后，广大业主可通过平台进行在线报案、了解理赔进展，以及和政府、保险公司沟通社情民意。</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "versionSpecification",

  data() {
    return {};
  },
  methods: {
    onClickLeft() {
      if (this.$route.query.title==0) {
        this.$router.replace({
          path: `/aboutApp`,
          query: {
            title: 1
          }
        });
      } else {
        this.$router.go(-1);
      }
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.cont-wrap {
  padding: 1rem;
  p {
    line-height: 1.8;
    font-size: 14/16rem;
    text-align: justify;
    margin-bottom: 10/16rem;
    text-indent: 30/16rem;
    margin-top: 4/16rem;
  }
}
</style>
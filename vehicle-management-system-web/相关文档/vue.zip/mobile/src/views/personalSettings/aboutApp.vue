<template>
  <div>
    <van-nav-bar title="关于" left-text="返回" left-arrow @click-left="onClickLeft" class="mc-navbar" />
    <div class="about-logo">
      <div class="about-logo-wrap">
        <img src="@/assets/imgs/logo-2.png" alt />
      </div>
    </div>
    <van-cell title="版本说明" @click="goVersion" is-link />
    <van-cell title="版权信息" @click="goCopyright" is-link />
    <van-cell title="隐私政策" @click="privacyPoilcy" is-link />
    <van-cell title="检查新版本" @click="newVersion" is-link />
    <van-button type="info" class="clearCache" round @click="cacheClear">清除应用缓存</van-button>
    <!-- 提示是否更新新版本 -->
    <van-dialog v-model="activationDialog" title="提示" required show-cancel-button>
      <!--dialog里的属性 :beforeClose="onBldingsConfirm" -->
      <span>{{activationMsg}}</span>
    </van-dialog>
    <!--马鞍山 -->
    <van-popup v-model="show" class="model-content" :close-on-click-overlay="false">
      <div class="wrapper">
        <div class="body-content">
          <!-- 文字部分 -->
          <div class="word-text">
            <div style="height:300px;overflow:auto">
              <div class="title">{{$getMobileData.modelContent}}IDI信息平台隐私保护提示</div>
              <div style="text-indent: 0px;" class="padding-top">尊敬的用户：</div>
              <div
                class="padding-top"
              >您好，感谢您的信任与使用！{{$getMobileData.modelContent}}IDI信息平台非常重视用户的隐私保护和个人信息保护。</div>
              <div
                class="padding-top"
              >我们依据最新的法律法规要求，更新了《{{$getMobileData.modelContent}}IDI信息平台隐私政策》。其中涉及与您权利义务相关的特别规定等重要条款，请您重点仔细阅读。</div>
              <div
                class="padding-top"
              >在您使用{{$getMobileData.modelContent}}IDI信息平台及服务前，请您务必仔细阅读并透彻理解该协议及政策，您同意并接受全部条款后可开始使用我们的服务。</div>
              <div class="padding-top">
                您可以点击下述链接阅读完整的
                <em
                  style="color: #2277ff;font-style: normal;"
                  @click.stop="privacyDeils(0)"
                >《{{$getMobileData.modelContent}}IDI信息平台隐私政策》</em>了解具体内容，如您对协议内容有任何疑问、意见或建议，您可通过客服与我们联系。
              </div>
              <div
                class="padding-top"
                style="font-weight:bold"
              >特别提示，当您点击“同意”即表示您已充分阅读、理解并接受《{{$getMobileData.modelContent}}IDI信息平台隐私政策》的全部内容，如您不同意其中的任何条款，您应立即停止使用{{$getMobileData.modelContent}}IDI信息平台及服务。</div>
            </div>
          </div>
          <div style="border-top:1px solid #f2f2f2">
            <van-button plain type="info" class="btn" @click.stop="privacyDeils(1)">同意</van-button>
            <van-button type="default" class="btn" @click.stop="privacyDeils()">取消</van-button>
          </div>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script>
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
import { Toast } from "vant";
export default {
  name: "AboutApp",

  data() {
    return {
      userInfoList: {},
      activationDialog: false,
      activationMsg: "",
      show: false
    };
  },
  created() {
    if (typeof androidApp !== "undefined") {
      androidApp.setRefresh(false); //手机消息推送配置
    }
    this.userInfoList = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    );
    if (this.$route.query.title == 0) {
      this.show = true;
    }
  },
  methods: {
    ...mapActions(["clearArr"]),
    onClickLeft() {
      if (this.$route.query.title == 0) {
        this.$router.go(-2);
      } else if (this.$route.query.title == 1) {
        this.$router.go(-3);
      } else {
        this.$router.go(-1);
      }
    },
    //清除应用缓存
    cacheClear() {
      if (typeof androidApp !== "undefined") androidApp.clearCache(true);
      Toast("应用缓存已清除成功！");
    },
    //退出登录
    logout() {
      const keywords = {
        userId: this.userInfoList.userId,
        tenantId: this.userInfoList.tenantId,
        logoutStatus:"0"
      };
      http.get("/logout", keywords).then(res => {
        if (res.code === 0) {
          localStorage.clear();
          this.clearArr();
          this.$toast("退出登录");
          this.$router.push("/login");
        }
      });
    },
    privacyDeils(flag) {
      if (flag == 0) {
        if (this.$getMobileData.lesseeId == "eidi-maanshan") {
          this.$router.push({
            path: "/masprivacyPoilcy",
            query: {
              flag: 1
            }
          });
        } else if (this.$getMobileData.lesseeId == "eidi-beijing") {
          this.$router.push({
            path: "/bjprivacyPoilcy",
            query: {
              flag: 1
            }
          });
        } else if (this.$getMobileData.lesseeId == "eidi-shanghai") {
          this.$router.push({
            path: "/shprivacyPoilcy",
            query: {
              flag: 1
            }
          });
        } else if (this.$getMobileData.lesseeId == "eidi-yangquan") {
          this.$router.push({
            path: "/yqprivacyPoilcy",
            query: {
              flag: 1
            }
          });
        }
      } else if (flag == 1) {
        http
          .post("/privateClause", {
            userId: this.userInfoList.userId,
            tenantId: this.userInfoList.tenantId,
            privateClause: "Y"
          })
          .then(res => {});
        if (typeof androidApp !== "undefined") {
          androidApp.setRefresh(true); //手机消息推送配置
        }
        this.show = false;
      } else {
        http
          .post("/privateClause", {
            userId: this.userInfoList.userId,
            tenantId: this.userInfoList.tenantId,
            privateClause: "N"
          })
          .then(res => {
            if (res.code == 0) {
              this.logout();
            }
          });
      }
    },
    //隐私政策
    privacyPoilcy() {
      if (typeof androidApp !== "undefined") {
        androidApp.setRefresh(false); //手机消息推送配置
        androidApp.clearCache(true);
      }
      this.show = true;
    },
    //跳转到版本说明
    goVersion() {
      this.$router.push({
        path: `/versionSpecification`,
        query: {
          title: this.$route.query.title
        }
      });
    },
    //跳转到版权信息
    goCopyright() {
      this.$router.push({
        path: `/copyrightInformation`,
        query: {
          title: this.$route.query.title
        }
      });
    },
    newVersion() {
      //  http.get("/sys/app/getUpdateApp/eidi-yangquan").then(res => { //阳泉
      http
        .get("/sys/app/getUpdateApp/" + this.$getMobileData.lesseeId)
        .then(res => {
          //马鞍山
          if (res.code === 0 || res.code === 500) {
            this.$toast(res.msg);
          } else if (res.code === 1) {
            this.activationMsg = res.msg;
            // this.activationDialog = true;
            // this.onBldingsConfirm()
            this.$toast(res.msg);
            if (typeof androidApp !== "undefined") {
              androidApp.download(res.data.appUrl, 1);
            }
          } else {
            this.$toast(res.msg);
          }
        });
    }
    // // 确定是否为最新版本
    // onBldingsConfirm(action, done) {
    //   if (action === "cancel") {
    //     done();
    //   } else if (action === "confirm") {
    //     done();
    //   }
    // }
  }
};
</script>
<style lang="less" scoped>
// 弹窗遮罩
.model-content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 350/16rem;
}
.btn {
  width: 100/16rem;
  margin: 15/16rem 20/16rem;
}
.wrapper {
  // display: flex;
  // align-items: center;
  // justify-content: center;
  height: 60%;
}
.body-content {
  background: #fff;
  border: 1px solid #f2f2f2;
  border-radius: 5px;
}
.word-text {
  height: 300/16rem;
  overflow: scroll;
  padding: 15/16rem;
}
.padding-top {
  padding-top: 10/16rem;
}
.word-text div {
  font-family: PingFangSC-Medium;
  text-align: left;
  font-size: 14px;
  text-indent: 20/16rem;
}
.title {
  font-size: 0.875rem;
  color: black;
  font-weight: bold;
  text-align: center !important;
}
.block {
  // border-radius: 5%;
  width: 80%;
  background-color: #fff;
  text-align: left;
  padding: 20/16rem;
}
.blockdiv {
  background-color: #fff;
  text-align: left;
  padding: 20/16rem;
}
.van-cell {
  text-align: left;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.about-logo {
  text-align: center;
  padding: 25/16rem 0 36/16rem;
  background-color: #f3f3f5;
  .about-logo-wrap {
    background-color: rgba(79, 187, 247, 0.6);
    width: 80/16rem;
    height: 80/16rem;
    line-height: 110/16rem;
    border-radius: 50%;
    border: 10/16rem solid #fff;
    margin: 0 auto;
    img {
      width: 100%;
    }
  }
}
.clearCache {
  width: 150/16rem;
  height: 40/16rem;
  line-height: 40/16rem;
  bottom: -30/16rem;
}
</style>
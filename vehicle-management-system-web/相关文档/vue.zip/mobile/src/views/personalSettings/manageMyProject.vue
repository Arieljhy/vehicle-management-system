<template>
  <div>
    <van-nav-bar
      title="管理我的项目"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    >
      <van-icon name="plus" slot="right" @click="isDialog" v-if="tis=='OWN' || tis=='WY'" />
    </van-nav-bar>
    <!-- 小区列表 -->
    <div>
      <van-panel
        :title="item.communityName"
        :desc="item.projectAddress"
        icon="location"
        v-for="(item, index) in projectList"
        :key="index"
      >
        <van-row class="concatImgDOS-margin">
          <van-col span="3"></van-col>
          <van-col span="21">
            <van-row type="flex">
              <van-col
                span="4.2"
                :gutter="12"
                v-for="(iteam, index) in item.concatImgDOS"
                :key="index"
              >
                <van-image
                  width="60px"
                  height="60px"
                  fit="contain"
                  :src="iteam.revealImageUrl"
                  class="revealImageUrl-border"
                  @click="img(iteam.revealImageUrl)"
                />
              </van-col>
            </van-row>
          </van-col>
        </van-row>
        <!-- 业主类型不能进行设置 -->
        <van-row type="flex" justify="end">
          <van-col span="3" v-if="userInfo.roleType=='INS'">
            <div class="iconfont icon-xaingji selectPic-style" @click="selectPic(item)"></div>
          </van-col>

          <van-col span="3" v-else></van-col>
          <van-col span="3">
            <div class="iconfont icon-delete deletes-style" @click="deletes(item.id)"></div>
          </van-col>
        </van-row>
      </van-panel>
    </div>
    <!-- 添加新的保单号 -->
    <van-dialog v-model="isShow" show-cancel-button :beforeClose="chargeBtn">
      <van-field v-model="value" clearable label="保单号" placeholder="请输入保单号" />
    </van-dialog>
    <!-- 选择照片,最多5张 -->
    <van-dialog
      v-model="isPicture"
      title="请选择图片"
      show-cancel-button
      :beforeClose="chargePic"
      class="select-images"
    >
      <van-row>
        <van-col span="8">
          <van-uploader :after-read="afterRead">
            <div class="iconfont icon-xaingji pictures-style">
              <div class="upload-pictures">上传图片</div>
            </div>
          </van-uploader>
        </van-col>
        <!-- 长按事件,用于触发删除功能 -->
        <div
          class="col-images"
          @click="selectPicture(item, index)"
          v-for="(item, index) in plotsListDialog"
          :key="index"
          @touchstart="touchin(item,index)"
          @touchend="cleartime(item,index)"
        >
          <van-image
            width="100px"
            height="100px"
            fit="contain"
            :src="item.revealImageUrl"
            :class="item.banner?'checkedPid':'false'"
          />
        </div>
      </van-row>
      <div class="mask" ref="mask"></div>
    </van-dialog>
    <!-- 弹窗删除图片功能 -->
    <van-dialog v-model="actionShow" show-cancel-button @click="deleteBtn">
      <!-- <van-field v-model="value" clearable label="保单号" placeholder="请输入保单号" /> -->
    </van-dialog>
  </div>
</template>
<script>
import http from "@/common/request";
import { ImagePreview } from "vant";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "ManageMyProject",

  data() {
    return {
      dealImgWidth: 600,
      isShow: false,
      isPicture: false,
      value: "",
      picVal: "",
      // 从缓存里取出来的user信息
      userInfo: {},
      projectList: [],
      // 外部图片列表
      plotsList: [],
      // 弹窗后的图片列表
      plotsListDialog: [],
      // 确认图片必传的projectId
      currProject: {},
      // 定时器
      loop: 0,
      // 控制删除弹窗
      actionShow: false,
      tis: undefined
    };
  },
  computed: {
    ...mapGetters(["selectedPrj"])
  },
  created() {
    // 获取账号类型
    this.userInfo = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    );
    this.getProjectList({ isPage: false });
    this.tis = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    ).roleType;
  },
  methods: {
    ...mapActions(["isDataList"]),
    isDialog() {
      this.isShow = true;
    },
    // 获取列表接口
    getProjectList(data) {
      const _this = this;
      const keywords = data;
      http.post("/community/listIns", keywords).then(res => {
        if (res.code === 0) {
          _this.projectList = res.data;
          // 缓存内的 selectPrj
          if (_this.projectList.length != 0) {
            _this.projectList.map(_id => {
              // 如果项目列表没有缓存,则新添加一个缓存数据
              if (!JSON.parse(localStorage.getItem("eidi.selected_project"))) {
                localStorage.setItem(
                  "eidi.selected_project",
                  JSON.stringify(_this.projectList[0])
                );
                // 如果项目列表与缓存的 projectId不一致,则表示不存在,需进行更新缓存
              } else if (
                _id.projectId !==
                  JSON.parse(localStorage.getItem("eidi.selected_project"))
                    .projectId &&
                this.tis != "OP" &&
                this.tis != "GOV"
              ) {
                localStorage.setItem(
                  "eidi.selected_project",
                  JSON.stringify(_this.projectList[0])
                );
              }
            });
          } else if (
            _this.projectList.length == 0 &&
            this.tis != "OP" &&
            this.tis != "GOV"
          ) {
            // 判断获取新的列表后是否还存在项目,如果不存在,就清空缓存
            localStorage.setItem("eidi.selected_project", null);
            _this.isDataList(false);
          }

          // 将返回来的地址拼接可以展示的地址
          if (_this.projectList.length != 0) {
            // 加上判断防止没有图片时报错
            _this.projectList.map(_imgList => {
              _imgList.concatImgDOS.map(_url => {
                _url.revealImageUrl =
                  "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                  _url.imageUri;
              });
            });
          }
        }
      });
    },
    // 添加保单号接口
    setProjects() {
      const _this = this;
      const keywords = {
        userid: _this.userInfo.userId,
        insContractNo: _this.value
      };
      // 判断输入框是否为空
      if (_this.value == "") {
        this.$toast("请输入要添加的保单号");
        return;
      }
      // 判断重复添加同一个保单号
      let isPresence = false;
      _this.projectList.map(_id => {
        if (_id.insContractNo == _this.value) {
          this.$toast("您已添加本项目,请勿反复添加!");
          return (isPresence = true);
        }
      });
      if (!isPresence) {
        http
          .post("/community/saveown", keywords)
          .then(res => {
            if (res.code == 0) {
              //向后端传值并关闭dialog弹出框
              _this.$toast("保单添加成功");
              _this.isShow = false;
              _this.getProjectList({ isPage: false });
            } else {
              // 判断保单在不在理赔阶段
              _this.$toast(res.msg);
            }
          })
          .catch(err => {
            _this.$toast("保单添加失败");
          });
      }
      // 将value设成空,防止下次再输入的时候保留
      _this.value = "";
    },
    // 删除项目接口
    setProjectsDelete(id) {
      const _this = this;
      http.delete("/community/delete/" + id).then(res => {
        if (res.code == 0) {
          _this.getProjectList({ isPage: false });
          //向后端传值并关闭dialog弹出框
          _this.isShow = false;
        } else {
          _this.$toast("删除失败");
        }
      });
    },
    onClickLeft() {
      this.$router.go(-1);
    },
    // 添加保单确认事件
    chargeBtn(action, done) {
      if (action === "cancel") {
        //取消按钮
        done();
      } else if (action === "confirm") {
        //确定按钮
        this.setProjects();
      }
      done();
    },
    //图片缩略
    img(item) {
      // ImagePreview([item]);
      ImagePreview({
        images: [item],
        closeable: true,
        closeOnPopstate: true
      });
    },
    // 选择图片
    chargePic(action, done) {
      if (action === "cancel") {
        //取消按钮
        done();
        this.getProjectList({ isPage: false });
      } else if (action === "confirm") {
        //确定按钮
        let selectImg = [];
        this.plotsListDialog.map(_picture => {
          if (_picture.banner) {
            selectImg.push(_picture);
          }
        });
        if (selectImg.length > 3) {
          this.$toast("最多可选择3张图片");
          done(false);
          return;
        }
        this.confirmImages(this.currProject.projectId, selectImg);
      }
      done();
    },
    // 确认后将选中的图片传给后端
    confirmImages(projectId, selectImg) {
      const _this = this;
      const keywords = selectImg;
      http
        .put("/project/concatImg/setBanner/" + projectId, keywords)
        .then(res => {
          if (res.code === 0) {
            this.$toast("修改成功");
            this.getProjectList({ isPage: false });
          } else {
            this.$toast("修改失败");
          }
        });
    },
    // 删除保单事件
    deletes(id) {
      this.$dialog
        .confirm({
          title: "确定删除?",
          message: ""
        })
        .then(() => {
          this.setProjectsDelete(id);
        })
        .catch(() => {});
    },
    // 更改选中图片的状态
    selectPicture(item, index) {
      item.banner = !item.banner;
    },
    // 调取图片列表
    selectPic(id) {
      const _this = this;
      const keywords = { projectId: id.projectId };
      http
        .get("/project/concatImg/concatImg/" + keywords.projectId)
        .then(res => {
          if (res.code === 0) {
            this.plotsListDialog = res.data;
            // 将返回来的地址拼接可以展示的地址
            if (this.plotsListDialog.length != 0) {
              // 加上判断防止没有图片时报错
              this.plotsListDialog.map(_url => {
                _url.revealImageUrl =
                  "/api/processDoc/downloadProcessDoc?cloudDocId=" +
                  _url.imageUri;
              });
            }
            // 将数据存储到currProject里,方便使用
            this.currProject = id;
            this.isPicture = true;
          }
        });
    },
    async afterRead(param) {
      param.status = "uploading";
      param.message = "上传中";
      this.$refs.mask.style.display = 'block';
      var toFile = param.file
      if(toFile.type.startsWith("image") && toFile.size > 1024*1024) {
        var _this = this
        var base64 = await this.$dealImage(
          URL.createObjectURL(toFile),
          _this.dealImgWidth // 设置压缩后的图片宽度
        )
        toFile = _this.$dataURLtoFile(base64, toFile.name)
      }
      // 此时可以自行将文件上传至服务器
      let file = new FormData();
      file.append("file", toFile);
      file.append("fileIcon", "banner");
      file.append("projectId", _this.currProject.projectId);
      http.post("/processDoc/uploadProcessDocTmp", file).then(res => {
        if (res.code === 0) {
          const keywords = {
            banner: false,
            imageName: res.data.fileName,
            imageUri: res.data.cloudDocIdTmp,
            projectId: _this.currProject.projectId
          };
          http.post("/project/concatImg/upload ", keywords).then(res => {
            if (res.code === 0) {
              _this.selectPic(_this.currProject);
              param.status = "done";
              this.$refs.mask.style.display = 'none';
            } else {
              param.status = "failed";
              param.message = "上传失败";
              this.$refs.mask.style.display = 'none';
            }
          });
        }
      });
    },
    // 长按事件
    touchin(item, index) {
      var _this = this;
      this.loop = setTimeout(() => {
        _this.loop = 0;
        //执行长按要执行的内容，如弹出菜单
        _this.deleteBtn(item, index);
        // MessageBox.confirm('是否确认删除').then(action => {
        //   _this.imgurl.splice(index, 1)
        // })
      }, 500);
      return false;
    },
    // 长按后离开屏幕事件
    cleartime(index) {
      var _this = this;
      clearTimeout(this.loop);
      if (_this.loop != 0) {
        //这里写要执行的内容（尤如onclick事件）
        // _this.previewPicture(index)
      }
      return false;
    },
    // 控制弹出删除控件
    deleteBtn(item, index) {
      const _this = this;
      this.$dialog
        .confirm({
          title: "确认删除"
        })
        .then(() => {
          // 调取删除接口
          if (item.id == 0) {
            this.$toast("该照片为风险事件图片,不可删除");
          } else {
            // 先将选中标记关掉,防止删除后,不能够选中3张
            item.banner = false;
            http.delete("/project/concatImg/delete/" + item.id).then(res => {
              if (res.code === 0) {
                // 接口调通后,删除该图片
                _this.plotsListDialog.splice(index, 1);
              }
            });
          }
          // on confirm
        })
        .catch(() => {
          // on cancel
        });
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
  .van-cell__title {
    padding-left: 10/16rem;
  }
}
.van-cell__left-icon {
  margin-top: 10/16rem;
  font-size: 20/16rem;
}
.van-cell:not(:last-child)::after {
  right: 16/16rem;
}
// 复选框样式
.checkedPid {
  border: 1/16rem solid #128feb;
}
// 滚动条
.select-images /deep/ .van-dialog__content {
  overflow: scroll;
  height: 400/16rem;
}
.col-images {
  width: 100/16rem;
  display: inline-block;
  margin: 0 2/16rem;
}
.upload-pictures {
  font-size: 15/16rem;
}
.pictures-style {
  font-size: 30/16rem;
  text-align: center;
  border: 1/16rem solid #c5c5c5;
  width: 78/16rem;
  height: 68/16rem;
  padding-top: 10/16rem;
}
.deletes-style {
  text-align: center;
  padding-top: 5/16rem;
}
.selectPic-style {
  text-align: center;
  padding-top: 5/16rem;
  font-size: 24/16rem;
}
.revealImageUrl-border {
  border: 1/16rem solid #fefefe;
}
.concatImgDOS-margin {
  margin-top: 10/16rem;
}
.mask {
  display: none;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.1);
  z-index: 100;
}
</style>
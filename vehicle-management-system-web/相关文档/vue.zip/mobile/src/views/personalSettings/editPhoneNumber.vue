<template>
  <div>
    <van-nav-bar
      title="修改手机号"
      right-text="确定"
      left-arrow
      @click-left="onClickLeft"
      @click-right="onClickRight"
      class="mc-navbar"
    />
    <van-field clearable class="iconfont icon-face" v-model="mobile" placeholder="请输入新手机号" />
    <van-field
      center
      clearable
      class="iconfont icon-yaoshi"
      v-model="loginCode"
      placeholder="请输入短信验证码"
    >
      <van-button v-show="show" slot="button" size="small" type="primary" @click="sendVerificationCode">发送验证码</van-button>
      <van-button v-show="!show" disabled class="count" slot="button" size="small" type="primary">重新发送（{{count}}）</van-button>
    </van-field>
    <p class="message-style">注：请输入真实信息</p>
  </div>
</template>
<script>
import http from "@/common/request";

export default {
  name: "EditPhoneNumber",

  data() {
    return {
      userInfoList: {},
      mobile: "",
      loginCode: "",
      show:true,
      count:'',
      timer:null
    };
  },
  created() {
    this.userInfoList = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    );
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    onClickRight() {
      // 是否输入验证码
      if (this.loginCode == "") {
        this.$toast("请先输入验证码");
        return;
      }
      this.userInfoList.loginCode = this.loginCode;
      this.userInfoList.mobile = this.mobile;
      const keywords = this.userInfoList;
      http.post("/sys/user/updateUserMobileByCode", keywords).then(res => {
        if (res.code === 0) {
          this.$toast(res.msg);
          this.$router.go(-1);
        }else{
          this.$toast(res.msg);
        }
      });
    },
    // 发送验证码
    sendVerificationCode() {
      // 是否输入手机号
      if (this.mobile == "") {
        this.$toast("请输入手机号");
        return;
      }
      if (this.mobile.length !== 11) {
        this.$toast("请输入正确的手机号");
        return;
      }
      var reg = /^[0-9]+.?[0-9]*$/;
      if (!reg.test(this.mobile)) {
        this.$toast("请输入正确的手机号");
        return;
      }
     const TIME_COUNT = 60;
     if (!this.timer) {
        this.count = TIME_COUNT;
        this.show = false;
        this.timer = setInterval(() => {
          if (this.count > 0 && this.count <= TIME_COUNT) {
           this.count--;
          } else {
           this.show = true;
           clearInterval(this.timer);
           this.timer = null;
          }
        }, 1000)
      }
      this.userInfoList.loginCode = this.loginCode;
      this.userInfoList.mobile = this.mobile;
      const keywords = this.userInfoList;
      http.post("/getLoginCode", keywords).then(res => {
        if (res.code === 0) {
          this.$toast(res.msg);
        } else {
          this.$toast(res.msg);
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell /deep/ .van-cell__value {
  margin-left: 12/16rem;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.count{
  background: #bdbdbd;
  border: #bdbdbd;
}
.message-style{
  text-align: left;
  color: #989292;
  font-size: 14/16rem;
  margin-left: 20/16rem;
}
</style>
<template>
  <div id="container">
    <van-nav-bar
      title="我的消息"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    />
    <div class="main">
      <van-row>
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
          :offset="1"
        >
          <van-row v-for="(item,index) of allMessages" :key="index">
            <van-row
              style="text-align:center;"
              class="underline"
              @click.native="readInformation(item)"
              :class="{unreadStyle: item.read=='0'}"
            >
              <!-- <van-col span="7.5">
              <van-icon name="envelop-o" />
              <span class="policy">{{item.userId}}</span>
              </van-col>-->
              <van-col span="16" style="text-align:left;">
                <span class="policy">{{item.topic}}</span>
              </van-col>
              <van-col span="8" style="text-align:right;">
                <span class="policy">{{item.sendDate | filterDate}}</span>
              </van-col>
            </van-row>
          </van-row>
        </van-list>
      </van-row>
      <!-- 分页 -->
      <!-- <van-row>
        <van-col span="24">
          <van-pagination
            v-model="currentPage"
            :total-items="total"
            :show-page-size="offset"
            force-ellipses
            mode="simple"
            :items-per-page="limit"
            @change="changePage"
          />
        </van-col>
      </van-row>-->
    </div>
  </div>
</template>

<script>
import http from "@/common/request";
export default {
  name: "ReadMyMessage",
  data() {
    return {
      allMessages: [],
      // 分页
      total: 0,
      // currentPage: 1, //当前页
      // limit: 17, //每页几条数据
      offset: 1, //第几页
      // 下拉加载
      loading: false,
      finished: false
    };
  },
  created() {
    //展示消息列表
    this.getAllMessage();
  },
  methods: {
    //回到上一页
    onClickLeft() {
      this.$router.go(-1);
    },
    //获取所有消息
    getAllMessage() {
      const _this = this;
      // const keywords = { limit: this.limit, offset: this.offset };
      const keywords = { offset: this.offset };
      http.get("/send/getUserAllMessage", keywords).then(res => {
        _this.allMessages = res.data.rows;
        _this.loading = false;
        _this.total = res.data.total;
        if (_this.allMessages.length >= _this.total) {
          this.finished = true;
          return;
        }
      });
    },
    //点击任一条消息，阅读消息内容，状态变为已读
    readInformation(item) {
      item.read = "1";
      // 跳转消息内容页面
      this.$router.push({ path: "/information", query: { id: item.id } });
    },
    // 分页
    // changePage(val) {
    //   this.offset = val;
    //   this.getAllMessage();
    // },
    // 下拉加载
    onLoad() {
      this.offset++;
      this.getAllMessage();
    }
  }
};
</script>

<style lang="less" scoped>
#container {
  font-family: Microsoft Yahei;
  font-size: 16/16rem;
  .header {
    background: #e3ebf5;
    width: 100%;
  }
  .main {
    padding: 10/16rem 20/16rem;
    font-size: 12/16rem;
    .underline {
      border-bottom: 0.5/16rem #ccc solid;
      color: #ccc;
      .policy {
        line-height: 35/16rem;
      }
    }
    .unreadStyle {
      color: #408ce7;
    }
  }
}
</style>


<template>
  <div>
    <van-nav-bar
      title="版权信息"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    />
    <div class="cont-wrap">
      <p>本应用的所有内容，包括但不限于文本、图表、图片、代码以及任何独立图片或照片，均受中国及其他版权法律保护，是IDI信息平台的专有财产。</p>
      <p>对本应用内容或者单个图片或照片的任何使用，包括任何复制、传播、展示或传输，均被严厉禁止。</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "copyrightInformation",

  data() {
    return {};
  },
  methods: {
    onClickLeft() {
      if (this.$route.query.title == 0) {
        this.$router.replace({
          path: `/aboutApp`,
          query: {
            title: 1
          }
        });
      } else {
        this.$router.go(-1);
      }
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.cont-wrap {
  padding: 1rem;
  p {
    line-height: 1.8;
    font-size: 14/16rem;
    text-align: justify;
    margin-bottom: 10/16rem;
    text-indent: 30/16rem;
    margin-top: 4/16rem;
  }
}
</style>
<template>
  <div>
    <van-nav-bar
      title="个人信息"
      left-text="返回"
      left-arrow
      @click-left="onClickLeft"
      class="mc-navbar"
    />

    <div class="mc-navbar-margin">
      <van-cell @click="changeHead()" class="my_head" is-link>
        <template slot="title">
          <van-row>
            <van-col span="12">
              <div class="custom-title">头像</div>
            </van-col>
            <van-col span="12">
              <div class="head-img">
                <van-image round fit="cover" width="50" height="50" :src="userDO.userImage" />
                <input
                  v-show="false"
                  type="file"
                  id="uploadImage"
                  name="image"
                  ref="uploadBtn"
                  class="getImgUrl_file"
                  @change="shangc($event)"
                  accept="image/jpg, image/jpeg, image/png"
                />
              </div>
            </van-col>
          </van-row>
        </template>
      </van-cell>
      <van-cell title="账号" is-link :value="userDO.userId" @click="jumpPage('/editPhoneNumber')" />
      <van-cell title="姓名" :value="userDO.username" class="my-name" />
      <van-cell title="身份证" :value="userDO.idCard" />
    </div>
  </div>
</template>
<script>

import http from "@/common/request";

export default {
  name: "ModifyInformation",

  data() {
    return {
      dealImgWidth: 300,
      userInfoList: {},
      userDO: {}
    };
  },
  created() {
    this.userInfoList = JSON.parse(
      localStorage.getItem(this.$getMobileData.userInfo)
    );
    const keywords = { userId: this.userInfoList.userId };
    http.get("/sys/user/selectUserByUserId", keywords).then(res => {
      if (res.code === 0) {
        this.userDO = res.data;
         localStorage.setItem(
            this.$getMobileData.userInfo,
            JSON.stringify(res.data)
          );
        // keywords1.userImage = "base64";
      }
    });
  },
  methods: {
    async shangc(e) {
      let files = document.getElementById("uploadImage").files[0];
      let name = document.getElementById("uploadImage").files[0].name;
      let fileSize = 0;
      let fileMaxSize = 10240; //1M
      if (files) {
        fileSize = files.size;
        if (fileSize > 10 * 1024 * 1024) {
          alert("文件大小不能大于10M！");
          file.value = "";
          return false;
        } else if (fileSize <= 0) {
          alert("文件大小不能为0M！");
          file.value = "";
          return false;
        }
      } else {
        return false;
      }
      if (files.type.startsWith("image") && files.size > 1024*100) {
        let _this = this;
        var base64 = await _this.$dealImage(
          URL.createObjectURL(files),
          _this.dealImgWidth
        )
        files = _this.$dataURLtoFile(base64,files.name);
      }
      //转码base64
      let reader = new FileReader();
      let imgFile;
      // let that = this
      reader.readAsDataURL(files);
      reader.onload = e => {
        imgFile = e.target.result;
        this.userDO.userImage = imgFile;
        http.post("/sys/user/updateUserMySelf", this.userDO).then(res => {
          if (res.code === 0) {
            localStorage.setItem(this.$getMobileData.userInfo, JSON.stringify(this.userDO))
            this.$toast(res.msg);
          }
        });
      };
    },
    onClickLeft() {
      this.$router.go(-1);
    },
    jumpPage(flag) {
      this.$router.push(flag);
    },
    changeHead() {
      this.$refs.uploadBtn.click();
      console.log("更换头像！");
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
}
.van-cell__title {
  .head-img {
    text-align: right;
  }
}
.custom-title {
  margin-top: 12/16rem;
}
.my_head /deep/ {
  .van-cell__right-icon {
    margin-top: 12/16rem;
  }
}
.my-name /deep/ .van-cell__value span {
  padding-right: 20/16rem;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.mc-navbar-margin{
  margin:20/16rem 0 20/16rem 0;
}
</style>
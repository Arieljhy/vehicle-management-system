<template>
  <div>
    <van-nav-bar title="修改密码" left-arrow @click-left="onClickLeft" class="mc-navbar" />
    <van-field clearable v-model="oldPassword" type="password" placeholder="输入旧密码" />
    <van-field clearable v-model="password" type="password" placeholder="输入新密码" />
    <van-field clearable v-model="againPwd" type="password" placeholder="再次输入新密码" />
    <div class="forgrt-passWord">
      <van-icon name="question-o" /><span @click="forgetPassWord">忘记密码</span>
    </div>
    <div style="text-align:left">
      <van-button type="info" class="bottom-btn" @click="conservePassWord">保存</van-button>
    </div>
  </div>
</template>
<script>
import http from "@/common/request";
import md5 from "js-md5";

export default {
  name: "ChangePassword",

  data() {
    return {
      oldPassword: "",
      password: "",
      againPwd: ""
    };
  },
  methods: {
    // 修改密码
    conservePassWord() {
      if(this.oldPassword=="") {
          this.$toast("请输入旧密码");
          return
        }
      if(this.password=="" && this.againPwd=="") {
          this.$toast("请输入新密码");
          return
        }
      var regex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}');
      if (!regex.test(this.password)) {
        this.$toast("密码至少8位且必须包含字母、数字，请及时修改!");
        return
      }   
      if (this.password != this.againPwd) {
        this.$toast("两次密码输入不一致！");
        return;
      }
      const keywords = {
        oldPassword: md5(this.oldPassword),
        password: md5(this.password)
      };
      http.post("/changePwd", keywords).then(res => {
        if (res.code === 0) {
          this.$toast(res.msg);
          this.$router.go(-1);
        } else {
          this.$toast(res.msg);
        }
      });
    },
    //忘记密码
    forgetPassWord() {
      // this.$router.push("/forgetPassWord");
      this.$router.push({
        path: "/forgetPassWord",
        query: {
          flag: 'flag',
        }
      });
    },
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="less" scoped>
.forgrt-passWord {
  text-align: right;
  color: #989292;
  font-size: 14/16rem;
  margin-right: 20/16rem;
  margin-top: 5/16rem;
}
.bottom-btn {
  width: 100%;
  position: fixed;
  bottom: 0;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
</style>
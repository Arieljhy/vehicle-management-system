<template>
  <div>
    <div class="per-bg">
      <van-nav-bar
        title="我的"
        left-text="返回"
        left-arrow
        @click-left="onClickLeft"
        class="mc-navbar"
      />
      <div>
        <van-image round fit="cover" width="56" height="56" :src="userInfo.userImage" />
        <div class="username-style">{{userInfo.username}}</div>
        <div class="mobile-style">{{userInfo.mobile}}</div>
      </div>
    </div>
    <van-cell
      title="我的项目"
      class="iconfont icon-myproject"
      is-link
      @click="jumpPage('/manageMyProject')"
    />
    <van-cell
      title="我的消息"
      class="iconfont title-style"
      icon="chat"
      is-link
      @click="jumpPage('/readMyMessage')"
    />
    <div class="interval-line"></div>
    <div>
      <van-cell
        title="修改信息"
        class="iconfont icon-edit"
        is-link
        @click="jumpPage('/modifyInformation')"
      />
      <van-cell
        title="修改密码"
        class="iconfont icon-changepassword"
        is-link
        @click="jumpPage('/changePassword')"
      />
      <van-cell
        title="手势密码"
        class="iconfont icon-hand"
        is-link
        @click="jumpPage('/gesturePassword')"
      />
      <van-cell
        title="刷脸登录"
        class="iconfont icon-face"
        is-link
        @click="jumpPage('/faceRecognition')"
      />
    </div>
    <div class="interval-line"></div>
    <van-cell title="关于" class="iconfont icon-about" is-link @click="jumpPage('/aboutApp')" />
    <div class="back-height"></div>
    <div class="back-button">
      <van-button type="info" size="large" @click="logout">退出登录</van-button>
    </div>
  </div>
</template>
<script>
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";

export default {
  name: "PersonalSettings",

  data() {
    return {
      userInfoList: {}
    };
  },
  computed: {
    userInfo() {
      return (this.userInfoList = JSON.parse(
        localStorage.getItem(this.$getMobileData.userInfo)
      ));
    }
  },
  created() {},
  methods: {
    ...mapActions(["clearArr"]),
    onClickLeft() {
      this.$router.go(-1);
    },
    jumpPage(flag) {
      this.$router.push(flag);
    },
    //退出登录
    logout() {
      const keywords = { userId: this.userInfoList.userId,tenantId:this.userInfoList.tenantId,logoutStatus:"1"};
      http.get("/logout", keywords).then(res => {
        if (res.code === 0) {
          localStorage.clear();
          this.clearArr();
          this.$toast("退出登录");
          this.$router.push("/login");
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.van-cell {
  text-align: left;
  line-height: 32/16rem;
  .van-cell__title {
    padding-left: 10/16rem;
  }
  .van-cell__right-icon {
    margin-top: 5/16rem;
  }
}
.per-bg {
  background: url(../../assets/imgs/beijing.jpg) no-repeat;
  background-size: 100%;
  width: 100%;
  height: 220/16rem;
}
[class*="van-hairline"]::after {
  border: none;
}
.mc-navbar {
  background-color: rgba(255, 255, 255, 0) !important;
}
.van-image--round {
  border: 7/16rem solid #5585e8;
}
.van-cell:not(:last-child)::after {
  right: 20/16rem;
}
.interval-line {
  height: 15/16rem;
  background-color: #f3f3f3;
}
.back-button {
  position: fixed;
  bottom: 0;
  width: 100%;
}
.back-height {
  height: 80/16rem;
  width: 100%;
}
.username-style {
  color: white;
  font-size: 16/16rem;
}
.mobile-style {
  color: white;
  font-size: 12/16rem;
}
.van-cell__left-icon{
  color: #128feb;
  font-size: 18px;
  height: 35px;
  line-height: 35px;
  font-style: normal;
}
.title-style{
  line-height: 35px;
}
</style>
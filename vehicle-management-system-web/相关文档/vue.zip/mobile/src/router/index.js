/* eslint-disable standard/object-curly-even-spacing */
import Vue from 'vue'
import Router from 'vue-router'
// import { Loading } from 'element-ui'
import { mobileData } from "@/assets/js/mobileData.js";
Vue.use(Router)
const commonData = mobileData[process.env.VUE_APP_CITY]
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

const router = new Router({
  mode: 'history',
  base: commonData.base,
  // base: "manageMent",//租户管理平台配置
  routes: [
    {
      path: '/demo',
      name: 'demo',
      component: () => import('@/views/demo/demo.vue'),
      meta: { title: 'demo' }
    },
    //区块链-首页
    // {
    //   path: '/boobyBlock',
    //   name: 'BlockHomePage',
    //   component: () => import('@/views/boobyBlock/index.vue'),
    //   meta: { title: '区块链-首页' }
    // },
    //区块链-区块详情
    // {
    //   path: '/blockDetail',
    //   name: 'BlockDetail',
    //   component: () => import('@/views/boobyBlock/blockDetail.vue'),
    //   meta: { title: '区块详情' }
    // },
    //区块链-交易详情
    // {
    //   path: '/blockTradingDetail',
    //   name: 'BlockTradingDetail',
    //   component: () => import('@/views/boobyBlock/blockTradingDetail.vue'),
    //   meta: { title: '交易详情' }
    // },
    //只有交易详情页面的路由配置
    {
      path: '/boobyBlock',
      name: 'BlockTradingDetail',
      component: () => import('@/views/boobyBlock/blockTradingDetail.vue'),
      meta: { title: '区块链-交易详情' }
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/login/login.vue'),
      meta: { title: '登陆' }
    },
    {
      path: '/',
      redirect: {
        name: 'login'
      }
    },
    {
      path: '/toRegister',
      name: 'toRegister',
      component: () => import('@/views/login/toRegister.vue'),
      meta: { title: '注册' }
    },
    {
      path: '/userAgreement',
      name: 'userAgreement',
      component: () => import('@/views/login/userAgreement.vue'),
      meta: { title: '用户注册协议' }
    },
    {
      path: '/forgetPassWord',
      name: 'forgetPassWord',
      component: () => import('@/views/login/forgetPassWord.vue'),
      meta: { title: '重置密码' }
    },
    {
      path: '/insuranceCompanyTodo',
      name: 'insuranceCompanyTodo',
      component: () => import('@/views/insuranceCompany/insuranceCompanyTodo.vue'),
      meta: { title: '保险公司首页' }
    },
    {
      path: '/insuranceCompanyTodoList',
      name: 'insuranceCompanyTodoList',
      component: () => import('@/views/insuranceCompany/insuranceCompanyTodoList.vue'),
      meta: { title: '保险公司待办list' }
    },
    // 业主
    {
      path: '/owner',
      name: 'Owner',
      component: () => import('@/views/owner/index.vue'),
      meta: { title: '业主模块' },
      children: [
        {
          path: '/ownerCommunity',
          name: 'OwnerCommunity',
          component: () => import('@/views/owner/ownerCommunity.vue'),
          meta: { title: '业主-小区' }
        },
        {
          path: '/ownerReport',
          name: 'OwnerReport',
          component: () => import('@/views/owner/ownerReport.vue'),
          meta: { title: '业主-报案' }
        },
        {
          path: '/ownerClaims',
          name: 'OwnerClaims',
          component: () => import('@/views/owner/ownerClaims.vue'),
          meta: { title: '业主-理赔' }
        }
      ]
    },
    //政府项目详情
    {
      path: '/governmentProject',
      name: 'GovernmentProject',
      component: () => import('@/views/supervise/governmentProject/index.vue'),
      meta: { title: '政府项目详情模块' },
      children: [
        {
          path: '/governmentCommunity',
          name: 'GovernmentCommunity',
          component: () => import('@/views/supervise/governmentProject/governmentCommunity.vue'),
          meta: { title: '政府-承保' }
        },
        {
          path: '/governmentReport',
          name: 'GovernmentReport',
          component: () => import('@/views/supervise/governmentProject/governmentReport.vue'),
          meta: { title: '政府-风控' }
        },
        {
          path: '/governmentClaims',
          name: 'GovernmentClaims',
          component: () => import('@/views/owner/ownerClaims.vue'),
          meta: { title: '政府-理赔' }
        }
      ]
    },
    // 业主页我的保单详情页
    {
      path: '/policyDetail',
      name: 'PolicyDetail',
      component: () => import('@/views/owner/policyDetail.vue'),
      meta: { title: '业主-保单详情' }

    },
    // 业主报案详情页
    {
      path: '/ownerReportDetail',
      name: 'OwnerReportDetail',
      component: () => import('@/views/owner/ownerReportDetail.vue'),
      meta: { title: '业主-报案详情' }
    },
    // 业主理赔详情页
    {
      path: '/ownerClaimsDetail',
      name: 'OwnerClaimsDetail',
      component: () => import('@/views/owner/ownerClaimsDetail.vue'),
      meta: { title: '业主-理赔详情' }
    },
    {
      path: '/myToDoRisk',
      name: 'MyToDoRisk',
      component: () => import('@/views/riskManagement/myToDoRisk.vue'),
      meta: { title: 'Tis风险管理首页' }
    },
    {
      path: '/newRiskEvents',
      name: 'NewRiskEvents',
      component: () => import('@/views/riskManagement/newRiskEvents.vue'),
      meta: { title: '新增风险' }
    },
    // 新增整改
    {
      path: '/rectificationReport',
      name: 'RectificationReport',
      component: () => import('@/views/riskManagement/rectificationReport.vue')
    },
    // 治安监管
    {
      path: '/statistics',
      name: 'SuperviseState',
      component: () => import('@/views/supervise/superviseState.vue'),
      meta: { title: '项目状态' }
    },
    {
      path: '/superviseTrade',
      name: 'SuperviseTrade',
      component: () => import('@/views/supervise/superviseTrade.vue'),
      meta: { title: '行业监管' }
    },
    {
      path: '/superviseProjectArea',
      name: 'SuperviseProjectArea',
      component: () => import('@/views/supervise/superviseProjectArea.vue'),
      meta: { title: '项目区域' }
    },
    {
      path: '/superviseSelect',
      name: 'SuperviseSelect',
      component: () => import('@/views/supervise/superviseSelect.vue'),
      meta: { title: '项目搜索' }
    },
    {
      path: '/personalSettings',
      name: 'PersonalSettings',
      component: () => import('@/views/personalSettings/personalSettings.vue'),
      meta: { title: '个人设置' }
    },
    {
      path: '/manageMyProject',
      name: 'ManageMyProject',
      component: () => import('@/views/personalSettings/manageMyProject.vue'),
      meta: { title: '我的项目' }
    },
    {
      path: '/readMyMessage',
      name: 'ReadMyMessage',
      component: () => import('@/views/personalSettings/readMyMessage.vue'),
      meta: { title: '我的消息' }
    },
    {
      path: '/information',
      name: 'InformationDetail',
      component: () => import('@/views/personalSettings/information/informationDetail.vue'),
      meta: { title: '消息内容' }
    },
    {
      path: '/modifyInformation',
      name: 'ModifyInformation',
      component: () => import('@/views/personalSettings/modifyInformation.vue'),
      meta: { title: '个人信息' }
    },
    {
      path: '/editPhoneNumber',
      name: 'EditPhoneNumber',
      component: () => import('@/views/personalSettings/editPhoneNumber.vue'),
      meta: { title: '修改手机号' }
    },
    {
      path: '/changePassword',
      name: 'ChangePassword',
      component: () => import('@/views/personalSettings/changePassword.vue'),
      meta: { title: '修改密码' }
    },
    {
      path: '/gesturePassword',
      name: 'GesturePassword',
      component: () => import('@/views/personalSettings/gesturePassword.vue'),
      meta: { title: '手势密码' }
    },
    {
      path: '/faceRecognition',
      name: 'FaceRecognition',
      component: () => import('@/views/personalSettings/faceRecognition.vue'),
      meta: { title: '人脸录制' }
    },
    {
      path: '/faceLogin',
      name: 'faceLogin',
      component: () => import('@/components/faceLogin.vue'),
      meta: { title: '刷脸登陆' }
    },
    {
      path: '/aboutApp',
      name: 'AboutApp',
      component: () => import('@/views/personalSettings/aboutApp.vue'),
      meta: { title: '关于' }
    },
    {
      path: '/versionSpecification',
      name: 'VersionSpecification',
      component: () => import('@/views/personalSettings/versionSpecification.vue'),
      meta: { title: '版本说明' }
    },
    {
      path: '/copyrightInformation',
      name: 'CopyrightInformation',
      component: () => import('@/views/personalSettings/copyrightInformation.vue'),
      meta: { title: '版权信息' }
    },
    // 报告详情
    {
      path: '/reportDetails',
      name: 'ReportDetails',
      component: () => import('@/views/riskManagement/reportDetails.vue'),
      meta: { title: '风险报告详情' }
    },
    // 搜索
    {
      path: '/search',
      name: 'Search',
      component: () => import('@/views/riskManagement/child/search.vue'),
      meta: { title: '搜素' }
    },
    // 搜索详情
    {
      path: '/searchDetails',
      name: 'SearchDetails',
      component: () => import('@/views/riskManagement/searchDetails.vue'),
      meta: { title: '搜索详情' }
    },
    // 风险事件详情
    {
      path: '/riskEvevtsDetails',
      name: 'RiskEvevtsDetails',
      component: () => import('@/views/riskManagement/riskEvevtsDetails.vue'),
      meta: { title: '风险事件详情' }
    },
    // 风险事件评论
    {
      path: '/riskEventComment',
      name: 'RiskEventComment',
      component: () => import('@/views/riskManagement/riskEventComment.vue'),
      meta: { title: '风险事件评论' }
    },
    // 回访详情
    {
      path: '/returnVisitDetails',
      name: 'ReturnVisitDetails',
      component: () => import('@/views/riskManagement/returnVisitDetails.vue'),
      meta: { title: '风险事件评论' }
    },
    {
      path: '/forumOpen',
      name: 'forumOpen',
      component: () => import('@/views/owner/forumOpen.vue'),
      meta: { title: '帖子详情' }
    },
    // 用户注册协议
    {
      path: '/userAgreement',
      name: 'userAgreement',
      component: () => import('@/views/login/userAgreement.vue'),
      meta: { title: '用户注册协议' }
    },
    //马鞍山隐私详情
    {
      path: '/masprivacyPoilcy',
      name: 'MasprivacyPoilcy',
      component: () => import('@/views/login/masprivacyPoilcy.vue'),
      meta: { title: '隐私详情' }
    },
     //北京隐私详情
     {
      path: '/bjprivacyPoilcy',
      name: 'BjprivacyPoilcy',
      component: () => import('@/views/login/bjprivacyPoilcy.vue'),
      meta: { title: '隐私详情' }
    }, 
    //阳泉隐私详情
    {
      path: '/yqprivacyPoilcy',
      name: 'YqprivacyPoilcy',
      component: () => import('@/views/login/yqprivacyPoilcy.vue'),
      meta: { title: '隐私详情' }
    },
     //上海隐私详情
     {
      path: '/shprivacyPoilcy',
      name: 'ShprivacyPoilcy',
      component: () => import('@/views/login/shprivacyPoilcy.vue'),
      meta: { title: '隐私详情' }
    },
  ]
})

let loadingService

// router.beforeEach((to, from, next) => {
//   // 全局loadoing
//   loadingService = Loading.service({
//     lock: true,
//     text: 'Loading...',
//     customClass: 'loading-background'
//   })
//   setTimeout(() => {
//     if (!from, name) {
//       window.scrollTo(0, 0);
//     }
//     next();
//   }, 105)
// })

// router.afterEach((to, from) => {
//   // 关闭全局loading
//   loadingService.close()
// })

export default router

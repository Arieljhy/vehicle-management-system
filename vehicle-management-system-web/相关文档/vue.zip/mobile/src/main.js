import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './plugins/vant.js'
import echarts from 'echarts'
import api from './common/api'
import '@/assets/js/filter'
import '@/assets/js/rem'
import Meta from 'vue-meta'
import { getValueByCode } from "@/assets/js/utils.js";
import { mobileData} from "@/assets/js/mobileData.js";
import dealFile from "@/utils/dealFile.js"
Vue.use(Meta)
Vue.use(dealFile)
Vue.prototype.$echarts = echarts
Vue.config.productionTip = false
Vue.prototype.$api = api
Vue.prototype.$EventBus = new Vue();
Vue.prototype.$getValueByCode = getValueByCode;
Vue.prototype.$getMobileData = mobileData[process.env.VUE_APP_CITY];
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

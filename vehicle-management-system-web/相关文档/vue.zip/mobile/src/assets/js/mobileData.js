//北京版本数据
export const mobileData = {
    bjMobile: {
        province: '北京市',
        city: '北京市',
        control: 'beijing', //切换版本
        lesseeId: 'eidi-beijing',  //登录数据切换
        userInfo: "eidi_beijing_mobile",
        appChnName: "北京市IDI平台",
        modelContent: '北京市', //隐私政策
        bgheight: 44,  //units文字的高度
        base: 'bjMobile',
        token: 'eidi_beijing_token',
        baseSelects: "eidi_beijing_baseSelects",
        units: [
            "如有疑问，请拨打咨询电话：010-66576611",
            "北京市住房和城乡建设委员会",
            "中国银行保险监督管理委员会北京监管局",
            "北京市地方金融监督管理局",
            "北京市规划和自然资源委员会",
            "Copyright@All Rights Reserved"
        ],//北京
        orgList: ''
    },
    masMobile: {
        province: '安徽省',
        city: '马鞍山市',
        control: 'maanshan',
        lesseeId: 'eidi-maanshan',
        userInfo: "eidi_maanshan_mobile",
        appChnName: "马鞍山市IDI平台",
        modelContent: '安徽省马鞍山市',
        bgheight: 160,//文字的高度
        token: 'eidi_maanshan_token',
        base: 'anhui/masMobile',
        baseSelects: "eidi_maanshan_baseSelects",
        units: [
            "如有疑问，请拨打咨询电话：021-68577274",
            "马鞍山市住房和城乡建设局",
            "马鞍山市建筑管理处",
            "中国银行保险监督管理委员会马鞍山监管分局",
            "马鞍山市地方金融监督管理局",
            "Copyright@All Rights Reserved"
        ],
        orgList: '安徽省马鞍山市建设工程质量潜在缺陷保险系统(IDI信息平台)由中国再保险(集团)股份有限公司承建,是市住建委、市建筑管理处、银保监局、地方金融监管局、对工程质量潜在缺陷保险进行监管的工作平台'
    },
    shMobile: {
        province: '上海市',
        city: '上海市',
        control: 'shanghai',
        lesseeId: 'eidi-shanghai',
        userInfo: "eidi_shanghai_mobile",
        appChnName: "上海市IDI平台",
        modelContent: '上海市',
        bgheight: 44,//文字的高度
        base: 'shMobile',
        token: 'eidi_shanghai_token',
        baseSelects: "eidi_shanghai_baseSelects",
        units: [
            "如有疑问，请拨打咨询电话：021-58369157",
            "上海市住房和城乡建设管理委员会",
            "中国银行保险监督管理委员会上海监管局",
            "上海市地方金融监督管理局",
            "Copyright@All Rights Reserved"
        ],//上海
        orgList: '上海市建设工程质量潜在缺陷保险信息系统（IDI信息平台），是中再集团受上海市住建委委托代为建设的，上海市住建委、上海市保监局、上海市金融办三方共同政府工作平台。'
    },
    yqMobile: {
        province: '山西省',
        city: '阳泉市',
        control: 'yangquan',
        lesseeId: 'eidi-yangquan',
        userInfo: "eidi_yangquan_mobile",
        appChnName: "阳泉市IDI平台",
        modelContent: '山西省阳泉市',
        bgheight: 44,//文字的高度
        base: 'shanxi/yqMobile',
        token: 'eidi_yangquan_token',
        baseSelects: "eidi_yangquan_baseSelects",
        units: [
            "如有疑问，请拨打咨询电话：021-68577274",
            "阳泉市住房和城乡建设局",
            "中国银行保险监督管理委员会阳泉监管分局",
            "阳泉市地方金融监督管理局",
            "Copyright@All Rights Reserved"
        ],//上海
        orgList: '山西省阳泉市建设工程质量潜在缺陷保险系统(IDI信息平台)由中国再保险(集团)股份有限公司承建,是市住建委、银保监局、地方金融监管局、对工程质量潜在缺陷保险进行监管的工作平台'
    }
}


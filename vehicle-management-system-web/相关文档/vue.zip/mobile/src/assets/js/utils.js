import * as codes from "@/assets/js/codes.js"
/** 
   * @param {Object} obj  转换对象
  */
export function convertParams(obj) {
  if (!obj || typeof (obj) !== 'object') {
    return obj
  }
  const params = []
  Object.keys(obj).forEach((key) => {
    let value = obj[key]
    // 如果值为undefined我们将其置空
    if (typeof value === 'undefined') {
      value = ''
    }
    // 对于需要编码的文本（比如说中文）我们要进行编码
    params.push([key, encodeURIComponent(value)].join('='))
  })
  return params.join('&')
}
/**
 * 
 * @param {String} name codes中定义的名称
 * @param {String} code code值
 */
export function getValueByCode(name, code) {
  let data = codes[name] || [];
  const res = data.find(item => {
    return item.code === code;
  }) || {};
  return res.value;
}
/**
 * @param {Number} num  展示的表单
 */
export function getList(num = 11) {
  const list = ['BasicInformation', 'BstablishInformation', 'UnderwritingInformation', 'InsuranceReview', 'RiskPlan', 'RiskPlanReview', 'RiskReportList', 'RiskEventsList', 'InsuranceCoverage', 'CopyRiskPlanReview', 'ProjectReturns', 'ProjectClaims']
  let setList = []
  if(num != 11) {
    for(let i = 0; i <= num; i++) {
      setList.push(list[i])
    }
    return setList
  }
  return list
}
/**
 * 返回上一节点
 */
export function getNode(item) {
  switch (item.taskName) {
    case 'insertInsureInfo':
      return 'newProject'
    case 'underwrite':
      return 'insertInsureInfo'
    case 'startRiskPlan':
      return 'underwrite'
    case 'insertRiskCtrlPlan':
      return 'startRiskPlan'
    case 'checkRiskCtrlPlan':
      return 'insertRiskCtrlPlan'
    case 'riskCtrlMgr':
      return 'riskCtrlMgr'
    case 'insertCompletedInfo':
      return 'riskCtrlMgr'
    case 'insuranceReview':
      return 'insertCompletedInfo'
    case 'riskReportMent':
      return 'riskReportMent'
    case 'settleClaims':
      return 'settleClaims'
  }
}
/**
 * 随机数
 */
export function randomString(n = 6) {
  var str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWYZ';
  let id = ''
  for (let i = id.length; i < n; i++) {
      id += str.charAt(Math.floor(Math.random() * str.length))
  }
  return id
}
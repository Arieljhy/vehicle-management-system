import Vue from 'vue'
import 'vant/lib/index.css'// 引入通用css
import 'vant/lib/icon/local.css'// 引用字体css
// ui按需加载
import {
  Button, Cell, CellGroup, Icon, Row, Col, Popup, Image, Checkbox, CheckboxGroup, RadioGroup, Radio,
  DatetimePicker, Swipe, SwipeItem, Lazyload, Field, Uploader, NavBar, Grid, GridItem, Divider, Dialog,
  Progress, NumberKeyboard, Skeleton, Sticky, Picker, Step, Steps, Slider, List, Panel, NoticeBar, Collapse,
  CollapseItem, Tab, Tabs, Search, DropdownMenu, DropdownItem, Pagination, Toast, ImagePreview, Overlay, Area, Rate,Loading
} from 'vant'

Vue
  .use(Button)
  .use(Cell)
  .use(CellGroup)
  .use(Icon)
  .use(Row)
  .use(Col)
  .use(NavBar)
  .use(Field)
  .use(Popup) // 弹出层
  .use(Image)
  .use(Checkbox)
  .use(CheckboxGroup)
  .use(Radio)
  .use(RadioGroup)
  .use(DatetimePicker)
  .use(Swipe)
  .use(SwipeItem)
  .use(Lazyload)
  .use(Uploader)
  .use(Grid)
  .use(GridItem)
  .use(Divider)
  .use(Dialog)
  .use(Progress)
  .use(NumberKeyboard)
  .use(Skeleton)
  .use(Sticky)
  .use(Picker)
  .use(Step)
  .use(Steps)
  .use(Slider)
  .use(List)
  .use(Panel)
  .use(NoticeBar)
  .use(Collapse)
  .use(CollapseItem)
  .use(Tab)
  .use(Tabs)
  .use(Search)
  .use(DropdownMenu)
  .use(DropdownItem)
  .use(Pagination)
  .use(Toast)
  .use(ImagePreview)
  .use(Overlay)
  .use(Area)
  .use(Rate)
  .use(Loading)
  


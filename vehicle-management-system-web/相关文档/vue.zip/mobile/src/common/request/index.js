import axios from "axios";
import { Message } from "element-ui";
import store from '@/store'
import { convertParams } from "@/assets/js/utils.js"
import { errMsg } from '@/assets/js/codes'
import { mobileData } from '@/assets/js/mobileData.js'
import router from "@/router";
const commonData = mobileData[process.env.VUE_APP_CITY]
//全局设置baseURL.
axios.defaults.baseURL = '/api';
axios.defaults.timeout = 90*1000;
// axios.defaults.headers = { Authorization: Cookies.get("token") }
// axios.defaults.headers.common["Authorization"] = AUTH_TOKEN;
axios.defaults.headers.post["Content-Type"] =
  "application/x-www-form-urlencoded";

axios.defaults.withCredentials = true;

// 请求前拦截
axios.interceptors.request.use(
  config => {
    config.headers.common = {
      'jwttoken':localStorage[commonData.token]==undefined?'':localStorage[commonData.token]
    }
    return config;
  },
  error => {
    console.warn(error);
    store.dispatch('loading', false) // loading控制
    return Promise.reject("请求配置失败!");
  }
);
let time = 0
// 设置response统一处理
axios.interceptors.response.use(
  response => {
    if(response && response.data && response.data.code === 101){
    // store.state.reloginDialog = true //弹框
      if(!time) {
        time++
        Message({
          type: 'error',
          showClose: true,
          message: response.data.msg
        })
        setTimeout(() => {
          if (router.currentRoute.path !== '/login') {
            router.replace({
              path: '/'
            })
            localStorage.clear()
          }
          time = 0
        }, 3000)
      }
    }
    return Promise.resolve(response);
  },
  error => {
    store.dispatch('loading', false) // loading控制
    if (error.response && error.response.status) {
      let msg = errMsg.find(item => {
        return item.code == error.response.status
      })
      Message({
        type: 'error',
        showClose: true,
        message: msg && msg.value ? msg.value : error.response.data && error.response.data.msg ? error.response.data.msg : '接口异常'
      })
    }
    return Promise.reject(error);
  }
);

export default {
  /**
   * 发送post请求(form表单)
   * @param {string} url 地址
   * @param {object} data 请求数据
   * @param {Function} done 成功回调
   * @param {Function} fail 失败回调(可选)
   */
  post(url, data) {
    return axios({
      method: "post",
      url,
      data,
      headers: {
        'CONTENT-TYPE': 'application/json',
        'Accept': 'application/json'
      }
    })
      .then(data => {
        return data.data
      })
  },
  /**
   * 发送post请求(body流)
   * @param {string} url 地址
   * @param {object} data 请求数据
   * @param {Function} done 成功回调
   * @param {Function} fail 失败回调(可选)
   */
  postBody(url, data, done, fail) {
    return axios
      .post(url, data)
      .then(data => done(data))
      .catch(error => {
        if (fail) {
          fail(error);
        } else {
          Message.error({
            message: error
          });
        }
      });
  },
  /**
   * 发送get请求
   * @param {string} url 请求地址
   * @param {object} data 请求数据(可选)
   * @param {Function} done 成功回调
   * @param {Function} fail 失败回调(可选)
   */
  get(Url, params) {
    const url = params ? `${Url}${typeof (params) === 'object' ? '?' : ''}${convertParams(params)}` : Url;
    return axios({
      method: "get",
      url,
      // headers: {
      //     "X-Requested-With": "XMLHttpRequest"
      // }
    })
      .then(data => {
        return data.data
      })
  },
  /**
   * delete
   * @param {string} url 请求地址
   * @param {object} data 请求数据(可选)
   * @param {Function} done 成功回调
   * @param {Function} fail 失败回调(可选)
   */
  delete(Url, params) {
    const url = params ? `${Url}${typeof (params) === 'object' ? '?' : ''}${convertParams(params)}` : Url;
    return axios({
      method: "delete",
      url,
      // headers: {
      //     "X-Requested-With": "XMLHttpRequest"
      // }
    })
      .then(data => {
        return data.data
      })
  },
  put(url, data) {
    return axios({
      method: "put",
      url,
      data,
      headers: {
        "X-Requested-With": "XMLHttpRequest"
      }
    })
      .then(data => {
        return data.data
      })
  }
};

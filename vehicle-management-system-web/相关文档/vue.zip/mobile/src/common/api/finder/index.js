import http from '@/common/request'
const url = require('../url')

export function mytodo (param) {
  return http.get(url.mytodo, param)
}
export function getProjectList (param) {
  return http.post(url.getProjectList, param)
}
export function getClaimTip (param) {
  return http.get(url.getClaimTip, param)
}
export function getSuperviseList (param) {
  return http.get(url.getSuperviseList, param)
}
export function getImgPictures (param) {
  return http.get(url.getImgPictures, param)
}

module.exports = {
  myChart: '/myChart',
  login: '/logincas', // 登录
  logout: '/logout', // 退出
  getProjectList: '/community/listIns', // 查询列表
  getClaimTip: '/insurance/InsCaseReport/listPrjClaim', // 查询小红点
  getSuperviseList: '/project/PrjQueryInfo', // 筛选接口
  getImgPictures:'/project/concatImg/logo/',//获取头像
  setUserHandPass:'/sys/user/setUserHandPass',//设置手势密码
}

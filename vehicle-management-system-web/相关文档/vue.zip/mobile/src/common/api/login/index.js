import http from "@/common/request";
const url = require('../url');
// 登录
export function login(param) {
    return http.post(url.login, param);
}
// 修改密码
export function changePwd(param) {
    return http.post(url.changePwd, param);
}
// 退出
export function logout(param) {
    return http.get(url.logout, param);
}
// 发送验证码
export function getLoginCode(param) {
    return http.post(url.getLoginCode, param);
}
// 找回密码
export function findPwd(param) {
    return http.post(url.findPwd, param);
}
// 菜单
export function menu(param) {
    return http.post(url.menu, param);
}
//设置手势密码
export function setUserHandPass(param){
    return http.post(url.setUserHandPass,param);
}

import {
  logout,
  login,
  menu,
  changePwd,
  setUserHandPass
} from './login/index'

import {
  getProjectList,
  getClaimTip,
  getSuperviseList,
  getImgPictures
} from './finder/index'

export default {
  login,
  changePwd,
  setUserHandPass,
  logout,
  menu,
  getProjectList,
  getClaimTip,
  getSuperviseList,
  getImgPictures
}

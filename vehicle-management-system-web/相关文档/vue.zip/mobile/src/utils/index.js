// 千分制保留两位小数
export const numberFormat = (num) => {

    num = parseFloat(num)
    if (num && num != 0) {
        let str = num.toString()
        if (str.indexOf('.') > 0) {
            num = num.toFixed(2)       //保留两位小数 例如 100.1.toFixed(2) 结果为100.10
            str = num.toString()       //将保留两位小数的num变成str
            str = str.split('.');        //变数组
        } else {
            var a = str.split('');
            a.splice(a.length, 0, ".00");
            str = a.join('');
            str = str.split('.');
        }
        var reg = /(\d{1,3})(?=(?:\d{3})+$)/g
        str[0] = str[0].replace(reg, '$1,')
        return str[0] + "." + str[1];
    } else {
        return '0.00'
    }
}

// 千分制
export const numberFormatSystem = (num) => {
    num = parseFloat(num)
    if (num && num != 0) {
        let str = num.toString()
        var reg = /(\d{1,3})(?=(?:\d{3})+$)/g
        str = str.replace(reg, '$1,')
        return str
    } else {
        return '0'
    }
}

export const numberFormatNew = (num) => {
    num = parseFloat(num)
    let unit = ''
    if (num && num != 0) {
        if (num >= 10000 && num < 100000000) {
            num = num / 10000
            unit = '万'
        } else if (num >= 100000000) {
            unit = '亿'
            num = num / 100000000
        }else{
            unit = '元'
        }
        let str = num.toString()
        if (str.indexOf('.') > 0) {
            num = num.toFixed(2)       //保留两位小数 例如 100.1.toFixed(2) 结果为100.10
            str = num.toString()       //将保留两位小数的num变成str
            str = str.split('.');        //变数组
        } else {
            var a = str.split('');
            a.splice(a.length, 0, ".00");
            str = a.join('');
            str = str.split('.');
        }
        var reg = /(\d{1,3})(?=(?:\d{3})+$)/g
        str[0] = str[0].replace(reg, '$1,')
        return str[0] + "." + str[1] + unit
    } else {
        return '0.00'
    }
}

export const numberFormatArea = (num) => {
    num = parseFloat(num)
    let unit = ''
    if (num && num != 0) {
        if (num >= 10000 && num < 100000000) {
            num = num / 10000
            unit = '万㎡'
        } else if (num >= 100000000) {
            unit = '亿㎡'
            num = num / 100000000
        }else{
            unit = '㎡'
        }
        let str = num.toString()
        if (str.indexOf('.') > 0) {
            num = num.toFixed(2)       //保留两位小数 例如 100.1.toFixed(2) 结果为100.10
            str = num.toString()       //将保留两位小数的num变成str
            str = str.split('.');        //变数组
        } else {
            var a = str.split('');
            a.splice(a.length, 0, ".00");
            str = a.join('');
            str = str.split('.');
        }
        var reg = /(\d{1,3})(?=(?:\d{3})+$)/g
        str[0] = str[0].replace(reg, '$1,')
        return str[0] + "." + str[1] + unit
    } else {
        return '0.00'
    }
}

export const numberFormatNewSys = (num) => {
    num = parseFloat(num)
    let unit = ''
    if (num && num != 0) {
        if (num >= 10000 && num < 100000000) {
            num = num / 10000
            unit = '万'
        } else if (num >= 100000000) {
            unit = '亿'
            num = num / 100000000
        }
        let str = num.toString()
        var reg = /(\d{1,3})(?=(?:\d{3})+$)/g
        str = str.replace(reg, '$1,')
        return str + unit
    } else {
        return '0'
    }
}

//时间戳转日期格式
export const dateTransferFormat = (times) => {
    times = times / 1000;
    let date = new Date(times);
    let year = date.getFullYear();
    let month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
    let day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    let hours = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    let minutes = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    let seconds = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
    let traddingDate = year + '-' + month + '-' + day + ' ' + hours + '：' + minutes + '：' + seconds;
    return traddingDate;
}
export default {
    install(Vue) {
        // 压缩方法
        Vue.prototype.$dealImage = function (base64, w) {
            return new Promise((resolve, reject) => {
              console.log(base64)
              var newImage = new Image()
              var quality = 1
              newImage.src = base64
              newImage.setAttribute("crossOrigin", "Anonymous")
              var imgWidth,imgHeight
              newImage.onload = function() {
                imgWidth = this.width
                imgHeight = this.height
                var canvas = document.createElement('canvas')
                var ctx = canvas.getContext("2d")
                if(Math.max(imgWidth, imgHeight) > w) {
                  if(imgWidth > imgHeight) {
                    canvas.width = w;
                    canvas.height = (w * imgHeight) / imgWidth
                  } else {
                    canvas.height = w;
                    canvas.width = (w * imgWidth) / imgHeight
                  }
                } else {
                  canvas.width = imgWidth
                  canvas.height = imgHeight
                }
                ctx.clearRect( 0, 0, canvas.width, canvas.height )
                ctx.drawImage( this, 0, 0, canvas.width, canvas.height )
                var base64 = canvas.toDataURL("image/jpeg", quality)
      
                while(base64.length / 1024 > 1024) {
                  quality -= 0.01
                  if(quality < 0.1) {
                    break
                  }
                  base64 = canvas.toDataURL("image/jpeg", quality)
                  console.log('压缩大小，系数(xiao)',base64.length, quality)
                }
                // while(base64.length / 1024 < 50*1024) {
                //   quality += 0.01
                //   if(quality > 0.92) {
                //     break
                //   }
                //   base64 = canvas.toDataURL("image/jpeg", quality)
                //   console.log('压缩大小，系数(da)',base64.length, quality)
                // }
                console.log("压缩后大小", base64.length / 1024)
                resolve(base64)
              }
            })
        }
        // 将base64转化为文件
        Vue.prototype.$dataURLtoFile = function (dataurl, filename) {
            var arr = dataurl.split(","),
              mime = arr[0].match(/:(.*?);/)[1],
              bstr = atob(arr[1]),
              n = bstr.length,
              u8arr = new Uint8Array(n)
            while( n-- ) {
              u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime })
          }
    }
}
module.exports = {
  lintOnSave: false,
  publicPath: process.env.VUE_APP_BASE_URL,
  outputDir: process.env.VUE_APP_BASE_FLAG,
  productionSourceMap: false,
  devServer: {
    // open: true,
    proxy: {
      "/api/baidu": {
        target: "http://vop.baidu.com", // 百度语音识别文档接口
        pathRewrite: {
          "^/api/baidu": ""
        },
        changeOrigin: true
      },
      "/api": {
        target: "http://172.25.147.175:9999", // 开发环境 
        pathRewrite: {
          "^/api": ""
        },
        changeOrigin: true
      }
    }
  }
}

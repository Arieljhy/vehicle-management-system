/* eslint-disable standard/object-curly-even-spacing */
import Vue from 'vue'
import Router from 'vue-router'
import { Loading } from 'element-ui'
import Home from '@/views/layout/index.vue'
import Statistics from '@/views/statistics/statistics.vue'
import MyToDo from '@/views/myToDo/myToDo.vue'
import MyToDoRisk from '@/views/myToDo/myToDoRisk.vue'
import MyToDoRun from '@/views/myToDo/myToDoRun.vue'
import { versionData } from "@/assets/js/versionData.js";
Vue.use(Router)
const commonData = versionData[process.env.VUE_APP_CITY]
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

const router = new Router({
  mode: 'history',
  base: commonData.base,
  // base: 'manageMent',
  routes: [
    {
      path: '/dataCenter',
      name: 'DataCenter',
      component: () => import('@/views/statistics/dataCenter.vue')
    },
    {
      path: '/projectSummary',
      name: 'ProjectSummary',
      component: () => import('@/views/projectSummary/projectSummary.vue')
    },
    {
      path: '/projectSingle',
      name: 'ProjectSingle',
      component: () => import('@/views/projectSummary/projectSingle.vue')
    },
    {
      path: '/demo',
      name: 'demo',
      component: () => import('@/views/demo/demo.vue')
    },
    {
      path: '/demo002',
      name: 'demo002',
      component: () => import('@/views/demo/demo002.vue')
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/login/login.vue')
    },
    {
      path: "/manageSystemLogin",
      name: "manageSystemLogin",
      component: () => import('@/views/manageSystem/login/index')
    },
    {
      path: '/',
      redirect: {
        name: 'login'
      }
    },
    {
      path: '/home',
      component: Home,
      hidden: true,
      children: [
        {
          path: '/myToDo',
          name: 'MyToDo',
          component: MyToDo,
          meta: { title: '我的待办（保险公司）', screen: true, fuzzyQuery: true }
        },
        {
          path: '/myToDoRisk',
          name: 'MyToDoRisk',
          component: MyToDoRisk,
          meta: { title: '我的待办(风险管理机构)', screen: true, fuzzyQuery: true }
        },
        {
          path: '/myToDoRun',
          name: 'MyToDoRun',
          component: MyToDoRun,
          meta: { title: '我的待办(运营方)', screen: true, fuzzyQuery: true }
        },
        {
          path: '/riskManagement',
          name: 'RiskManagement',
          component: () => import('@/views/riskManagement/riskManagement.vue'),
          meta: { title: '风险管理', upload: true, fuzzyQuery: true }
        },
        {
          path: '/riskManagementRisk',
          name: 'RiskManagementRisk',
          component: () => import('@/views/riskManagement/riskManagementRisk.vue'),
          meta: { title: '风险管理(风险管理机构)', fuzzyQuery: true }
        },
        {
          path: '/projectInquiry',
          name: 'ProjectInquiry',
          component: () => import('@/views/projectInquiry/projectInquiry.vue'),
          meta: { title: '项目查询' }
        },
        {
          path: '/operationManagement',
          name: 'OperationManagement',
          component: () => import('@/views/operationManagement/operationManagement.vue'),
          meta: { title: '运营管理' }
        },
        {
          path: '/claimsService',
          name: 'ClaimsService',
          component: () => import('@/views/claimsService/claimsService.vue'),
          meta: { title: '理赔服务' }
        },
        {
          path: '/claimsServiceDetail',
          name: 'ClaimsServiceDetail',
          component: () => import('@/views/claimsService/claimsServiceDetail.vue'),
          meta: { title: '理赔服务详情', activePath: '/claimsService' }
        },
        {
          path: '/claimsServiceDetailing',
          name: 'ClaimsServiceDetailing',
          component: () => import('@/views/claimsService/claimsServiceDetailing.vue'),
          meta: { title: '理赔服务详情x下详情', activePath: '/claimsService' }
        },
        {
          path: '/claimsServiceDetailAdd',
          name: 'ClaimsServiceDetailAdd',
          component: () => import('@/views/claimsService/claimsServiceDetailAdd.vue'),
          meta: { title: '理赔服务详情新增', activePath: '/claimsService' }
        },
        {
          path: '/claimsServiceDetailingAdd',
          name: 'ClaimsServiceDetailingAdd',
          component: () => import('@/views/claimsService/claimsServiceDetailingAdd.vue'),
          meta: { title: '理赔服务详情x下详情新增', activePath: '/claimsService' }
        },
        {
          path: '/claimsForum',
          name: 'ClaimsForum',
          component: () => import('@/views/claimsService/claimsForum/claimsForum.vue'),
          meta: { title: '理赔->论坛' },
          children: [
            {
              path: '/forumDetails',
              name: 'ForumDetails',
              component: () => import('@/views/claimsService/claimsForum/forumDetails.vue'),
              meta: { title: '论坛详情', activePath: '/claimsService' },
            },
            {
              path: '/forumOpen',
              name: 'ForumOpen',
              component: () => import('@/views/claimsService/claimsForum/forumOpen.vue'),
              meta: { title: '论坛展开', activePath: '/claimsService' },
            },
            {
              path: '/myForumMessage',
              name: 'MyForumMessage',
              component: () => import('@/views/claimsService/claimsForum/myForumMessage.vue'),
              meta: { title: '我的消息' },
            },
            {
              path: '/myForumPost',
              name: 'MyForumPost',
              component: () => import('@/views/claimsService/claimsForum/myForumPost.vue'),
              meta: { title: '我的贴子' },
            }
          ]
        },
        {
          path: '/statistics',
          name: 'Statistics',
          component: Statistics,
          meta: { title: '统计分析' }
        },
        {
          path: '/systemManagement',
          name: 'SystemManagement',
          component: () => import('@/views/systemManagement/systemManagement.vue'),
          meta: { title: '系统管理' }
        },
        {
          path: '/odsWarranty',
          name: 'OdsWarranty',
          component: () => import('@/views/systemManagement/odsWarranty.vue'),
          meta: { title: 'ods保单', activePath: '/systemManagement' }
        },
        {
          path: '/odsRiskEvent',
          name: 'OdsRiskEvent',
          component: () => import('@/views/systemManagement/odsRiskEvent.vue'),
          meta: { title: 'ODS风险事件', activePath: '/systemManagement' }
        },
        {
          path: '/odsSettlement',
          name: 'OdsSettlement',
          component: () => import('@/views/systemManagement/odsSettlement.vue'),
          meta: { title: 'ODS理赔', activePath: '/systemManagement' }
        },
        {
          path: '/newReinsurance',
          name: 'NewReinsurance',
          component: () => import('@/views/systemManagement/systemChild/newReinsurance.vue'),
          meta: { title: '新增共再保体', activePath: '/systemManagement' }
        },
        {
          path: '/newAccount',
          name: 'NewAccount',
          component: () => import('@/views/systemManagement/newAccount.vue'),
          meta: { title: '新增账户管理', activePath: '/systemManagement' }
        },
        {
          path: '/accountNew',
          name: 'AccountNew',
          component: () => import('@/views/systemManagement/accountNew.vue'),
          meta: { title: '账户管理新增', activePath: '/systemManagement' }
        },
        {
          path: '/accountManagement',
          name: 'AccountManagement',
          component: () => import('@/views/systemManagement/accountManagement.vue'),
          meta: { title: '账户管理', activePath: '/systemManagement' }
        },
        {
          path: '/InsuranceTreaty',
          name: 'InsuranceTreaty',
          component: () => import('@/views/systemManagement/InsuranceTreaty.vue'),
          meta: { title: '系统管理(保险条款)', activePath: '/systemManagement' }
        },
        {
          path: '/InsuranceTreatyAdd',
          name: 'InsuranceTreatyAdd',
          component: () => import('@/views/systemManagement/systemChild/InsuranceTreatyAdd.vue'),
          meta: { title: '系统管理(保险条款新增)', activePath: '/systemManagement' }
        },
        {
          path: '/contentManagement',
          name: 'contentManagement',
          component: () => import('@/views/systemManagement/contentManagement.vue'),
          meta: { title: '系统管理(内容管理)', activePath: '/systemManagement' }
        },
        {
          path: '/contentManagementRevision',
          name: 'contentManagementRevision',
          component: () => import('@/views/systemManagement/systemChild/contentManagementRevision.vue'),
          meta: { title: '系统管理(内容管理修改)', activePath: '/systemManagement' }
        },
        {
          path: '/riskReportManagement',
          name: 'RiskReportManagement',
          component: () => import('@/views/riskManagement/riskReportManagement.vue'),
          meta: { title: '风险系统管理(整改)', activePath: '/riskManagementRisk' }
        },
        {
          path: '/addNewProject',
          name: 'AddNewProject',
          component: () => import('@/views/projectInquiry/addNewProject.vue'),
          meta: { title: '新增项目（补录）', activePath: '/projectInquiry' }
        },
        {
          path: '/riskEventManagement',
          name: 'RiskEventManagement',
          component: () => import('@/views/riskManagement/riskEventManagement.vue'),
          meta: { title: '风险事件管理（风险管理机构）', activePath: '/riskManagementRisk' }
        },
        {
          path: '/riskAssessmentReportManagement',
          name: 'RiskAssessmentReportManagement',
          component: () => import('@/views/riskManagement/riskAssessmentReportManagement.vue'),
          meta: { title: '风险评估报告管理（风险管理机构）', activePath: '/riskManagementRisk' }
        },
        {
          path: '/returnVisitReportManagement',
          name: 'ReturnVisitReportManagement',
          component: () => import('@/views/riskManagement/returnVisitReportManagement.vue'),
          meta: { title: '回访估报告管理（风险管理机构）', activePath: '/riskManagementRisk' }
        },
        {
          path: '/returnVisitDetails',
          name: 'ReturnVisitDetails',
          component: () => import('@/views/riskManagement/returnVisitDetails.vue'),
          meta: { title: '回访估报告详情', activePath: '/riskManagementRisk' }
        },
        {
          path: '/establishInfo',
          name: 'EstablishInfo',
          component: () => import('@/views/establishInfo/establishInfo.vue'),
          meta: { title: '报建信息维护', activePath: '/riskManagementRisk' }
        },
        {
          path: '/costThreshold',
          name: 'CostThreshold',
          component: () => import('@/views/systemManagement/costThreshold.vue'),
          meta: { title: '造价预值', activePath: '/systemManagement' }
        },
        {
          path: '/riskParticulars',
          name: 'RiskParticulars',
          component: () => import('@/views/riskManagement/riskParticulars.vue'),
          meta: { title: '风险管理报告详情', activePath: '/riskManagementRisk' }
        },
        {
          path: '/riskReportAmend',
          name: 'RiskReportAmend',
          component: () => import('@/views/riskManagement/riskReportAmend.vue'),
          meta: { title: '风险管理报告修改', activePath: '/riskManagementRisk' }
        },
        {
          path: '/finalRiskInspectionReport',
          name: 'FinalRiskInspectionReport',
          component: () => import('@/views/riskManagement/finalRiskInspectionReport.vue'),
          meta: { title: '最终风险检查报告', activePath: '/riskManagement' }
        },
        {
          path: '/dataUnlock',
          name: 'DataUnlock',
          component: () => import('@/views/systemManagement/dataUnlock.vue'),
          meta: { title: '数据解锁', activePath: '/systemManagement' }
        },
        {
          path: '/messageManagement',
          name: 'MessageManagement',
          component: () => import('@/views/systemManagement/messageManagement.vue'),
          meta: { title: '消息管理', activePath: '/systemManagement' }
        },
        {
          path: '/mailBrowsing',
          name: 'MailBrowsing',
          component: () => import('@/views/systemManagement/systemChild/mailBrowsing.vue'),
          meta: { title: '消息管理(详情,修改)', activePath: '/systemManagement' }
        },
        {
          path: '/odsWarrantyBrowse',
          name: 'OdsWarrantyBrowse',
          component: () => import('@/views/systemManagement/systemChild/odsWarrantyBrowse.vue'),
          meta: { title: 'ODS保单', activePath: '/systemManagement' }
        },
        {
          path: '/claimBrowsing',
          name: 'ClaimBrowsing',
          component: () => import('@/views/systemManagement/systemChild/claimBrowsing.vue'),
          meta: { title: 'ODS理赔详情(修改)', activePath: '/systemManagement' }
        },
        {
          path: '/odsRiskReportAmend',
          name: 'OdsRiskReportAmend',
          component: () => import('@/views/systemManagement/odsRiskReporting/odsRiskReportAmend.vue'),
          meta: { title: 'ODS报告详情(修改)', activePath: '/systemManagement' }
        },
        {
          path: '/odsRectificationDetails',
          name: 'OdsRectificationDetails',
          component: () => import('@/views/systemManagement/odsRectification/odsRectificationDetails.vue'),
          meta: { title: 'ODS整改详情(修改)', activePath: '/systemManagement' }
        },
        {
          path: '/odsReturnVisitDetails',
          name: 'OdsReturnVisitDetails',
          component: () => import('@/views/systemManagement/odsReturnVisit/odsReturnVisitDetails.vue'),
          meta: { title: 'ODS回访详情(修改)', activePath: '/systemManagement' }
        },
        {
          path: '/odsRiskRectificationBase',
          name: 'OdsRiskRectificationBase',
          component: () => import('@/views/systemManagement/odsRisk/odsRiskRectificationBase.vue'),
          meta: { title: 'ODS事件详情(修改)', activePath: '/systemManagement' }
        },
        {
          path: '/manageSystem',
          redirect: { name: 'manageSystemLogin' }
        },
        {
          path: '/manageSystem/baseData',
          name: 'baseDataList',
          component: () => import('@/views/manageSystem/baseData/index'),
          meta: { title: '字典表' }
        }, {
          path: '/manageSystem/baseData/info',
          name: 'baseDataInfo',
          component: () => import('@/views/manageSystem/baseData/add'),
          meta: { title: '字典表详情' }
        }, {
          path: '/manageSystem/baseData/parentInfo',
          name: 'baseParentDataInfo',
          component: () => import('@/views/manageSystem/baseData/addParent'),
          meta: { title: '字典表父详情' }
        },
        {
          path: '/manageSystem/userManage',
          name: 'userManageList',
          component: () => import('@/views/manageSystem/userManage/index'),
          meta: { title: '用户管理' }
        }, {
          path: '/manageSystem/userManage/info',
          name: 'userManageInfo',
          component: () => import('@/views/manageSystem/userManage/add'),
          meta: { title: '用户详情', activePath: "/manageSystem/userManage" }
        },
        {
          path: '/manageSystem/tenantManage',
          name: 'tenantManageList',
          component: () => import('@/views/manageSystem/tenantManage/index'),
          meta: { title: '租户管理' }
        }, {
          path: '/manageSystem/tenantManage/info',
          name: 'tenantManageInfo',
          component: () => import('@/views/manageSystem/tenantManage/add'),
          meta: { title: '租户详情', activePath: "/manageSystem/tenantManage" }
        }, {
          path: '/manageSystem/tenantManage/setting',
          name: 'tenantManageSetting',
          component: () => import('@/views/manageSystem/tenantManage/setting'),
          meta: { title: '租户设置', activePath: "/manageSystem/tenantManage" }
        },
        {
          path: '/manageSystem/ODS',
          name: 'manageSystemODS',
          component: () => import("@/views/manageSystem/ODS/index"),
          meta: { title: "ODS保单" }
        },
        {
          path: '/manageSystem/ODS/add',
          name: 'manageSystemODSInfo',
          component: () => import("@/views/manageSystem/ODS/add"),
          meta: { title: "ODS保单详情", activePath: "/manageSystem/ODS" }
        },
        {
          path: '/monitoring',
          name: 'Monitoring',
          component: () => import('@/views/manageSystem/baseData/monitoring.vue'),
          meta: { title: '租户运营状况监控' }
        }, {
          path: '/manageSystem/tenantProcessSetting',
          name: 'TenantProcessSetting',
          component: () => import('@/views/manageSystem/tenantProcessSetting/index.vue'),
          meta: { title: '应用系统流程管理' }
        },
        {
          path: '/manageSystem/timingTask',
          name: 'TimingTask',
          component: () => import('@/views/manageSystem/timingTask/index.vue'),
          meta: { title: '定时任务' }
        },
        {
          path: '/manageSystem/timingTask/journal',
          name: 'Journal',
          component: () => import('@/views/manageSystem/timingTask/journal.vue')
          // meta: { title: '定时任务' }
        },
        {
          path: '/manageSystem/rolePermissionConfiguration',
          name: 'RolePermissionConfiguration',
          component: () => import('@/views/manageSystem/rolePermissionConfiguration/index.vue'),
          meta: { title: '角色权限配置' }
        },
        {
          path: '/quoation',
          name: 'Quoation',
          component: () => import('@/views/projectQuoation/quoation.vue'),
          meta: { title: '项目报价' }
        },
        {
          path: '/quoationAddDetail',
          name: 'QuoationAddDetail',
          component: () => import('@/views/projectQuoation/quoationAddDetail.vue'),
          meta: { title: '项目报价新增', activePath: '/quoation' }
        },
      ]
    }
  ]
})

let loadingService

router.beforeEach((to, from, next) => {
  // 全局loadoing
  loadingService = Loading.service({
    lock: true,
    text: 'Loading...',
    customClass: 'loading-background'
  })
  setTimeout(() => {
    if (!from, name) {
      window.scrollTo(0, 0);
    }
    next();
  }, 105)
})

router.afterEach((to, from) => {
  // 关闭全局loading
  loadingService.close()
})

export default router
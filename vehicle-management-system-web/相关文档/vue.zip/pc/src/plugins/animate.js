import Vue from 'vue'
import animate from 'animate.css'
Vue.use(animate)
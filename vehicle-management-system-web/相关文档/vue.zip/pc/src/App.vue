<template>
  <div id="app">
    <router-view />
  </div>
</template>
<script>
import { mapGetters } from "vuex";
export default {
  // created() {
  //   window.addEventListener("beforeunload", e => {
  //     this.$api.logout({ userId: this.userInfo.userId });
  //   });
  // },
  computed: {
    ...mapGetters(["userInfo"])
  }
};
</script>
<style lang="scss">
@import "@/assets/styles";
#app {
  font-family: Source Han Sans CN;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #221815;
}
</style>

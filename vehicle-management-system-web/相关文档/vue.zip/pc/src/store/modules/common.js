export default {
    state: {
        projectQueryParams: {},//项目查询筛选条件
        OMQueryParams: {},//运营管理筛选条件
        heJia:""
    },
    mutations: {
        SET_PROJECTQUERYPARAMS(state, params) {
            state.projectQueryParams = params;
        },
        SET_OMQUERYPARAMS(state, params) {
            state.OMQueryParams = params;
        },
        GET_HE_JIA(state, params) {
            state.heJia = params;
        }
    },
    actions: {
        setProjectQueryParams({ commit }, params) {
            commit('SET_PROJECTQUERYPARAMS', params);
        },
        setOMQueryParams({ commit }, params) {
            commit('SET_OMQUERYPARAMS', params);
        },
         //存储已核价
         getHeJia({ commit }, res) {
            commit('GET_HE_JIA', res)
            return
        },
    }
}
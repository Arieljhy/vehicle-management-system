import api from '@/common/api'

export default {
    state: {
        riskList: {},
        reportList: {},
        showRiskPage: 'riskEvent',
        fuzzyQuery: { value: "" },
        riskManamentRiskList: {},
        screen: {},
        filterCriteria: false,
        getDate: date => {
            const monthsInEng = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ];
            if (date) {
                const newDate = new Date(date.replace(/-/g, "/"));
                const mydate = {
                    case_year: newDate.getFullYear(),
                    case_month: monthsInEng[newDate.getMonth()],
                    case_day: newDate.getDate()
                };
                return mydate;
            }
            return {}
        }

    },
    mutations: {
        RISK_MANAGEMENT(state, data) {
            data.data.rows.map((item, index) => {
                item.amendProgress = Number(item.amendProgress); //转换成数字类型
            });
            state.riskList = data.data
        },
        REPORT_MANAGEMENT(state, data) {
            data.data.rows.map((item, index) => {
                item.mydate = state.getDate(item.signDate); //转换成数字类型
            });
            state.reportList = data.data
        },
        SHOW_RISK_PAGE(state, data) {
            state.showRiskPage = data
        },
        GET_FUZZY_QUERY(state, data) {
            state.fuzzyQuery.value = data
        },
        GET_SCREEN(state, data) {
            state.screen = data
        },
        RISK_SCREEN(state, data) {
            state.filterCriteria = data
        },
        OFFSET_LIST(state, data) {
            state.offsetLists = data
        },
        MANAGEMENT_RISK(state, data) {
            data.data.rows.map((item, index) => {
                if (item.projectStatus == 'ProjectOnBuliding' && item.taskName == 'riskCtrlMgr') {
                    if (item.totalRectification == 0) {
                        item.percentage = 0
                    } else {
                        item.percentage = (1 - item.noRectificationNum / item.totalRectification) * 100
                    }
                } else {
                    item.percentage = 100
                }
            })
            state.riskManamentRiskList = data.data
        }
    },
    actions: {
        async riskManagement({ commit }, param) {
            const res = await api.risk(param);
            commit('RISK_MANAGEMENT', res)
            return
        },
        async reportManagement({ commit }, param) {
            const res = await api.getProjectList(param);
            commit('REPORT_MANAGEMENT', res)
            return
        },
        changeRiskPage({ commit }, res) {
            commit('SHOW_RISK_PAGE', res)
            return
        },
        //输入框
        setFuzzyQuery({ commit }, res) {
            commit('GET_FUZZY_QUERY', res)
            return
        },
        //筛选条件
        getScreen({ commit }, res) {
            commit('GET_SCREEN', res)
            return
        },
        //显示组件
        riskScreen({ commit }, res) {
            commit('RISK_SCREEN', res)
            return
        },
        async riskManagementRisk({ commit }, param) {
            const res = await api.getManagementRiskList(param);
            commit('MANAGEMENT_RISK', res)
            return
        },
    }
}

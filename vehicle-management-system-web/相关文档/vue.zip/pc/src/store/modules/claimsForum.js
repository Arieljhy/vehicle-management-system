import api from '@/common/api'
import http from "@/common/request";
import config from '@/common/config';
export default {
    state: {
        forumBaseInfo: {
            userInfo: { personalPostNum: null },//用户信息
            forumInfo: {},//小区论坛基本信息
            leaderboard: [{}]//排行榜
        },//论坛基础信息
        mainPost: {
            mainPostList: [],
            total: 0,
            followPost: []
        }
    },
    mutations: {
        SET_FORUM_BASE_INFO(state, res) {
            state.forumBaseInfo.forumInfo = res.data;
        },
        SET_FORUM_LEADERBOARD(state, res) {
            res.data.rows.map(item => {
                item.forumPicDOList.map(childItem => {
                    childItem.imgUrl =
                    `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}&view=1`;
                });
            });
            state.forumBaseInfo.leaderboard = res.data.rows.length > 0 ? res.data.rows : [{}];
        },
        SET_LIST_MAIN(state, res) {
            res.data.rows.map(item => {
                item.forumPicDOList.map(childItem => {
                    childItem.imgUrl =
                     `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}&view=1`;
                });
            });
            state.mainPost.mainPostList = res.data.rows;
            state.mainPost.total = res.data.total;
        },
        SET_USER_POST(state, res) {
            state.forumBaseInfo.userInfo.personalPostNum = res.data.total;
        },
        SET_FOLLOW_POST(state, res) {
            state.mainPost.followPost = res.data.rows;
        }
    },
    actions: {
        async setForumBaseInfo({ commit }, param) {
            const res = await api.getForumInfo(param);
            commit('SET_FORUM_BASE_INFO', res);
        },
        async setForumLeaderboard({ commit }, param) {
            const keywords = {
                projectId: param
            };
            const res = await api.mainOrderPost(keywords);
            commit('SET_FORUM_LEADERBOARD', res);
            return res

        },
        setListMain({ commit }, param) {
            http.get("/forum/listMain", param).then(res => {
                commit('SET_LIST_MAIN', res);
            });
        },
        setUserPost({ commit }, param) {
            http.get("/forum/listMain", param).then(res => {
                commit('SET_USER_POST', res);
            });
        },
        setFollowPost({ commit }, param) {
            http.get("/forum/listFollowReply", param).then(res => {
                commit('SET_FOLLOW_POST', res);
            });
        }
    }
}
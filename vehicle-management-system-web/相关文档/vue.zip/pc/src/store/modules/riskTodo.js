import api from '@/common/api'

export default {
    state: {
        //待办-保险公司
        riskTodoAll: {
            allTypeList: {},
            insertInsure: { mydate: {} },
            checkRiskCtrlPlan: { mydate: {} },
            insertCompleted: { mydate: {} }
        },
        //待办-运营公司
        riskTodoRunAll: {
            allTypeRunList: {},
            startRiskPlan: { mydate: {} },
            underWrite: { mydate: {} },
            insuranceReview: { mydate: {} }
        },
        //待办-风险管理机构
        todoRiskList: { insertRiskCtrlPlan: { rows: [] } },
        getDate: date => {
            const monthsInEng = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ];
            if (date) {
                const newDate = new Date(date.replace(/-/g, "/"));
                const mydate = {
                    case_year: newDate.getFullYear(),
                    case_month: monthsInEng[newDate.getMonth()],
                    case_day: newDate.getDate()
                };
                return mydate;
            }
            return {}
        },
        showFilter: 'mytodo'
    },
    mutations: {
        RISK_TODO(state, data) {
            const allTypeList = data.data;
            if (allTypeList.insertInsureInfo.rows.length > 0)
                allTypeList.insertInsureInfo.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });
            if (allTypeList.checkRiskCtrlPlan.rows.length > 0)
                allTypeList.checkRiskCtrlPlan.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });
            if (allTypeList.insertCompletedInfo.rows.length > 0)
                allTypeList.insertCompletedInfo.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });
            const insertInsure = allTypeList.insertInsureInfo.rows[0] || {
                mydate: {}
            };
            const checkRiskCtrlPlan = allTypeList.checkRiskCtrlPlan.rows[0] || {
                mydate: {}
            };
            const insertCompleted = allTypeList.insertCompletedInfo.rows[0] || {
                mydate: {}
            };
            state.riskTodoAll = {
                allTypeList: allTypeList,
                insertInsure: insertInsure,
                checkRiskCtrlPlan: checkRiskCtrlPlan,
                insertCompleted: insertCompleted
            }
        },
        RISK_TODO_RUN(state, data) {
            const allTypeRunList = data.data;
            if (allTypeRunList.startRiskPlan.rows.length > 0)
                allTypeRunList.startRiskPlan.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });
            if (allTypeRunList.underWrite.rows.length > 0)
                allTypeRunList.underWrite.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });
            if (allTypeRunList.insuranceReview.rows.length > 0)
                allTypeRunList.insuranceReview.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });
            const startRiskPlan = allTypeRunList.startRiskPlan.rows[0] || {
                mydate: {}
            };
            const underWrite = allTypeRunList.underWrite.rows[0] || {
                mydate: {}
            };
            const insuranceReview = allTypeRunList.insuranceReview.rows[0] || {
                mydate: {}
            };
            state.riskTodoRunAll = {
                allTypeRunList: allTypeRunList,
                startRiskPlan: startRiskPlan,
                underWrite: underWrite,
                insuranceReview: insuranceReview
            }
        },
        TODO_RISK(state, data) {
            const todoRisk = data.data;
            if (todoRisk.insertRiskCtrlPlan.rows.length > 0)
                todoRisk.insertRiskCtrlPlan.rows.map((item, index) => {
                    item.mydate = state.getDate(item.signDate);
                });

            state.todoRiskList = todoRisk
        },
        SHOW_FILTER(state, data) {
            state.showFilter = data
        }
    },
    actions: {
        async riskTodo({ commit }, param) {
            const res = await api.mytodo(param);
            commit('RISK_TODO', res)
            return
        },
        async riskTodoRun({ commit }, param) {
            const res = await api.todorun(param);
            commit('RISK_TODO_RUN', res)
            return
        },
        async todorisk({ commit }, param) {
            const res = await api.todorisk(param);
            commit('TODO_RISK', res)
            return
        },
        showFilter({ commit }, param) {
            commit('SHOW_FILTER', param)
            return
        }
    }
}

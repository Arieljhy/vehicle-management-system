import api from '@/common/api'
import { manageAuthlogout } from '../../common/api/operational/operational';
import { versionData } from "@/assets/js/versionData.js";
const commonData = versionData[process.env.VUE_APP_CITY]
const userInfo = sessionStorage.getItem(commonData.userInfo) != 'undefined' ? JSON.parse(sessionStorage.getItem(commonData.userInfo)) : {}

export default {
  state: {
    isManageSystem: !!JSON.parse(sessionStorage.getItem("isManageSystem")),
    userInfo,
    tips: [],
    infoDropdown: {
      changePwd: false,
    },
    reloginDialog: false,
    menus: !!JSON.parse(sessionStorage.getItem("isManageSystem")) ? JSON.parse(sessionStorage.getItem("idi") || "[]").menus : [],
    control: [],
    hasNews: true,
    showDialog: false,
    loading: false,
    selects: {
      data: {
        IDI_PROJECT_TYPES_shanghai: []
      }
    },
    insOrg: {},
    districts: {},//省级
    citys: {}, //城市级
    countys: {},//当前区
    projectSummary: {
      allInsuranceCoverage:{},
      allClause:{},
      underwritingInformation: {//承保信息
        insBasicInfoDO: {
          isMainIns:'',
          contractType:''
        }, //承保基本信息
        insReinsuranceDOList: [],// 承保再保列表
        insCoinsuranceDOList: [],// 承保共保列表
        mainInsLiabilitiesDOList: [],// 承保主险
        otherInsLiabilitiesDOList: []// 承保附加险
      },
      copyUnderwriting: {
        mainInsLiabilitiesDOList: [],// 承保主险
        otherInsLiabilitiesDOList: []// 承保附加险
      },
      basicBstablish: {//基本信息、报建信息
        prjBasicInfoDO: {
          district: ''
        },
        prjConstructionInfoDO: {},
        prjSingleUnitsDOList: {
          rows: [],
          total: 0,
          rowList: []
        },
        prjConstructionLicensesDOList: [],
        constructionList:[]
      },
      riskPlan: {//风险检查工作计划,
        riskManagementPlanBigDO: {},
        userDO: []
      },
      riskReportList: {},//风险评估报告列表
      riskEventsList: {}, //风险事件列表
      riskFinalReport: {
        riskReportLastDO: {},
        riskManagementPlanBigDO: {},
        riskReportDO: {}
      }, //风险最终检查报告
      insuranceCoverage: {
        insBasicInfoCompletedDO: {},
        insCoinsuranceCompletedDOList: [],//竣工共保信息集合
        insReinsuranceCompletedDOList: [],//竣工再保信息集合
        mainInsLiabilitiesDOList: [],//竣工主险责任范围信息集合
        addInsLiabilitiesDOList: [],//竣工附加险险责任范围信息集合
      }, //保险责任范围说明书
      copyInsuranceCoverage: {
        mainInsLiabilitiesDOList: [],// 竣工主险责任范围信息集合
        addInsLiabilitiesDOList: []// 竣工附加险险责任范围信息集合
      },
      projectClaims: {}, //项目理赔列表
      projectReturns: {}, //项目回访列表
      insuranceReview: {
        insuranceReview: {},//竣工审核
        newInsuranceReview: {
          status: '',
          taskEndTime: new Date(),
          projectId: '',
          chsAssignee: JSON.parse(sessionStorage.getItem(commonData.userInfo)) ? JSON.parse(sessionStorage.getItem(commonData.userInfo)).username : '',
          orgName: (sessionStorage.getItem('eidi.ins') != 'undefined' && sessionStorage.getItem('eidi.ins') != null) ? JSON.parse(sessionStorage.getItem('eidi.ins')).orgName : '',
          roleType: JSON.parse(sessionStorage.getItem(commonData.userInfo)) ? JSON.parse(sessionStorage.getItem(commonData.userInfo)).roleType : '',
          ruleTypes: [],
          comment: ''
        },
        checkRiskCtrlPlan: {},//审核风控管理计划
        newCheckRiskCtrlPlan: {
          status: '', taskEndTime: new Date(), projectId: '',
          chsAssignee: JSON.parse(sessionStorage.getItem(commonData.userInfo)) ? JSON.parse(sessionStorage.getItem(commonData.userInfo)).username : '',
          orgName: (sessionStorage.getItem('eidi.ins') != 'undefined' && sessionStorage.getItem('eidi.ins') != null) ? JSON.parse(sessionStorage.getItem('eidi.ins')).orgName : '',
          roleType: JSON.parse(sessionStorage.getItem(commonData.userInfo)) ? JSON.parse(sessionStorage.getItem(commonData.userInfo)).roleType : '',
          ruleTypes: [],
          comment: ''
        },
        underwrite: {},//保险审核
        newUnderwrite: {
          status: '', taskEndTime: new Date(), projectId: '',
          chsAssignee: JSON.parse(sessionStorage.getItem(commonData.userInfo)) ? JSON.parse(sessionStorage.getItem(commonData.userInfo)).username : '',
          orgName: (sessionStorage.getItem('eidi.ins') != 'undefined' && sessionStorage.getItem('eidi.ins') != null) ? JSON.parse(sessionStorage.getItem('eidi.ins')).orgName : '',
          roleType: JSON.parse(sessionStorage.getItem(commonData.userInfo)) ? JSON.parse(sessionStorage.getItem(commonData.userInfo)).roleType : '',
          ruleTypes: [],
          tips: '',
          checkMsg: '',
          comment: ''
        },
        projectId: ''//监听
      }, //保险审核
    },
    copyProjectSummary: {
      prjBasicInfoDO: {},
      prjSingleUnitsDOList: {
        rows: [],
        total: 0,
        rowList: []
      },
      prjConstructionInfoDO:{},
      getUnderwritingInformation:{}
    },
    orgId: {
      wyOrgList: [], //物业
      insOrgList: [], //保险公司
      bldOrgList: [], //开发商、建设单位
      rinsOrgList: [], //再保险公司
      tisOrgList: [], //风险公司
      sinsOrgList: [], //共保险公司
      opOrgList: [], //运营方
      zbOrgList: [], //总包单位
      kcOrgList: [], // 勘察单位
      jlOrgList: [], // 监理单位
      sjOrgList: [], // 设计单位
      ownOrgList: [], // 业主
      govOrgList: [], // 监管机构
    },
    insOrgList: []
  },
  mutations: {
    SET_INS_ORG_LIST(state, res) {
      res.map((item, index) => {
        item.select = false;
      });
      state.insOrgList = res;

    },
    TOGGLE_ISMANAGESYSTEM(state, isManageSystem) {
      sessionStorage.setItem('isManageSystem', isManageSystem)
      state.isManageSystem = isManageSystem;
    },
    SET_USERINFO(state, userInfo) {
      state.userInfo = userInfo;
    },
    LOGIN(state, res) {
      if (res.data) {
        state.userInfo = res.data
        sessionStorage.setItem(commonData.userInfo, JSON.stringify(res.data))
        sessionStorage.setItem(commonData.token, res.token)
        sessionStorage.setItem(commonData.hasBIAuthority, res.hasBIAuthority)
        state.projectSummary.insuranceReview.newInsuranceReview = {
          status: '',
          taskEndTime: new Date(),
          projectId: '',
          chsAssignee: JSON.parse(sessionStorage.getItem(commonData.userInfo)).username,
          orgName: (sessionStorage.getItem('eidi.ins') != 'undefined' && sessionStorage.getItem('eidi.ins') != null) ? JSON.parse(sessionStorage.getItem('eidi.ins')).orgName : '',
          roleType: JSON.parse(sessionStorage.getItem(commonData.userInfo)).roleType,
          ruleTypes: [],
          comment: ''
        }
        state.projectSummary.insuranceReview.newCheckRiskCtrlPlan = {
          status: '', taskEndTime: new Date(), projectId: '',
          chsAssignee: JSON.parse(sessionStorage.getItem(commonData.userInfo)).username,
          orgName: (sessionStorage.getItem('eidi.ins') != 'undefined' && sessionStorage.getItem('eidi.ins') != null) ? JSON.parse(sessionStorage.getItem('eidi.ins')).orgName : '',
          roleType: JSON.parse(sessionStorage.getItem(commonData.userInfo)).roleType,
          ruleTypes: [],
          comment: ''
        }
        state.projectSummary.insuranceReview.newUnderwrite = {
          status: '', taskEndTime: new Date(), projectId: '',
          chsAssignee: JSON.parse(sessionStorage.getItem(commonData.userInfo)).username,
          orgName: (sessionStorage.getItem('eidi.ins') != 'undefined' && sessionStorage.getItem('eidi.ins') != null) ? JSON.parse(sessionStorage.getItem('eidi.ins')).orgName : '',
          roleType: JSON.parse(sessionStorage.getItem(commonData.userInfo)).roleType,
          ruleTypes: [],
          tips: '',
          checkMsg: '',
          commentL: ''
        }
      }
    },
    GITTIPS(state, res) {
      state.tips = res.data
    },
    GET_MENU(state, res) {
      if (res) {
        state.menus = res.data
        state.isManageSystem && sessionStorage.setItem("idi", JSON.stringify({ menus: res.data }));
        state.control = res.perms
      }
    },
    SHOW_DIALOG(state, res) {
      state.showDialog = res
    },
    HAS_NEWS(state, res) {
      state.hasNews = res
    },
    RELOGIN_DIALOG(state, res) {
      state.reloginDialog = res
    },
    //基础数据
    SELECTS(state, res) {
      res.data.IDI_RISK_EVENT_LEVEL.map((item, index) => {
        item.text = item.dictValue,
          item.value = item.dictKey
      })
      res.data.IDI_RISK_EVENT_TYPE.map((item, index) => {
        item.text = item.dictValue,
          item.value = item.dictKey
      })
      state.selects = res

    },
    DISTRICTS(state, res) {
      if (res) {
        state.districts = res.data
        for (let item of res.data) {
          if (item.province === commonData.province) {
            state.citys = item.city
            state.countys = item.city[0].area
          }
        }
      }
    },
    LOADING(state, res) {
      state.loading = res
    },
    UNDERWRITINGINFORMATION(state, res) {
      let obj = { ...res }
      state.projectSummary.underwritingInformation = obj
      state.projectSummary.allClause=JSON.parse(JSON.stringify(obj))
      // 金额字段不能为空
      state.projectSummary.underwritingInformation.insBasicInfoDO.totalPremium = obj.insBasicInfoDO.totalPremium || 0
      state.projectSummary.underwritingInformation.insBasicInfoDO.totalCoverage = obj.insBasicInfoDO.totalCoverage || 0
      state.projectSummary.underwritingInformation.insBasicInfoDO.deductibleAmount = obj.insBasicInfoDO.deductibleAmount || 0
      state.projectSummary.underwritingInformation.insBasicInfoDO.list = "001"
      if(state.projectSummary.underwritingInformation.insBasicInfoDO.isMainIns == '' ||  !state.projectSummary.underwritingInformation.insBasicInfoDO.isMainIns) {
        state.projectSummary.underwritingInformation.insBasicInfoDO.isMainIns = "Y"
      } 
      if(state.projectSummary.underwritingInformation.insBasicInfoDO.contractType == '' ||  !state.projectSummary.underwritingInformation.insBasicInfoDO.contractType) {
        state.projectSummary.underwritingInformation.insBasicInfoDO.contractType = "NEW"
      } 
      if(state.projectSummary.underwritingInformation.insBasicInfoDO.contractType == "NEW"){
        let mainTable = [];
        let otherTable = [];
        for (let item of obj.mainInsLiabilitiesDOList) {
          if (item.selected == 'Y') {
            mainTable.push(item)
          }
        }
        for (let item1 of obj.otherInsLiabilitiesDOList) {
          if (item1.selected == 'Y') {
            otherTable.push(item1)
          }
        }
        //勾选状态赋值
        state.projectSummary.underwritingInformation.mainInsLiabilitiesDOList = mainTable
        state.projectSummary.underwritingInformation.otherInsLiabilitiesDOList = otherTable
  
        //复制初始数据，用来对比用户时候修改
        state.copyProjectSummary.getUnderwritingInformation = JSON.parse(JSON.stringify(state.projectSummary.underwritingInformation))
        //全部数据
        state.projectSummary.copyUnderwriting.mainInsLiabilitiesDOList = res.mainInsLiabilitiesDOList
        state.projectSummary.copyUnderwriting.otherInsLiabilitiesDOList = res.otherInsLiabilitiesDOList
      }else if(state.projectSummary.underwritingInformation.insBasicInfoDO.contractType=='OLD'){
        let mainTable = [];
        let otherTable = [];
        for (let item of obj.oldmainInsLiabilitiesDOList) {
          if (item.selected == 'Y') {
            mainTable.push(item)
          }
        }
        for (let item1 of obj.oldotherInsLiabilitiesDOList) {
          if (item1.selected == 'Y') {
            otherTable.push(item1)
          }
        }
        //勾选状态赋值
        state.projectSummary.underwritingInformation.mainInsLiabilitiesDOList = mainTable
        state.projectSummary.underwritingInformation.otherInsLiabilitiesDOList = otherTable
        //复制初始数据，用来对比用户时候修改
        state.copyProjectSummary.getUnderwritingInformation = JSON.parse(JSON.stringify(state.projectSummary.underwritingInformation))
        //全部数据
        state.projectSummary.copyUnderwriting.mainInsLiabilitiesDOList = res.oldmainInsLiabilitiesDOList
        state.projectSummary.copyUnderwriting.otherInsLiabilitiesDOList = res.oldotherInsLiabilitiesDOList
      }
    },
    POLICY(state,res){
      //勾选状态赋值
      if(res=='NEW'){
        state.projectSummary.underwritingInformation.mainInsLiabilitiesDOList = []
        state.projectSummary.underwritingInformation.otherInsLiabilitiesDOList = []
      //全部数据
      state.projectSummary.copyUnderwriting.mainInsLiabilitiesDOList = state.projectSummary.allClause.mainInsLiabilitiesDOList
      state.projectSummary.copyUnderwriting.otherInsLiabilitiesDOList = state.projectSummary.allClause.otherInsLiabilitiesDOList
      }else{
        state.projectSummary.underwritingInformation.mainInsLiabilitiesDOList = []
        state.projectSummary.underwritingInformation.otherInsLiabilitiesDOList = []
      //全部数据
      state.projectSummary.copyUnderwriting.mainInsLiabilitiesDOList = state.projectSummary.allClause.oldmainInsLiabilitiesDOList
      state.projectSummary.copyUnderwriting.otherInsLiabilitiesDOList = state.projectSummary.allClause.oldotherInsLiabilitiesDOList
      }
    },
    BASICBSTABLISH(state, res) {
      state.projectSummary.basicBstablish.prjConstructionInfoDO = res.data.prjConstructionInfoDO
      state.projectSummary.basicBstablish.prjBasicInfoDO = res.data.prjBasicInfoDO
      //复制初始数据，用来对比用户时候修改
      state.copyProjectSummary.prjConstructionInfoDO = JSON.parse(JSON.stringify(res.data.prjConstructionInfoDO))
      state.copyProjectSummary.prjBasicInfoDO = JSON.parse(JSON.stringify(res.data.prjBasicInfoDO))
      state.projectSummary.basicBstablish.prjConstructionLicensesDOLists = res.data.prjConstructionLicensesDOList;
        state.projectSummary.basicBstablish.constructionList=res.data.prjConstructionLicensesDOList
    },
    RISKPLAN(state, res) {
      state.projectSummary.riskPlan = res.data
    },
    RISKREPORTLIST(state, res) {
      state.projectSummary.riskReportList = res.data
    },
    RISKEVENTSLIST(state, res) {
      state.projectSummary.riskEventsList = res.data
    },
    RISKFINALREPORT(state, res) {
      if(res.code==0){
        state.projectSummary.riskFinalReport = res.data
        state.projectSummary.riskFinalReport.sqlstatus = 1
      }else {
        state.projectSummary.riskFinalReport.sqlstatus = 0
      }
    },
    INSURANCECOVERAGE(state, res) {
      state.projectSummary.insuranceCoverage = res.data
      state.projectSummary.allInsuranceCoverage=JSON.parse(JSON.stringify(res.data))
      state.projectSummary.insuranceCoverage.insBasicInfoCompletedDO.list = '555'
      if( state.projectSummary.insuranceCoverage.insBasicInfoCompletedDO.contractType=='NEW'){
      state.projectSummary.copyInsuranceCoverage.mainInsLiabilitiesDOList = res.data.mainInsLiabilitiesDOList
      state.projectSummary.copyInsuranceCoverage.addInsLiabilitiesDOList = res.data.addInsLiabilitiesDOList
      let mainTable = [];
      let otherTable = [];
      for (let item of res.data.mainInsLiabilitiesDOList) {
        if (item.selected == 'Y') {
          mainTable.push(item)
        }
      }
      for (let item1 of res.data.addInsLiabilitiesDOList) {
        if (item1.selected == 'Y') {
          otherTable.push(item1)
        }
      }
      //勾选状态赋值
      state.projectSummary.insuranceCoverage.mainInsLiabilitiesDOList1 = mainTable
      state.projectSummary.insuranceCoverage.addInsLiabilitiesDOList1 = otherTable
      }else{
        state.projectSummary.copyInsuranceCoverage.mainInsLiabilitiesDOList = res.data.oldmainInsLiabilitiesDOList
        state.projectSummary.copyInsuranceCoverage.addInsLiabilitiesDOList = res.data.oldaddInsLiabilitiesDOList
        let mainTable = [];
        let otherTable = [];
        for (let item of res.data.oldmainInsLiabilitiesDOList) {
          if (item.selected == 'Y') {
            mainTable.push(item)
          }
        }
        for (let item1 of res.data.oldaddInsLiabilitiesDOList) {
          if (item1.selected == 'Y') {
            otherTable.push(item1)
          }
        }
        //勾选状态赋值
        state.projectSummary.insuranceCoverage.mainInsLiabilitiesDOList1 = mainTable
        state.projectSummary.insuranceCoverage.addInsLiabilitiesDOList1 = otherTable
      }
    },
    INSURANCECOVERAGEPOLICY(state,res){
      //勾选状态赋值
      if(res=='NEW'){
      state.projectSummary.insuranceCoverage.mainInsLiabilitiesDOList1 = []
      state.projectSummary.insuranceCoverage.addInsLiabilitiesDOList1 = []
      //全部数据
      state.projectSummary.copyInsuranceCoverage.mainInsLiabilitiesDOList = state.projectSummary.allInsuranceCoverage.mainInsLiabilitiesDOList
      state.projectSummary.copyInsuranceCoverage.addInsLiabilitiesDOList =state.projectSummary.allInsuranceCoverage.addInsLiabilitiesDOList
      }else{
        state.projectSummary.insuranceCoverage.mainInsLiabilitiesDOList1 = []
        state.projectSummary.insuranceCoverage.addInsLiabilitiesDOList1 = []
      //全部数据
      state.projectSummary.copyInsuranceCoverage.mainInsLiabilitiesDOList = state.projectSummary.allInsuranceCoverage.oldmainInsLiabilitiesDOList
      state.projectSummary.copyInsuranceCoverage.addInsLiabilitiesDOList = state.projectSummary.allInsuranceCoverage.oldaddInsLiabilitiesDOList
      }
    },
    PROJECTCLAIMS(state, res) {
      state.projectSummary.projectClaims = res.data
    },
    PROJECTRETURNS(state, res) {
      state.projectSummary.projectReturns = res.data
    },
    BUILDINGINFO(state, res) {
      state.projectSummary.basicBstablish.prjSingleUnitsDOList.rowList = res.data.rows;
      state.projectSummary.basicBstablish.prjSingleUnitsDOList.total = res.data.total;
      state.copyProjectSummary.prjSingleUnitsDOList.rowList = res.data.rows
    },
    INSURANCEREVIEW(state, res) {
      // 执行前清空缓存
      state.projectSummary.insuranceReview.insuranceReview = {}
      state.projectSummary.insuranceReview.checkRiskCtrlPlan = {}
      state.projectSummary.insuranceReview.underwrite = {}
      if (res.data && res.data.length > 0) {
        res.data.map((item, index) => {
          state.projectSummary.insuranceReview[item.taskName] = item
          if (item.projectId) {
            state.projectSummary.insuranceReview.projectId = item.projectId//监听projectId
          }
        })
      }
    },
    //保险审核提示信息
    INSURANCEREVIEWTIPS(state, res) {
      state.projectSummary.insuranceReview.newUnderwrite.tips = res.msg
    },
    CHECKRULEGETMSG(state, res) {
      let insMseeage = "";
      for (var i in res.errMsg) {
        insMseeage = insMseeage + res.errMsg[i] + ';';
      }
      state.projectSummary.insuranceReview.newUnderwrite.checkMsg = insMseeage.substring(0, insMseeage.length - 1)
    },
    GETORGID(state, res) {
      state.orgId = res.data
    },
    CHECKEDMAINOTHER(state, data) {
      if (data.flag == 'main') {
        state.projectSummary.underwritingInformation.mainInsLiabilitiesDOList = data.val
      } else if (data.flag == "other") {
        state.projectSummary.underwritingInformation.otherInsLiabilitiesDOList = data.val
      } if (data.flag == 'mainRisk') {
        data.val.map((item)=>{
          item.selected='Y'
        })
        state.projectSummary.insuranceCoverage.mainInsLiabilitiesDOList = data.val
      } else if (data.flag == "additionalRisk") {
        data.val.map((item)=>{
          item.selected='Y'
        })
        state.projectSummary.insuranceCoverage.addInsLiabilitiesDOList = data.val
      }
    },
    ADDCOIREI(state, flag) {
      if (flag == 'coinsurance') {
        state.projectSummary.underwritingInformation.insCoinsuranceDOList.push({ coinsPercent: 0, indivPerformance: 0 })
      } else if (flag == "reinsurance") {
        state.projectSummary.underwritingInformation.insReinsuranceDOList.push({ reinsPercent: 0 })
      } else if (flag == "coinsuranceCoverage") {
        state.projectSummary.insuranceCoverage.insCoinsuranceCompletedDOList = state.projectSummary.insuranceCoverage.insCoinsuranceCompletedDOList || []
        state.projectSummary.insuranceCoverage.insCoinsuranceCompletedDOList.push({})
      } else if (flag == "reinsuranceCoverage") {
        state.projectSummary.insuranceCoverage.insReinsuranceCompletedDOList = state.projectSummary.insuranceCoverage.insReinsuranceCompletedDOList || []
        state.projectSummary.insuranceCoverage.insReinsuranceCompletedDOList.push({})
      }
    },
    SHOWINFO(state, flag) {
      state.infoDropdown = flag
    },
    INSORG(state, res) {
      state.insOrg = res.data
      sessionStorage.setItem('eidi.ins', JSON.stringify(res.data))

      state.projectSummary.insuranceReview.newInsuranceReview.
        orgName = JSON.parse(sessionStorage.getItem('eidi.ins')).orgName;

      state.projectSummary.insuranceReview.newCheckRiskCtrlPlan.
        orgName = JSON.parse(sessionStorage.getItem('eidi.ins')).orgName;
      state.projectSummary.insuranceReview.newUnderwrite
        .orgName = JSON.parse(sessionStorage.getItem('eidi.ins')).orgName;
    }


  },
  actions: {
    async getInsOrgList({ commit }, res) {
      commit('SET_INS_ORG_LIST', res)
    },

    async login({ commit }, param) {
      const res = await api.login(param)
      commit('LOGIN', res)
      commit('TOGGLE_ISMANAGESYSTEM', false);
      return res
    },
    async manageLoginCas({ commit }, params) {
      const res = await api.login(params);
      if(res.code=="0"){
        commit('TOGGLE_ISMANAGESYSTEM', true);
        commit('SET_USERINFO', res.data);
        sessionStorage.setItem(commonData.userInfo, JSON.stringify(res.data))
      }
      
      const menus = [
        { childrens: null, component: null, icon: null, name: null, path: "/monitoring", title: "首页" },
        { childrens: null, component: null, icon: null, name: null, path: "/manageSystem/userManage", title: "用户管理" },
        { childrens: null, component: null, icon: null, name: null, path: "/manageSystem/tenantManage", title: "租户管理" },
        { childrens: null, component: null, icon: null, name: null, path: "/manageSystem/ODS", title: "ODS保单" },
        { childrens: null, component: null, icon: null, name: null, path: "/manageSystem/tenantProcessSetting", title: "应用系统流程管理" },
        { childrens: null, component: null, icon: null, name: null, path: "/manageSystem/timingTask", title: "定时任务" },
        { childrens: null, component: null, icon: null, name: null, path: "/manageSystem/rolePermissionConfiguration", title: "角色权限配置" },
      ]
      commit('GET_MENU', { data: menus, perms: [] })
      return res
    },
    async manageAuthlogout() {
      sessionStorage.clear();
      // sessionStorage.setItem(commonData.userInfo, "undefined")
      // sessionStorage.setItem('eidi.ins', "undefined")
      // sessionStorage.setItem('idi',JSON.stringify({menu:[]}))
    },
    async getMenu({ commit }) {
      const res = await api.menu()
      commit('GET_MENU', res)
    },
    async selects({ commit }) {
      const res = await api.selects()
      commit('SELECTS', res)
    },
    async getInsOrg({ commit }, param) {
      const res = await api.insOrg(param)
      commit('INSORG', res)
    },
    async districts({ commit }) {
      const res = await api.districts()
      commit('DISTRICTS', res)
    },
    async underwritingInformation({ commit }, param) {
      const res = await api.underwritingInformation(param)
      commit('UNDERWRITINGINFORMATION', res.data)
    },
    async basicBstablish({ commit }, param) {
      const res = await api.basicBstablish(param)
      commit('BASICBSTABLISH', res)
    },
    async riskPlan({ commit }, param) {
      const res = await api.riskPlan(param)
      commit('RISKPLAN', res)
    },
    async riskReportList({ commit }, param) {
      const res = await api.riskReportList(param)
      commit('RISKREPORTLIST', res)
    },
    async riskEventsList({ commit }, param) {
      const res = await api.riskEventsList(param)
      commit('RISKEVENTSLIST', res)
    },
    async riskFinalReport({ commit }, param) {
      const res = await api.finalRiskCheck(param)
      commit('RISKFINALREPORT', res)
    },
    async insuranceCoverage({ commit }, param) {
      const res = await api.insuranceCoverage(param)
      commit('INSURANCECOVERAGE', res)
    },
    async projectClaims({ commit }, param) {
      const res = await api.projectClaims(param)
      commit('PROJECTCLAIMS', res)
    },
    async projectReturns({ commit }, param) {
      const res = await api.projectReturns(param)
      commit('PROJECTRETURNS', res)
    },
    async buildingInfo({ commit }, param) {
      const res = await api.buildingInfo(param)
      commit('BUILDINGINFO', res)
    },
    async getOrgId({ commit }, param) {
      const res = await api.getOrgId(param)
      commit('GETORGID', res)
    },
    async insuranceReview({ commit }, param) {
      const res = await api.insuranceReview(param)
      commit('INSURANCEREVIEW', res)
    },
    async insuranceReviewTips({ commit }, param) {
      const res = await api.insuranceReviewTips(param)
      commit('INSURANCEREVIEWTIPS', res)
    },
    checkRuleGetMsg({ commit }, param) {
      commit('CHECKRULEGETMSG', param)
    },
    async getTips({ commit }, param) {
      const res = await api.getTips(param)
      commit('GITTIPS', res)
    },
    reloginDialog({ commit }, res) {
      commit('RELOGIN_DIALOG', res)
    },
    dialog({ commit }, res) {
      commit('SHOW_DIALOG', res)
    },
    hasNews({ commit }, res) {
      commit('HAS_NEWS', res)
    },
    loading({ commit }, res) {
      commit('LOADING', res)
    }
  }
}

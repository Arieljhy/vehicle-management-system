import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import app from './modules/app'
import riskTodo from './modules/riskTodo'
import common from './modules/common'
import riskManagement from './modules/riskManagement'
import claimsForum from './modules/claimsForum'
Vue.use(Vuex)
const store = new Vuex.Store({
  modules: {
    app,
    riskTodo,
    common,
    riskManagement,
    claimsForum
  },
  getters
})

export default store

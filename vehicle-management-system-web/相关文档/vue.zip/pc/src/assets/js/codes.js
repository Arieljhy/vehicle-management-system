//报错提示
export const errMsg = [
  { code: 403, value: '您没有访问此功能的权限' },
  { code: 400, value: '服务器不理解请求的语法' },
  { code: 404, value: '服务器找不到请求地址' },
  { code: 408, value: '服务器等候请求时发生超时' },
  { code: 500, value: '服务器遇到错误，无法完成请求' },
  { code: 501, value: '服务器不具备完成请求的功能' },
  { code: 502, value: '错误网关' },
  { code: 503, value: '服务器目前无法使用(由于超载或停机维护)' },
  { code: 504, value: '网关超时' },
  { code: 505, value: '服务器不支持请求中所用的 HTTP 协议版本' },
  { code: 0, value: '网关超时' },
]
export const projectProgress = [
  { code: 4, value: '施工许可证待审核', check: false },
  { code: 1, value: '项目施工中', check: false },
  { code: 2, value: '项目已竣工', check: false },
  { code: 3, value: '项目理赔中', check: false },
]
//保单版本
export const insuranceVersion = [
  { code: "NEW", value: "新保单" },
  { code: "OLD", value: "旧保单" },
]
//保单类型
export const insuranceType = [
  { code: "M", value: "主险" },
  { code: "A", value: "附加险" },
]

//机构类型
export const orgType = [
  { orgType: "BLD", value: "开发商、建设单位", code: 'bldOrgList' },
  { orgType: "TIS", value: "风险公司", code: 'tisOrgList' },
  { orgType: "SGF", value: "总包单位", code: 'zbOrgList' },
  { orgType: "KC", value: "勘察单位", code: 'kcOrgList' },
  { orgType: "JL", value: "监理单位", code: 'jlOrgList' },
  { orgType: "SJ", value: "设计单位", code: 'sjOrgList' },
]

//租户数据库状态
export const status = [
  {code:"0",value:"未开通"},
  {code:"1",value:"开通"},
  {code:"2",value:"可用"},
  {code:"3",value:"禁用"}
]
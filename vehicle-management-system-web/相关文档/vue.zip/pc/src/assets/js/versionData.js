
//公共配置数据
export const versionData = {
    maanshan: {
        province: '安徽省',
        city: '马鞍山市',
        control: 'maanshan',
        lesseeId: 'eidi-maanshan',
        userInfo: 'eidi_maanshan',
        bgheight: 44,//文字的高度
        phone: '如有疑问，请拨打咨询电话：021-68577274',
        coordinate: [118.507405, 31.708667],//默认经纬度坐标
        base: 'anhui/maanshan',
        token: 'eidi_maanshan_token',
        hasBIAuthority:'eidi-maanshan-hasBIAuthority',
        units: [
            "马鞍山市住房和城乡建设局",
            "马鞍山市建筑管理处",
            "中国银行保险监督管理委员会马鞍山监管分局",
            "马鞍山市地方金融监督管理局",
        ],
        orgList: [
            {
                href: 'http://www.mohurd.gov.cn',
                address: '中华人民共和国住房和城乡建设部'
            },
            {
                href: 'http://www.cbirc.gov.cn/cn/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会'
            },
            {
                href: 'http://zjj.mas.gov.cn/',
                address: '马鞍山市住房和城乡建设局'
            },
            {
                href: 'http://www.masgcxx.cn/masjgc/Default.aspx/',
                address: '马鞍山市建筑管理处'
            },
            {
                href: 'http://www.cbirc.gov.cn/branch/anhui/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会安徽监管局'
            },
            {
                href: 'http://ahjr.ah.gov.cn',
                address: '安徽省地方金融监督管理局'
            }
        ]
    },
    beijing: {
        province: '北京市',
        city: '北京市',
        control: 'beijing', //切换版本
        lesseeId: 'eidi-beijing',  //登录数据切换
        userInfo: 'eidi_beijing',
        bgheight: 44,              //units文字的高度
        phone: "如有疑问，请拨打咨询电话：010-66576611",
        coordinate: [116.397405, 39.908667],//默认经纬度坐标
        token: 'eidi_beijing_token',
        base: 'beijing',
        hasBIAuthority:'eidi-beijing-hasBIAuthority',
        units: [
            "北京市住房和城乡建设委员会",
            "中国银行保险监督管理委员会北京监管局",
            "北京市地方金融监督管理局",
            "北京市规划和自然资源委员会"
        ],//北京
        orgList: [
            {
                href: 'http://www.mohurd.gov.cn',
                address: '中华人民共和国住房和城乡建设部'
            },
            {
                href: 'http://www.cbirc.gov.cn/cn/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会'
            },
            {
                href: 'http://zjw.beijing.gov.cn/',
                address: '北京市住房和城乡建设委员会'
            },
            {
                href: 'http://www.cbirc.gov.cn/branch/beijing/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会北京监管局'
            },
            {
                href: 'http://jrj.beijing.gov.cn/',
                address: '北京市地方金融监督管理局'
            },
            {
                href: 'http://ghzrzyw.beijing.gov.cn/',
                address: "北京市规划和自然资源委员会"
            }
        ]
    },
    shanghai: {
        province: '上海市',
        city: '上海市',
        control: 'shanghai',
        lesseeId: 'eidi-shanghai',
        userInfo: 'eidi_shanghai',
        bgheight: 60,//文字的高度
        phone: "如有疑问，请拨打咨询电话：021-58369157",
        coordinate: [121.477405, 31.238667],//默认经纬度坐标
        token: 'eidi_shanghai_token',
        base: 'shanghai',
        hasBIAuthority:'eidi-shanghai-hasBIAuthority',
        units: [
            "上海市住房和城乡建设管理委员会",
            "中国银行保险监督管理委员会上海监管局",
            "上海市地方金融监督管理局",
        ],//上海
        orgList: [
            {
                href: 'http://www.mohurd.gov.cn',
                address: '中华人民共和国住房和城乡建设部'
            },
            {
                href: 'http://www.cbirc.gov.cn/cn/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会'
            },
            {
                href: 'http://zjw.sh.gov.cn/',
                address: '上海市住房和城乡建设管理委员会'
            },
            {
                href: 'http://www.cbirc.gov.cn/branch/shanghai/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会上海监管局'
            },
            {
                href: 'http://jrj.sh.gov.cn/index.html',
                address: '上海市地方金融监督管理局'
            },
        ]
    },
    yangquan: {
        province: '山西省',
        city: '阳泉市',
        control: 'yangquan',
        lesseeId: 'eidi-yangquan',
        userInfo: 'eidi_yangquan',
        bgheight: 60,//文字的高度
        phone: "如有疑问，请拨打咨询电话：021-68577274",
        coordinate: [113.287405, 40.088667],//默认经纬度坐标
        token: 'eidi_yangquan_token',
        base: 'shanxi/yangquan',
        hasBIAuthority:'eidi-yangquan-hasBIAuthority',
        units: [
            "阳泉市住房和城乡建设局",
            "中国银行保险监督管理委员会阳泉监管分局",
            "阳泉市地方金融监督管理局",
        ],//上海
        orgList: [
            {
                href: 'http://www.mohurd.gov.cn',
                address: '中华人民共和国住房和城乡建设部'
            },
            {
                href: 'http://www.cbirc.gov.cn/cn/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会'
            },
            {
                href: 'http://zjj.yq.gov.cn/',
                address: '阳泉市住房和城乡建设局'
            },
            {
                href: 'http://www.cbirc.gov.cn/branch/shanxi/view/pages/index/index.html',
                address: '中国银行保险监督管理委员会山西监管局'
            },
        ]
    }
}

import Vue from 'vue'
import App from './App'
// import 'element-ui/lib/theme-chalk/index.css'
import router from './router'
import store from './store'
import './plugins/element.js'
import './plugins/animate.js'
import echarts from 'echarts'
import api from './common/api'
import '@/assets/js/filter'
import { getValueByCode } from "@/assets/js/utils.js";
import VueAMap from 'vue-amap'
import { versionData } from "@/assets/js/versionData.js";

setTimeout(() => {
  localStorage.clear();
  Vue.use(VueAMap);
}, 0);

Vue.prototype.$echarts = echarts
Vue.config.productionTip = false
Vue.prototype.$api = api
Vue.prototype.$EventBus = new Vue();
Vue.prototype.$messageSuccess = function (msg) {
  Vue.prototype.$message({ ...msg, duration: 5000, type: 'success', showClose: true })
}
Vue.prototype.$messageError = function (msg) {
  Vue.prototype.$message({ ...msg, duration: 5000, type: 'error', showClose: true })
}
Vue.prototype.$getValueByCode = getValueByCode;
Vue.prototype.$getversionData = versionData[process.env.VUE_APP_CITY];

Vue.prototype.$doScrollStyle = () => {
  const eles = document.getElementsByClassName(
    "el-table__body-wrapper is-scrolling-none"
  );
  Array.from(eles).forEach(element => {
    element.classList.add("scroll-content");
  });
}

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

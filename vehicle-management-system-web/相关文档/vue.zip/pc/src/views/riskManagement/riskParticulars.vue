<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
          <el-row>
            <el-col :span="12">
              <el-form-item label="报告名称：">
                <el-input v-model="tableData.name" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="涉及风险事件：">
                <template slot-scope="scope">
                  <el-table
                    class="mc-table"
                    :data="riskReportingData.selectionOfRiskEvents"
                    style="width: 100%"
                    ref="multipleTable"
                  >
                    <el-table-column type="index" label="序号" align="center" width="80"></el-table-column>
                    <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
                    <el-table-column
                      prop="riskEventType"
                      align="center"
                      label="风险事件类型"
                      show-overflow-tooltip
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column
                      prop="riskLevel"
                      align="center"
                      label="风险等级"
                      show-overflow-tooltip
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="最初报告时间" show-overflow-tooltip>
                      <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="建议整改截止日期" show-overflow-tooltip>
                      <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
                    </el-table-column>
                     <el-table-column align="center" label="风险事件编号" width="120" prop="eventIdForUser"></el-table-column>
                    <el-table-column prop="riskEventStatus" align="center" label="业务状态">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                    </el-table-column>
                  </el-table>
                </template>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="承保意见：">
                <el-table class="mc-table" style="width: 100%" :data="riskReportItemTrueDO">
                  <el-table-column prop="clause" align="center" label="保险条款名称"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)" width="150"></el-table-column>
                  <el-table-column prop="type" align="center" label="保险类型" width="150">
                    <template
                      slot-scope="scope"
                    >{{scope.row.type | filterCode(listBaseData.IDI_LIABILITIES_TYPE,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2 ,maxRows: 4}"
                        style="opacity:0.2 color:#3E3A39;"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        :disabled="true"
                        class="tex"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报告人：">
                <el-input v-model="tableData.reporter" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="审核人：">
                <el-input v-model="tableData.reviewer" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="批准人：">
                <el-input v-model="tableData.approver" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报告时间：">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="tableData.reportDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  disabled
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="下载报告：">
              <el-col :span="8">
                <el-input v-model="tableData.fileName" disabled></el-input>
              </el-col>
              <el-col :span="8">
                <el-button
                  size="mini"
                  @click="downloadBtn()"
                  style="margin-left: -90px;"
                  :disabled="disabled"
                >下载</el-button>
              </el-col>
            </el-form-item>
          </el-row>
          <el-row style="text-align: right; margin-top: 70px;margin-bottom: 30px">
            <el-button size="mini" @click="shutbtn()">关闭</el-button>
          </el-row>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import MessageEdit from "@/components/Message.vue";
import { mapGetters, mapActions } from "vuex";
export default {
  components: {
    MessageEdit
  },
  name: "AddNewProject", //风险评估报告详情页
  data() {
    return {
      disabled: true,
      countys: [],
      textarea: "",
      url: "",
      insRemark: "",
      assessmentReportFile: "",
      fileName: "",
      projectId: "", //项目ID
      tableData: [
        {
          startWorkDate: "",
          textarea: "",
          name: "",
          id: ""
        }
      ],
      riskReportItemTrueDO: [],
      riskReportingData: {
        selectionOfRiskEvents: []
      }
    };
  },
  computed: {
    ...mapGetters(["district", "listBaseData"])
  },
  created() {
    this.riskAssessment();
    this.riskEventFunction();
  },
  methods: {
    async riskAssessment() {
      this.id = this.$route.query.id;
      const res = await this.$api.riskDetails(this.id);
      this.tableData = res.data.riskReportDO;
      this.url = this.tableData.assessmentReportFile;
      this.riskReportItemTrueDO = res.data.riskReportItemTrueDO;
      this.projectId = this.tableData.projectId;
      if (this.tableData.fileName) {
        this.disabled = false;
      }
    },
    //请求风险事件数据(勾选)
    async riskEventFunction() {
      const rid = {
        reportId: this.$route.query.reportId
      };
      const res = await this.$api.riskEvents(rid);
      this.riskReportingData.selectionOfRiskEvents = res.data;
    },
    shutbtn() {
      //关闭按钮
      this.$router.go(-1);
    },
    downloadBtn() {
      //文件下载
      var a = document.createElement("a");
      var filename = this.tableData.fileName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    }
  }
};
</script>
<style scoped lang="scss">
.el-form-item--mini {
  margin-bottom: 12px;
}
.rid {
  margin-right: 150px;
}
.lucency {
  opacity: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
}
.tex {
  width: 318px;
}
</style>
<template>
  <div>
    <el-dialog
      class="dialog"
      title="风险评估报告"
      :visible.sync="dialogVisible"
      :before-close="handleClose"
      :close-on-click-modal="false"
    >
      <!-- 第一项 -->
      <el-row style="margin:0 25px" class="put" v-if="one">
        <el-row style="margin-bottom:8px">
          <el-col :span="18" :offset="6">
            <div class="step">上传报告&填写信息&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
            <div class="step step1">恭喜您已成功上传！</div>
          </el-col>
        </el-row>
        <el-form label-width="100px" size="mini" label-position="left" align="left">
          <!-- 选择类型 -->
          <el-row>
            <el-form-item label="选择报告类型:" class="first">
              <el-col :span="7">
                <el-select v-model="value" placeholder style="width: 200px">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </el-col>
            </el-form-item>
          </el-row>
          <!-- 下拉的第一项 -->
          <div v-if="value=='1'">
            <el-form
              label-width="100px"
              size="mini"
              label-position="left"
              :rules="rules"
              ref="riskReportingData.riskReportDO"
              :model="riskReportingData.riskReportDO"
            >
              <el-row style="margin:10px 0">
                <el-col :span="10">
                  <el-form-item label="报告名称:" prop="name">
                    <el-input v-model="riskReportingData.riskReportDO.name" style="width:200px"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="6">
                  <el-form-item label="上传报告:" prop="fileName">
                    <el-input
                      v-model="riskReportingData.riskReportDO.fileName"
                      disabled
                      style="width:160px"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-col :span="3" style="position: relative; left: 90px">
                    <img v-if="!begin" src="../../assets/imgs/put.png" class="img-upload" />
                    <el-progress v-if="begin" type="circle" :percentage="progress" :width="30"></el-progress>
                    <!-- <img v-if="begin " src="../../assets/imgs/gif.gif" class="img-upload" /> -->
                  </el-col>
                  <el-col :span="21" style="position: relative; left: 80px">
                    <el-upload
                      class="inline-block mlr97"
                      action
                      :http-request="uploadFile"
                      :show-file-list="false"
                    >
                      <el-button size="mini" style="background:#108FEB;color:#fff">上传</el-button>
                    </el-upload>
                    <el-button size="mini" @click="delBtn()">删除</el-button>
                  </el-col>
                </el-col>
              </el-row>
              <el-row style="margin-top:15px">
                <el-col :span="22">
                  <el-form-item label="涉及风险事件:">
                    <el-input
                      disabled
                      v-model="inputs"
                      size="mini"
                      @click.native="refer"
                      placeholder="请选择风险事件"
                    />
                  </el-form-item>
                  <el-button class="tack" icon="el-icon-check" @click="selects"></el-button>
                </el-col>
              </el-row>
              <el-row v-show="tables">
                <el-table
                  class="table"
                  tooltip-effect="light"
                  :data="riskReportingData.riskReportItemDO"
                  style="width: 100%;border:1px #ccc solid"
                >
                  <el-table-column prop="clause" align="center" label="保险条款名称"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                  <el-table-column prop="type" align="center" label="保险类型">
                    <template
                      slot-scope="scope"
                    >{{scope.row.type | filterCode(listBaseData.IDI_LIABILITIES_TYPE,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        size="mini"
                        :autosize=" {maxRows: 2}"
                        style="opacity:0.2 color:#3E3A39;margin: 2px 0"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        class="tex"
                        placeholder="请输入内容"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-row>
              <!-- 涉及风险事件报告 -->
              <el-row v-show="referTable" style="border:1px #ccc solid;margin:15px 0">
                <!-- 搜索 -->
                <el-row>
                  <el-col :span="4" style="margin-top: 7px;margin-right: 35px;">
                    <el-form-item
                      label="查询相关事件:"
                      class="con-head"
                      style="margin-top:5px;margin-bottom:2px"
                    ></el-form-item>
                  </el-col>
                  <el-col :span="14" class="con-head" style="margin-top:5px;margin-bottom:2px">
                    <el-input
                      v-model="refinput"
                      placeholder="请输入风险事件名称/风险事件类型/风险等级"
                      style="margin-top:8px;"
                    >
                      <el-button slot="append" icon="el-icon-search" @click="referSearch"></el-button>
                    </el-input>
                  </el-col>
                </el-row>
                <!-- table -->
                <el-row>
                  <el-table
                    class="table reftable"
                    ref="multipleTable"
                    :data="riskReportingData.searchForRiskEvents"
                    tooltip-effect="dark"
                    @select="checkedList"
                    @select-all="checkedLists"
                    style="width: 100%;"
                  >
                    <el-table-column type="selection" width="45"></el-table-column>
                    <!-- <el-table-column type="index" align="center" label="序号" width="50"></el-table-column> -->
                    <el-table-column
                      type="index"
                      align="center"
                      label="序号"
                      width="50"
                      :index="(index)=>{return(index+1)+(offset-1)*limit}"
                    ></el-table-column>
                    <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
                    <el-table-column prop="riskEventType" align="center" label="风险事件类型">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column prop="riskLevel" align="center" label="风险等级">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column prop="riskFoundTime" align="center" label="最初报告时间">
                      <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
                    </el-table-column>
                    <el-table-column prop="proposedAmendDeadline" align="center" label="建议整改截止时间">
                      <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
                    </el-table-column>
                    <el-table-column
                      align="center"
                      label="风险事件编号"
                      width="120"
                      prop="eventIdForUser"
                    ></el-table-column>
                    <el-table-column prop="riskEventStatus" align="center" label="业务状态">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                    </el-table-column>
                  </el-table>
                </el-row>
                <!-- 分页 -->
                <el-row>
                  <el-pagination
                    small
                    style="text-align:right;margin-bottom:10px"
                    class="page-lucency"
                    layout="prev, pager, next"
                    :total="this.total"
                    :current-page="this.offset"
                    :page-size="this.limit"
                    v-show="this.total!=0"
                    @current-change="handleCurrentChange"
                  ></el-pagination>
                </el-row>
              </el-row>
              <!-- 署名 -->
              <el-row>
                <el-col :span="8">
                  <el-form-item label="报告人:">
                    <el-input
                      v-model="riskReportingData.riskReportDO.reporter"
                      @click.native="openAgency({title: '报告人', type: 'BGR',num:'2' })"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="审核人:">
                    <el-input
                      v-model="riskReportingData.riskReportDO.reviewer"
                      @click.native="openAgency({title: '审核人', type: 'SHR',num:'2' })"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="批准人:">
                    <el-input
                      v-model="riskReportingData.riskReportDO.approver"
                      @click.native="openAgency({title: '批准人', type: 'PZR',num:'2' })"
                    ></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row style="margin-top:10px;">
                <el-col :span="8">
                  <el-form-item label="报告出具时间:" prop="reportDate">
                    <el-date-picker
                      type="date"
                      size="mini"
                      :picker-options="dateValid"
                      style="width:141.66px"
                      placeholder="选择日期"
                      v-model="riskReportingData.riskReportDO.reportDate"
                      value-format="yyyy-MM-dd HH:mm:ss"
                    ></el-date-picker>
                  </el-form-item>
                </el-col>
              </el-row>
              <!-- 保存提交 -->
              <el-row>
                <el-col :span="20">&nbsp;</el-col>
                <el-col :span="2" style="margin-top:21px">
                  <el-button
                    size="mini"
                    type="primary"
                    @click="saveBtn('riskReportingData.riskReportDO')"
                  >保存</el-button>
                </el-col>
                <el-col :span="2" style="margin-top:21px">
                  <el-button
                    size="mini"
                    type="primary"
                    @click="submitBtn('riskReportingData.riskReportDO')"
                  >提交</el-button>
                </el-col>
              </el-row>
            </el-form>
          </div>
          <!-- 下拉的第二项 -->
          <div v-if="value=='2'">
            <el-form
              label-width="100px"
              size="mini"
              label-position="left"
              align="left"
              :rules="rules"
              ref="riskReporting.riskReportDO"
              :model="riskReporting.riskReportDO"
            >
              <el-row style="margin:6px 0">
                <el-col :span="10">
                  <el-form-item label="改正缺陷数量:" prop="faultChangeCount">
                    <el-input v-model.number="riskReporting.riskReportDO.faultChangeCount"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="4">&nbsp;</el-col>
                <el-col :span="10">
                  <el-form-item label="风险管理机构:">
                    <el-input v-model="riskReporting.riskReportDO.tisOrgId" disabled></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row style="margin:6px 0">
                <el-col :span="10">
                  <el-form-item label="开始介入日期:" prop="startWorkDate">
                    <el-date-picker
                      type="date"
                      placeholder="选择日期"
                      v-model="riskReporting.riskReportDO.startWorkDate"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      style="width: 100%;"
                    ></el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :span="4">&nbsp;</el-col>
                <el-col :span="10">
                  <el-form-item label="竣工检查日期:" prop="reportDate">
                    <el-date-picker
                      type="date"
                      placeholder="选择日期"
                      v-model="riskReporting.riskReportDO.reportDate"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      style="width: 100%;"
                    ></el-date-picker>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-form-item label="工程概况:">
                  <el-col :span="24">
                    <el-input
                      type="textarea"
                      :autosize=" {minRows: 4}"
                      placeholder="请输入内容"
                      v-model="riskReporting.riskReportDO.projDesc"
                    ></el-input>
                  </el-col>
                </el-form-item>
              </el-row>
              <el-row style="margin:6px 0">
                <el-form-item label="本报告所涉及的承保范围:">
                  <el-col :span="24">
                    <el-input
                      type="textarea"
                      :autosize=" {minRows: 4}"
                      placeholder="请输入内容"
                      v-model="riskReporting.riskReportDO.reportScope"
                    ></el-input>
                  </el-col>
                </el-form-item>
              </el-row>
              <el-row>
                <el-form-item label="针对承保范围的总体风险评价:" prop="reportScopeNote">
                  <el-col :span="24">
                    <el-input
                      type="textarea"
                      :autosize=" {minRows: 4}"
                      placeholder="请输入内容"
                      v-model="riskReporting.riskReportDO.reportScopeNote"
                    ></el-input>
                  </el-col>
                </el-form-item>
              </el-row>
              <el-row style="margin:10px 0">
                <el-form-item label="保险公司审核意见:" prop="insReviewNote">
                  <el-col :span="24">
                    <el-input
                      type="textarea"
                      :autosize=" {minRows: 4}"
                      placeholder="请输入内容"
                      v-model="riskReporting.riskReportDO.insReviewNote"
                    ></el-input>
                  </el-col>
                </el-form-item>
              </el-row>
              <el-row>
                <el-col :span="10">
                  <el-form-item label="上传报告:" prop="fileName">
                    <el-col :span="18">
                      <el-input v-model="riskReporting.riskReportDO.fileName" disabled></el-input>
                    </el-col>
                    <!-- <el-col :span="1">
                      <img src="../../assets/imgs/put.png" alt="tu" style="width:100%;height:100%" />
                    </el-col>-->
                    <el-col :span="1">
                      <el-upload
                        class="upload-demo"
                        size="mini"
                        action
                        :http-request="uploadFile"
                        :on-change="handleChangeing"
                        :show-file-list="false"
                      >
                        <el-button style="width:55px;height:25px;background:#108FEB;color:#fff">上传</el-button>
                      </el-upload>
                    </el-col>
                  </el-form-item>
                </el-col>
                <el-col :span="4">&nbsp;</el-col>
                <el-col :span="10">
                  <el-form-item label="报告签发日期:" prop="assessmentReportFileDate">
                    <el-date-picker
                      type="date"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="选择日期"
                      v-model="riskReporting.riskReportDO.assessmentReportFileDate"
                      style="width: 100%"
                    ></el-date-picker>
                  </el-form-item>
                </el-col>
              </el-row>
              <!-- 保存提交 -->
              <el-row>
                <el-col :span="22">&nbsp;</el-col>
                <el-col :span="2" style="margin-top:21px">
                  <el-button
                    size="mini"
                    type="primary"
                    @click="examineSubmitBtn('riskReporting.riskReportDO')"
                  >提交</el-button>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </el-form>
      </el-row>
      <!-- 第二项 -->
      <el-row style="margin:0 25px" class="submit" v-if="two">
        <el-row style="margin-bottom:8px">
          <el-col :span="18" :offset="6">
            <div class="step stepTwo1">上传报告&填写信息&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
            <div class="step stepTwo2">恭喜您已成功上传！</div>
          </el-col>
        </el-row>
        <el-row>
          <img src="../../assets/imgs/submit.png" alt="tu" />
          <p v-show="this.riskReportingData.riskReportDO.sqlStatus == 1">您好，您已成功上传</p>
          <p v-show="this.riskReportingData.riskReportDO.sqlStatus == 0">您好，您已成功保存本次上传</p>
        </el-row>
        <el-divider></el-divider>
        <el-row>
          <el-col class="text-left" :span="24">
            <span class="con-title">{{item.projectName}}</span>
          </el-col>
          <el-form>
            <el-col :span="8">
              <el-form-item class="text-left" label="保单号：">
                <div
                  class="policy"
                  :title="item.insContractNo"
                  style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                >{{item.insContractNo}}</div>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="text-left" label="所在区域：">
                <span>{{item.district}}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="text-left" label="是否主承：">
                <span v-if="item.isMainIns == 'Y'">
                  <span>是</span>
                </span>
                <span v-if="item.isMainIns == 'N'">
                  <span>否</span>
                </span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="text-left" label="住宅性质：">
                <span>{{item.dictValue}}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="text-left" label="签单日期：">
                <span>{{item.signDate | filterDate('yyyy-MM-dd')}}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="text-left" label="项目状态：">
                <span>{{item.projectChnStatus}}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="text-left" label="业务状态：">
                <span>{{item.taskChnName}}</span>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
              <el-form-item class="text-left" label="当前处理人：">
                <span>{{item.processRoleId}}</span>
              </el-form-item>
            </el-col>-->
          </el-form>
        </el-row>
      </el-row>
    </el-dialog>
    <el-dialog
      class="dialog"
      :title="title"
      :visible.sync="openVisible"
      width="615px"
      :close-on-click-modal="false"
    >
      <select-agency
        :type="type"
        :title="title"
        @getAngency="getAngency"
        v-if="openVisible"
        :num="num"
        :project="project"
      ></select-agency>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import upload from "@/common/request/index.js";
import SelectAgency from "@/components/selectAgency.vue";
import { log } from "util";
import axios from 'axios';
export default {
  name: "riskEventManagementDialog",
  computed: {
    ...mapGetters(["listBaseData"])
  },
  components: {
    SelectAgency
  },
  props: {
    dialogVisible: Boolean
  },
  data() {
    return {
      progress:0,
      begin: false,
      openVisible: false,
      type: "",
      title: "",
      num: "",
      project: "",
      // 表单校验
      rules: {
        name: [{ required: true, message: "请输入报告名称", trigger: "blur" }],
        fileName: [
          { required: true, message: "请上传报告", trigger: "change" }
        ],
        startWorkDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        reportDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        assessmentReportFileDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        faultChangeCount: [
          { required: true, message: "请输入数量" },
          { type: "number", message: "缺陷数量必须为数字值" }
        ],
        reportScopeNote: [
          { required: true, message: "请输入风险评估", trigger: "blur" }
        ],
        insReviewNote: [
          { required: true, message: "请输入审核意见", trigger: "blur" }
        ]
      },
      name: "",
      input: "",
      // inputs: [],
      inputs: "",
      refinput: "",
      value: "",
      projectId: "",
      fileName: "",
      item: "",
      newArray: [],
      // 分页
      total: 0,
      limit: 5, //每页几条数据
      offset: 1, //第几页
      // 标题的切换
      one: true,
      two: false,
      // 上传风险下拉内容
      options: [
        {
          value: "1",
          label: "上传风险评估报告"
        }
        //  下拉的第二个目前注释掉
        // {
        //   value: '2',
        //   label: '上传最终风险检查报告'
        // }
      ],
      // 上传风险下拉类型切换
      // assess: false,
      // examine: false,
      // 涉及风险事件table的隐显
      tables: true,
      referTable: false,
      fileList: [],
      insRemark: "",
      // 涉及风险事件
      preservationState: 0, //保存状态
      submissionState: 1, //提交状态
      assessmentReportFile: "", //上传文件成功后URL
      // 下拉第一个的form表单
      riskReportingData: {
        riskReportDO: {
          name: "",
          fileName: "",
          reportType: "1"
        },
        riskReportItemDO: [{}], //建议
        selectionOfRiskEvents: undefined,
        searchForRiskEvents: [{}],
        riskEventReportRelDO: []
      },
      // 下拉第二个form表单
      riskReporting: {
        riskReportDO: {
          fileName: "",
          reportType: "2",
          faultChangeCount: "",
          tisOrgId: "",
          startWorkDate: "",
          reportDate: "",
          projDesc: "",
          reportScope: "",
          reportScopeNote: "",
          insReviewNote: ""
        },
        riskManagementPlanBigDO: {
          projectId: ""
        }
      },
      riskBlding: [],
      checkId: [],
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      }
    };
  },
  created() {
    this.value = "1";
    if (this.dialogVisible == true) {
      this.one = true;
      this.two = false;
      this.item = JSON.parse(this.$route.query.item);
      this.projectId = this.$route.query.id;
      this.riskDuty(); // 保险责任范围接口调用
      this.riskEvent(); // 涉及风险事件
    }
  },
  methods: {
    openAgency(data) {
      this.openVisible = true;
      this.type = data.type;
      this.title = data.title;
      this.num = data.num;
      this.project = this.$route.query.id;
    },
    getAngency(value) {
      if (value.type == "BGR") {
        this.riskReportingData.riskReportDO.reporter = value.username;
      } else if (value.type == "SHR") {
        this.riskReportingData.riskReportDO.reviewer = value.username;
      } else if (value.type == "PZR") {
        this.riskReportingData.riskReportDO.approver = value.username;
      }
      this.openVisible = false;
    },
    handleClose() {
      this.$emit("handleClose", this.dialogVisible);
    },
    // 选中
    selects() {
      this.referTable = false;
      this.tables = true;
    },
    refer() {
      this.referTable = true;
      this.tables = false;
    },
    //提交按钮
    submitBtn(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.riskReportingData.riskEventReportRelDO = this.checkId; //选中风险的id
          this.riskReportingData.riskReportDO.sqlStatus = this.submissionState; //页面基础数据
          this.riskReportingData.riskReportDO.assessmentReportFile = this.assessmentReportFile; // 文件的地址
          this.riskReportingData.riskReportDO.assessmentReportFileName = this.assessmentReportFileName; // 文件的名称
          this.riskReportingData.riskReportDO.projectId = this.projectId; // 页面id
          this.riskReportingData.riskReportDO.reportOrgId = JSON.parse(
            sessionStorage.getItem("eidi.ins")
          ).orgId;
          this.saveRequest();
        } else {
          this.$messageError({
            message: "请完善信息"
          });
        }
      });
    },
    // 保存按钮
    saveBtn(formName) {
      this.riskReportingData.riskEventReportRelDO = this.checkId; //选中风险的id
      this.riskReportingData.riskReportDO.sqlStatus = this.preservationState; //页面基础数据 0
      this.riskReportingData.riskReportDO.assessmentReportFile = this.assessmentReportFile; // 文件的地址
      this.riskReportingData.riskReportDO.assessmentReportFileName = this.assessmentReportFileName; // 文件的名称
      this.riskReportingData.riskReportDO.projectId = this.projectId; // 页面id
      this.riskReportingData.riskReportDO.reportOrgId = JSON.parse(
        sessionStorage.getItem("eidi.ins")
      ).orgId;
      this.saveRequest();
    },
    // 检查报告保存提交
    // 提交按钮
    examineSubmitBtn(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.riskReporting.riskReportDO.sqlStatus = this.submissionState; //页面基础数据
          this.riskReporting.riskReportDO.assessmentReportFile = this.assessmentReportFile; // 文件的地址
          this.riskReporting.riskReportDO.assessmentReportFileName = this.assessmentReportFileName; // 文件的名称
          // this.riskReporting.riskReportDO.projectId = this.projectId; // 页面id
          this.riskReporting.riskManagementPlanBigDO.projectId = this.projectId; // 页面id
          this.riskReporting.riskManagementPlanBigDO.reportOrgId = JSON.parse(
            sessionStorage.getItem("eidi.ins")
          ).orgId;
          this.examineSaveRequest();
        } else {
          this.$messageError({
            message: "请完善信息 "
          });
        }
      });
    },
    // 上传文件
    uploadClick() {},
    handleChange(file) {},
    handleChangeing(file) {},
    // 文件上传
    async uploadFile(param) {
      this.begin = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("projectId", this.$route.query.id);
      file.append("fileIcon", "assessmentReportFile");
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this.progress = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.progress=100
          this.$messageSuccess({
            message: "上传成功"
          });
          this.assessmentReportFile = res.data.data.cloudDocId;
          this.riskReportingData.riskReportDO.fileName = res.data.data.fileName;
          this.riskReporting.riskReportDO.fileName = res.data.data.fileName;
        } else {
          this.$messageError({
            message: res.data.msg
          });
        }
        this.begin = false;
      });
      this.progress = 0;
    },
    // 删除
    delBtn() {
      this.riskReportingData.riskReportDO.fileName = "";
      this.assessmentReportFileLast = "";
    },
    // 保险责任范围
    async riskDuty() {
      const keywords = {
        projectId: this.projectId
      };
      const data = await this.$api.riskDuty(keywords);
      this.riskReportingData.riskReportItemDO = data.data.rows;
    },
    // 涉及风险事件
    //请求风险事件数据(全部)
    async riskEvent() {
      const info = {
        projectId: this.projectId,
        fuzzyQuery: this.refinput,
        offset: this.offset,
        limit: this.limit
      };
      const data = await this.$api.riskEvent(info);
      this.total = data.data.total;
      this.riskReportingData.searchForRiskEvents = data.data.rows;
      for (let item of this.checkId) {
        for (let item2 of this.riskReportingData.searchForRiskEvents) {
          if (item == item2.id) {
            setTimeout(() => {
              this.$refs.multipleTable.toggleRowSelection(item2);
            });
          }
        }
      }
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex(item => {
        return item.id == row.id;
      });
      if (isCkeck < 0) {
        for (let [index, item2] of this.riskBlding.entries()) {
          if (item2 == row.riskEventName) {
            this.$delete(this.riskBlding, index);
            this.inputs = this.riskBlding.join();
          }
        }
        for (let [index, item2] of this.checkId.entries()) {
          if (item2 == row.id) {
            this.$delete(this.checkId, index);
          }
        }
      } else {
        this.riskBlding.push(row.riskEventName);
        this.checkId.push(row.id);
        this.inputs = this.riskBlding.join();
      }
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.checkId) {
            if (item2 == item.id) {
              for (let item3 of this.riskBlding)
                if (item3 == item.riskEventName) {
                  flag = true;
                }
            }
          }
          if (!flag) {
            this.riskBlding.push(item.riskEventName);
            this.inputs = this.riskBlding.join();
            this.checkId.push(item.id);
          }
        }
      } else {
        let riskList = this.inputs.split(",");
        for (let item of this.riskReportingData.searchForRiskEvents) {
          for (let [index, item2] of this.checkId.entries()) {
            if (item.id == item2) {
              this.$delete(this.checkId, index);
            }
          }
          for (let [index, item2] of riskList.entries()) {
            if (item.riskEventName == item2) {
              this.$delete(riskList, index);
            }
          }
        }
        this.riskBlding = riskList;
        this.inputs = riskList.join();
      }
    },
    // 保存提交请求
    async saveRequest() {
      const res = await this.$api.preservationRiskReports(
        this.riskReportingData
      );
      if (res.code == 0) {
        this.one = false;
        this.two = true;
        this.$emit("passValue");
        this.$messageSuccess({
          message: res.msg
        });
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    // 检查报告保存提交请求
    async examineSaveRequest() {
      const res = await this.$api.saveFinalRiskCheck(this.riskReporting);
      if (res.code == 0) {
        this.one = false;
        this.two = true;
        this.$emit("passValue");
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    // 查询风险事件
    referSearch() {
      this.riskEvent();
    },
    // 分页
    handleCurrentChange(val) {
      this.offset = val;
      this.riskEvent();
    }
  },
  // 监听弹框打开的时候
  watch: {}
};
</script>
<style lang="scss" scoped rel="stylesheet/scss">
.dialog {
  background: rgba(255, 255, 255, 0.5);
  /deep/ .el-dialog {
    width: 815px;
    min-height: 485px;
    margin-top: 14vh;
  }
  /deep/ .el-dialog__header {
    padding: 8px;
    background: #297ae3;
  }
  /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
}
// 矩形步骤
.step {
  width: 195px;
  height: 43px;
  float: left;
  background-image: url(../../assets/imgs/step1.png);
  color: #fff;
  line-height: 32px;
  // text-align: center;
  background-repeat: no-repeat;
  background-size: 90% 70%;
}
.step1 {
  margin-left: -20px;
  color: #000;
  background-image: url(../../assets/imgs/step3.png);
}
.stepTwo1 {
  margin-left: -20px;
  color: #000;
  background-image: url(../../assets/imgs/step1-1.png);
}
.stepTwo2 {
  margin-left: -20px;
  color: #fff;
  background-image: url(../../assets/imgs/step3-2.png);
}
// 涉及风险事件
.dialog /deep/ .con-head {
  margin-top: 25px;
  margin-bottom: 15px;
  .el-input {
    /deep/ .el-input__inner {
      height: 28px;
      border-radius: 0;
      border: 1px solid #297ae3;
    }
  }
}
// 分页
.dialog /deep/ .page-lucency {
  button {
    color: #000 !important;
  }
  .el-pager li {
    color: #000 !important;
  }
  .el-pager .active {
    background-color: rgba(41, 122, 227, 1) !important;
    color: #fff !important;
    border-radius: 50%;
  }
}
.put /deep/.el-form {
  .el-form-item {
    // margin: 10px 0 0 0;
    font-weight: bold;
    height: 13.5px;
    /deep/ .el-form-item__label {
      font-size: 12.5px;
      color: rgba(62, 58, 57, 1);
      line-height: 30px;
      padding: 0 6.5px 0 0 !important;
      text-align: right;
    }
  }
  /deep/ .el-col-1 {
    margin-left: 10px;
    width: 30px;
    margin-top: 2px;
    height: 25px;
  }
  /deep/.el-input-group__append {
    background: rgba(16, 143, 235, 1);
    border-radius: 0;
    border: 0;
    padding: 0 7px;
    .el-button {
      margin: 0;
      padding: 0;
      color: #fff;
      font-size: 19px;
    }
  }
  /deep/ .table {
    margin: 17px 0;
  }
  /deep/ .reftable th {
    padding: 0px !important;
  }
  /deep/ .table th {
    background-color: rgba(16, 143, 235, 1);
    color: #fff;
    padding: 6px 0;
    font-weight: 400;
  }
  /deep/ .table td {
    padding: 0;
  }
}
.first /deep/ .el-form-item__label {
  color: #297ae3 !important;
}
.el-input--mini /deep/ .el-input__icon {
  color: #297ae3 !important;
}
.tack {
  width: 56px;
  position: absolute;
  top: 1px;
  right: 0px;
  padding: 4px 5px;
  font-size: 17px;
  background: rgba(16, 143, 235, 0.8);
  color: #fff;
}
.put /deep/.affix /deep/ .el-form-item /deep/ .el-form-item__label {
  color: #000;
  font-weight: bold;
  margin-top: 0;
}
.put /deep/.affix /deep/ span {
  line-height: 26px;
}
.put /deep/.affix /deep/ .el-input--prefix .el-input__inner {
  line-height: 26px;
  width: 124px;
}
.put /deep/.affix /deep/ .el-date-editor.el-input {
  width: 124px !important;
}

.submit {
  /deep/ p {
    font-family: Microsoft YaHei;
    font-size: 16;
    font-weight: bold;
    margin-top: -7px;
  }
  /deep/ .con-title {
    font-size: 14.5px;
    color: #297ae3;
    font-weight: bold;
    padding-bottom: 1.5px;
    border-bottom: 1.5px solid #297ae3;
  }
  /deep/ .el-form {
    .el-form-item {
      margin: 10px 0 0 0;
      font-weight: bold;
      height: 13.5px;
      /deep/ .el-form-item__label {
        font-size: 12.5px;
        color: rgba(62, 58, 57, 1);
        line-height: 13.5px;
        padding: 0 !important;
      }
      /deep/ .el-form-item__content {
        font-size: 12.5px;
        color: rgba(62, 58, 57, 1);
        line-height: 13.5px !important;
      }
      .policy {
        font-weight: normal;
      }
    }
  }
}
// 分割线
.el-divider {
  margin: 16px 0px;
  background-color: #297ae3;
  height: 2px;
}
</style>
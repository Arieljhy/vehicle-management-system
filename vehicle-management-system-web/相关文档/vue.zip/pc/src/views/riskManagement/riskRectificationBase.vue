<template>
  <div>
    <el-divider
      class="mc-divider"
      v-if="$route.query.type=='rectification'||$route.query.type=='history'"
    ></el-divider>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
    </el-col>
    <el-form
      :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'||$route.query.type=='confirm'"
      class="mc-form"
      label-width="137px"
      size="mini"
      :model="caseDetails.riskEventDO"
      :rules="rules"
      ref="ruleForm"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="风险事件编号：" prop="eventIdForUser">
            <el-input
              v-model="caseDetails.riskEventDO.eventIdForUser"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="风险事件名称：" prop="riskEventName">
            <el-input v-model="caseDetails.riskEventDO.riskEventName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="所属楼栋：" prop="riskBldings1">
            <el-input v-model="caseDetails.riskEventDO.riskBldings1" style="display: none;"></el-input>
            <span @click="storiedBuilding" @mouseover="mouseover" @mouseleave="mouseleave">
              <el-input
                v-model="caseDetails.riskEventDO.riskBldings"
                :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
                readonly
              ></el-input>
            </span>
            <el-popover
              placement="top"
              width="200"
              trigger="manual"
              :content="caseDetails.riskEventDO.riskBldings"
              v-model="visible"
            ></el-popover>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="风险等级：" prop="riskLevel">
            <el-select
              v-model="caseDetails.riskEventDO.riskLevel"
              placeholder="请选择"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            >
              <el-option
                v-for="item in listBaseData.IDI_RISK_EVENT_LEVEL"
                :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
                :key="item.dictKey"
                :label="item.dictValue"
                :value="item.dictKey"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="风险事件类型：">
            <el-select
              v-model="caseDetails.riskEventDO.riskEventType"
              clearable
              placeholder="请选择"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            >
              <el-option
                v-for="item in listBaseData.IDI_RISK_EVENT_TYPE"
                :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
                :key="item.dictKey"
                :label="item.dictValue"
                :value="item.dictKey"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="发生时间：" prop="riskFoundTime">
            <el-date-picker
              v-model="caseDetails.riskEventDO.riskFoundTime"
              value-format="yyyy-MM-dd HH:mm:ss"
              type="date"
              :picker-options="pickerOptionsStart"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
              placeholder="选择日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="建议整改截止日期:" class="mc-multi-row" prop="proposedAmendDeadline">
            <el-date-picker
              v-model="caseDetails.riskEventDO.proposedAmendDeadline"
              value-format="yyyy-MM-dd HH:mm:ss"
              type="date"
              :picker-options="pickerOptionsEnd"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
              placeholder="选择日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="项目阶段：">
            <el-select
              v-model="caseDetails.riskEventDO.constructionStage"
              clearable
              placeholder="请选择"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            >
              <el-option
                v-for="item in listBaseData.IDI_PROJ_PROCESS"
                :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
                :key="item.dictKey"
                :label="item.dictValue"
                :value="item.dictKey"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="形象进度：">
            <el-input
              v-model="caseDetails.riskEventDO.projectVisualProgress"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="检查方式：">
            <el-checkbox-group
              v-model="caseDetails.riskEventDO.checkMethods"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            >
              <el-checkbox
                v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                :disabled="$route.query.type=='view'"
                :key="item.dictKey"
                :label="item.dictKey"
              >{{item.dictValue}}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="缺陷描述：">
            <el-input
              type="textarea"
              :autosize=" {minRows: 2}"
              placeholder="请输入内容"
              v-model="caseDetails.riskEventDO.riskDesc"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="整改建议方案：">
            <el-input
              type="textarea"
              :autosize=" {minRows: 2}"
              placeholder="请输入内容"
              v-model="caseDetails.riskEventDO.proposedAmendPlan"
              :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="现场图片：">
            <el-table class="mc-table" :data="caseDetails.riskEventPicDO" style="width: 100%">
              <el-table-column prop="address" align="center" label="内容" width="350px">
                <template slot-scope="scope">
                  <el-upload
                    action
                    list-type="picture-card"
                    :http-request="(file) => { uploadFile(file, scope.$index) }"
                    :show-file-list="false"
                    v-if="scope.row.show"
                    :before-upload="beforeAvatarUpload"
                  >
                    <i class="el-icon-plus"></i>
                  </el-upload>
                  <img
                    v-else
                    width="75%"
                    height="160px"
                    :src="scope.row.imgUrl"
                    @click="openPic(scope.row.imgUrl)"
                  />
                </template>
                <!-- <template slot-scope="scope">
                  <el-input size="mini" v-model="scope.row.picPath"></el-input>
                </template>-->
              </el-table-column>
              <el-table-column prop="date" align="center" label="描述">
                <template slot-scope="scope">
                  <el-input
                    :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
                    type="textarea"
                    :autosize=" {minRows: 8}"
                    v-model="scope.row.picDescription"
                  ></el-input>
                </template>
              </el-table-column>
              <el-table-column
                prop="mobile"
                align="center"
                width="180"
                v-if="!$route.query.type=='view' || !$route.query.type=='rectification'||$route.query.type=='new'|| $route.query.type=='edit'||!$route.query.type=='history'"
              >
                <template slot="header">
                  <div
                    class="el-icon-circle-plus-outline mouse-pointer"
                    style="font-size:20px;line-height:40px"
                    @click="addLivePic"
                  ></div>
                </template>
                <template slot-scope="scope">
                  <div
                    class="el-icon-remove-outline mouse-pointer"
                    style="font-size:20px;"
                    @click="delLivePic(scope.$index)"
                  ></div>
                </template>
              </el-table-column>
            </el-table>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="参与人：">
            <el-table class="mc-table" :data="caseDetails.userDO" style="width: 100%">
              <el-table-column prop="mobile" align="center" label="联系电话">
                <template slot-scope="scope">
                  <el-input
                    v-model="scope.row.mobile"
                    size="mini"
                    placeholder="请录入联系电话"
                    @blur="checkUser(scope.row)"
                    :disabled="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'"
                  />
                </template>
              </el-table-column>
              <el-table-column prop="username" align="center" label="姓名">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.username" size="mini" disabled />
                </template>
              </el-table-column>
              <el-table-column prop="professional" align="center" label="专业领域">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.professional" size="mini" disabled />
                </template>
              </el-table-column>
              <el-table-column prop="orgName" align="center" label="机构名称">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.orgName" size="mini" disabled />
                </template>
              </el-table-column>
              <el-table-column
                align="center"
                width="180"
                v-if="!$route.query.type=='view' || !$route.query.type=='rectification'|| $route.query.type=='new' || $route.query.type=='edit'||!$route.query.type=='history'"
              >
                <template slot="header">
                  <div
                    class="el-icon-circle-plus-outline mouse-pointer"
                    style="font-size:20px;line-height:40px"
                    @click="addParticipant"
                  ></div>
                </template>
                <template slot-scope="scope">
                  <div
                    class="el-icon-remove-outline mouse-pointer"
                    style="font-size:20px;"
                    @click="delParticipant(scope.$index)"
                  ></div>
                </template>
              </el-table-column>
            </el-table>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-dialog
      title="用户添加"
      :visible.sync="dialogAddUser"
      width="815px"
      class="dialog"
      :close-on-click-modal="false"
    >
      <el-form
        :model="userInfo"
        ref="userInfo"
        class="mc-addUser"
        :rules="rules"
        size="mini"
        label-width="120px"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="姓名：" prop="username">
              <el-input v-model="userInfo.username"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="电话：" prop="mobile">
              <el-input v-model="userInfo.mobile" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="专业领域：" prop="professional">
              <el-input v-model="userInfo.professional"></el-input>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="11">
            <el-form-item prop="orgType" label="机构类型：">
              <el-select v-model="userInfo.orgType" clearable placeholder="请选择" @change="getInsOrg">
                <el-option
                  v-for="item in orgTypes"
                  :key="item.orgType"
                  :label="item.value"
                  :value="item.orgType"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>-->
          <el-col :span="12">
            <el-form-item prop="insOrgId" label="机构名称：">
              <el-select v-model="userInfo.insOrgId" placeholder="请选择" @change="getInsOrg">
                <el-option
                  v-for="item in orgIds"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="roleId" label="角色：">
              <el-select v-model="userInfo.roleId" clearable placeholder="请选择">
                <el-option
                  v-for="item in roleList"
                  :key="item.roleId"
                  :label="item.roleName"
                  :value="item.roleId"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="可查看项目区域：" prop="list">
              <el-input v-model="userInfo.list" style="display: none;"></el-input>
              <el-table
                class="mc-table district-table"
                tooltip-effect="light"
                :data="userInfo.listTransArea"
                style="width: 100%;border-radius:2px;"
              >
                <el-table-column align="center" label="省">
                  <template slot-scope="scope">
                    <el-select
                      disabled
                      class="miniColumn"
                      @change="getCity(scope.row,'city')"
                      v-model="scope.row.province"
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in district"
                        :key="item.province"
                        :label="item.province"
                        :value="item.province"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="市">
                  <template slot-scope="scope">
                    <el-select
                      class="miniColumn ml5"
                      @change="getCity(scope.row, 'county')"
                      v-model="scope.row.city"
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in scope.row.citys"
                        :key="item.name"
                        :label="item.name"
                        :value="item.name"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="区/县">
                  <template slot-scope="scope">
                    <el-select
                      class="miniColumn ml5"
                      v-model="scope.row.county"
                      placeholder="请选择"
                      @change="selectCounty(scope.row.county)"
                    >
                      <el-option
                        v-for="item in scope.row.countys"
                        :key="item.district"
                        :label="item.district"
                        :value="item.district"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column align="center">
                  <template slot="header" solt-scope="scope">
                    <i @click="doRowAdd" class="el-icon-circle-plus-outline"></i>
                  </template>
                  <template slot-scope="scope">
                    <i @click="doRowDel(scope.$index)" class="el-icon-remove-outline"></i>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="dialogAddUser = false">取 消</el-button>
        <el-button size="mini" type="primary" @click="addUserInfo('userInfo')">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog
      title="住宅楼信息"
      :visible.sync="buildingWindows"
      width="900px"
      class="dialog"
      :close-on-click-modal="false"
    >
      <el-row style="border:1px #ccc solid">
        <el-row>
          <el-table
            class="mc-table residence-table"
            :data="residentialBuildingInformation"
            @select="checkedList"
            @select-all="checkedLists"
            ref="multipleTable"
          >
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="buildingName" align="center" label="竣工后楼栋门牌号"></el-table-column>
            <el-table-column prop="unitId" align="center" label="单体编号"></el-table-column>
            <el-table-column prop="unitName" align="center" label="单体名称"></el-table-column>
            <el-table-column prop="buildingType" align="center" label="类别"></el-table-column>
            <el-table-column prop="totalStories" align="center" label="总层数"></el-table-column>
            <el-table-column prop="totalUnits" align="center" label="总户数"></el-table-column>
          </el-table>
        </el-row>
      </el-row>
      <el-row style="text-align: left;padding-top: 15px;">
        <el-checkbox v-model="checked" @change="check()" style="padding-left: 15px;">
          其他
          <el-input
            v-model="caseDetails.rectificationInfo.other"
            placeholder="请输入内容"
            v-if="checked"
          ></el-input>
        </el-checkbox>
      </el-row>
      <el-pagination
        small
        class="text-center mt10 control block page-lucency"
        @current-change="handleCurrentChangePaging"
        :current-page.sync="offset"
        :page-size="this.limit"
        layout="prev, pager, next"
        :total="this.total"
      ></el-pagination>

      <el-row style="text-align: right; margin-top: 30px" class="btns">
        <el-button size="mini" @click="confirmationBtn()">确定</el-button>
      </el-row>
    </el-dialog>
    <el-dialog :visible.sync="dialogVisibleImg" :close-on-click-modal="false">
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
  </div>
</template>

<script>
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import { mapGetters, mapActions } from "vuex";
import { orgType } from "@/assets/js/codes";
import md5 from "js-md5";
import config from "@/common/config";
export default {
  name: "riskRectficationBase",
  components: {
    BasicInformation,
  },
  props: {
    caseDetails: {
      type: Object,
      required: false,
      default: "",
    },
    disabled: {
      type: Boolean,
      default: false,
      required: false,
    },
  },
  computed: {
    ...mapGetters(["listBaseData", "getOrgId", "district", "getCitys"]),
  },
  // watch: {
  //   'disabled'() {
  //     if(this.disabled) {
  //       this.$route.query.type = 'view'
  //     }
  //   }
  // },
  data() {
    return {
      checked: false,
      pickerOptionsStart: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        },
      },
      pickerOptionsEnd: {
        disabledDate: (time) => {
          if (this.caseDetails.riskEventDO.riskFoundTime) {
            return (
              time.getTime() <
              new Date(this.caseDetails.riskEventDO.riskFoundTime).getTime()
            );
          }
        },
      },
      dialogVisibleImg: false,
      list: "",
      limit: 10, //每页几条数据
      offset: 1, //第几页
      residentialBuildingInformation: undefined, //报建信息住宅楼
      buildingWindows: false,
      orgTypes: [...orgType],
      rules: {
        riskEventName: [
          {
            required: true,
            message: "请录入风险事件名称",
            trigger: "blur",
          },
        ],
        riskBldings1: [
          {
            required: true,
            message: "请录入所属楼栋",
            trigger: "blur",
          },
        ],
        riskLevel: [
          {
            required: true,
            message: "请选择风险等级",
            trigger: "change",
          },
        ],
        proposedAmendDeadline: [
          {
            // type: "date",
            required: true,
            message: "请录入建议整改截止日期",
            trigger: "change",
          },
        ],
        riskFoundTime: [
          {
            // type: "date",
            required: true,
            message: "请录入发生时间",
            trigger: "change",
          },
        ],
        eventIdForUser: [
          { required: true, message: "请输入编号", trigger: "blur" },
        ],
        username: [{ required: true, message: "请录入姓名", trigger: "blur" }],
        mobile: [{ required: true, message: "请录入手机号", trigger: "blur" }],
        list: [{ required: true, message: " ", trigger: "blur" }],
        insOrgId: [
          { required: true, message: "请选择机构名称", trigger: "change" },
        ],
        roleId: [{ required: true, message: "请选择角色", trigger: "change" }],
      },
      dialogAddUser: false,
      userInfo: {},
      orgIds: [],
      roleList: [],
      addNewUserFlag: false,
      dialogVisible: false,
      total: undefined,
      riskBlding: [],
      dialogImageUrl: "",
      citys: [],
      county: "",
      province: "", //省
      city: "",
      address: "",
      countys: [],
      uid: [],
      visible: false,
    };
  },
  async created() {
    const { code, msg, data } = await this.$api.findCfgAreaInfo();
    if (code === 0) {
      this.districtList = data;
    }
    setTimeout(() => {
      this.$refs["ruleForm"].clearValidate();
    }, 10);
  },
  methods: {
    mouseover() {
      this.visible = true;
    },
    mouseleave() {
      this.visible = false;
    },
    //单选
    check() {
      this.caseDetails.rectificationInfo.other = "";
    },
    selectCounty(county) {
      let countyNum = 0;
      this.userInfo.listTransArea.map((item) => {
        if (item.county == county) {
          countyNum++;
          if (countyNum > 1) {
            item.county = "";
            this.$messageError({
              message: "该区域已存在",
            });
            return;
          }
        }
      });
    },
    getCity(i, flag) {
      if (flag === "county") {
        let list = [];
        for (let item of this.district) {
          list = [...list, ...item.city];
        }
        for (let item of list) {
          if (i.city == item.name) {
            i.countys = item.area;
          }
        }
      } else if (flag === "city") {
        for (let city of this.district) {
          if (city.province == i.province) {
            i.citys = city.city;
          }
        }
      }
    },
    //确定按钮
    cancelBtn() {
      this.buildingWindows = false;
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex((item) => {
        return item.unitId == row.unitId;
      });
      if (isCkeck < 0) {
        for (let [index, item2] of this.riskBlding.entries()) {
          if (item2 == row.unitId) {
            this.$delete(this.riskBlding, index);
            this.caseDetails.riskEventDO.riskBldings = this.riskBlding.join();
          }
        }
      } else {
        this.riskBlding.push(row.unitId);
        this.caseDetails.riskEventDO.riskBldings = this.riskBlding.join();
      }
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.riskBlding) {
            if (item2 == item.unitId) {
              flag = true;
            }
          }
          if (!flag) {
            this.riskBlding.push(item.unitId);
            this.caseDetails.riskEventDO.riskBldings = this.riskBlding.join();
          }
        }
      } else {
        // this.riskBlding = [];
        // this.caseDetails.riskEventDO.riskBldings = this.riskBlding.join();
        let riskList = this.caseDetails.riskEventDO.riskBldings.split(",");
        for (let item of this.residentialBuildingInformation) {
          for (let [index, item2] of this.riskBlding.entries()) {
            if (item.unitId == item2) {
              this.$delete(this.riskBlding, index);
            }
          }
          for (let [index, item3] of riskList.entries()) {
            if (item.unitId == item3) {
              this.$delete(riskList, index);
            }
          }
        }
        this.caseDetails.riskEventDO.riskBldings = riskList.join();
      }
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      this.riskRequestForConstruction();
    },
    //确定按钮
    confirmationBtn() {
      if (this.checked && this.caseDetails.rectificationInfo.other == "") {
        this.$messageError({ message: "请输入其他的内容" });
        return false;
      }
      this.caseDetails.riskEventDO.splicingBldings =
        this.riskBlding.join() +
        "82GFe8eYR64e26HG89HT477" +
        this.caseDetails.rectificationInfo.other;
      if (this.caseDetails.rectificationInfo.other) {
        if (this.riskBlding.length > 0) {
          this.buildingWindows = false;
          this.caseDetails.riskEventDO.riskBldings = this.riskBlding.join();
          this.caseDetails.riskEventDO.riskBldings =
            this.caseDetails.riskEventDO.riskBldings +
            "," +
            this.caseDetails.rectificationInfo.other;
        } else {
          this.buildingWindows = false;
          this.caseDetails.riskEventDO.riskBldings = this.caseDetails.rectificationInfo.other.replace(
            ",",
            "，"
          );
        }
      } else {
        this.buildingWindows = false;
        this.caseDetails.riskEventDO.riskBldings = this.riskBlding.join();
      }
    },
    //所属楼栋弹窗
    storiedBuilding() {
      if (this.caseDetails.rectificationInfo.other) {
        this.checked = true;
      }
      if (
        this.$route.query.type === "edit" ||
        this.$route.query.type === "new"
      ) {
        this.buildingWindows = true;
        this.riskRequestForConstruction();
      }
    },
    async riskRequestForConstruction() {
      const reportBuildingData = {
        projectId: this.$route.query.projectId,
        offset: this.offset,
        limit: this.limit,
      };
      const res = await this.$api.buildingInformation(reportBuildingData);
      this.total = res.data.total;
      this.residentialBuildingInformation = res.data.rows;
      if (
        this.$route.query.type === "edit" ||
        this.$route.query.type === "new"
      ) {
        if (this.caseDetails.rectificationInfo.other) {
          var basic = this.caseDetails.riskEventDO.riskBldings.substring(
            0,
            this.caseDetails.riskEventDO.splicingBldings.lastIndexOf(
              "82GFe8eYR64e26HG89HT477"
            )
          );
        } else {
          var basic = this.caseDetails.riskEventDO.riskBldings;
        }
        if (this.caseDetails.riskEventDO.riskBldings) {
          this.riskBlding = basic.split(",");
          for (var i = 0; i < this.riskBlding.length; i++) {
            if (
              this.riskBlding[i] == "" ||
              this.riskBlding[i] == null ||
              typeof this.riskBlding[i] == undefined
            ) {
              this.riskBlding.splice(i, 1);
              i = i - 1;
            }
          }
        }
        for (let item of this.riskBlding) {
          for (let item2 of this.residentialBuildingInformation) {
            if (item == item2.unitId) {
              setTimeout(() => {
                this.$refs.multipleTable.toggleRowSelection(item2);
              });
            }
          }
        }
      }
    },
    //添加用户区域
    doRowAdd(scope) {
      const keywords = {
        province: this.district[0].province,
        citys: [],
      };
      for (let city of this.district) {
        if (city.province == this.district[0].province) {
          keywords.citys = city.city;
        }
      }
      this.userInfo.listTransArea.push(keywords);
    },
    //删除用户区域
    doRowDel(curIndex) {
      this.userInfo.listTransArea.splice(curIndex, 1);
    },
    //添加现场图片
    addLivePic() {
      let newPic = {
        picType: "1",
        picPath: "",
        picDescription: null,
        picName: "",
        picUidName: "",
        show: true,
      };
      this.caseDetails.riskEventPicDO.push(newPic);
    },
    //删除现场图片
    delLivePic(index) {
      this.caseDetails.riskEventPicDO.splice(index, 1);
    },
    //添加参与人
    addParticipant() {
      let newPic = {
        username: "",
        professional: "",
        mobile: "",
        orgName: "",
        orgName: "",
      };
      this.caseDetails.userDO.push(newPic);
    },
    //删除参与人
    delParticipant(index) {
      this.caseDetails.userDO.splice(index, 1);
    },
    //根据手机号查询参与人信息
    async checkUser(row) {
      if (row.mobile.length !== 11) {
        this.$messageError({ message: "请输入正确手机号" });
        return;
      }
      var reg = /^[1][3,4,5,7,8,9][0-9]{9}$/;
      if (!reg.test(row.mobile)) {
        this.$messageError({ message: "请输入正确手机号" });
        return;
      }
      this.riskEvntOrg();
      const keywords = { mobile: row.mobile };
      if (row.mobile) {
        const res = await this.$api.getParticipants(keywords);
        if (res.code == 500) {
          this.$confirm("此用户不存在是否添加?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          })
            .then(() => {
              this.dialogAddUser = true;
              this.userInfo = {
                list: "5555",
                password: md5("123456"),
                status: "1",
                insOrgId: "",
                roleId: "",
                listTransArea: [],
                listTransHouseProperty: [],
                mobile: row.mobile,
                username: "",
                professional: "",
                orgType: "",
                orgName: "",
              };
              row.username = "";
              row.professional = "";
              row.orgName = "";
              this.dialogAddUser = true;
              if (this.dialogAddUser == true) {
                this.roleList = null;
              }
              this.$nextTick(() => {
                this.$refs.userInfo.resetFields();
                this.userInfo.mobile = row.mobile;
              });
            })
            .catch(() => {
              row.mobile = "";
              row.username = "";
              row.professional = "";
            });
        } else if (res.code == 0) {
          row.username = res.data.username;
          row.professional = res.data.professional;
          row.userId = res.data.userId;
          row.orgName = res.data.orgName;
        } else if (res.code == 1) {
          this.$messageSuccess({ message: res.msg });
        }
      } else {
        row.username = "";
        row.professional = "";
        row.userId = "";
        row.orgName = "";
      }
    },
    //新增用户信息
    async addUserInfo(formName) {
      this.addNewUserFlag = false;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          console.log("submit!");
          this.addNewUserFlag = true;
        } else {
          console.log("error submit!!");
          return false;
        }
      });
      if (this.addNewUserFlag) {
        if (this.userInfo.listTransArea.length > 0) {
          this.userInfo.tenantId = JSON.parse(
            sessionStorage.getItem(this.$getversionData.userInfo)
          ).tenantId;
          const keywords = this.userInfo;
          const res = await this.$api.addParticipants(keywords);
          if (res.code == 0) {
            this.caseDetails.userDO.map((item, index) => {
              if (item.mobile == res.data.mobile) {
                item.professional = res.data.professional;
                item.username = res.data.username;
                item.mobile = res.data.mobile;
                item.orgName = res.data.orgName;
                item.userId = res.data.userId;
              }
            });
            this.$messageSuccess({ message: "添加成功" });
            this.dialogAddUser = false; //保存成功，关闭弹框
          } else if (res.code == 1) {
            this.$messageError({ message: res.msg });
          }
        } else {
          this.$messageError({ message: "可查看项目区域不能为空" });
        }
      }
    },
    //查询机构
    async riskEvntOrg() {
      const res = await this.$api.riskEvntOrg(this.$route.query.projectId);
      this.orgIds = res.data;
    },
    //获取机构名称/角色
    async getInsOrg() {
      this.userInfo.roleId = "";
      const orgid = this.userInfo.insOrgId;
      if (orgid) {
        const res = await this.$api.listRoleByOrgid(orgid);
        this.roleList = res.data;
      }
    },
    //上传校验
    beforeAvatarUpload(file) {
      var isJPG = false;
      switch (file.type) {
        case "image/png":
          isJPG = true;
          break;
        case "image/jpeg":
          isJPG = true;
          break;
        case "image/jpg":
          isJPG = true;
          break;
        case "image/gif":
          isJPG = true;
          break;
        case "image/tiff":
          isJPG = true;
          break;
        default:
          isJPG = false;
          break;
      }
      if (!isJPG) {
        this.$message.error("请上传正确的图片格式!");
        this.show = true;
      }
      return isJPG;
    },
    //上传
    uploadFile(param, rpid) {
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "riskEventPic");
      file.append("projectId", this.$route.query.projectId);
      this.$api.pictureProcessDoc(file).then((res) => {
        if (res.code == 0) {
          this.caseDetails.riskEventPicDO.map((item, index) => {
            if (rpid == index) {
              item.picPath = res.data.cloudDocId;
              item.picName = res.data.fileName;
              item.picUidName = res.data.uidFileName;
              item.show = item.picPath ? false : true;
              item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
            }
          });
        } else {
          this.$messageError({ message: res.msg });
        }
      });
    },
    //图片放大
    openPic(picUrl) {
      this.dialogImageUrl = picUrl;
      this.dialogVisibleImg = true;
    },
  },
};
</script>
<style scoped lang="scss">
.mc-addUser /deep/ .el-select--mini {
  width: 100%;
}
.mc-multi-row /deep/ .el-form-item__label {
  line-height: 15px;
  text-align: right;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
</style>
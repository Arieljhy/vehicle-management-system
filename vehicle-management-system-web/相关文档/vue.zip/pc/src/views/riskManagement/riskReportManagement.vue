<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px 35px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <div
          v-if="$route.query.type=='view' || $route.query.type=='new'|| $route.query.type=='edit'||$route.query.type=='confirm'"
        >
          <risk-rectfication-base ref="valid" :caseDetails="caseDetails"></risk-rectfication-base>
        </div>
        <div v-if="$route.query.type=='view'||$route.query.type=='confirm'">
          <el-divider class="mc-divider"></el-divider>
        </div>

        <div
          v-if="$route.query.type=='view' || $route.query.type=='rectification'||$route.query.type=='history'||$route.query.type=='confirm'"
        >
          <div v-if="$route.query.type!='view'&&$route.query.type!='confirm'">
            <div v-if="$route.query.type!='history'">
              <!-- 整改信息 -->
              <el-col class="text-left mc-title" :span="24">
                <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
                <span style="font-size: 14.5px;" class="blue font-bold">本次整改信息</span>
              </el-col>
              <el-form
                class="mc-form"
                label-width="137px"
                size="mini"
                label-position="left"
                align="left"
                :model="caseDetails.rectificationInfo"
                :rules="rules"
                ref="ruleForm"
              >
                <el-row>
                  <el-col :span="8">
                    <el-form-item label="整改时间：" prop="riskPepairTime">
                      <el-date-picker
                        style="width: 183px;"
                        v-model="caseDetails.rectificationInfo.riskPepairTime"
                        value-format="yyyy-MM-dd"
                        placeholder="选择日期"
                      ></el-date-picker>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="整改进度(%)：" prop="amendProgress">
                      <format-input
                        v-model="caseDetails.rectificationInfo.amendProgress"
                        text-align="left"
                        empty-value="0"
                        :max="100"
                        :min="0"
                      ></format-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="项目阶段：">
                      <el-select
                        v-model="caseDetails.rectificationInfo.projectPhase"
                        clearable
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in listBaseData.IDI_PROJ_PROCESS"
                          :key="item.dictKey"
                          :label="item.dictValue"
                          :value="item.dictKey"
                        ></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="8">
                    <el-form-item label="形象进度：">
                      <el-input v-model="caseDetails.rectificationInfo.projectVisualProgress"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="检查人：">
                      <el-input
                        v-model="caseDetails.rectificationInfo.checkPtcp"
                        readonly
                        @click.native="openAgency({title: '检查人', type: 'JCRZ',num:'5' })"
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24">
                    <el-form-item label="检查方式：">
                      <el-checkbox-group v-model="caseDetails.rectificationInfo.checkMethods">
                        <el-checkbox
                          v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                          :disabled="$route.query.type=='view'||$route.query.type=='confirm'"
                          :key="item.dictKey"
                          :label="item.dictKey"
                        >{{item.dictValue}}</el-checkbox>
                      </el-checkbox-group>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24">
                    <el-form-item label="整改描述：">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2}"
                        placeholder="请输入内容"
                        v-model="caseDetails.rectificationInfo.amendActionDesc"
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24">
                    <el-form-item label="整改图片：">
                      <el-table
                        class="mc-table"
                        :data="caseDetails.rectificationInfo.imagePathList"
                        style="width: 100%"
                      >
                        <el-table-column prop="address" align="center" label="内容" width="350px">
                          <template slot-scope="scope">
                            <el-upload
                              action
                              list-type="picture-card"
                              :http-request="(file) => { uploadFile(file, scope.$index) }"
                              :show-file-list="false"
                              v-if="scope.row.show"
                              :before-upload="beforeAvatarUpload"
                            >
                              <i class="el-icon-plus"></i>
                            </el-upload>
                            <img
                              v-else
                              width="75%"
                              height="160px"
                              :src="scope.row.imgUrl"
                              @click="openPic(scope.row.imgUrl)"
                            />
                          </template>
                        </el-table-column>
                        <el-table-column prop="date" align="center" label="描述">
                          <template slot-scope="scope">
                            <el-input
                              type="textarea"
                              :autosize=" {minRows: 8}"
                              v-model="scope.row.picDescription"
                            ></el-input>
                          </template>
                        </el-table-column>
                        <el-table-column prop="mobile" align="center" width="180">
                          <template slot="header">
                            <div
                              class="el-icon-circle-plus-outline mouse-pointer"
                              style="font-size:20px;line-height:40px"
                              @click="addLivePics()"
                            ></div>
                          </template>
                          <template slot-scope="scope">
                            <div
                              class="el-icon-remove-outline mouse-pointer"
                              style="font-size:20px;"
                              @click="delLivePics(scope.$index)"
                            ></div>
                          </template>
                        </el-table-column>
                      </el-table>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
              <el-divider class="mc-divider"></el-divider>
            </div>
          </div>
          <!--  弹窗-->
          <el-dialog
            title="整改详情"
            :visible.sync="buildingWindows"
            width="900px"
            class="dialog"
            :before-close="handleClose"
            :close-on-click-modal="false"
          >
            <el-form
              class="mc-form"
              label-width="137px"
              size="mini"
              label-position="left"
              align="left"
              :model="dialogCaseDetails.dialogRectificationInfo"
              :rules="rules"
              ref="ruleForms"
              :disabled="this.disabled"
            >
              <el-row>
                <el-col :span="11">
                  <el-form-item label="整改时间：" prop="riskPepairTime">
                    <el-date-picker
                      v-model="dialogCaseDetails.dialogRectificationInfo.riskPepairTime"
                      value-format="yyyy-MM-dd"
                      placeholder="选择日期"
                    ></el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :span="11">
                  <el-form-item label="整改进度(%)：" prop="amendProgress">
                    <format-input
                      v-model="dialogCaseDetails.dialogRectificationInfo.amendProgress"
                      text-align="left"
                      empty-value="0"
                      :max="100"
                      :min="0"
                    ></format-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="11">
                  <el-form-item label="形象进度：">
                    <el-input
                      v-model="dialogCaseDetails.dialogRectificationInfo.projectVisualProgress"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="11">
                  <el-form-item label="项目阶段：">
                    <el-select
                      style="width:266px"
                      v-model="dialogCaseDetails.dialogRectificationInfo.projectPhase"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in listBaseData.IDI_PROJ_PROCESS"
                        :key="item.dictKey"
                        :label="item.dictValue"
                        :value="item.dictKey"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="24">
                  <el-form-item label="检查方式：">
                    <el-checkbox-group
                      v-model="dialogCaseDetails.dialogRectificationInfo.checkMethods"
                    >
                      <el-checkbox
                        v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                        :disabled="$route.query.type=='view'||$route.query.type=='confirm'"
                        :key="item.dictKey"
                        :label="item.dictKey"
                      >{{item.dictValue}}</el-checkbox>
                    </el-checkbox-group>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="11">
                  <el-form-item label="检查人：">
                    <el-input
                      v-model="dialogCaseDetails.dialogRectificationInfo.checkPtcp"
                      readonly
                      @click.native="openAgency({title: '检查人', type: 'JCR',num:'5' })"
                    ></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="整改描述：">
                    <el-input
                      type="textarea"
                      :autosize=" {minRows: 2}"
                      placeholder="请输入内容"
                      v-model="dialogCaseDetails.dialogRectificationInfo.amendActionDesc"
                    ></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="整改图片：">
                    <el-table
                      class="mc-table"
                      :data="dialogCaseDetails.dialogRectificationInfo.imagePathList"
                      style="width: 100%;"
                    >
                      <el-table-column prop="address" align="center" label="内容">
                        <template slot-scope="scope">
                          <el-upload
                            action
                            list-type="picture-card"
                            :http-request="(file) => { uploadFile(file, scope.$index,'falg') }"
                            :show-file-list="false"
                            v-if="scope.row.show"
                            :before-upload="beforeAvatarUpload"
                          >
                            <i class="el-icon-plus"></i>
                          </el-upload>
                          <img
                            v-else
                            width="75%"
                            height="160px"
                            :src="scope.row.imgUrl"
                            @click="openPic(scope.row.imgUrl)"
                          />
                        </template>
                      </el-table-column>
                      <el-table-column prop="date" align="center" label="描述">
                        <template slot-scope="scope">
                          <el-input
                            type="textarea"
                            :autosize=" {minRows: 8}"
                            v-model="scope.row.picDescription"
                          ></el-input>
                        </template>
                      </el-table-column>
                      <el-table-column
                        prop="mobile"
                        align="center"
                        v-if="this.dialogButton"
                        width="80px"
                      >
                        <template slot="header">
                          <div
                            class="el-icon-circle-plus-outline mouse-pointer"
                            style="font-size:20px;line-height:40px"
                            @click="dialogAddLivePics()"
                          ></div>
                        </template>
                        <template slot-scope="scope">
                          <div
                            class="el-icon-remove-outline mouse-pointer"
                            style="font-size:20px;"
                            @click="dialogDelLivePics(scope.$index)"
                          ></div>
                        </template>
                      </el-table-column>
                    </el-table>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <el-row style="text-align: right; margin-top: 50px" class="dialogBtn">
              <el-button
                size="small"
                class="btn"
                @click="dialogSaveRectification(0)"
                v-if="this.dialogButton"
              >保存</el-button>
              <el-button
                size="mini"
                type="primary"
                @click="dialogSaveRectification(1)"
                v-if="this.dialogButton"
              >提交</el-button>
              <el-button
                size="mini"
                type="primary"
                @click="deleteRectification"
                v-if="this.dialogButton"
              >删除</el-button>
              <el-button class="btn" size="small" @click="dialogCloseRectification">关闭</el-button>
            </el-row>
          </el-dialog>
          <!-- 历史整改信息 -->
          <el-col class="text-left mc-title" :span="24">
            <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
            <span style="font-size: 14.5px;" class="blue font-bold">历史整改信息</span>
          </el-col>
          <el-form
            class="mc-form"
            label-width="137px"
            size="mini"
            label-position="left"
            align="left"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label>
                  <el-table
                    class="mc-table"
                    tooltip-effect="light"
                    :data="caseDetails.rectificationHistoryList"
                    style="width: 100%"
                    @row-dblclick="dbGoVisitDetails"
                  >
                    <!-- <el-table-column type="index" align="center" label="序号"></el-table-column> -->
                    <el-table-column
                      type="index"
                      align="center"
                      label="序号"
                      :index="(index)=>{return(index+1)+(offset-1)*limit}"
                    ></el-table-column>
                    <el-table-column prop="riskPepairTime" align="center" label="整改时间"></el-table-column>
                    <el-table-column prop="projectPhase" align="center" label="项目阶段">
                      <template
                        slot-scope="scope"
                      >{{scope.row.projectPhase | filterCode(listBaseData.IDI_PROJ_PROCESS,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column prop="checkPtcp" align="center" label="检查人"></el-table-column>
                    <el-table-column
                      prop="createdBy"
                      :show-overflow-tooltip="true"
                      align="center"
                      label="整改用户"
                    ></el-table-column>
                    <el-table-column prop="orgName" align="center" label="整改机构"></el-table-column>
                    <el-table-column prop="amendProgress" align="center" label="整改进度(%)"></el-table-column>
                    <el-table-column prop="sqlStatus" align="center" label="状态">
                      <template slot-scope="scope">
                        <div v-if="scope.row.sqlStatus==0">已保存</div>
                        <div v-if="scope.row.sqlStatus==1">已提交</div>
                      </template>
                    </el-table-column>
                  </el-table>
                </el-form-item>
                <el-pagination
                  layout="prev, pager, next"
                  small
                  class="text-right mt10 page-lucency"
                  @current-change="getPagination"
                  :current-page.sync="offset"
                  :page-size="limit"
                  :total="caseDetails.total"
                ></el-pagination>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div v-if="$route.query.type=='rectification'||$route.query.type=='history'">
          <risk-rectfication-base :caseDetails="caseDetails"></risk-rectfication-base>
        </div>
        <el-row style="text-align: right; ">
          <el-col>
            <span
              style="margin-right: 10px;"
              v-if="$route.query.type=='rectification'||$route.query.type =='edit'||$route.query.type =='new'"
            >
              <el-button
                size="mini"
                type="primary"
                @click="saveRectification(0)"
                :disabled="disableds"
              >保存</el-button>
              <el-button
                size="mini"
                type="primary"
                @click="saveRectification(1)"
                :disabled="disableds"
              >提交</el-button>
            </span>
            <el-button
              v-if="$route.query.type=='confirm'"
              size="mini"
              @click="confirmCloseRectification"
              type="primary"
              :disabled="disableds"
            >确认整改</el-button>
            <el-button size="mini" @click="closeRectification" :disabled="disableds">关闭</el-button>
          </el-col>
        </el-row>
      </div>
      <el-dialog :visible.sync="dialogVisibleImg">
        <img width="100%" :src="dialogImageUrl" alt />
      </el-dialog>
      <el-dialog
        class="dialog"
        :title="title"
        :visible.sync="openVisible"
        width="615px"
        :close-on-click-modal="false"
      >
        <select-agency
          :type="type"
          :title="title"
          :num="num"
          @getAngency="getAngency"
          v-if="openVisible"
          :project="project"
        ></select-agency>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import RiskRectficationBase from "@/views/riskManagement/riskRectificationBase"; //基础信息
import { async } from "q";
import { mapGetters, mapActions } from "vuex";
import formatInput from "@/components/formatInput";
import config from "@/common/config";
import SelectAgency from "@/components/selectAgency.vue";
export default {
  name: "RiskReportManagement",
  components: {
    RiskRectficationBase,
    formatInput,
    SelectAgency,
  },
  data() {
    return {
      offset: 1,
      limit: 5,
      disableds: false,
      openVisible: false,
      type: "",
      title: "",
      num: "",
      project: "",
      dialogImageUrl: "",
      dialogVisibleImg: false,
      rules: {
        amendProgress: [
          { required: true, message: "请输入内容", trigger: "blur" },
        ],
        riskPepairTime: [
          { required: true, message: "请选择日期", trigger: "change" },
        ],
      },
      radio: "",
      textarea: "",
      dialogImageUrl: "",
      dialogVisible: false,
      caseDetails: {
        riskEventDO: {
          checkMethods: [],
          riskBldings1: "123",
        },
        riskEventPicDO: [],
        userDO: [],
        rectificationInfo: {
          riskEventId: "", //风险事件编号
          riskPepairTime: "", // 整改时间
          projectPhase: "", // 项目阶段
          amendProgress: "", // 整改进度
          amendActionDesc: "", // 整改描述
          projectVisualProgress: "", // 形象进度
          checkMethods: [], // 检查方式
          checkPtcp: "", // 检查人
          sqlStatus: "", // 保存还是提交 0:未提交，1：已提交
          imagePathList: [],
          other: "",
        },
        rectificationHistoryList: [],
      },
      rectificationEdit: false,
      verificationPass: false,
      buildingWindows: false, //弹窗
      dialogCaseDetails: {
        //弹窗数据
        dialogRectificationInfo: {
          imagePathList: [],
          checkMethods: [],
        },
      },
      disabled: "",
      dialogButton: "",
      rid: "",
    };
  },
  computed: {
    ...mapGetters(["listBaseData", "getOrgId"]),
  },
  created() {
    if (
      this.$route.query.type === "view" ||
      this.$route.query.type === "rectification" ||
      this.$route.query.type === "edit" ||
      this.$route.query.type === "history" ||
      this.$route.query.type == "confirm"
    ) {
      this.getRectificationBaseInfo();
    }
    if (
      this.$route.query.type === "rectification" ||
      this.$route.query.type === "view" ||
      this.$route.query.type === "history" ||
      this.$route.query.type == "confirm"
    ) {
      this.getRectificationHistoryInfo();
    }
  },
  methods: {
    ...mapActions(["changeRiskPage"]),
    openAgency(data) {
      this.openVisible = true;
      this.type = data.type;
      this.title = data.title;
      this.num = data.num;
      this.project = this.$route.query.projectId;
    },
    getAngency(value) {
      if (value.type == "JCRZ") {
        this.caseDetails.rectificationInfo.checkPtcp = value.username;
      } else if (value.type == "JCR") {
        this.dialogCaseDetails.dialogRectificationInfo.checkPtcp =
          value.username;
      }
      this.openVisible = false;
    },
    // this.caseDetails.rectificationInfo
    //双击进入详情
    dbGoVisitDetails(row) {
      this.rid = row.id;
      if (this.$route.query.type === "rectification") {
        this.buildingWindows = true;
        this.dialogCaseDetails.dialogRectificationInfo = row;
        this.dialogCaseDetails.dialogRectificationInfo.imagePathList.map(
          (item, index) => {
            item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
          }
        );
        //保存
        if (this.dialogCaseDetails.dialogRectificationInfo.sqlStatus == 0) {
          this.disabled = false;
          this.dialogButton = true;
          if (!this.dialogCaseDetails.dialogRectificationInfo.imagePathList) {
            this.dialogCaseDetails.dialogRectificationInfo.imagePathList =
              row.imagePathList;
          }
        } else {
          //提交
          this.disabled = true;
          this.dialogButton = false;
        }
      } else {
        this.dialogCaseDetails.dialogRectificationInfo = row;
        this.dialogCaseDetails.dialogRectificationInfo.imagePathList.map(
          (item, index) => {
            item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
          }
        );
        this.buildingWindows = true;
        this.disabled = true;
        this.dialogButton = false;
      }
    },
    //弹窗关闭
    dialogCloseRectification() {
      if (this.$route.query.type === "history") {
        this.buildingWindows = false;
      } else {
        this.buildingWindows = false;
        this.dialogCaseDetails.dialogRectificationInfo.projectVisualProgress =
          "";
        // this.dialogCaseDetails.dialogRectificationInfo.riskPepairTime=''
        // this.dialogCaseDetails.dialogRectificationInfo.amendProgress=''
        this.dialogCaseDetails.dialogRectificationInfo.projectPhase = "";
        this.dialogCaseDetails.dialogRectificationInfo.checkMethods = [];
        this.dialogCaseDetails.dialogRectificationInfo.checkPtcp = "";
        this.dialogCaseDetails.dialogRectificationInfo.amendActionDesc = "";
        this.dialogCaseDetails.dialogRectificationInfo.imagePathList = [];
        this.getRectificationHistoryInfo();
      }
    },
    //弹窗关闭清空表单
    handleClose(done) {
      if (this.$route.query.type === "history") {
        done();
      } else {
        this.dialogCaseDetails.dialogRectificationInfo.projectVisualProgress =
          "";
        // this.dialogCaseDetails.dialogRectificationInfo.riskPepairTime=''
        // this.dialogCaseDetails.dialogRectificationInfo.amendProgress=''
        this.dialogCaseDetails.dialogRectificationInfo.projectPhase = "";
        this.dialogCaseDetails.dialogRectificationInfo.checkMethods = [];
        this.dialogCaseDetails.dialogRectificationInfo.checkPtcp = "";
        this.dialogCaseDetails.dialogRectificationInfo.amendActionDesc = "";
        this.dialogCaseDetails.dialogRectificationInfo.imagePathList = [];
        done();
        this.getRectificationHistoryInfo();
      }
    },
    //增加整改图片
    addLivePics() {
      let newPic = {
        picType: "2",
        picPath: "",
        picDescription: "",
        picName: "",
        picUidName: "",
        show: true,
      };
      this.caseDetails.rectificationInfo.imagePathList.push(newPic);
    },
    //删除整改图片
    delLivePics(index) {
      this.caseDetails.rectificationInfo.imagePathList.splice(index, 1);
    },
    //弹窗增加
    dialogAddLivePics() {
      let dialogNewPic = {
        picType: "2",
        picPath: "",
        picDescription: "",
        picName: "",
        picUidName: "",
        show: true,
      };
      this.dialogCaseDetails.dialogRectificationInfo.imagePathList.push(
        dialogNewPic
      );
    },
    //弹窗删除
    dialogDelLivePics(index) {
      this.dialogCaseDetails.dialogRectificationInfo.imagePathList.splice(
        index,
        1
      );
    },
    //上传校验
    beforeAvatarUpload(file) {
      var isJPG = false;
      switch (file.type) {
        case "image/png":
          isJPG = true;
          break;
        case "image/jpeg":
          isJPG = true;
          break;
        case "image/jpg":
          isJPG = true;
          break;
        case "image/gif":
          isJPG = true;
          break;
        case "image/tiff":
          isJPG = true;
          break;
        default:
          isJPG = false;
          break;
      }
      if (!isJPG) {
        this.$message.error("请上传正确的图片格式!");
        this.show = true;
      }
      return isJPG;
    },
    //上传
    uploadFile(param, rpid, falg) {
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "riskEventRepairPic");
      file.append("projectId", this.$route.query.projectId);
      this.$api.pictureProcessDoc(file).then((res) => {
        if (res.code == 0) {
          if (falg) {
            this.dialogCaseDetails.dialogRectificationInfo.imagePathList.map(
              (item, index) => {
                if (rpid == index) {
                  item.picPath = res.data.cloudDocId;
                  item.picName = res.data.fileName;
                  item.picUidName = res.data.uidFileName;
                  item.show = item.picPath ? false : true;
                  item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
                }
              }
            );
          } else {
            this.caseDetails.rectificationInfo.imagePathList.map(
              (item, index) => {
                if (rpid == index) {
                  item.picPath = res.data.cloudDocId;
                  item.picName = res.data.fileName;
                  item.picUidName = res.data.uidFileName;
                  item.show = item.picPath ? false : true;
                  item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
                }
              }
            );
          }
        } else {
          this.$messageError({ message: res.msg });
        }
      });
    },
    //弹窗保存提交
    async dialogSaveRectification(flag) {
      this.$refs["ruleForms"].validate((valid) => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      if (flag == 0) {
        this.dialogCaseDetails.dialogRectificationInfo.sqlStatus = 0;
        this.dialogCaseDetails.dialogRectificationInfo.projectId = this.$route.query.projectId;
      } else {
        this.dialogCaseDetails.dialogRectificationInfo.sqlStatus = 1;
        this.dialogCaseDetails.dialogRectificationInfo.projectId = this.$route.query.projectId;
      }
      if (this.verificationPass) {
        let keywordsBase = this.dialogCaseDetails.dialogRectificationInfo;
        const res = await this.$api.newRectificationHistory(keywordsBase);
        if (res.code === 0) {
          this.$messageSuccess({
            message: res.msg,
          });
          this.buildingWindows = false;
        } else {
          this.$messageError({
            message: res.msg,
          });
        }
      }
    },
    //保存flag=0，提交flag=1
    async saveRectification(flag) {
      this.caseDetails.riskEventDO.other = this.caseDetails.rectificationInfo.other;
      this.disableds = true;
      let _this = this;
      //表单校验
      this.verificationPass = false;
      if (
        this.$route.query.type === "new" ||
        this.$route.query.type === "edit"
      ) {
        let status = false;
        if (flag == 1) {
          this.$refs.valid.$refs["ruleForm"].validate((valid) => {
            for (let item of _this.caseDetails.riskEventPicDO) {
              if (!item.imgUrl) {
                status = true;
              }
            }
            if (status) {
              this.$messageError({ message: "请上传图片" });
              this.disableds = false;
              return !status;
            }
            if (
              this.caseDetails.riskEventDO.other == "" &&
              !this.caseDetails.riskEventDO.riskBldings
            ) {
              this.$messageError({ message: "请选择所属楼栋" });
              this.disableds = false;
              return false;
            }
            if (valid) {
              console.log("校验通过!");
              this.verificationPass = true;
              this.caseDetails.riskEventDO.riskEventPtcp = "";
              this.caseDetails.userDO.map((item, index) => {
                if (item.username) {
                  if (this.caseDetails.riskEventDO.riskEventPtcp) {
                    this.caseDetails.riskEventDO.riskEventPtcp =
                      this.caseDetails.riskEventDO.riskEventPtcp +
                      "," +
                      item.userId;
                  } else {
                    this.caseDetails.riskEventDO.riskEventPtcp = item.userId;
                  }
                }
              });
            } else {
              this.$messageError({ message: "请填写信息" });
              console.log("error submit!!");
              this.disableds = false;
              return false;
            }
          });
        } else {
          for (let item of _this.caseDetails.riskEventPicDO) {
            if (!item.imgUrl) {
              status = true;
            }
          }
          if (status) {
            this.$messageError({ message: "请上传图片" });
            this.disableds = false;
            return !status;
          }
          if (
            this.caseDetails.riskEventDO.proposedAmendDeadline <
            this.caseDetails.riskEventDO.riskFoundTime
          ) {
            this.$messageError({ message: "请重新选择整改时间" });
            this.disableds = false;
            return false;
          }
          this.verificationPass = true;
          this.caseDetails.riskEventDO.riskEventPtcp = "";
          this.caseDetails.userDO.map((item, index) => {
            if (item.username) {
              if (this.caseDetails.riskEventDO.riskEventPtcp) {
                this.caseDetails.riskEventDO.riskEventPtcp =
                  this.caseDetails.riskEventDO.riskEventPtcp +
                  "," +
                  item.userId;
              } else {
                this.caseDetails.riskEventDO.riskEventPtcp = item.userId;
              }
            }
          });
        }
      }
      if (this.$route.query.type === "rectification") {
        this.$refs["ruleForm"].validate((valid) => {
          if (valid) {
            this.verificationPass = true;
          } else {
            this.disableds = false;
            this.$messageError({ message: "请填写必填项！" });
            return false;
          }
        });
      }
      if (this.verificationPass) {
        const keywordsBase = {
          riskEventDO: this.caseDetails.riskEventDO,
          riskEventPicDO: this.caseDetails.riskEventPicDO,
        };
        const keywordsRect = {
          ...this.caseDetails.rectificationInfo,
        };
        keywordsBase.riskEventDO.sqlStatus = flag;
        keywordsBase.riskEventDO.projectId = this.$route.query.projectId;
        keywordsBase.riskEventDO.completeType = 0;
        if (this.$route.query.type === "new") {
          keywordsRect.sqlStatus = flag;
          try {
            await this.$api.rectificationBaseInfoSave(keywordsBase).then(res=>{
              if (res.code === 0) {
                if (keywordsBase.riskEventDO.sqlStatus == "1")
                  this.$messageSuccess({
                    message: res.msg,
                  });
                this.closeRectification();
              } else {
                this.$messageError({
                  message: res.msg,
                });
                this.disableds = false;
              }
            })
          } catch (error) {
            this.disableds = false;
          }
        } else if (this.$route.query.type === "edit") {
          try {
            await this.$api.rectificationBaseEditSave(keywordsBase).then(res=>{
              if (res.code === 0) {
                if (keywordsBase.riskEventDO.sqlStatus == "1")
                  this.$messageSuccess({
                    message: res.msg,
                  });
                this.closeRectification();
              } else {
                this.$messageError({
                  message: res.msg,
                });
                this.disableds = false;
              }
            })
          } catch (error) {
            this.disableds = false;
          }
        } else if (this.$route.query.type === "rectification") {
          keywordsRect.riskEventId = this.$route.query.id;
          keywordsRect.projectId = this.$route.query.projectId;
          keywordsRect.sqlStatus = flag;
          if (this.rectificationEdit) {
            const res = await this.$api.rectificationHistoryEditSave(
              keywordsRect
            );
            if (res.code === 0) {
              if (keywordsRect.sqlStatus == "1")
                this.$messageSuccess({
                  message: res.msg,
                });
              this.closeRectification();
            } else {
              this.$messageError({
                message: res.msg,
              });
              this.disableds = false;
            }
          } else {
            const res = await this.$api.rectificationHistoryInfoSave(
              keywordsRect
            );
            if (res.code === 0) {
              if (
                this.caseDetails.rectificationInfo.amendProgress == "100" &&
                JSON.parse(
                  sessionStorage.getItem(this.$getversionData.userInfo)
                ).roleType == "TIS"
              ) {
                this.confirmCloseRectification();
              } else {
                if (keywordsRect.sqlStatus == "1")
                  this.$messageSuccess({
                    message: res.msg,
                  });
                this.closeRectification();
              }
            } else {
              this.$messageError({
                message: res.msg,
              });
              this.disableds = false;
            }
          }
        }
      }
    },

    closeRectification() {
      this.changeRiskPage("riskEvent");
      if(this.$route.query.flag){
        this.$router.push({
        path: "/riskManagement",
        query: {
          judge:'1'
        }
      });
      }else{
        this.$router.go(-1);
      }
      
    },
    async confirmCloseRectification() {
      const res = await this.$api.confirmCloseRectification({
        id: this.caseDetails.riskEventDO.id,
        riskEventStatus: "RES08",
      });
      if (res.code === 0) {
        this.$messageSuccess({
          message: res.msg,
        });
        this.closeRectification();
      }
    },
    //删除
    async deleteRectification() {
      const res = await this.$api.deleteRectificationEvent(this.rid);
      if (res.code === 0) {
        this.$messageSuccess({
          message: res.msg,
        });
        this.buildingWindows = false;
        this.getRectificationHistoryInfo();
      } else {
        this.$messageError({
          message: res.msg,
        });
      }
    },
    //获取整改基本信息
    async getRectificationBaseInfo() {
      const projectId = this.$route.query.id;
      const res = await this.$api.rectificationBaseInfo(projectId);
      this.caseDetails.riskEventDO = res.data.riskEventDO;
      this.caseDetails.riskEventPicDO = res.data.riskEventPicDO;
      this.caseDetails.riskEventDO.riskBldings1 = "123"
      this.caseDetails.riskEventPicDO.map((item, index) => {
        item.show = item.picPath ? false : true;
        item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
      });
      this.caseDetails.userDO = res.data.userDO || [];
      if (this.caseDetails.riskEventDO.other) {
        this.caseDetails.rectificationInfo.other = this.caseDetails.riskEventDO.other;
        if (this.caseDetails.riskEventDO.riskBldings) {
          this.caseDetails.riskEventDO.riskBldings =
            this.caseDetails.riskEventDO.riskBldings +
            "," +
            this.caseDetails.rectificationInfo.other;
        } else {
          this.caseDetails.riskEventDO.riskBldings = this.caseDetails.rectificationInfo.other;
        }
      }
    },
    //获取本次整改基本信息
    async getRectificationHistoryInfo() {
      const keywords = {
        riskEventId: this.$route.query.id,
        offset: 1,
        limit: 5,
      };
      const res = await this.$api.rectificationHistoryInfo(keywords);
      if (this.$route.query.type == "history") {
        res.data.rows.map((item, index) => {
          if (item.sqlStatus == 1) {
            this.caseDetails.rectificationHistoryList.push(item);
          }
        });
      } else {
        this.caseDetails.rectificationHistoryList = res.data.rows;
      }
      this.caseDetails.total = res.data.total;
      // this.$refs["ruleForm"].resetFields();
    },
    async getPagination(val) {
      const keywords = {
        riskEventId: this.$route.query.id,
        offset: val,
        limit: 5,
      };
      const res = await this.$api.rectificationHistoryInfo(keywords);
      this.caseDetails.rectificationHistoryList = res.data.rows;
      this.caseDetails.total = res.data.total;
    },
    handleRemove(file, fileList) {},
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    //图片放大
    openPic(picUrl) {
      this.dialogImageUrl = picUrl;
      this.dialogVisibleImg = true;
    },
  },
};
</script>
<style scoped lang="scss">
.content {
  background: rgba(255, 255, 255, 0.9);
}
.el-form-item--mini {
  margin-bottom: 12px;
}
.lucency {
  opacity: 0;
}
// .btns {
//   position: fixed;
//   right: 210px;
//   bottom: 20px;
// }
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 266px;
}
.dialog /deep/.el-select.el-input--suffix.el-input__inner {
  width: 266px;
}
</style>
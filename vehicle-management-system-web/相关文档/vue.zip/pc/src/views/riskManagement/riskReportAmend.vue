<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          :model="riskReportingData.riskReportDO"
          :rules="rules"
          ref="ruleForm"
        >
          <el-row>
            <el-col :span="12">
              <el-form-item label="报告名称：" prop="name">
                <el-input v-model="riskReportingData.riskReportDO.name"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="涉及风险事件：">
                <el-input
                  v-model="search"
                  size="mini"
                  placeholder="请输入风险事件名称/风险事件类型/风险等级"
                  style="background:rgba(255,255,255,0);border-radius:4px"
                  @keyup.enter.native="riskSearch"
                />
                <i class="el-icon-search" style="width:50px" @click="riskSearch()"></i>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item>
                <template>
                  <el-table
                    class="mc-table"
                    :data="riskReportingData.selectionOfRiskEvents"
                    style="width: 100%"
                    ref="multipleTable"
                  >
                    <!-- <el-table-column type="index" label="序号" align="center" width="80"></el-table-column> -->
                    <el-table-column type="index" align="center" label="序号" width="80" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
                    <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
                    <el-table-column
                      prop="riskEventType"
                      align="center"
                      label="风险事件类型"
                      show-overflow-tooltip
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column
                      prop="riskLevel"
                      align="center"
                      label="风险等级"
                      show-overflow-tooltip
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="最初报告时间" show-overflow-tooltip>
                      <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="建议整改截止日期" show-overflow-tooltip>
                      <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
                    </el-table-column>
                     <el-table-column align="center" label="风险事件编号" width="120" prop="eventIdForUser"></el-table-column>
                    <el-table-column prop="riskEventStatus" align="center" label="业务状态">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                    </el-table-column>
                  </el-table>
                </template>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="承保意见：">
                <el-table
                  class="mc-table"
                  style="width: 100%"
                  :data="riskReportingData.riskReportItemDO"
                >
                  <el-table-column prop="clause" align="center" label="保险条款名称"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)" width="150"></el-table-column>
                  <el-table-column prop="type" align="center" label="保险类型" width="150">
                    <template
                      slot-scope="scope"
                    >{{scope.row.type | filterCode(listBaseData.IDI_LIABILITIES_TYPE,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2 , maxRows: 4}"
                        style="opacity:0.2 color:#3E3A39;"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        class="tex"
                        placeholder="请输入内容"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报告人：">
                <el-input
                  v-model="riskReportingData.riskReportDO.reporter"
                  readonly
                  @click.native="openAgency({title: '报告人', type: 'BGR',num:'2' })"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="审核人：">
                <el-input
                  v-model="riskReportingData.riskReportDO.reviewer"
                  readonly
                  @click.native="openAgency({title: '审核人', type: 'SHR' ,num:'2'})"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="批准人：">
                <el-input
                  v-model="riskReportingData.riskReportDO.approver"
                  readonly
                  @click.native="openAgency({title: '批准人', type: 'PZR' ,num:'2'})"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报告日期：" prop='reportDate'>
                <el-date-picker
                  type="date"
                  :picker-options="dateValid"
                  placeholder="选择日期"
                  v-model="riskReportingData.riskReportDO.reportDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="上传报告：" prop="fileName">
                <el-input v-model="riskReportingData.riskReportDO.fileName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-col :span="3" style="position: relative; left: 10px">
                <img v-if="!upload" :src="imgUpload" class="img-upload" />
                <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
                <!-- <img v-if="upload" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
              </el-col>
              <el-col :span="21">
                <el-upload
                  class="inline-block mlr97"
                  action
                  :http-request="uploadFile"
                  :show-file-list="false"
                  :on-change="handleChange"
                >
                  <el-button size="mini" type="primary">上传</el-button>
                </el-upload>
                <el-button size="mini" @click="delBtn()">删除</el-button>
                <el-button size="mini" @click="downloadBtn()" :disabled="disabled">下载</el-button>
              </el-col>
            </el-col>
          </el-row>
          <el-row style="text-align: right; margin-top: 100px" class="btns">
            <el-button size="mini" type="primary" @click="saveReturnVisit(0)">保存</el-button>
            <el-button size="mini" type="primary" @click="saveReturnVisit(1)">提交</el-button>
            <el-button size="mini" @click="shutbtn()">关闭</el-button>
          </el-row>
        </el-form>
        <!-- 弹窗 -->
        <el-dialog title="选择风险事件" :visible.sync="dialogVisible" width="900px" class="dialog" :close-on-click-modal="false">
          <el-row style="border:1px #ccc solid">
            <el-row>
              <el-table
                class="mc-table"
                :data="riskReportingData.searchForRiskEvents"
                ref="multipleTable"
                @select="checkedList"
                @select-all="checkedLists"
              >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <!-- <el-table-column type="index" label="序号" align="center"></el-table-column> -->
                <el-table-column type="index" align="center" label="序号" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
                <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
                <el-table-column
                  prop="riskEventType"
                  align="center"
                  label="风险事件类型"
                  show-overflow-tooltip
                >
                  <template
                    slot-scope="scope"
                  >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                </el-table-column>
                <el-table-column prop="riskLevel" label="风险等级" align="center" show-overflow-tooltip>
                  <template
                    slot-scope="scope"
                  >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                </el-table-column>
                <el-table-column label="最初报告时间" show-overflow-tooltip>
                  <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
                </el-table-column>
                <el-table-column align="center" label="建议整改截止日期" show-overflow-tooltip>
                  <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
                </el-table-column>
                 <el-table-column align="center" label="风险事件编号" width="120" prop="eventIdForUser"></el-table-column>
                <el-table-column prop="riskEventStatus" align="center" label="业务状态" width="120">
                  <template
                    slot-scope="scope"
                  >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                </el-table-column>
              </el-table>
            </el-row>
          </el-row>
          <!-- 分页 -->
          <el-pagination
            small
            class="text-center mt10 control block"
            @current-change="handleCurrentChangePaging"
            :current-page.sync="offset"
            :page-size="this.limit"
            layout="prev, pager, next"
            :total="this.total"
          ></el-pagination>
          <el-row style="text-align: right; margin-top: 30px" class="btns">
            <el-button size="mini" type="primary" @click="confirmationBtn()">关闭</el-button>
            <!-- <el-button size="small" class="btn" @click="cancelBtn()">取消</el-button> -->
          </el-row>
        </el-dialog>
        <el-dialog class="dialog" :title="title" :visible.sync="openVisible" width="615px" :close-on-click-modal="false">
          <select-agency
            :type="type"
            :title="title"
            @getAngency="getAngency"
            v-if="openVisible"
            :num="num"
            :project="project"
          ></select-agency>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<script>
import MessageEdit from "@/components/Message.vue";
import { mapGetters, mapActions } from "vuex";
import imgUpload from "@/assets/imgs/put.png";
import SelectAgency from "@/components/selectAgency.vue";
import axios from 'axios';
export default {
  components: {
    MessageEdit,
    SelectAgency
  },
  name: "AddNewProject", //风险评估报告修改页面
  data() {
    return {
      progress:0,
      dateValid: {
      disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      disabled: true,
      rules: {
        name: [{ required: true, message: "请输入项目名称", trigger: "blur" }],
        fileName: [{ required: true, message: "请上传报告", trigger: "change" }],
         reportDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
      },
      upload: false,
      imgUpload,
      insRemark: "", //建议
      search: undefined,
      fileName: "",
      url: "",
      dialogVisible: false,
      total: undefined,
      limit: 10, //弹窗展示数据
      offset: 1, //第几页
      valueData: undefined,
      verificationPass: false,
      cloudPath: "", //文件临时位置
      assessmentReportFile: "", //上传文件成功后URL
      riskReportingData: {
        riskReportDO: {
          name: "",
          fileName: ""
        },
        riskReportItemDO: [], //建议
        selectionOfRiskEvents: undefined,
        searchForRiskEvents: [],
        riskEventReportRelDO: []
      },
      dossierSelectId: [], //选中表格数据
      pageIndex: 1, //当前页码
      openVisible: false,
      type: "",
      title: "",
      num: "",
      project: ""
    };
  },
  computed: {
    ...mapGetters(["district", "listBaseData", "getBasicBstablish"])
  },
  created() {
    this.riskAssessment();
    this.riskEventFunction();
  },
  methods: {
    openAgency(data) {
      this.openVisible = true;
      this.type = data.type;
      this.title = data.title;
      this.num = data.num;
      this.project = this.$route.query.projectId;
    },
    getAngency(value) {
      if (value.type == "BGR") {
        this.riskReportingData.riskReportDO.reporter = value.username;
      } else if (value.type == "SHR") {
        this.riskReportingData.riskReportDO.reviewer = value.username;
      } else if (value.type == "PZR") {
        this.riskReportingData.riskReportDO.approver = value.username;
      }
      this.openVisible = false;
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.riskReportingData.selectionOfRiskEvents) {
            if (item2.id == item.id) {
              flag = true;
            }
          }
          if (!flag) {
            this.riskReportingData.selectionOfRiskEvents.push(item);
          }
        }
      } else {
        for (let item of this.riskReportingData.searchForRiskEvents) {
          for (let [
            index,
            item2
          ] of this.riskReportingData.selectionOfRiskEvents.entries()) {
            if (item.id == item2.id) {
              this.$delete(this.riskReportingData.selectionOfRiskEvents, index);
            }
          }
        }
      }
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex(item => {
        return item.id == row.id;
      });
      if (isCkeck < 0) {
        for (let [
          index,
          item2
        ] of this.riskReportingData.selectionOfRiskEvents.entries()) {
          if (item2.id == row.id) {
            this.$delete(this.riskReportingData.selectionOfRiskEvents, index);
          }
        }
      } else {
        this.riskReportingData.selectionOfRiskEvents.push(row);
      }
    },
    //请求风险事件数据(勾选)
    async riskEventFunction() {
      const rid = {
        reportId: this.$route.query.reportId
      };
      const res = await this.$api.riskEvents(rid);
      this.riskReportingData.selectionOfRiskEvents = res.data;
    },
    //请求风险事件数据(全部)
    async riskEventFun() {
      let projectId = this.$route.query.projectId;
      let info = {
        projectId,
        fuzzyQuery: this.search ? this.search : "",
        limit: this.limit,
        offset: this.offset,
        reportId: this.riskReportingData.riskReportDO.reportId
      };
      const { data } = await this.$api.riskEvent(info);
      this.total = data.total;
      this.riskReportingData.searchForRiskEvents = data.rows;
      for (let item of this.riskReportingData.selectionOfRiskEvents) {
        for (let item2 of this.riskReportingData.searchForRiskEvents) {
          if (item.id == item2.id) {
            setTimeout(() => {
              this.$refs.multipleTable.toggleRowSelection(item2);
            });
          }
        }
      }
    },
    //请求风险数据
    async riskAssessment() {
      this.id = this.$route.query.id;
      const res = await this.$api.riskDetails(this.id);
      this.total = res.data.total;
      this.riskReportingData.riskReportDO = res.data.riskReportDO;
      this.url = res.data.riskReportDO.assessmentReportFile;
      this.riskReportingData.riskReportItemDO = res.data.riskReportItemTrueDO;
      if (this.riskReportingData.riskReportDO.fileName) {
        this.disabled = false;
      }
    },
    shutbtn() {
      //关闭按钮
      this.$router.go(-1);
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      this.riskEventFun();
    },
    //表单校验
    async saveReturnVisit(flag) {
      if (flag == "1") {
        this.$refs["ruleForm"].validate(valid => {
          if (valid) {
            this.verificationPass = true;
          } else {
            return false;
          }
        });
      } else {
        this.verificationPass = true;
      }
      if (this.verificationPass) {
        this.$store.dispatch("loading", true);
        this.storageFun();
        this.riskReportingData.riskReportDO.sqlStatus = flag;
        this.riskReportingData.riskReportDO.reportOrgId = JSON.parse(
          sessionStorage.getItem("eidi.ins")
        ).orgId;
        const keywords = this.riskReportingData;
        const res = await this.$api.preservationRisk(keywords);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
          this.$store.dispatch("loading", false);
        } else {
          this.$store.dispatch("loading", false);
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    //搜索按钮
    riskSearch() {
      this.riskEventFun();
      this.dialogVisible = true;
    },
    //取消按钮
    cancelBtn() {
      this.dialogVisible = false;
    },
    //确定按钮
    confirmationBtn() {
      this.dialogVisible = false;
    },
    handleChange(file) {},
    //下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.riskReportingData.riskReportDO.fileName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    async uploadFile(param) {
      //上传
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      this.projectId = this.$route.query.projectId;
      let data = {
        projectId: this.projectId
      };
      file.append("projectId", this.projectId);
      file.append("fileIcon", "assessmentReportFile");
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this.progress = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.progress=100
          this.$messageSuccess({
            message: res.msg
          });
          this.disabled = false;
          this.assessmentReportFile = res.data.data.cloudDocId;
          this.riskReportingData.riskReportDO.assessmentReportFile = this.assessmentReportFile;
          this.riskReportingData.riskReportDO.fileName = res.data.data.fileName;
          this.url = res.data.data.cloudDocId;
        } else {
          this.$messageError({
            message: res.data.msg
          });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    // 删除
    delBtn() {
      this.riskReportingData.riskReportDO.fileName = "";
      this.url = "";
      this.disabled = true;
    },
    storageFun() {
      //获取数据
      this.riskReportingData.selectionOfRiskEvents.forEach(data => {
        this.riskReportingData.riskEventReportRelDO.push(data.id);
      });
    }
  }
};
</script>
<style scoped lang="scss">
.el-form-item--mini {
  margin-bottom: 12px;
}
.rid {
  margin-right: 150px;
}
.lucency {
  opacity: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
}
.buttn {
  width: 64.5px;
  height: 29.5px;
  background: rgba(16, 143, 235, 1);
  border-radius: 8px;
  color: #fff;
}
.control {
  text-align: right;
  margin-bottom: 20px;
}
.tex {
  width: 318px;
}
.el-icon-search {
  position: absolute;
  top: 7px;
  left: 345px;
  font-size: 14px;
  color: #a6adb5;
}
.con-head {
  margin-top: 25px;
  margin-bottom: 15px;
  .el-input {
    /deep/ .el-input__inner {
      height: 28px;
      border-radius: 0;
      border: 1px solid #297ae3;
    }
  }
  /deep/ .el-input-group__append {
    background: #297ae3;
    border-radius: 0;
    border: 0;
    padding: 0;
    width: 38px;
    height: 28px;
  }
  /deep/ .el-button {
    color: #fff;
    font-size: 20px;
  }
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.el-input--mini /deep/ .el-input__inner {
  border: none;
}
</style>
<template>
  <div style="position: relative">
    <div class="content">
      <el-row>
        <div>
          <div class="case_title">
            <i class="el-icon-arrow-left mouse-pointer" @click="backMytodo"></i>
            <span @click="backMytodo" class="mouse-pointer">风险事件管理</span>
            <span style="float: right;" @click.stop="show3 = !show3" class="mouse-pointer">筛选</span>
          </div>
        </div>
        <div>
          <transition>
            <div v-show="show3" class="transition-box">
              <el-row style="margin-bottom:10px">
                <el-col :span="2">&nbsp;</el-col>
                <el-col :span="10">
                  <el-input placeholder="请输入风险事件名称/风险事件编号" size="small" v-model="riskFuzzyQuery">
                    <el-button type="primary" slot="append" icon="el-icon-search" @click="riskEventScreening"></el-button>
                  </el-input>                  
                </el-col>
              </el-row>
              <div style="text-align: left;">
                <span class="font-bold">风险事件类型:</span>
                <div
                  style="margin-left: 5px; padding-bottom: 3px;"
                  class="inline-block area mouse-pointer"
                  @click="handleQuery(item,'falg')"
                  :class="{'checked': item.check}"
                  v-for="item of listBaseData.IDI_RISK_EVENT_TYPE"
                  :key="item.ddId"
                  :label="item.dictKey"
                >{{item.dictValue}}</div>
              </div>
              <div>
                <div style="text-align: left;">
                  <span class="font-bold" style="padding-right: 30px;">风险等级:</span>
                  <div
                    style="padding-bottom: 3px;"
                    class="inline-block area mouse-pointer"
                    @click="handleQuery(item)"
                    :class="{'checked': item.check}"
                    v-for="item of listBaseData.IDI_RISK_EVENT_LEVEL"
                    :key="item.ddId"
                    :label="item.dictKey"
                  >{{item.dictValue}}</div>
                </div>
              </div>
              <div style="text-align: left;">
                <el-col class="blue font-bold" style="margin-bottom: 7px" :span="2">发生日期:</el-col>
                <el-col :span="12">
                  <el-date-picker
                    class="date"
                    type="date"
                    @change="riskEventScreening"
                    :picker-options="pickerOptionsStart"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    v-model="minRiskFoundTime"
                    placeholder="发生起期"
                  ></el-date-picker>
                  <span style="margin-left:7.75px">-</span>
                  <el-date-picker
                    class="date"
                    style="margin: 0 0 16px 7.75px"
                    type="date"
                    @change="riskEventScreening"
                    :picker-options="pickerOptionsEnd"
                    value-format="yyyy-MM-dd 23:59:59"
                    v-model="maxRiskFoundTime"
                    placeholder="发生止期"
                  ></el-date-picker>
                </el-col>
              </div>
            </div>
          </transition>
        </div>
      </el-row>
      <el-table
        class="mc-table"
        tooltip-effect="light"
        :data="tableData"
        style="width: 100%"
        @row-dblclick="dbGoVisitDetails"
      >
        <!-- 计算分页 -->
        <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
        <!-- <el-table-column type="index" align="center" label="序号" width="100"></el-table-column> -->
        <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
        <el-table-column label="风险事件类型" align="center">
          <template
            slot-scope="scope"
          >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
        </el-table-column>
        <el-table-column prop="riskLevel" label="风险等级" align="center">
          <template
            slot-scope="scope"
          >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
        </el-table-column>
        <el-table-column align="center" label="发生时间" width="120">
          <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate }}</template>
        </el-table-column>
        <el-table-column align="center" label="建议整改截止日期" width="120">
          <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
        </el-table-column>
        <el-table-column align="center" label="风险事件编号" width="120" prop="eventIdForUser"></el-table-column>
        <el-table-column prop="riskEventStatus" align="center" label="业务状态">
          <template
            slot-scope="scope"
          >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
        </el-table-column>
        <el-table-column prop="tel" align="center">
          <template slot-scope="scope">
            <el-dropdown
              placement="bottom"
              size="small"
              trigger="click"
              @command="handleCommand(scope.row,$event)"
            >
              <span class="el-dropdown-link">
                <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                <span v-if="scope.row.completeType=='0'">
                  <el-dropdown-item
                    icon="el-icon-remove-outline"
                    command="1"
                    v-if="scope.row.sqlStatus==0"
                  >删除</el-dropdown-item>
                  <el-dropdown-item
                    icon="el-icon-document"
                    command="2"
                    v-if="scope.row.sqlStatus==0"
                  >修改</el-dropdown-item>
                  <el-dropdown-item
                    icon="el-icon-document"
                    command="3"
                    v-if="scope.row.sqlStatus==1"
                  >报告整改</el-dropdown-item>
                  <el-dropdown-item
                    icon="el-icon-reading"
                    command="4"
                    v-if="scope.row.sqlStatus==1"
                  >历史整改</el-dropdown-item>
                  <el-dropdown-item
                    icon="el-icon-message"
                    command="6"
                    v-if="scope.row.sendSHZJ==1&&tenantId=='eidi-shanghai'"
                  >逾期推送</el-dropdown-item>
                   <el-dropdown-item
                    icon="el-icon-reading"
                    command="5"
                    v-if="scope.row.sqlStatus==1&&scope.row.riskEventStatus=='RES06'"
                  >确认整改</el-dropdown-item>
                </span>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      <div class="project-collection mouse-pointer" @click="goRiskReportDetails('','new')">
        <i class="el-icon-plus"></i>
        <div>新增风险事件</div>
      </div>
    </div>
    <el-pagination
      small
      class="page-lucency text-center mt10 control"
      @current-change="handleCurrentChange"
      :current-page.sync="offset"
      :page-size="this.limit"
      layout="prev, pager, next"
      :total="this.total"
    ></el-pagination>
  </div>
</template>
<script>
import MessageEdit from "@/components/Message.vue";
import { log, debuglog } from "util";
import { async } from "q";
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "RiskEventManagement",
  components: { MessageEdit },
  data() {
    return {
      tenantId:"",
      show3: false,
      total: undefined,
      limit: 8, //每页几条数据
      offset: 1, //第几页
      value1: "",
      tableData: [],
      filterHold: [],
      value: "",
      listQuery: {
        status: "",
        list: ""
      },
      riskLevel: [], //风险等级
      riskEventType: [], //风险类型
      minRiskFoundTime: "",
      maxRiskFoundTime: "",
      riskFuzzyQuery:'',
      pickerOptionsStart: {
        disabledDate: time => {
          if (this.maxRiskFoundTime) {
            return time.getTime() > new Date(this.maxRiskFoundTime).getTime();
          }
        }
      },
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.minRiskFoundTime) {
            return time.getTime() < new Date(this.minRiskFoundTime).getTime();
          }
        }
      }
    };
  },
  computed: {
    ...mapGetters(["district", "listBaseData", "getBasicBstablish"])
  },
  methods: {
    dbGoVisitDetails(row) {
      this.goRiskReportDetails(row.id, "view");
    },
    handleRemove(file, fileList) {},
    handleCommand(item, command) {
      if (command === "0") {
        //查看数据
        this.goRiskReportDetails(item.id, "view");
      } else if (command === "1") {
        //删除数据
        this.removeEventHandle(item.id);
      } else if (command === "2") {
        //编辑
        this.goRiskReportDetails(item.id, "edit");
      } else if (command === "3") {
        //整改
        this.goRiskReportDetails(item.id, "rectification");
      } else if (command === "4") {
        //历史整改
        this.goRiskReportDetails(item.id, "history");
      }else if(command === "5"){
        //确认整改
        this.goRiskReportDetails(item.id, "confirm");
      }else if(command === "6"){
        http.get(`/risk/RiskEvent/sendSHZJ/${item.id}`).then(res=>{
          if(res.code==0){
            this.$messageSuccess({
              message: "推送成功！"
            });
            this.riskEventScreening();
          }else{
            this.$messageError({
              message: "推送失败，请重试"
            });
          }
        })
      }
    },
    //新增new、查看view、编辑edit
    goRiskReportDetails(id, type) {
      this.$router.push({
        path: "/riskReportManagement",
        query: {
          id: id,
          projectId: this.$route.query.projectId,
          type: type
        }
      });
    },
    //删除
    async removeEventHandle(num) {
      this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          const res = await this.$api.deleteRiskEvent(num);
          if (res.code == 0) {
            this.$messageSuccess({
              message: "删除成功"
            });
            this.riskEventScreening();
          } else {
            this.$messageError({
              message: "删除失败 "
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    backMytodo() {
      this.$router.go(-1);
    },
    handleCurrentChange(val) {
      this.offset = val;
      this.riskEventScreening();
    },
    async riskEventScreening() {
      const objId = {
        projectId: this.$route.query.projectId,
        limit: this.limit,
        offset: this.offset,
        riskEventType: this.riskEventType,
        riskLevel: this.riskLevel,
        riskFuzzyQuery: this.riskFuzzyQuery,
        maxRiskFoundTime: this.maxRiskFoundTime,
        minRiskFoundTime: this.minRiskFoundTime
      };
      const res = await this.$api.riskEventScreening(objId);
      this.tableData = res.data.rows;
      this.total = res.data.total;
    },
    //风险等级筛选
    handleQuery(item, falg, isCode = false) {
      let riskEventType = [];
      let riskLevel = [];
      item.check = !item.check;
      if (falg) {
        this.listBaseData.IDI_RISK_EVENT_TYPE.map((item, index) => {
          if (item.check) {
            riskEventType.push(item.dictKey);
          }
        });
        this.riskEventType = riskEventType;
        this.riskEventScreening();
      } else {
        this.listBaseData.IDI_RISK_EVENT_LEVEL.map((item, index) => {
          if (item.check) {
            riskLevel.push(item.dictKey);
          }
        });
        this.riskLevel = riskLevel;
        this.riskEventScreening();
      }
    }
  },
  created() {
    this.riskEventScreening();
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    console.log(this.tenantId)
    // this.listBaseData.IDI_RISK_EVENT_TYPE.map((item, index) => {
    //   item.check = false;
    // });
    // this.listBaseData.IDI_RISK_EVENT_LEVEL.map((item, index) => {
    //   item.check = false;
    // });
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 60px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 5px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 0;
}
.el-table__column-filter-trigger i {
  color: #ffffff !important;
}
.el-form-item {
  margin-bottom: 0;
}
$color: rgba(62, 58, 57, 1);
.area {
  color: $color;
  padding: 2px 6px;
  // margin: 0 12.5px 8.5px 0;
  margin: 0 2.5px 10px 0;
}
$blue: #297ae3;
.checked {
  background-color: $blue;
  color: #fff !important;
  border-radius: 15px;
}
.transition-box {
  width: 100%;
  // height: 65px;
  border-radius: 4px;
  color: #297ae3;
  padding: 5px 5px;
  box-sizing: border-box;
  font-size: 12.5px;
}
.el-dropdown-menu /deep/ .el-icon-reading {
  color: #2a7be3;
  font-size: 16px;
}
.el-dropdown-menu /deep/ .el-icon-message {
  color: #2a7be3;
  font-size: 16px;
}
.date {
  width: 140px;
  /deep/ .el-input__icon {
    color: #297ae3 !important;
  }
  /deep/ .el-input__inner {
    border-radius: 1px;
    opacity: 0.68;
    height: 22px !important;
    line-height: 22px !important;
  }
  /deep/ .el-input__prefix {
    top: -9px;
    left: 0;
  }
  /deep/ .el-input__suffix {
    right: 0;
    top: -9px;
  }
} 
.el-input /deep/ .el-input__inner{
  height: 25px;
  line-height: 25px;
}
</style>
<template>
  <div style="position: relative">
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'RiskManagement' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomOutLeft' :'animated zoomOutLeft'"
    >
      <el-row v-show="showMyCase==='RiskManagement'">
        <el-col :span="8">
          <div class="content" style="border-radius:6px;padding:0 10px">
            <span
              class="el-icon-edit-outline mouse-pointer"
              @click="selectEchart(0)"
              style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
            >自定义</span>
            <div v-show="this.variable" class="newclass" style="height:240px">
              <span>{{this.echartTitle}}</span>
            </div>
            <chart ref="chart"></chart>
          </div>
          <!-- 无数据时 -->
          <div
            v-show="this.dataShow.length===0"
            style="position: absolute;left: 15%;top: 150px;transform: translate(-50%,-67%);"
          >
            <img src="@/assets/imgs/noData.png" width="220" height="171" />
          </div>
          <div class="content" style="border-radius:6px;padding:0 10px">
            <span
              class="el-icon-edit-outline mouse-pointer"
              @click="selectEchart(1)"
              style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
            >自定义</span>
            <div v-show="this.variabletwo" class="newclass" style="height:240px">
              <span>{{this.echartTitletwo}}</span>
            </div>
            <chart ref="chartLine"></chart>
          </div>
          <!-- 无数据时 -->
          <div
            v-show="this.dataShow.length===0"
            style="position: absolute;left: 15%;top: 400px;transform: translate(-50%,-67%);"
          >
            <img src="@/assets/imgs/noData.png" width="220" height="171" />
          </div>
        </el-col>
        <el-col :span="1">
          <div class="content1">
            <div
              @click="showRisk('riskEvent',1)"
              class="toggle_button"
              :class="[showRiskPage==='riskReport'?'unchecked_state':'checked_state']"
            >
              <div style="padding-top: 7px;">风险事件管理</div>
            </div>
            <div
              @click.stop="showRisk('riskReport',1)"
              class="toggle_button"
              :class="[showRiskPage==='riskReport'?'checked_state':'unchecked_state']"
            >
              <div style="padding-top: 17px;">报告管理</div>
            </div>
          </div>
          <div class="content1"></div>
        </el-col>
        <el-col :span="15" v-if="showRiskPage==='riskEvent'">
          <el-row>
            <div v-for="(item,index) in riskManagementCase.rows" :key="item.id">
              <el-col :span="12">
                <div
                  class="content"
                  style="border-bottom-right-radius:6px;border-bottom-left-radius:6px;cursor:pointer;"
                  :class="{'even_num':  (index%2 ==0)? false:true}"
                  @click.stop="intoRectification(item)"
                >
                  <div class="risk_card">
                    <div
                      class="clearfix"
                      :title="item.riskEventName"
                      style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                    >
                      <span>{{item.riskEventName}}&nbsp;</span>
                    </div>
                    <el-row>
                      <el-col :span="8" style="text-align: center;">
                        <el-progress
                          type="circle"
                          :stroke-width="10"
                          class="my_progress"
                          :percentage="item.amendProgress"
                          style="width:100px;"
                        ></el-progress>
                        <div style="position: absolute;top: 60px;left:28px">整改进度</div>
                      </el-col>
                      <el-col :span="15" :offset="1">
                        <el-row>
                          <el-col :span="24" style="text-align: left">
                            <div style="float:left">项目名称：</div>
                            <div
                              :title="item.projectName"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                            >{{item.projectName}}</div>
                          </el-col>
                          <!-- <el-col :span="16"></el-col> -->
                        </el-row>
                        <el-row style="margin-top:6px">
                          <el-col :span="24" style="text-align: left;">
                            <div style="float:left">保单号：</div>
                            <div
                              :title="item.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                            >{{item.insContractNo}}</div>
                          </el-col>
                        </el-row>
                        <el-row style="margin-top:6px">
                          <el-col :span="24" style="text-align: left">检查人：{{item.createdBy}}</el-col>
                        </el-row>
                        <el-row style="margin-top:6px">
                          <el-col :span="24" style="text-align: left">
                            <div style="float:left">严重程度：</div>
                            <div
                              style="float:left"
                              v-if="item.riskLevel!=null&&item.riskLevel!=''"
                            >{{item.riskLevel| filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</div>
                            <div v-else style="float:left">未填写</div>
                          </el-col>
                        </el-row>
                        <el-row style="margin-top:6px">
                          <el-col :span="24" style="text-align: right">
                            <div style="float:left">事件类型：</div>
                            <div
                              style="float:left"
                              v-if="item.riskEventType!=null&&item.riskEventType!=''"
                            >{{item.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</div>
                            <div v-else style="float:left">未填写</div>
                          </el-col>
                        </el-row>
                      </el-col>
                    </el-row>
                  </div>
                  <el-row class="risk_btn">
                    <div
                      v-if="control.includes('riskManagementUrging')"
                      class="inline-block"
                      style="width: 50%"
                    >
                      <el-button
                        :disabled="isDisabled"
                        class="inline-block"
                        type="warning"
                        size="small"
                        style="background-color:#E3A658;border-bottom-left-radius:6px"
                        @click.stop="urgent(item)"
                      >催办</el-button>
                    </div>
                    <div
                      v-if="control.includes('riskManagementEnd')"
                      class="inline-block"
                      style="width: 50%"
                    >
                      <el-button
                        v-if="item.completeType=='0'"
                        class="inline-block"
                        type="primary"
                        size="small"
                        style="border-bottom-right-radius:6px"
                        @click.stop="endRiskEvent(item)"
                      >结束风险事件</el-button>
                      <el-button
                        v-if="item.completeType=='1'"
                        class="inline-block"
                        type="primary"
                        size="small"
                        @click.stop
                        style="border-bottom-right-radius:6px"
                      >已结束风险事件</el-button>
                    </div>
                  </el-row>
                </div>
              </el-col>
            </div>
            <!--   style="position: absolute;left: 50%;top:250px;transform: translate(-50%,-67%);" -->
            <div
              v-if="riskManagementCase.rows && riskManagementCase.rows.length===0"
              style="height: 486px;background: rgba(255, 255, 255, 0.9);border-radius: 6px;"
            >
              <img
                src="@/assets/imgs/noData.png"
                width="220"
                height="171"
                style="position: absolute;top: 25%;left: 35%;"
              />
            </div>
          </el-row>
          <el-pagination
            small
            class="page-lucency control"
            style="text-align: right;margin-top:3px"
            layout="prev, pager, next"
            @current-change="handleCurrentChange"
            :current-page.sync="offsets"
            :page-size="4"
            :total="riskManagementCase.total"
            v-if="riskManagementCase.total!=0"
          ></el-pagination>
        </el-col>
        <el-col :span="15" v-if="showRiskPage==='riskReport'">
          <el-row>
            <div
              @click="goForm(item)"
              style="cursor:pointer"
              v-for="(item,index1) in reportManagementCase.rows"
              :key="item.name"
            >
              <el-col :span="12">
                <div
                  class="content"
                  style="border-bottom-right-radius:6px;border-bottom-left-radius:6px;"
                  :class="{'even_num':  (index1%2 ==0)? false:true}"
                >
                  <div class="risk_card">
                    <div
                      class="clearfix"
                      :title="item.projectName"
                      style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                    >
                      <span>{{item.projectName}}&nbsp;</span>
                    </div>
                    <el-row>
                      <el-col :span="6" class="date leftContent" style="text-align: center;">
                        <span>{{item.mydate.case_month}}</span>
                        <div class="days" style="line-height: 40px">{{item.mydate.case_day}}</div>
                        <div class="year days" style="line-height: 14px">{{item.mydate.case_year}}</div>
                      </el-col>
                      <el-col :span="18">
                        <el-row>
                          <el-col :span="24" style="text-align: left">
                            <div style="float:left">保单号：</div>
                            <div
                              :title="item.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:160px float:left"
                            >{{item.insContractNo}}</div>
                          </el-col>
                        </el-row>
                        <el-row style="margin-top:6px">
                          <el-col :span="24" style="text-align: left">住宅性质：{{item.dictValue}}</el-col>
                        </el-row>
                        <el-row style="margin-top:6px">
                          <el-col :span="24" style="text-align: left">阶段：{{item.projectChnStatus}}</el-col>
                        </el-row>
                      </el-col>
                    </el-row>
                  </div>
                  <el-row
                    class="risk_btn"
                    v-if="item.projectStatus=='ProjectByCompleted' && item.taskName=='riskReportMent'"
                  >
                    <div @click.stop="goForm(item,true)" class="inline-block" style="width: 50%">
                      <el-button
                        class="inline-block"
                        type="warning"
                        size="small"
                        style="background-color:#E3A658;border-bottom-left-radius:6px"
                      >进入理赔</el-button>
                    </div>
                    <div class="inline-block" style="width: 50%">
                      <el-button
                        class="inline-block"
                        type="primary"
                        size="small"
                        style="border-bottom-right-radius:6px"
                        @click.stop="goToReturnVisitRM(item)"
                      >回访报告管理</el-button>
                    </div>
                  </el-row>
                  <el-row
                    class="risk_btn"
                    v-if="item.projectStatus=='ProjectOnBuliding' && item.taskName=='riskCtrlMgr'"
                  >
                    <div
                      class="inline-block"
                      style="width: 50%"
                      @click.stop="riskAssessmentReport(item)"
                    >
                      <el-button
                        class="inline-block"
                        type="primary"
                        size="small"
                        style="background-color:#E3A658;border-bottom-left-radius:6px"
                      >风险评估报告管理</el-button>
                    </div>
                    <div
                      class="inline-block"
                      style="width: 50%"
                      @click.stop="finalRiskInspectionReport(item)"
                    >
                      <el-button
                        class="inline-block"
                        type="warning"
                        size="small"
                        style="border-bottom-right-radius:6px;background: rgba(41, 122, 227, 0.56)"
                      >最终风险检查报告</el-button>
                    </div>
                  </el-row>
                </div>
              </el-col>
            </div>
            <div
              v-if="reportManagementCase.rows && reportManagementCase.rows.length===0"
              style="height: 486px;background: rgba(255, 255, 255, 0.9);border-radius: 6px;"
            >
              <img
                src="@/assets/imgs/noData.png"
                width="220"
                height="171"
                style="position: absolute;top: 25%;left: 35%;"
              />
            </div>
          </el-row>
          <el-pagination
            small
            class="page-lucency control"
            style="text-align: right;margin-top:3px"
            layout="prev, pager, next"
            @current-change="handleReportChange"
            :current-page.sync="offset"
            :page-size="4"
            :total="reportManagementCase.total"
            v-if="reportManagementCase.total!=0"
          ></el-pagination>
        </el-col>
      </el-row>
    </transition>
    <!-- echart自定义 -->
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'RiskManagement' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-if="showMyCase==='mytodoEchartList'" style="position: absolute; top: 0;width: 100%;">
        <MytodoEchartList
          @option="option"
          @backMytodo="backMytodo"
          :origEchartId="origEchartId"
          :interfaceName="interfaceName"
        ></MytodoEchartList>
      </div>
    </transition>
    <!-- 调用弹框组件 -->
    <dialog-edit />
    <transition
      :duration="1500"
      :enter-active-class="showMyCase==='formManagement' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase==='RiskManagement' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-show="showMyCase==='formManagement'" style="position: absolute; top: 0;width: 100%;">
        <div id="top">
          <flow-chart :current="current" @goBack="goBack('close')" />
          <basic-information :disabled="true" />
          <bstablish-information :disabled="true" ref="basicBstablish" showMyCase="UnderwritingInformation"/>
          <underwriting-information
            ref="underwriting"
            :disabled="true"
            showMyCase="UnderwritingInformation"
          />
          <insurance-review
            ref="insuranceReviewTwo"
            :disabled="true"
            title="保险审核"
            taskType="underwrite"
          />
          <risk-plan :disabled="true" ref="riskPlan" />
          <insurance-review
            :disabled="true"
            ref="insuranceReview"
            title="风险管理计划审核"
            taskType="checkRiskCtrlPlan"
          />
          <risk-report-list :disabled="true" ref="riskReportList" />
          <risk-events-list :disabled="true" ref="riskEventsList" />
          <risk-final-report :disabled="true" ref="riskFinalReport" />
          <insurance-coverage v-show="isShowArea" ref="insuranceCoverage" :disabled="true" />
          <insurance-review
            v-show="isShowArea"
            title="竣工保险审核"
            taskType="insuranceReview"
            :disabled="true"
          />
          <project-returns v-show="isShowArea" ref="projectReturns" :disabled="true" />
          <el-row v-if="isAction">
            <el-col :span="22" class="text-right">
              <el-button
                type="primary"
                style="background-color: #108FEB"
                size="mini"
                @click="doSubmit"
              >提交</el-button>
              <el-button size="mini" @click="showMyCase='RiskManagement'">关闭</el-button>
            </el-col>
          </el-row>
        </div>
      </div>
    </transition>
    <el-button @click="goTop" id="go-top" circle :style="screen_width">
      <i class="el-icon-arrow-up"></i>
    </el-button>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import chart from "@/components/charts";
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import DialogEdit from "./riskManagementDialog.vue";
import MytodoEchartList from "@/views/myToDo/myToDoEchartList";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
import RiskPlanReview from "@/components/ProjectSummary/RiskPlanReview"; //风险管理计划审核--竣工保险审核
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import ProjectReturns from "@/components/ProjectSummary/ProjectReturns"; //项目回访列表

export default {
  name: "RiskManagement",
  components: {
    chart,
    DialogEdit,
    MytodoEchartList,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    UnderwritingInformation,
    RiskPlan,
    InsuranceCoverage,
    RiskPlanReview,
    RiskReportList,
    RiskEventsList,
    RiskFinalReport,
    ProjectReturns,
    InsuranceReview
  },
  computed: {
    ...mapGetters([
      "app",
      "control",
      "riskManagementCase",
      "reportManagementCase",
      "userInfo",
      "fuzzyQuery",
      "getBasicBstablish",
      "getUnderwritingInformation",
      "getInsuranceCoverage",
      "getInsuranceReview",
      "listBaseData",
      "showRiskPage",
      "screen",
      'offsetLists'
    ]),
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  data() {
    return {
      charts: {
        maanshan: maanshan,
        beijing: beijing,
        shanghai: shanghai,
        yangquan: yangquan
      },
      isDisabled: false,
      showMyCase: "RiskManagement",
      type: "rectification",
      index: "1",
      riskList: [{ name: "2" }, { name: "4" }, { name: "5" }, { name: "7" }],
      riskTotal: 0,
      interfaceName: "RISKMGMT",
      dataShow: [],
      ids: "",
      idstwo: "",
      origEchartId: "",
      // showRiskPage: "riskEvent",
      reportManagementList: [{}, {}, {}, {}],
      reportTotal: 0,
      current: {
        finished: [],
        current: []
      },
      error: false,
      showPage: "main",
      currentItem: null,
      isShowArea: false,
      isAction: false,
      showForm: false,
      variable: false,
      echartTitle: "",
      variabletwo: false,
      echartTitletwo: "",
      offset: 1,
      offsets: 1
    };
  },
  destroyed() {
    console.log("我已经离开了！");
    // if(this.$route.query.judge!='1'){
    //  this.changeRiskPage("riskReport")
    // }else{
    //   // this.changeRiskPage("riskReport")
    // //  this.changeRiskPage("riskEvent")
    // }
 },
  created() {
    if(this.$route.query.judge!='0'&&this.$route.query.judge!='1'){
       this.setFuzzyQuery("");
    }
    this.risk(1, this.fuzzyQuery);
    this.Echarts();
    if (this.$router.history.current.name == "RiskManagement") {
      this.showRisk(this.showRiskPage,0);
    }
  },
  mounted() {
    window.addEventListener("scroll", this.showGoTop, true);
    this.$EventBus.$on("QUERY_EVENT", () => {
      this.offsets = 1;
      this.riskManagementCase.total=0
    });
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  },
  methods: {
    ...mapActions([
      "riskManagement",
      "reportManagement",
      "changeRiskPage",
      "setFuzzyQuery",
      'riskScreen',
      "getScreen",
    ]),
    showGoTop() {
      if (this.showForm) {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    showRisk(val,value) {
      this.changeRiskPage(val);
       if(value==1){
          this.setFuzzyQuery("");
          this.getScreen({})
       }
      if (this.showRiskPage === "riskReport") {
        this.getReportManagement(1, this.fuzzyQuery);
        this.offset = 1;
      }
      if (this.showRiskPage === "riskEvent") {
        this.risk(1, this.fuzzyQuery);
        this.offsets = 1;
      }
    },
    // echart自定义
    selectEchart(flag) {
      if (flag == 0) {
        this.origEchartId = this.ids;
      } else if (flag == 1) {
        this.origEchartId = this.idstwo;
      }
      this.showMyCase = "mytodoEchartList";
    },
    //返回首页
    backMytodo() {
      this.showMyCase = "RiskManagement";
    },
    //风险事件管理list查询
    async risk(val, fuzzyQuery) {
      const keywords = {
        sqlStatus: "1",
        completeType: "0",
        offset: val,
        limit: 4,
        fuzzyQuery: fuzzyQuery.value,
        insOrgId: JSON.parse(sessionStorage.getItem("eidi.ins")).orgId,
        riskLevel: this.screen.riskLevel,
        riskEventType: this.screen.riskEventType,
        minRiskFoundTime: this.screen.minRiskFoundTime,
        maxRiskFoundTime: this.screen.maxRiskFoundTime
      };
      this.$store.dispatch("loading", true);
      this.riskManagement(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    },
    //获取风险报告list
    async getReportManagement(val, fuzzyQuery) {
      const keywords = {
        sqlStatus: "1",
        offset: val,
        limit: 4,
        fuzzyQuery: fuzzyQuery.value,
        taskName: "riskCtrlMgr,riskReportMent"
      };
      this.$store.dispatch("loading", true);
      this.reportManagement(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    },
    //分页查询
    handleCurrentChange(val) {
      this.risk(val, this.fuzzyQuery);
    },
    handleReportChange(val) {
      this.getReportManagement(val, this.fuzzyQuery);
    },
    //结束风险事件
    async endRiskEvent(item) {
      const keywords = {
        id: item.id,
        completeType: 1
      };
      const resEnd = await this.$api.endRiskEvent(keywords);
      if (resEnd.code == 0) this.risk(1, this.fuzzyQuery);
      this.$messageSuccess({
        message: resEnd.msg
      });

      if (resEnd.code == 1)
        this.$messageError({
          message: resEnd.msg
        });
    },
    //催办
    async urgent(item) {
      this.isDisabled = true;
      const keywords = {
        riskEvent: item.riskEventName,
        eventId: item.id
      };
      const res = await this.$api.urgentCase(keywords);
      if (res.code == 0) {
        this.isDisabled = false;
        this.$messageSuccess({
          message: res.msg
        });
      }

      if (res.code == 1) {
        this.isDisabled = false;
        this.$messageError({
          message: res.msg
        });
      }
    },
    // 自定义echart
    option() {
      this.$refs.chart.destroy(); //销毁
      this.$refs.chartLine.destroy(); //销毁
      this.Echarts();
    },
    // echarts
    async Echarts() {
      const keywords = {
        userId: this.userInfo.userId,
        orgId: this.userInfo.insOrgId,
        province: this.$getversionData.province,
        city: this.$getversionData.city
      };
      const { data } = await this.$api.riskecharts(keywords);
      this.dataShow = data;
      if (data[0]) {
        this.ids = data[0].echartId;
        this.echartTitle = data[0].title;
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(category_option);
          }, 10);
        } else if (data[0].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["25%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "17",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[0].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chart.initChart(pie_option);
            this.$refs.chart.editEcahrt(pie_option, this.$refs.chart.id);
          }, 10);
        } else if (data[0].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(axas_option);
          }, 10);
        } else if (data[0].echartType === "boxplot") {
          // 盒须图
          let boxplot_option = {
            title: {
              text: data[0].title,
              left: "center"
            },
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "shadow"
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: data.axisDatas,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              // axisLabel: {
              //   formatter: 'expr {value}'
              // },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              splitArea: {
                show: true
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: data.boxData
              },
              {
                name: "outlier",
                type: "scatter",
                data: data.outliers
              }
            ]
          };
          for (let n of data[0].data) {
            boxplot_option.xAxis.data = [
              // ...boxplot_option.axisData.data,
              n.name
            ];
            boxplot_option.series[0].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
            boxplot_option.series[1].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(boxplot_option);
          }, 10);
        } else if (data[0].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[0].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[0].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chart.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[0].echartType === "lines") {
          // 多折线图
          let categorys_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: [
                "一月",
                "二月",
                "三月",
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
              ]
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[0].data.map((item, num) => {
            (item.type = "line"),
              (item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.chart.initChart(categorys_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              color: "#0000CD",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(Yaxas_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            legend: {
              top: "12",
              right: "13",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: ["1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4"]
            },
            series: item.data
          };
          data[0].data.map((item, num) => {
            (item.type = "bar"),
              (itemstack = ""),
              (item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.chart.initChart(Yaxass_option);
          }, 10);
        } else if (data[0].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[0];
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["50%", "50%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              left: "45%",
              top: "16%",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.chart.initChart(spie_option);
          }, 10);
        }
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].data.length != 0) {
          this.variable = false;
        }
      }
      if (data[1]) {
        this.idstwo = data[1].echartId;
        this.echartTitletwo = data[1].title;
        if (data[1].data.length == 0) {
          this.variabletwo = true;
        } else if (data[1].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,

              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(category_option);
          }, 10);
        } else if (data[1].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["25%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "20",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[1].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(pie_option);
            this.$refs.chartLine.editEcahrt(
              pie_option,
              this.$refs.chartLine.id
            );
          }, 10);
        } else if (data[1].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(axas_option);
          }, 10);
        } else if (data[1].echartType === "boxplot") {
          // 盒须图
          let boxplot_option = {
            title: {
              text: data[1].title,
              left: "center"
            },
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "shadow"
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: data.axisDatas,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              // axisLabel: {
              //   formatter: 'expr {value}'
              // },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              splitArea: {
                show: true
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: data.boxData
              },
              {
                name: "outlier",
                type: "scatter",
                data: data.outliers
              }
            ]
          };
          for (let n of data[1].data) {
            boxplot_option.xAxis.data = [
              // ...boxplot_option.axisData.data,
              n.name
            ];
            boxplot_option.series[0].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
            boxplot_option.series[1].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(boxplot_option);
          }, 10);
        } else if (data[1].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[1].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            dataRange: {
              show: false, //是否显示图例
              min: 0,
              max: 10, //图例标识最大值
              text: ["High", "Low"],
              color: ["#f8b9ce", "#00adef", "#8ec63f", "#f36523", "#ed207b"]
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[1].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[1].echartType === "lines") {
          // 多折线图
          let categorys_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: [
                "一月",
                "二月",
                "三月",
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
              ]
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[1].data.map((item, num) => {
            item.type = "line";
            item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.chartLine.initChart(categorys_option);
          }, 10);
        } else if (data[1].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(Yaxas_option);
          }, 10);
        } else if (data[1].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            legend: {
              top: "12",
              right: "13",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: ["1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4"]
            },
            series: item.data
          };
          data[1].data.map((item, num) => {
            (item.type = "bar"),
              (itemstack = ""),
              (item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.chartLine.initChart(Yaxass_option);
          }, 10);
        } else if (data[1].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[1];
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["50%", "50%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              left: "45%",
              top: "16%",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.chartLine.initChart(spie_option);
          }, 10);
        }
        if (data[1].data.length == 0) {
          this.variabletwo = true;
        } else if (data[1].data.length != 0) {
          this.variabletwo = false;
        }
      }
    },
    //跳转回访报告管理
    goToReturnVisitRM(item) {
      this.$router.push({
        path: "/returnVisitReportManagement",
        query: {
          id: item.projectId,
           flag:'1'
        }
      });
    },
    //跳转到风险评估报告管理
    riskAssessmentReport(item) {
      this.$router.push({
        path: "/riskAssessmentReportManagement",
        query: {
          id: item.projectId,
           flag:'1',
          // item: item
          item: JSON.stringify(item)
        }
      });
    },
    //跳转到最终风险检查报告
    finalRiskInspectionReport(item) {
      this.$router.push({
        path: "/finalRiskInspectionReport",
        query: {
          id: item.projectId,
           flag:'1'
        }
      });
    },
    //跳转到风险事件整改
    intoRectification(item) {
      this.$router.push({
        path: "/riskReportManagement",
        query: {
          projectId: item.projectId,
          type: "view",
          id: item.id,
          flag:'1'
        }
      });
    },
    goBack() {
      this.showMyCase = "RiskManagement";
    },
    //点击进入理赔，跳转至大表单
    goForm(item, isAction) {
      this.showForm = true;
      this.currentItem = item;
      this.isAction = isAction;
      this.showMyCase = "formManagement";
      const { projectId, taskName } = item;
      this.riskScreen(true)
      if (
        item.projectStatus === "ProjectByCompleted" &&
        item.taskName === "riskReportMent"
      ) {
        //进入理赔
        this.isShowArea = true;
        this.current = {
          finished: [
            "enteringIns",
            "newProject",
            "insuranceAudit",
            "launchRisk",
            "enteringRisk",
            "checkRisk",
            "riskManage",
            "entreingCompleted",
            "insuranceCheck"
          ],
          current: ["riskReturn"],
          projectId: projectId
        };
        this.$refs.insuranceCoverage.insuranceCoverage(projectId);
        this.$refs.insuranceCoverage.init(projectId);
        this.$refs.basicBstablish.init(projectId);
        this.$refs.riskPlan.init(projectId);
        this.$refs.underwriting.init(projectId);
        this.$refs.riskFinalReport.riskFinalReport(projectId);
        this.$refs.riskReportList.getPagination(1, projectId, "hasPrama");
        this.$refs.riskEventsList.getPagination(1, projectId, "hasPrama");
        this.$refs.projectReturns.projectReturn(projectId);
        this.$refs.insuranceReview.insuranceReview({
          projectId: projectId
        });
      } else if (
        item.projectStatus === "ProjectOnBuliding" &&
        item.taskName === "riskCtrlMgr"
      ) {
        this.current = {
          finished: [
            "enteringIns",
            "newProject",
            "insuranceAudit",
            "launchRisk",
            "enteringRisk",
            "checkRisk"
          ],
          current: ["riskManage"],
          projectId: projectId
        };
        this.isShowArea = false;
        this.$refs.insuranceCoverage.insuranceCoverage(projectId);
        this.$refs.insuranceCoverage.init(projectId);
        this.$refs.basicBstablish.init(projectId);
        this.$refs.riskPlan.init(projectId);
        this.$refs.underwriting.init(projectId);
        this.$refs.riskFinalReport.riskFinalReport(projectId);
        this.$refs.riskReportList.getPagination(1, projectId, "hasPrama");
        this.$refs.riskEventsList.getPagination(1, projectId, "hasPrama");
        this.$refs.projectReturns.projectReturn(projectId);
        this.$refs.insuranceReview.insuranceReview({
          projectId: projectId
        });
      }
    },
    async doSubmit() {
      this.$store.dispatch("loading", true);
      const { code, msg } = await this.$api.doComplete(
        this.currentItem.projectId
      );
      if (code === 0) {
        this.$messageSuccess({ message: msg });
        this.showMyCase = "RiskManagement";
        if (this.showRiskPage === "riskReport") this.getReportManagement(1, this.fuzzyQuery);
        if (this.showRiskPage === "riskEvent") this.risk(1, this.fuzzyQuery);
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    }
  }
};
</script>

<style scoped lang="scss" rel="stylesheet/scss">
.newclass {
  background: url(../../assets/imgs/noData.png);
  background-size: 160px 160px;
  background-repeat: no-repeat;
  background-position: 107px 30px;
}
.newclass /deep/ span {
  font-size: 17px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 15px;
  left: 21px;
}
.content {
  position: relative;
  height: 240px;
  background: rgba(255, 255, 255, 0.9);
  margin-bottom: 7px;
}
.content1 {
  height: 240px;
  margin-bottom: 7px;
}
.middle {
  margin-top: 20px;
  margin-bottom: 8px;
}
.risk_card {
  padding: 18px 21px 0 21px;
  text-align: left;
  .clearfix {
    margin-bottom: 30px;
    span {
      font-size: 17px;
      font-weight: bold;
    }
  }
  /deep/ .el-col {
    font-size: 13px;
    // line-height: 15px;
    font-weight: bold;
  }
}
.risk_btn {
  position: absolute;
  bottom: 0;
  width: 100%;
  div {
    .el-button {
      width: 100%;
      border-radius: 0;
      font-weight: Medium;
      font-size: 16px;
    }
    .el-button--warning {
      background: rgba(255, 150, 15, 0.56);
      border: none;
    }
    .el-button--primary {
      background: rgba(41, 122, 227, 0.56);
      border: none;
    }
  }
}
.my_progress /deep/ {
  .el-progress-circle {
    height: 100px !important;
    width: 100px !important;
  }
  .el-progress__text {
    color: #333333;
    font-size: 22px !important;
    top: 40%;
  }
  .el-progress-circle__path {
    stroke: rgb(119, 165, 224);
  }
}
.el-pagination {
  padding: 2px 0px;
  /deep/ button {
    padding: 0;
  }
}
.control {
  position: absolute;
  bottom: -20px;
  right: 5px;
  left: 0;
}
.leftContent span {
  color: #fff;
  line-height: 26px;
  margin-left: -9px;
}
.date {
  height: 130px;
  // margin-top: 35px;
  background-image: url(../../assets/imgs/todo/todo1.png);
  background-repeat: no-repeat;
  background-size: 90% 60%;
}
.date1 {
  background-image: url(../../assets/imgs/todo/todo2.png);
}
.date2 {
  background-image: url(../../assets/imgs/todo/todo3.png);
}
.days {
  color: #7eafed;
  font-size: 35px;
  font-weight: bold;
  margin-left: -10px;
  margin-top: -6px;
}
.year {
  font-size: 12px;
  margin-top: -7px;
}
.rightContent {
  text-align: left;
  font-size: 13px;
  font-weight: bold;
}
.rightContent p {
  font-weight: bold;
  font-size: 16px;
}
.toggle_button {
  width: 20px;
  height: 90px;
  font-size: 13px;
  color: #ffffff;
  border-bottom-left-radius: 6px;
  border-top-left-radius: 6px;
  line-height: 13px;
  cursor: pointer;
  margin-left: 28.5px;
}
.checked_state {
  background: rgba(255, 150, 15, 0.57);
  box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.5);
}
.unchecked_state {
  background: rgba(62, 58, 57, 0.3);
  box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.5);
}
.even_num {
  margin-left: 7px;
}
</style>

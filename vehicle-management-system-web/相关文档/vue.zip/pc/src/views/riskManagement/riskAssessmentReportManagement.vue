<template>
  <div style="position: relative;">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>风险评估报告管理</span>
        </div>
      </el-row>
      <el-table
        class="mc-table"
        tooltip-effect="light"
        :data="tableData"
        style="width: 100%"
        @row-dblclick="dbGoVisitDetails"
      >
        <!-- <el-table-column type="index" align="center" label="序号" width="100"></el-table-column> -->
        <el-table-column
          type="index"
          align="center"
          label="序号"
          width="100"
          :index="(index)=>{return(index+1)+(offset-1)*limit}"
        ></el-table-column>
        <el-table-column prop="name" align="center" label="报告名称"></el-table-column>
        <el-table-column prop="reporter" align="center" label="报告人"></el-table-column>
        <el-table-column prop="reviewer" align="center" label="审核人"></el-table-column>
        <el-table-column prop="approver" align="center" label="批准人"></el-table-column>
        <el-table-column align="center" label="报告日期">
          <template slot-scope="scope">{{ scope.row.reportDate| filterDate}}</template>
        </el-table-column>
        <el-table-column prop="approver" align="center" label="报告状态">
          <template slot-scope="scope">
            <div v-if="scope.row.sqlStatus=='1'">已提交</div>
            <div v-if="scope.row.sqlStatus=='0'">待提交</div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-dropdown
              placement="bottom"
              size="small"
              trigger="click"
              @command="handleCommand(scope.row.reportId,$event,scope.row.id)"
            >
              <span class="el-dropdown-link">
                <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item
                  icon="el-icon-remove-outline"
                  command="1"
                  v-show="scope.row.sqlStatus==0"
                >删除</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-edit-outline"
                  command="2"
                  v-show="scope.row.sqlStatus==0"
                >修改</el-dropdown-item>
                <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      <div class="project-collection" @click="dialogVisible = true">
        <i class="el-icon-plus"></i>
        <div>风险评估报告</div>
      </div>
      <el-pagination
        small
        class="page-lucency text-center mt10 control"
        @current-change="handleCurrentChange"
        :current-page.sync="offset"
        :page-size="this.limit"
        layout="prev, pager, next"
        :total="this.total"
      ></el-pagination>
    </div>
    <!-- 风险报告弹窗 -->
    <Dialog
      :dialogVisible="dialogVisible"
      v-if="dialogVisible"
      @handleClose="riskOpen"
      @passValue="riskAssessment"
    ></Dialog>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import Dialog from "./riskAssessmentReportManagementDialog.vue";
import { log } from "util";
export default {
  name: "RiskAssessmentReportManagement",
  components: { MessageEdit, Dialog },
  data() {
    return {
      dialogVisible: false,
      dialogVisibleOne: false,
      tableData: undefined,
      total: undefined,
      limit: 10, //每页几条数据
      offset: 1, //第几页
      index: ""
    };
  },
  created() {
    this.riskAssessment();
  },
  methods: {
    riskOpen() {
      //弹窗
      this.dialogVisible = false;
    },
    async riskAssessment() {
      this.projectId = this.$route.query.id;
      const riskId = {
        //请求数据
        projectId: this.projectId,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.riskReport(riskId);
      this.total = res.data.total;
      this.tableData = res.data.rows;
    },
    handleCommand(id, command, ids) {
      if (command === "0") {
        //查看数据
        this.particulars(ids, id);
      } else if (command === "1") {
        this.removeRisk(id);
      } else {
        this.modification(id, ids);
      }
    },
    async removeRisk(num) {
      this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          //删除数据
          const res = await this.$api.deleteRisk(num);
          if (res.code == 0) {
            this.$messageSuccess({
              message: res.msg
            });
            this.riskAssessment();
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    handleCurrentChange(val) {
      this.offset = val;
      this.riskAssessment();
    },
    particulars(ids, id) {
      //详情
      this.$router.push({
        path: "/riskParticulars",
        query: {
          id: ids,
          reportId: id
        }
      });
    },
    modification(id, ids) {
      this.projectId = this.$route.query.id;
      //修改
      this.$router.push({
        path: "/riskReportAmend",
        query: {
          projectId: this.projectId, //项目ID
          id: ids, //点击报告id
          reportId: id
        }
      });
    },
    //双击进入详情
    dbGoVisitDetails(row) {
      this.particulars(row.id, row.reportId);
    },
    backMytodo() {
      if(this.$route.query.flag){
        this.$router.push({
        path: "/riskManagement",
        query: {
          judge:'0'
        }
      });
      }else{
        this.$router.go(-1);
      }
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 30px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
// 弹框自定义样式
.dialog {
  background: rgba(255, 255, 255, 0.5);
  /deep/ .el-dialog {
    width: 815px;
    min-height: 485px;
    margin-top: 14vh;
  }
  /deep/ .el-dialog__header {
    padding: 8px;
    background: #297ae3;
  }
  /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
}
.put /deep/.el-form {
  .el-form-item {
    margin: 10px 0 0 0;
    font-weight: bold;
    height: 13.5px;
    /deep/ .el-form-item__label {
      font-size: 12.5px;
      color: #297ae3;
      line-height: 30px;
      padding: 0 !important;
    }
  }
}
.put /deep/.affix /deep/ .el-form-item /deep/ .el-form-item__label {
  color: #000;
  margin-top: 0;
}
.control {
  position: absolute;
  bottom: 30px;
  right: 80px;
  left: 0;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
</style>
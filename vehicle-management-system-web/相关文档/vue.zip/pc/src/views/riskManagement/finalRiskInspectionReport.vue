<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">风险最终检查报告</span>
        </el-col>
        <el-form
          :model="getRiskFinalReport.riskReportDO"
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          :rules="rules"
          ref="ruleForm"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="项目报建号：">
                <el-input v-model="getRiskFinalReport.riskReportLastDO.buildPermitNo" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="牵头保险公司：">
                <el-select
                  disabled
                  v-model="getRiskFinalReport.riskManagementPlanBigDO.insOrgId"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.insOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="风险管理机构：">
                <el-select
                  disabled
                  v-model="getRiskFinalReport.riskManagementPlanBigDO.tisOrgId"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.tisOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="保险分类：">
                <el-select
                  v-model="getRiskFinalReport.riskManagementPlanBigDO.insCategory"
                  disabled
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_CATEGORIES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保单号：">
                <el-input
                  v-model="getRiskFinalReport.riskManagementPlanBigDO.insContractNo"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目名称：">
                <el-input v-model="getRiskFinalReport.riskReportLastDO.projectName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="15">
              <el-form-item label="项目地址：">
                <el-input v-model="getRiskFinalReport.riskReportLastDO.address" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="建设单位：">
                <el-input
                  v-model="getRiskFinalReport.riskManagementPlanBigDO.builderOrgName"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="area" label="总包单位：">
                <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.gconOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="勘察单位： ">
                <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.invOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item class="area" label="设计单位：">
                <el-input
                  v-model="getRiskFinalReport.riskManagementPlanBigDO.designOrgName"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="area" label="监理单位：">
                <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.supOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="改正缺陷数量：" prop="faultChangeCount">
                <el-input v-model.number="getRiskFinalReport.riskReportDO.faultChangeCount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="开始介入日期：" prop="startWorkDate">
                <el-date-picker
                  :clearable="false"
                  v-model="getRiskFinalReport.riskReportDO.startWorkDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="pickerOptionsStart"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="竣工检查日期：" prop="reportDate">
                <el-date-picker
                  :clearable="false"
                  v-model="getRiskFinalReport.riskReportDO.reportDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="pickerOptionsEnd"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="工程概况：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  placeholder="请输入内容"
                  v-model="getRiskFinalReport.riskReportDO.projDesc"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="本报告所涉及的承保范围：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  placeholder="请输入内容"
                  v-model="getRiskFinalReport.riskReportDO.reportScope"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="针对承保范围的总体风险评价：" prop="reportScopeNote">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  placeholder="请输入内容"
                  v-model="getRiskFinalReport.riskReportDO.reportScopeNote"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="保险公司审核意见：" prop="insReviewNote">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  placeholder="请输入内容"
                  v-model="getRiskFinalReport.riskReportDO.insReviewNote"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="最终检查报告：" prop="fileName">
                <el-input v-model="getRiskFinalReport.riskReportDO.fileName" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-col :span="3">
                <img v-if="!upload" :src="imgUpload" class="img-upload" />
                <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
                <!-- <img v-if="upload" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
              </el-col>
              <el-col :span="21">
                <el-upload
                  class="inline-block mlr97"
                  action
                  :http-request="uploadFile"
                  :show-file-list="false"
                  :on-change="handleChange"
                >
                  <el-button size="mini" type="primary">上传</el-button>
                </el-upload>
                <el-button size="mini" @click="delBtn()">删除</el-button>
                <el-button size="mini" @click="downloadBtn()" :disabled="disabled">下载</el-button>
              </el-col>
            </el-col>
            <el-col :span="8">
              <!--  :picker-options="pickerReportEnd" -->
              <el-form-item label="报告签发日期：" prop="assessmentReportFileDate">
                <el-date-picker
                 :picker-options="dateValid"
                  :clearable="false"
                  v-model="getRiskFinalReport.riskReportDO.assessmentReportFileDate"
                  type="date"
                  placeholder="选择日期"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row style="text-align: right; padding:50px 20px " class="btns">
          <el-button type="primary" size="mini" @click="saveReturnVisit(0)">保存</el-button>
          <el-button type="primary" size="mini" @click="saveReturnVisit(1)">提交</el-button>
          <el-button size="mini" @click="inspectionReportClosed()">关闭</el-button>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import imgUpload from "@/assets/imgs/put.png";
import { mapGetters, mapActions } from "vuex";
import axios from 'axios';
export default {
  name: "FinalRiskInspectionReport", //最终风险检查报告
  computed: {
    ...mapGetters(["listBaseData", "getOrgId"])
  },
  data() {
    return {
      progress:0,
      dateValid: {
      disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      disabled: true,
      rules: {
        faultChangeCount: [
          { required: true, message: "请输入内容", trigger: "blur" },
          { type: "number", message: "改正缺陷数量必须为数字值" }
        ],
        fileName: [
          { required: true, message: "请上传报告", trigger: "change" }
        ],
        startWorkDate: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        reportDate: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        assessmentReportFileDate: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        reportScopeNote: [
          { required: true, message: "请输入风险评价", trigger: "blur" }
        ],
        insReviewNote: [
          { required: true, message: "请输入审核意见", trigger: "blur" }
        ]
      },
      upload: false,
      verificationPass: undefined,
      getRiskFinalReport: {
        riskReportLastDO: {
          address: ""
        },
        riskReportDO: {},
        riskManagementPlanBigDO: {}
      }, //请求数据
      imgUpload,
      value: "",
      textarea1: "",
      url: "",
      projectId: undefined,
      fileName: "",
      pickerOptionsStart: {
        disabledDate: time => {
          if (this.getRiskFinalReport.riskReportDO.reportDate) {
            return (
              time.getTime() >
              new Date(
                this.getRiskFinalReport.riskReportDO.reportDate
              ).getTime()
            );
          }
        }
      },
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.getRiskFinalReport.riskReportDO.startWorkDate) {
            return (
              time.getTime() <
              new Date(
                this.getRiskFinalReport.riskReportDO.startWorkDate
              ).getTime() +
                86400000
            );
          }
        }
      },
      pickerReportEnd: {
        disabledDate: time => {
          if (this.getRiskFinalReport.riskReportDO.reportDate) {
            return (
              time.getTime() <
              new Date(
                this.getRiskFinalReport.riskReportDO.reportDate
              ).getTime()
            );
          }
        }
      }
    };
  },
  created() {
    this.finalReportRequest();
  },
  methods: {
    //页面请求数据
    async finalReportRequest() {
      this.$api.finalRiskCheck(this.$route.query.id).then(res => {
        this.getRiskFinalReport = res.data;
        if (this.getRiskFinalReport.riskReportDO.fileName) {
          this.disabled = false;
        }
        this.$refs["ruleForm"].resetFields();
      });
    },
    //风险关闭
    inspectionReportClosed() {
      if(this.$route.query.flag){
        this.$router.push({
        path: "/riskManagement",
        query: {
          judge:'0'
        }
      });
      }else{
        this.$router.go(-1);
      }
    },
    //风险保存
    async saveReturnVisit(flag) {
      //表单校验
      this.verificationPass = false;
      if (flag == 1) {
        this.$refs["ruleForm"].validate(valid => {
          if (valid) {
            this.verificationPass = true;
          } else {
            // 校验提示
            this.$messageError({
              message: "请完善内容"
            });
            return false;
          }
        });
      } else {
        this.verificationPass = true;
      }
      if (this.verificationPass) {
        this.$store.dispatch("loading", true);
        this.getRiskFinalReport.riskReportDO.sqlStatus = flag;
        this.getRiskFinalReport.riskReportDO.reportOrgId = JSON.parse(
          sessionStorage.getItem("eidi.ins")
        ).orgId;
        this.getRiskFinalReport.riskReportDO.reportType = "2";
        const keywords = this.getRiskFinalReport;
        const res = await this.$api.saveFinalRiskCheck(keywords);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$store.dispatch("loading", false);
          this.inspectionReportClosed()
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },

    //文件下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.getRiskFinalReport.riskReportDO.fileName;
      this.url = this.getRiskFinalReport.riskReportDO.assessmentReportFileLast;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    handleChange(file) {},
    //上传
    async uploadFile(param) {
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      this.projectId = this.$route.query.id;
      file.append("projectId", this.projectId);
      file.append("fileIcon", "assessmentReportFileLast");
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
           this.progress = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.progress=100
          this.$messageSuccess({
            message: "上传成功"
          });
          this.disabled = false;
          this.getRiskFinalReport.riskReportDO.fileName = res.data.data.fileName;
          this.getRiskFinalReport.riskReportDO.assessmentReportFileLast =
            res.data.data.cloudDocId;
          this.url = res.data.data.cloudDocId;
        } else {
          this.$messageError({
            message: "上传失败 "
          });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    // 删除
    delBtn() {
      this.disabled = true;
      this.getRiskFinalReport.riskReportDO.fileName = "";
      this.getRiskFinalReport.riskReportDO.assessmentReportFileLast = "";
    }
  }
};
</script>
<style scoped lang="scss">
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
}
.buttn {
  width: 64.5px;
  height: 29.5px;
  background: rgba(16, 143, 235, 1);
  border-radius: 8px;
  color: #fff;
}
</style>
<template>
  <div style="position: relative;">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>风险回访报告</span>
        </div>
      </el-row>
      <el-table
        class="mc-table"
        tooltip-effect="light"
        :data="riskVisitReportList"
        style="width: 100%"
        @row-dblclick="dbGoVisitDetails"
      >
        <!-- <el-table-column type="index" align="center" label="序号" width="100"></el-table-column> -->
        <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
        <el-table-column prop="surveyDate" align="center" label="回访时间">
          <template slot-scope="scope">{{ scope.row.surveyDate | filterDate}}</template>
        </el-table-column>
        <el-table-column
          prop="revistSummary"
          align="center"
          label="回访小结"
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column
          prop="reportScope"
          align="center"
          label="本报告所涉及的承保范围"
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column prop="reportDate" width="150" align="center" label="报告日期">
          <template slot-scope="scope">{{ scope.row.reportDate | filterDate}}</template>
        </el-table-column>
        <el-table-column align="center" label="报告状态" width="150">
          <template slot-scope="scope">
            <div v-if="scope.row.sqlStatus=='1'">已提交</div>
            <div v-if="scope.row.sqlStatus=='0'">待提交</div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-dropdown
              placement="bottom"
              size="small"
              trigger="click"
              @command="handleCommand(scope.row,$event)"
            >
              <span class="el-dropdown-link">
                <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item
                  icon="el-icon-remove-outline"
                  command="0"
                  v-show="scope.row.sqlStatus==0"
                >删除</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-edit-outline"
                  command="1"
                  v-if="scope.row.sqlStatus==0"
                >修改</el-dropdown-item>
                <el-dropdown-item icon="el-icon-view" command="2">详情</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      <div class="project-collection mouse-pointer" @click="goReturnVisitDetails('','new')">
        <i class="el-icon-plus"></i>
        <div>回访报告</div>
      </div>
      <el-pagination
        small
        class="page-lucency text-center mt10 control"
        @current-change="handleCurrentChange"
        :current-page.sync="offset"
        :page-size="limit"
        layout="prev, pager, next"
        :total="total"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import MessageEdit from "@/components/Message.vue";
import Dialog from "./riskAssessmentReportManagementDialog.vue";
import { mapGetters, mapActions } from "vuex";
import { log } from "util";
export default {
  name: "RiskAssessmentReportManagement",
  components: { MessageEdit, Dialog },
  data() {
    return {
      offset: 1,
      limit: 8,
      total: 0,
      riskVisitReportList: []
    };
  },
  created() {
    this.riskVisitReport(1);
  },
  methods: {
    ...mapActions(["changeRiskPage"]),
    async riskVisitReport(val) {
      const keywords = {
        //请求数据
        projectId: this.$route.query.id,
        limit: 8,
        offset: val
      };
      const res = await this.$api.visitReport(keywords);
      this.total = res.data.total;
      this.riskVisitReportList = res.data.rows;
    },
    handleCommand(item, command) {
      if (command == 0) {
        this.returnVisitDele(item.id); //删除
      } else if (command == 1) {
        this.goReturnVisitDetails(item.id, "edit"); //修改
      } else if (command == 2) {
        this.goReturnVisitDetails(item.id, "view"); //详情
      }
    },
    async returnVisitDele(id) {
      this.$confirm("此操作将永久删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          //删除数据
          const res = await this.$api.visitReportDele(id);
          if (res.code == 0) {
            this.$messageSuccess({
              message: "删除成功"
            });
            this.riskVisitReport(1);
          } else {
            this.$messageError({
              message: "删除失败 "
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    handleCurrentChange(val) {
      this.offset = val;
      this.riskVisitReport(val);
    },
    //新增new、查看view、编辑edit
    goReturnVisitDetails(id, type) {
      this.$router.push({
        path: "/returnVisitDetails",
        query: {
          id: id,
          projectId: this.$route.query.id,
          type: type
        }
      });
    },
    dbGoVisitDetails(row) {
      this.goReturnVisitDetails(row.id, "view");
    },
    backMytodo() {
      this.changeRiskPage("riskEvent");
      if(this.$route.query.flag){
        this.$router.push({
        path: "/riskManagement",
        query: {
          judge:'0'
        }
      });
      }else{
        this.$router.go(-1);
      }
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 30px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}

.control {
  position: absolute;
  bottom: 30px;
  right: 80px;
  left: 0;
}
.case_title {
  width: 125px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
</style>
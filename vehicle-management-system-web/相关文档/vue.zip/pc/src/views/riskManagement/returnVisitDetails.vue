<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">项目信息</span>
        </el-col>
        <el-form
          class="mc-form"
          :model="visitDetails.riskCheckReportDO"
          :rules="rules"
          ref="ruleForm"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="牵头保险公司：">
                <el-select
                  disabled
                  v-model="visitDetails.riskCheckReportProjectInfoDO.insOrgId"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.insOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保险分类：">
                <el-select
                  v-model="visitDetails.riskCheckReportProjectInfoDO.insCategory"
                  disabled
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_CATEGORIES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保单号：">
                <el-input
                  disabled
                  v-model="visitDetails.riskCheckReportProjectInfoDO.insContractNo"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目名称：">
                <el-input disabled v-model="visitDetails.riskCheckReportProjectInfoDO.projectName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="预计开始时间：">
                <el-date-picker
                  disabled
                  :clearable="false"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  v-model="visitDetails.riskCheckReportProjectInfoDO.plannedStartDate"
                  type="date"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="总包单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.gconOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="勘察单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.invOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="监理单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.supOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="设计单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.designOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="建设单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.buildOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-divider class="mc-divider"></el-divider>
          <el-col class="text-left mc-title" :span="24">
            <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
            <span style="font-size: 14.5px;" class="blue font-bold">回访信息</span>
          </el-col>
          <el-row>
            <el-col :span="8">
              <el-form-item label="回访时间：" prop="surveyDate">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  :picker-options="startDateValid"
                  v-model="visitDetails.riskCheckReportDO.surveyDate"
                    @change="validData(visitDetails.riskCheckReportDO.surveyDate, visitDetails.riskCheckReportDO.reportDate)"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :disabled="$route.query.type=='view'"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="报告出具日期：" prop='reportDate'>
                <el-date-picker
                :picker-options="endDateValid"
                  type="date"
                  placeholder="选择日期"
                    @change="validData(visitDetails.riskCheckReportDO.surveyDate, visitDetails.riskCheckReportDO.reportDate)"
                  v-model="visitDetails.riskCheckReportDO.reportDate"
                  :disabled="$route.query.type=='view'"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="本报告所涉及的承保范围：" class="mc-multi-row">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  v-model="visitDetails.riskCheckReportDO.reportScope"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item>
                <el-table
                  class="mc-table"
                  style="width: 100%"
                  :data="visitDetails.riskCheckReportItemDO"
                >
                  <el-table-column prop="clause" align="center" label="保险责任范围"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)" width="150"></el-table-column>
                  <el-table-column prop="type" align="center" label="保险类型" width="150">
                    <template
                      slot-scope="scope"
                    >{{scope.row.type | filterCode(listBaseData.IDI_LIABILITIES_TYPE,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2 , maxRows: 4}"
                        style="opacity:0.2 color:#3E3A39;"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        class="tex"
                        placeholder="请输入内容"
                        :disabled="$route.query.type=='view'"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="回访小结：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  v-model="visitDetails.riskCheckReportDO.revistSummary"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="风险报告回访：" prop="fileName">
                <el-input v-model="visitDetails.riskCheckReportDO.fileName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-col :span="3" style="position: relative; left: 10px">
                <img v-if="!upload" :src="imgUpload" class="img-upload" />
                <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
                <!-- <img v-if="upload" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
              </el-col>
              <el-col :span="21">
                <el-upload
                  class="inline-block mlr97"
                  action
                  :http-request="uploadFile"
                  :show-file-list="false"
                  :on-change="handleChange"
                >
                  <el-button size="mini" type="primary" v-if="this.$route.query.type!=='view'">上传</el-button>
                </el-upload>
                <el-button size="mini" @click="delBtn()" v-if="this.$route.query.type!=='view'">删除</el-button>
                <el-button size="mini" @click="downloadBtn()" :disabled='disabled'>下载</el-button>
              </el-col>
            </el-col>
          </el-row>
          <el-row style="text-align: right; margin-top: 100px" class="btns">
            <el-button
              v-if="$route.query.type!=='view'"
              size="mini"
              type="primary"
              @click="saveReturnVisit(0)"
            >保存</el-button>
            <el-button
              v-if="$route.query.type!=='view'"
              size="mini"
              type="primary"
              @click="saveReturnVisit(1)"
            >提交</el-button>
            <el-button size="mini" @click="shutbtn()">关闭</el-button>
          </el-row>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import imgUpload from "@/assets/imgs/put.png";
import { mapGetters, mapActions } from "vuex";
import axios from 'axios';
export default {
  name: "AddNewProject", //风险评估报告修改页面
  data() {
    return {
      progress:0,
      disabled: true,
      endDateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      upload: false,
      url: "",
      imgUpload,
      visitDetails: {
        riskCheckReportDO: {},
        riskCheckReportProjectInfoDO: {},
        riskCheckReportItemDO: []
      },
      rules: {
        surveyDate: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        reportDate: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        fileName: [{ required: true, message: "请上传报告", trigger: "change" }]
      },
      verificationPass: false
    };
  },
  computed: {
    ...mapGetters(["listBaseData", "getOrgId"])
  },
  created() {
    if (this.$route.query.type == "new") {
      this.getVisitBaseInfo();
    } else {
      this.getVisitReportView();
    }
  },
  mounted() {},
  methods: {
     //日期校验
    validData(start, end) {
      if (start) {
        this.endDateValid = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          }
        };
      } else {
        this.endDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
      if (end) {
        this.startDateValid = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          }
        };
      } else {
        this.startDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
    },
    //查看回访详情
    async getVisitReportView() {
      const id = this.$route.query.id;
      const res = await this.$api.visitReportView(id);
      this.visitDetails = res.data;
        this.getRiskFinalReport = res.data;
        if (this.visitDetails.riskCheckReportDO.revistReportFile) {
          this.disabled = false;
        }
      this.url = this.visitDetails.riskCheckReportDO.revistReportFile;
      this.$refs["ruleForm"].resetFields();
    },
    //查询项目基本信息
    async getVisitBaseInfo() {
      const projectId = this.$route.query.projectId;
      const res = await this.$api.visitBaseInfo(projectId);
      this.visitDetails.riskCheckReportDO = res.data.riskCheckReportDO || {
        surveyDate: ""
      };
      this.visitDetails.riskCheckReportProjectInfoDO =
        res.data.riskCheckReportProjectInfoDO;
      this.visitDetails.riskCheckReportItemDO = res.data.riskCheckReportItemDO;
      this.$refs["ruleForm"].resetFields();
    },

    //保存flag=0,提交flag=1
    async saveReturnVisit(flag) {
      //表单校验
      this.verificationPass = false;
      if (flag == 1) {
        this.$refs["ruleForm"].validate(valid => {
          if (valid) {
            this.verificationPass = true;
          } else {
            this.$messageError({
              message: "请完善内容"
            });
            return false;
          }
        });
      } else {
        this.verificationPass = true;
      }
      //验证通过，继续保存
      if (this.verificationPass) {
        this.$store.dispatch("loading", true);
        const operationType = this.$route.query.type;
        this.visitDetails.riskCheckReportDO.sqlStatus = flag;
        this.visitDetails.riskCheckReportDO.projectId = this.$route.query.projectId;
        const keywords = this.visitDetails;
        if (operationType === "new") {
          keywords.riskCheckReportDO.reportOrgId = JSON.parse(
            sessionStorage.getItem("eidi.ins")
          ).orgId;
          const res = await this.$api.visitReportNew(keywords);
          if (res.code == 0) {
            this.$messageSuccess({ message: res.msg });
            this.$router.go(-1);
          } else {
            this.$messageError({ message: res.msg });
          }
        } else if (operationType === "edit") {
          const res = await this.$api.visitReportEdit(keywords);
          if (res.code == 0) {
            this.$messageSuccess({ message: res.msg });
            this.$router.go(-1);
          } else {
            this.$messageError({ message: res.msg });
          }
        }
        this.$store.dispatch("loading", false);
      }
    },
    //关闭按钮
    shutbtn() {
      this.$router.go(-1);
    },
    //下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.visitDetails.riskCheckReportDO.fileName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    handleChange(file) {},
    //上传
    async uploadFile(param) {
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "checkReportFile");
      file.append("projectId", this.$route.query.projectId);
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
           this.progress = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.progress=100
          this.$set(
            this.visitDetails.riskCheckReportDO,
            "fileName",
            res.data.data.fileName
          );
           this.disabled = false;
          // this.visitDetails.riskCheckReportDO.fileName = res.data.fileName;
          this.visitDetails.riskCheckReportDO.revistReportFile =
            res.data.data.cloudDocId;
          this.url = res.data.data.cloudDocId;
        } else {
          this.$messageError({ message: res.data.msg });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    // 删除上传
    delBtn() {
       this.disabled = true;
      this.visitDetails.riskCheckReportDO.fileName = "";
      this.visitDetails.riskCheckReportDO.revistReportFile = "";
    }
  }
};
</script>
<style scoped lang="scss">
.el-form-item--mini {
  margin-bottom: 12px;
}
.rid {
  margin-right: 150px;
}
.lucency {
  opacity: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
}
.btn {
  width: 56px;
  height: 26.5px;
  background: rgba(237, 237, 237, 1);
  border-radius: 8px;
  padding: 6px 13px;
  font-size: 12.5px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(62, 58, 57, 1);
}
.btn1 {
  width: 56px;
  height: 26.5px;
  background: rgba(16, 143, 235, 1);
  border-radius: 8px;
  font-size: 12.5px;
  padding: 6px 13px;
  font-size: 12.5px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
  border: rgba(16, 143, 235, 1);
}
.buttn {
  width: 64.5px;
  height: 29.5px;
  background: rgba(16, 143, 235, 1);
  border-radius: 8px;
  color: #fff;
}
.control {
  text-align: right;
  margin-bottom: 20px;
}
.tex {
  width: 318px;
}
</style>
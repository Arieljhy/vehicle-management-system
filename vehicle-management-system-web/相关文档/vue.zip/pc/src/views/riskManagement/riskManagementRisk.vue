<template>
  <div style="position: relative">
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'riskManagementRisk' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-show="showMyCase==='riskManagementRisk'">
        <el-row>
          <el-col
            :span="12"
            style="padding-right:56px;height:489px;border-radius:6px;background:rgba(255,255,255,0.9);"
          >
            <el-row>
              <el-col :span="24">
                <span
                  class="el-icon-edit-outline mouse-pointer"
                  @click="selectEchart()"
                  style="position: absolute;right:-30px;top: 20px;color:#297AE3;z-index:999"
                >自定义</span>
                <div v-show="this.variable" class="newclass" style="height:488px">
                  <span>{{this.echartTitle}}</span>
                </div>
                <chart ref="beijingMap" style="width: 550px;height: 488px"></chart>
              </el-col>
              <!-- 无数据时 -->
              <div
                v-show="this.dataShow.length===0"
                style="position: absolute;left: 60%;top:50%;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
            </el-row>
          </el-col>
          <el-col :span="12" style="padding-left:28px;">
            <el-row class="card_risk" v-for="item in riskManamentRiskList.rows" :key="item.id">
              <div @click="goForm(item)" style="cursor:pointer">
                <el-row style="margin-top:50px;">
                  <el-col :span="9" style="position:relative;margin-top: -25px;">
                    <el-progress
                      type="circle"
                      :stroke-width="10"
                      :show-text="false"
                      color="#FF960F"
                      class="my_progress"
                      :percentage="item.percentage"
                      style="width:100px;"
                    />
                    <div
                      style="position:absolute;top:30px;left:75px;"
                      v-if="item.projectStatus=='ProjectOnBuliding' && item.taskName=='riskCtrlMgr'"
                    >
                      <!-- noRectificationNum    totalRectification-->
                      <span
                        style="margin: 0;font-weight:bold;color:#333333;font-size:30px;"
                      >{{item.noRectificationNum}}</span>
                      <span style="font-size: 25px;">/</span>
                      <span>{{item.totalRectification}}</span>
                      <p style="padding-left: 3px;font-size:15px;color:#333333;">未整改风险事件</p>
                    </div>
                    <div
                      style="position:absolute;top:35px;left:90px;"
                      v-if="item.projectStatus=='ProjectByCompleted' && item.taskName=='riskReportMent'"
                    >
                      <!-- returnVisitTotal -->
                      <span
                        style="margin: 0;font-weight:bold;color:#333333;font-size:30px;padding-left: 10px;"
                      >{{item.returnVisitTotal}}</span>
                      <p style="padding-left: 15px;font-size:14px;color:#333333;">回访报告</p>
                    </div>
                  </el-col>
                  <el-col :span="15" style="text-align:left;padding-left: 10px">
                    <!-- <p class="upTitle">轨道交通11号线城北路站</p> -->
                    <p class="upTitle" style="margin-bottom:12px;">{{item.projectName}}</p>
                    <ul
                      style="list-style:none;padding-left:0px;font-size:13px;color:#000000;font-weight:600;"
                    >
                      <li>保单号：{{item.insContractNo}}</li>
                      <li>住宅性质：{{item.dictValue}}</li>
                      <li>阶段：{{item.projectChnStatus}}</li>
                    </ul>
                  </el-col>
                </el-row>
              </div>
              <div style="position:absolute;bottom: 0; width:100%;">
                <el-row
                  style="height:35px;line-height:35px;"
                  v-if="item.projectStatus=='ProjectOnBuliding' && item.taskName=='riskCtrlMgr'"
                >
                  <el-col
                    :span="8"
                    style="border-radius:0px 0px 0px 6px;background:rgba(255,150,15,0.57);color:#fff"
                  >
                    <div @click="goRiskEventManagement(item)" style="cursor:pointer;">
                      <el-button type="text" style="color:#fff;font-size: 16px;">风险事件管理</el-button>
                    </div>
                  </el-col>
                  <el-col :span="8" style="background:rgba(41,122,227,0.57);color:#fff">
                    <div @click="reportManagement(item)" style="cursor:pointer;">
                      <el-button type="text" style="color:#fff;font-size: 16px;">风险评估报告管理</el-button>
                    </div>
                  </el-col>
                  <el-col
                    :span="8"
                    style="border-radius:0px 0px 6px 0px;background:rgba(20,167,157,0.57);color:#fff"
                  >
                    <div @click="goEstablishInfo(item)" style="cursor:pointer;">
                      <el-button type="text" style="color:#fff;font-size: 16px;">报建信息维护</el-button>
                    </div>
                  </el-col>
                </el-row>

                <el-row
                  style="height:35px;line-height:35px;"
                  v-if="item.projectStatus=='ProjectByCompleted' && item.taskName=='riskReportMent'"
                >
                  <el-col
                    :span="12"
                    style="border-radius:0 0 0 6px;background:rgba(20,167,157,0.57);color:#fff"
                  >
                    <div @click="goEstablishInfo(item)" style="cursor:pointer;">
                      <el-button type="text" style="color:#fff;font-size: 16px;">报建信息维护</el-button>
                    </div>
                  </el-col>
                  <el-col
                    :span="12"
                    style="border-radius:0 0 6px 0;background:rgba(41,122,227,0.57);color:#fff"
                  >
                    <div @click="goToReturnVisitRM(item)" style="cursor:pointer;">
                      <el-button type="text" style="color:#fff;font-size: 16px;">回访报告管理</el-button>
                    </div>
                  </el-col>
                </el-row>
              </div>
            </el-row>
            <div
              v-show="riskManamentRiskList.rows && riskManamentRiskList.rows.length===0"
              style="position: absolute;left: 75%;top: 50%;transform: translate(-50%,-67%);"
            >
              <img src="@/assets/imgs/noData.png" width="220" height="171" />
            </div>
          </el-col>
        </el-row>
        <el-pagination
          small
          class="page-lucency text-right"
          layout="prev, pager, next"
          @current-change="handleReportChange"
          :total="riskManamentRiskList.total"
          :page-size="2"
          v-show="riskManamentRiskList.total!=0"
        ></el-pagination>
      </div>
    </transition>
    <!-- echart自定义 -->
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'riskManagementRisk' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-if="showMyCase==='mytodoEchartList'" style="position: absolute; top: 0;width: 100%;">
        <mytodo-echart-list
          @option="option"
          @backMytodo="backMytodo"
          :origEchartId="origEchartId"
          :interfaceName="interfaceName"
        ></mytodo-echart-list>
      </div>
    </transition>
    <div v-show="showMyCase==='formManagement'" style="position: absolute; top: 0;width: 100%;">
      <div id="top">
        <flow-chart :current="current" @goBack="backMytodo()" />
        <basic-information :disabled="true" />
        <bstablish-information :disabled="true" ref="basicBstablish" showMyCase="basicBstablish"/>
        <!-- <underwriting-information ref="underwriting" :disabled="true" /> -->
        <risk-plan :disabled="true" ref="riskPlan" />
        <!-- <insurance-review
          :disabled="true"
          ref="insuranceReview"
          title="风险管理计划审核"
          taskType="checkRiskCtrlPlan"
        /> -->
        <risk-report-list :disabled="true" ref="riskReportList" />
        <risk-events-list :disabled="true" ref="riskEventsList" />
        <!-- <risk-final-report :disabled="true" ref="riskFinalReport" /> -->
        <!-- <insurance-coverage v-show="isShowArea" ref="insuranceCoverage" :disabled="true" /> -->
        <!-- <insurance-review
          v-show="isShowArea"
          title="竣工保险审核"
          taskType="insuranceReview"
          :disabled="true"
        /> -->
        <project-returns v-show="isShowArea" ref="projectReturns" :disabled="true" />
         <el-button @click="goTop" id="go-top" circle :style="screen_width">
          <i class="el-icon-arrow-up"></i>
        </el-button>
      </div>
    </div>
  </div>
</template>
<script>
import chart from "@/components/charts/index";
import { mapGetters, mapActions } from "vuex";
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import MessageEdit from "@/components/Message.vue";
import MytodoEchartList from "@/views/myToDo/myToDoEchartList";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
// import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
// import RiskPlanReview from "@/components/ProjectSummary/RiskPlanReview"; //风险管理计划审核--竣工保险审核
// import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import ProjectReturns from "@/components/ProjectSummary/ProjectReturns"; //项目回访列表
export default {
  components: {
    chart,
    MessageEdit,
    MytodoEchartList,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    // UnderwritingInformation,
    RiskPlan,
    InsuranceCoverage,
    // RiskPlanReview,
    RiskReportList,
    RiskEventsList,
    RiskFinalReport,
    ProjectReturns,
    // InsuranceReview
  },
  computed: {
    ...mapGetters(["userInfo", "control", "riskManamentRiskList","fuzzyQuery"]),
     screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  data() {
    return {
      charts:{
        maanshan:maanshan,
        beijing:beijing,
        shanghai:shanghai,
        yangquan:yangquan
      },
      showMyCase: "riskManagementRisk",
      updown: "",
      pagerCount: 5,
      pageSize: 10,
      total: 50,
      dataShow: [],
      ids: "",
      idstwo: "",
      origEchartId: "",
      interfaceName: "RISKMGMT",
      current: {
        finished: [],
        current: []
      },
      isShowArea: false,
      variable: false,
      echartTitle: '',
    };
  },
   mounted() {
    this.Echart();
    window.addEventListener("scroll", this.showGoTop, true);
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  },
  created() {
    this.getRiskManamentRiskList(1);
    this.setFuzzyQuery("");
  },
  methods: {
     showGoTop() {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
    },
     //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    ...mapActions(["riskManagementRisk", "setFuzzyQuery"]),
    // echart自定义
    selectEchart() {
      this.origEchartId = this.ids;
      this.showMyCase = "mytodoEchartList";
    },
    goForm(item) {
      this.showMyCase = "formManagement";
      const { projectId, taskName } = item;
      if (
        item.projectStatus === "ProjectByCompleted" &&
        item.taskName === "riskReportMent"
      ) {
        //进入理赔
        this.isShowArea = true;
        this.current = {
          finished: [
            "enteringIns",
            "newProject",
            "insuranceAudit",
            "launchRisk",
            "enteringRisk",
            "checkRisk",
            "riskManage",
            "entreingCompleted",
            "insuranceCheck"
          ],
          current: ["riskReturn"],
          projectId: projectId
        };
        // this.$refs.insuranceCoverage.insuranceCoverage(projectId);
        // this.$refs.insuranceCoverage.init(projectId);
        this.$refs.basicBstablish.init(projectId);
        this.$refs.riskPlan.init(projectId);
        // this.$refs.underwriting.init(item.projectId);
        // this.$refs.riskFinalReport.riskFinalReport(projectId);
        this.$refs.riskReportList.getPagination(1, projectId, "hasPrama");
        this.$refs.riskEventsList.getPagination(1, projectId, "hasPrama");
        this.$refs.projectReturns.projectReturns({
          projectId,
          limit: 5,
          offset: 1,
          sqlStatus: 1
        });
        // this.$refs.insuranceReview.insuranceReview({
        //   projectId: projectId
        // });
      } else if (
        item.projectStatus === "ProjectOnBuliding" &&
        item.taskName === "riskCtrlMgr"
      ) {
        this.current = {
          finished: [
            "enteringIns",
            "newProject",
            "insuranceAudit",
            "launchRisk",
            "enteringRisk",
            "checkRisk"
          ],
          current: ["riskManage"],
          projectId: projectId
        };
        this.isShowArea = false;
        // this.$refs.insuranceCoverage.insuranceCoverage(projectId);
        // this.$refs.insuranceCoverage.init(projectId);
        this.$refs.basicBstablish.init(projectId);
        this.$refs.riskPlan.init(projectId);
        // this.$refs.riskFinalReport.riskFinalReport(projectId);
        this.$refs.riskReportList.getPagination(1, projectId, "hasPrama");
        this.$refs.riskEventsList.getPagination(1, projectId, "hasPrama");
        this.$refs.projectReturns.projectReturns({
          projectId,
          limit: 5,
          offset: 1,
          sqlStatus: 1
        });
      }
    },
    // 返回首页
    backMytodo() {
      this.showMyCase = "riskManagementRisk";
    },
    option() {
      this.$refs.beijingMap.destroy(); //销毁
      this.Echart();
    },
    // 地图echart
    async Echart() {
      const keywords = {
        userId: this.userInfo.userId,
        orgId: this.userInfo.insOrgId,
        province: this.$getversionData.province,
        city: this.$getversionData.city
      };
      const { data } = await this.$api.riskecharts(keywords);
      this.dataShow = data;
      if (data.length != 0) {
        this.ids = data[0].echartId;
        this.echartTitle = data[0].title;
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize:12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize:11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + '万'
                  }  else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + '百万'
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + '千万'
                  } else if (value >= 100000000 ) {
                    value = value / 100000000 + '亿'
                  } 
                  return value
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[0].data) {
            if(typeof(n.value)!=='number'){
              continue
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(category_option);
          }, 10);
        } else if (data[0].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip:{
              triggrer: 'item',
              formatter:'{b}:{c} ({d}%)'
            },
            legend: {
              selectedMode:false,
              backgroundColor: 'rgba(245,245,245,1)',  // 设置整个图例区域背景颜色
              borderRadius: 10,              
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["35%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "17",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[0].data) {
            if(typeof(item.value)!=='number'){
              continue
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(pie_option);
            this.$refs.beijingMap.editEcahrt(pie_option,this.$refs.beijingMap.id);
          }, 10);
        } else if (data[0].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if(typeof(n.value)!=='number'){
              continue
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(axas_option);
          }, 10);
        } else if (data[0].echartType === "boxplot") {
          // 盒须图
          let boxplot_option = {
            title: {
              text: data[0].title,
              left: "center"
            },
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "shadow"
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: data.axisDatas,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              // axisLabel: {
              //   formatter: 'expr {value}'
              // },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              splitArea: {
                show: true
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: data.boxData
              },
              {
                name: "outlier",
                type: "scatter",
                data: data.outliers
              }
            ]
          };
          for (let n of data[0].data) {
            boxplot_option.xAxis.data = [
              // ...boxplot_option.axisData.data,
              n.name
            ];
            boxplot_option.series[0].data = [
              // ...boxplot_option.series[0].data,
              n.name
            ];
            boxplot_option.series[1].data = [
              // ...boxplot_option.series[0].data,
              n.name
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(boxplot_option);
          }, 10);
        } else if (data[0].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[0].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ['High', 'Low'],
              inRange: {
                color: ['lightskyblue', 'yellow', 'orangered']
              }
            },
            tooltip: {
              formatter:function(params,ticket, callback){
                if(isNaN(params.value)){
                  params.value= '-'
                  return params.seriesName+'<br />'+params.name+'：'+params.value
                } else{
                  return params.seriesName+'<br />'+params.name+'：'+params.value
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: { //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                },
              }
            ]
          };
          for (let item of data[0].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[0].echartType === "lines") {
          // 多折线图
          let categorys_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            legend: {},
            xAxis: {
              axisLabel: {
                fontSize:12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: [
                "一月",
                "二月",
                "三月",
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
              ]
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize:11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + '万'
                  }  else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + '百万'
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + '千万'
                  } else if (value >= 100000000 ) {
                    value = value / 100000000 + '亿'
                  } 
                  return value
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[0].data.map((item, num) => {
            item.type = "line";
            item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.beijingMap.initChart(categorys_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if(typeof(n.value)!=='number'){
              continue
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(Yaxas_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            legend: {
              top: "12",
              right: "13",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: ["1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4"]
            },
            series: item.data
          };
          data[0].data.map((item, num) => {
            (item.type = "bar"),
              (itemstack = ""),
              (item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.beijingMap.initChart(Yaxass_option);
          }, 10);
        } else if (data[0].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[0];
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["50%", "50%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: 'rgba(245,245,245,1)',  // 设置整个图例区域背景颜色
              borderRadius: 10,              
              orient: "vertical",
              left: "45%",
              top: "16%",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.beijingMap.initChart(spie_option);
          }, 10);
        }
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].data.length != 0) {
          this.variable = false;
        }
      }
    },

    handleReportChange(val) {
      this.getRiskManamentRiskList(val);
    },
    getRiskManamentRiskList(val) {
      const keywords = {
        offset: val,
        limit: 2,
        fuzzyQuery: this.fuzzyQuery.value,
        taskName: "riskCtrlMgr,riskReportMent",
        sqlStatus:''
      };
      this.riskManagementRisk(keywords);
    },
    //风险事件管理
    goRiskEventManagement(item) {
      this.$router.push({
        path: "/riskEventManagement",
        query: {
          projectId: item.projectId //项目ID
        }
      });
    },
    goEstablishInfo(item) {
      //跳转报建信息维护
      this.$router.push({
        path: "/establishInfo",
        query: {
          projectId: item.projectId, //项目ID
          buildPermitNo: item.buildPermitNo,
          projectChnStatus: item.projectChnStatus
        }
      });
    },
    reportManagement(item) {
      //跳转风险评估报告管理
      this.$router.push({
        path: "/riskAssessmentReportManagement",
        query: {
          id: item.projectId, //测试ID projectId1
          // item: item,
          item: JSON.stringify(item),
          reportId: item.reportId
        }
      });
    },
    //跳转回访报告管理
    goToReturnVisitRM(item) {
      this.$router.push({
        path: "/returnVisitReportManagement",
        query: {
          id: item.projectId
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
/deep/.el-card__body {
  padding-bottom: 0px;
}
.newclass {
  background: url(../../assets/imgs/noData.png);
  background-size: 260px 260px;
  background-repeat: no-repeat;
  background-position: 140px 100px;
}
.newclass /deep/ span {
  font-size: 17px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 15px;
  left: 21px;
}
.upTitle {
  font-size: 15px;
  color: #000000;
  font-weight: 900;
  margin: 0px;
}
.news {
  height: 45px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  span {
    margin-left: 16px;
  }
}
.my_progress /deep/ .el-progress-circle {
  height: 150px !important;
  width: 150px !important;
}
.card_risk {
  height: 240px;
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 0px 0px 6px 6px;
  border: 0px;
  margin-bottom: 8px;
}
</style>

<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
        </el-col>
        <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
          <el-row>
            <el-col :span="24">
              <el-form-item label="项目名称：">
                <el-input v-model="reportBuildingEssentialInformation.projectName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="项目地址：">
                <el-select
                  class="miniColumn"
                  @change="getCity(getBasicBstablish.prjBasicInfoDO.province,'city')"
                  v-model="reportBuildingEssentialInformation.province"
                  disabled
                >
                  <el-option
                    v-for="item in district"
                    :key="item.province"
                    :label="item.province"
                    :value="item.province"
                  ></el-option>
                </el-select>
                <el-select
                  class="miniColumn ml5"
                  @change="getCity(getBasicBstablish.prjBasicInfoDO.city, 'county')"
                  v-model="reportBuildingEssentialInformation.city"
                  disabled
                >
                  <el-option
                    v-for="item in citys"
                    :key="item.name"
                    :label="item.name"
                    :value="item.name"
                  ></el-option>
                </el-select>
                <el-select
                  class="miniColumn ml5"
                  v-model="reportBuildingEssentialInformation.district"
                  disabled
                >
                  <el-option
                    v-for="item in countys"
                    :key="item.district"
                    :label="item.district"
                    :value="item.district"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="11" prop="address" class="address">
              <el-input v-model="reportBuildingEssentialInformation.address" disabled></el-input>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="住宅性质：">
                <el-radio-group
                  v-model="reportBuildingEssentialInformation.buildingType"
                  v-if="$getversionData.lesseeId!='eidi-maanshan'"
                >
                  <el-radio
                    v-for="item of listBaseData.IDI_PROJECT_TYPES"
                    :key="item.ddId"
                    :label="item.dictKey"
                    disabled
                  >{{item.dictValue}}</el-radio>
                </el-radio-group>
                <el-select
                 disabled
                  v-model="reportBuildingEssentialInformation.buildingType"
                  placeholder="请选择"
                  v-if="$getversionData.lesseeId=='eidi-maanshan'"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_PROJECT_TYPES"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictKey"
                    disabled
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="10">
              <el-form-item label="小区名称：" class="communityName">
                <el-input v-model="reportBuildingEssentialInformation.communityName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="项目概述：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  v-model="reportBuildingEssentialInformation.projectInfo"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-divider class="mc-divider"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold" id="application">标的信息</span>
        </el-col>
        <div class="mc-edit mc-bg">
          <el-form
            class="mc-form"
            label-width="137px"
            size="mini"
            label-position="left"
            align="left"
            :model="reportBuildingEssentialInformation"
            :rules="rules"
            ref="reportBuildingEssentialInformation"
          >
            <el-row>
              <el-col :span="8">
                <el-form-item label="项目报建号：">
                  <el-input v-model="prjConstructionInfoDO.buildPermitNo" disabled></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="建筑幢数：">
                  <format-input text-align="left" v-model="prjConstructionInfoDO.numOfBuilding"></format-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="承保面积(m²)：" required>
                  <format-input
                    :disabled="disabledArea"
                    :precision="2"
                    text-align="left"
                    v-model="prjConstructionInfoDO.totalFloorage"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="地下室面积(㎡)：">
                  <format-input
                    :disabled="disabledArea"
                    text-align="left"
                    :precision="2"
                    v-model="prjConstructionInfoDO.basementFloorage"
                  ></format-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="设计图纸：">
                  <el-input disabled v-model="prjConstructionInfoDO.layoutName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-col :span="3" style="position: relative; left: 10px">
                  <img v-if="!upload" :src="imgUpload" class="img-upload" />
                  <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
                  <!-- <img v-if="upload" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
                </el-col>
                <el-col :span="21">
                  <el-upload
                    class="inline-block mlr97"
                    action
                    :http-request="uploadFile"
                    :show-file-list="false"
                  >
                    <el-button size="mini" type="primary">上传</el-button>
                  </el-upload>
                  <el-button size="mini" @click="delBtn()">删除</el-button>
                  <el-button
                    id="layout"
                    @click="download"
                    size="mini"
                    v-if="prjConstructionInfoDO.layoutName"
                  >下载</el-button>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="地块编号：">
                  <el-input v-model="prjConstructionInfoDO.landNo"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="施工许可证编号：" v-if="$getversionData.lesseeId!='eidi-shanghai'">
                  <el-input
                    v-model="prjConstructionInfoDO.constructionLicenseNo"
                    placeholder="多条信息请以 ',' 分割"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="施工许可证编号：" v-if="$getversionData.lesseeId=='eidi-shanghai'">
                  <el-select
                    value-key="constructionLicenseNo"
                    disabled
                    v-model="prjConstructionLicensesDOList"
                    multiple
                    placeholder="请选择"
                    style="width: 546px;"
                  >
                    <el-option
                      v-for="item in prjConstructionLicensesDOList"
                      :key="item.id"
                      :label="item.constructionLicenseNo"
                      :value="item"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="23">
                <el-form-item label="地块地址：">
                  <el-input v-model="prjConstructionInfoDO.landAddr"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="23" style="text-align:center">
                <!-- {{prjConstructionInfoDO}} -->
                <gaoMap
                  :allocation="prjConstructionInfoDO"
                  @getAllocation="getAllocation"
                  ref="gaoMap"
                ></gaoMap>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="23">
                <el-form-item label="住宅楼信息：">
                  <el-table
                    class="mc-table residence-table"
                    :data="residentialBuildingInformation"
                    style="width: 100%"
                  >
                    <el-table-column prop="buildingName" align="center" label="竣工后楼栋门牌号"></el-table-column>
                    <el-table-column prop="unitId" align="center" label="单体编号"></el-table-column>
                    <el-table-column prop="unitName" align="center" label="单体名称"></el-table-column>
                    <el-table-column prop="buildingType" align="center" label="类别"></el-table-column>
                    <el-table-column prop="totalStories" align="center" label="总层数"></el-table-column>
                    <el-table-column prop="totalUnits" align="center" label="总户数"></el-table-column>
                    <el-table-column align="center" width="80">
                      <template slot-scope="scope">
                        <el-dropdown
                          placement="bottom"
                          size="small"
                          trigger="click"
                          v-show="scope.$index!= residentialBuildingInformation.length"
                          @command="handleCommand(scope.row.id,$event)"
                        >
                          <span class="el-dropdown-link">
                            <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                          </span>
                          <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item
                              icon="el-icon-remove-outline"
                              command="0"
                              v-if="$getversionData.lesseeId!='eidi-shanghai'"
                            >删除</el-dropdown-item>
                            <el-dropdown-item icon="el-icon-edit-outline" command="1">修改</el-dropdown-item>
                            <el-dropdown-item icon="el-icon-edit-outline" command="2">详情</el-dropdown-item>
                          </el-dropdown-menu>
                        </el-dropdown>
                      </template>
                    </el-table-column>
                  </el-table>
                  <div class="mouse-pointer" v-if="$getversionData.lesseeId=='eidi-shanghai'">
                    <div @click="monomerMaintenance()" class="outline">
                      关联项目单体
                      <i
                        class="el-icon-circle-plus-outline"
                        style="color: #2A7BE3;font-size: 20px;position: absolute;top:10px;right:10px"
                      ></i>
                    </div>
                  </div>
                  <div class="mouse-pointer" v-if="$getversionData.lesseeId!='eidi-shanghai'">
                    <div @click="maintenanceMonomer()" class="outline">
                      维护项目单体
                      <i
                        class="el-icon-circle-plus-outline"
                        style="color: #2A7BE3;font-size: 20px;position: absolute;top:10px;right:10px"
                      ></i>
                    </div>
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
            <!-- 分页 -->
            <el-pagination
              small
              class="text-center mt10 control page-lucency"
              @current-change="handleCurrentChangePaging"
              :current-page.sync="offset"
              :page-size="this.limit"
              layout="prev, pager, next"
              :total="this.total"
            ></el-pagination>
            <!-- 按钮 -->
            <el-row style="text-align: right; margin-top: 40px;" class="btns">
              <el-button
                size="mini"
                type="primary"
                @click="preservationReportBuilding('reportBuildingEssentialInformation')"
              >保存</el-button>
              <el-button size="mini" @click="closeReportBuilding()">关闭</el-button>
            </el-row>
          </el-form>
        </div>
        <!-- 三方接口 -->
        <el-dialog
          id="completeDialog"
          title="关联单体"
          :visible.sync="dialogComplete"
          width="95%"
          top="5%"
          :show-close="false"
          :close-on-click-modal="false"
        >
          <div id="completeDiv">
            <iframe
              :src="prjConstructionInfoDO.buildInfoUrl"
              id="iframeId"
              v-if="completeDiv"
              height="400"
              width="100%"
            ></iframe>
          </div>
          <el-row style="text-align: right; margin-top: 30px margin-right: 45px" class="btns">
            <el-button size="mini" @click="singleZJW()" :disabled="singleBtn">关闭</el-button>
          </el-row>
        </el-dialog>
        <!-- 弹窗 -->
        <el-dialog
          title="住宅楼信息"
          :visible.sync="buildingWindows"
          width="900px"
          class="dialog"
          :close-on-click-modal="false"
        >
          <el-form
            class="mc-form"
            label-width="155px"
            size="mini"
            label-position="right"
            align="left"
            :disabled="disableDialog"
          >
            <el-row>
              <el-col :span="11">
                <el-form-item label="单体编号：">
                  <el-input v-model="residentialBuildingDetails.unitId" disabled></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="单体名称：">
                  <el-input v-model="residentialBuildingDetails.unitName" disabled></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="总层数：">
                  <el-input
                    v-model="residentialBuildingDetails.totalStories"
                    :disabled="$getversionData.lesseeId=='eidi-shanghai'"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="地下层数：">
                  <el-input
                    v-model="residentialBuildingDetails.basementStories"
                    :disabled="$getversionData.lesseeId=='eidi-shanghai'"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="竣工后楼栋门牌号：">
                  <el-input v-model="residentialBuildingDetails.buildingName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="楼栋类别：">
                  <el-select
                    v-model="residentialBuildingDetails.buildingType"
                    clearable
                    style="width: 100%"
                  >
                    <el-option
                      v-for="item in listBaseData.IDI_BUILDING_TYPES"
                      :key="item.ddId"
                      :label="item.dictValue"
                      :value="item.dictValue"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="土地性质：">
                  <el-select
                    v-model="residentialBuildingDetails.landType"
                    clearable
                    style="width: 100%"
                  >
                    <el-option
                      v-for="item in listBaseData.IDI_BUILDING_NATURE"
                      :key="item.ddId"
                      :label="item.dictValue"
                      :value="item.dictValue"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="结构类型：">
                  <el-select
                    v-model="residentialBuildingDetails.structureType"
                    clearable
                    style="width: 100%"
                  >
                    <el-option
                      v-for="item in listBaseData.IDI_BUILDING_FWORK"
                      :key="item.ddId"
                      :label="item.dictValue"
                      :value="item.dictValue"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="开工日期：">
                  <el-date-picker
                    :clearable="false"
                    type="date"
                    placeholder="选择日期"
                    @change="validDatas(residentialBuildingDetails.conStartDate, residentialBuildingDetails.conCompleteDate)"
                    v-model="residentialBuildingDetails.conStartDate"
                    style="width: 250.3px"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    :picker-options="pickerOptionsStart"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="竣工日期：">
                  <el-date-picker
                    type="date"
                    placeholder="选择日期"
                    @change="validDatas(residentialBuildingDetails.conStartDate, residentialBuildingDetails.conCompleteDate)"
                    v-model="residentialBuildingDetails.conCompleteDate"
                    style="width: 250.3px"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    :picker-options="pickerOptionsEnd"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="总户数：">
                  <el-input v-model="residentialBuildingDetails.totalUnits"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="商业用房、车棚 层、住宅层分布：">
                  <el-input
                    type="textarea"
                    :autosize=" {minRows: 2}"
                    maxlength="512"
                    show-word-limit
                    v-model="residentialBuildingDetails.floorDistribution"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="基础信息：">
                  <el-input
                    type="textarea"
                    :autosize=" {minRows: 2}"
                    maxlength="512"
                    show-word-limit
                    v-model="residentialBuildingDetails.basicDesc"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="其他情况：">
                  <el-input
                    type="textarea"
                    :autosize=" {minRows: 2}"
                    maxlength="512"
                    show-word-limit
                    v-model="residentialBuildingDetails.otherDesc"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <el-row style="text-align: right; margin-top: 30px margin-right: 45px" class="btns">
            <el-button type="primary" size="mini" @click="submitButton()" v-if="!disableDialog">保存</el-button>
            <el-button size="mini" @click="residentialClosingButton()">关闭</el-button>
          </el-row>
        </el-dialog>
        <!-- 新增弹窗 -->
        <el-dialog
          title="住宅楼信息"
          :visible.sync="addedBuildingWindows"
          width="900px"
          class="dialog"
          :close-on-click-modal="false"
        >
          <el-form
            class="mc-form"
            label-width="155px"
            size="mini"
            label-position="right"
            align="left"
            :rules="rules"
            :model="newMonomer"
            ref="newMonomer"
          >
            <el-row>
              <el-col :span="11">
                <el-form-item label="单体编号：" prop="unitId">
                  <el-input v-model="newMonomer.unitId" text-align="left"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="单体名称：" prop="unitName">
                  <el-input v-model="newMonomer.unitName"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="总层数：">
                  <format-input v-model="newMonomer.totalStories" text-align="left"></format-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="地下层数：">
                  <format-input v-model="newMonomer.basementStories" text-align="left"></format-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="竣工后楼栋门牌号：">
                  <el-input v-model="newMonomer.buildingName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="楼栋类别：">
                  <el-select v-model="newMonomer.buildingType" clearable style="width: 100%">
                    <el-option
                      v-for="item in listBaseData.IDI_BUILDING_TYPES"
                      :key="item.ddId"
                      :label="item.dictValue"
                      :value="item.dictValue"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="土地性质：">
                  <el-select v-model="newMonomer.landType" clearable style="width: 100%">
                    <el-option
                      v-for="item in listBaseData.IDI_BUILDING_NATURE"
                      :key="item.ddId"
                      :label="item.dictValue"
                      :value="item.dictValue"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="结构类型：">
                  <el-select v-model="newMonomer.structureType" clearable style="width: 100%">
                    <el-option
                      v-for="item in listBaseData.IDI_BUILDING_FWORK"
                      :key="item.ddId"
                      :label="item.dictValue"
                      :value="item.dictValue"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="开工日期：">
                  <el-date-picker
                    type="date"
                    placeholder="选择日期"
                    :picker-options="startDateValid"
                    @change="validData(newMonomer.conStartDate, newMonomer.conCompleteDate)"
                    v-model="newMonomer.conStartDate"
                    style="width: 250.3px"
                    value-format="yyyy-MM-dd HH:mm:ss"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="竣工日期：">
                  <el-date-picker
                    type="date"
                    :picker-options="endDateValid"
                    placeholder="选择日期"
                    @change="validData(newMonomer.conStartDate, newMonomer.conCompleteDate)"
                    v-model="newMonomer.conCompleteDate"
                    style="width: 250.3px"
                    value-format="yyyy-MM-dd HH:mm:ss"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="总户数：">
                  <format-input v-model="newMonomer.totalUnits" text-align="left"></format-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="商业用房、车棚 层、住宅层分布：">
                  <el-input
                    type="textarea"
                    :autosize=" {minRows: 2}"
                    maxlength="512"
                    show-word-limit
                    v-model="newMonomer.floorDistribution"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="基础信息：">
                  <el-input
                    type="textarea"
                    :autosize=" {minRows: 2}"
                    maxlength="512"
                    show-word-limit
                    v-model="newMonomer.basicDesc"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="其他情况：">
                  <el-input
                    type="textarea"
                    :autosize=" {minRows: 2}"
                    maxlength="512"
                    show-word-limit
                    v-model="newMonomer.otherDesc"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <el-row style="text-align: right; margin-top: 30px margin-right: 45px" class="btns">
            <el-button type="primary" size="mini" @click="newPreservation('newMonomer')">保存</el-button>
            <el-button size="mini" @click="residentialClosingButton()">关闭</el-button>
          </el-row>
        </el-dialog>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import imgUpload from "@/assets/imgs/put.png";
import formatInput from "@/components/formatInput";
import gaoMap from "@/components/gaoMap";
import http from "@/common/request";
import axios from "axios";
export default {
  components: {
    formatInput,
    gaoMap,
  },
  data() {
    return {
      singleBtn: false,
      progress: 0,
      disabledArea: false,
      completeDiv: false,
      prjConstructionLicensesDOLists: [],
      dialogComplete: false,
      // allocation: [116.397405, 39.908667],
      total: undefined,
      upload: false,
      disableDialog: false,
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        },
      },
      endDateValid: {
        disabledDate(data) {
          return "";
        },
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        },
      },
      pickerOptionsEnd: {
        disabledDate(data) {
          return "";
        },
      },
      pickerOptionsStart: {
        disabledDate(data) {
          return "";
        },
      },
      rules: {
        communityName: [
          { required: true, message: "请输小区名称", trigger: "blur" },
        ],
        unitId: [{ required: true, message: "请输单体编号", trigger: "blur" }],
        unitName: [
          { required: true, message: "请输单体名称", trigger: "blur" },
        ],
      },
      rule: {},
      citys: [],
      limit: 6, //每页几条数据
      offset: 1, //第几页
      countys: [],
      imgUpload,
      buildingWindows: false,
      addedBuildingWindows: false,
      residentialBuildingInformation: undefined, //报建信息住宅楼
      newMonomer: {}, //新增单体信息
      //基本信息
      reportBuildingEssentialInformation: {
        projectName: "",
        communityName: "",
      },
      //弹窗住宅楼详情
      residentialBuildingDetails: {},
      //其他信息(小区名称)
      prjConstructionInfoDO: {},
      saveConstructionApplicationInformation: {},
      prjConstructionLicensesDOList: [],
    };
  },
  computed: {
    ...mapGetters(["district", "listBaseData", "getBasicBstablish"]),
  },
  created() {
    this.essentialInformation();
    this.requestForConstruction();
    if (this.$route.query.projectChnStatus == "项目已竣工") {
      this.disabledArea = true;
    } else {
      this.disabledArea = false;
    }
  },
  methods: {
    //日期校验
    validData(start, end) {
      if (start) {
        this.endDateValid = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          },
        };
      } else {
        this.endDateValid = {
          disabledDate(data) {
            return "";
          },
        };
      }
      if (end) {
        this.startDateValid = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          },
        };
      } else {
        this.startDateValid = {
          disabledDate(data) {
            return "";
          },
        };
      }
    },
    //日期校验
    validDatas(start, end) {
      if (start) {
        this.pickerOptionsEnd = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          },
        };
      } else {
        this.pickerOptionsEnd = {
          disabledDate(data) {
            return "";
          },
        };
      }
      if (end) {
        this.pickerOptionsStart = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          },
        };
      } else {
        this.pickerOptionsStart = {
          disabledDate(data) {
            return "";
          },
        };
      }
    },
    getAllocation(e) {
      this.prjConstructionInfoDO.prjLocationX = e.lng;
      this.prjConstructionInfoDO.prjLocationY = e.lat;
    },
    //保存单体住宅楼信息
    async preservationMonomer() {
      const res = await this.$api.monomerHousing(
        this.residentialBuildingDetails
      );
      if (res.code == 0) {
        this.buildingWindows = false;
        this.$messageSuccess({
          message: "保存成功",
        });
        this.requestForConstruction();
      } else {
        this.$messageError({
          message: res.msg,
        });
      }
    },
    //新增单体保存
    async saveNewMonomer() {
      this.newMonomer.projectId = this.$route.query.projectId;
      const res = await this.$api.newPreservation(this.newMonomer);
      if (res.code == 0) {
        this.buildingWindows = false;
        this.$messageSuccess({
          message: res.msg,
        });
        this.requestForConstruction();
        this.newMonomer = {};
        this.addedBuildingWindows = false;
      } else {
        this.$messageError({
          message: res.msg,
        });
      }
    },
    //基本信息请求
    async essentialInformation() {
      this.projectId = this.$route.query.projectId;
      const res = await this.$api.basicBstablish(this.projectId);
      this.reportBuildingEssentialInformation = res.data.prjBasicInfoDO;
      this.prjConstructionInfoDO = res.data.prjConstructionInfoDO;
      this.$refs.gaoMap.initSearch();
      this.prjConstructionLicensesDOList =
        res.data.prjConstructionLicensesDOList;
    },
    //报建信息请求
    async requestForConstruction() {
      const reportBuildingData = {
        projectId: this.$route.query.projectId,
        offset: this.offset,
        limit: this.limit,
      };
      const res = await this.$api.buildingInformation(reportBuildingData);
      this.total = res.data.total;
      this.residentialBuildingInformation = res.data.rows;
    },
    //报建信息详情
    async detailedInformation() {
      const id = this.reportBuildingId;
      const res = await this.$api.buildingDetails(id);
      this.residentialBuildingDetails = res.data;
    },
    //报建信息单体维护跳转到三方
    monomerMaintenance() {
      this.dialogComplete = true;
      this.completeDiv = true;
    },
    async singleZJW() {
      this.singleBtn = true;
      const res = await this.$api.singleZJW({
        insContractNo: this.reportBuildingEssentialInformation.insContractNo,
        projectId: this.$route.query.projectId,
      });
      if (res.code == 0) {
        this.requestForConstruction();
        this.dialogComplete = false;
        this.singleBtn = false;
      } else {
        this.singleBtn = false;
        this.$messageError({
          message: "同步单体失败,请稍后重试",
        });
      }
      this.completeDiv = false;
    },
    //报建信息保存按钮
    async saveReportBuildingRequest() {
      //存数据
      this.$store.dispatch("loading", true);
      this.saveConstructionApplicationInformation = {
        prjBasicInfoDO: this.reportBuildingEssentialInformation,
        prjConstructionInfoDO: this.prjConstructionInfoDO,
        prjConstructionLicensesDOList: this.prjConstructionLicensesDOList,
      };
      const res = await this.$api.newspaperPreservation(
        this.saveConstructionApplicationInformation
      );
      if (res.code == 0) {
        this.$messageSuccess({
          message: "成功",
        });
        this.$router.go(-1);
      } else {
        this.$messageError({
          message: "失败 ",
        });
      }
      this.$store.dispatch("loading", false);
    },
    //分页
    handleCurrentChangePaging(val) {
      this.offset = val;
      this.requestForConstruction();
    },
    //弹窗关闭按钮
    residentialClosingButton() {
      this.buildingWindows = false;
      this.addedBuildingWindows = false;
    },
    //弹窗保存按钮
    submitButton() {
      this.preservationMonomer(this.residentialBuildingDetails);
    },
    //弹窗新增保存
    newPreservation(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.saveNewMonomer();
        } else {
          this.$messageError({
            message: "请完善信息",
          });
        }
      });
    },
    //关闭按钮
    closeReportBuilding() {
      console.log("guanbu");
      this.$router.push("/riskManagementRisk");
    },
    //保存信息
    preservationReportBuilding(formName) {
      if (this.prjConstructionInfoDO.totalFloorage) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveReportBuildingRequest();
          } else {
            this.$messageError({
              message: "请完善信息",
            });
          }
        });
      } else {
        this.$messageError({
          message: "承保面积不能为空",
        });
      }
    },
    //获取当前行内容
    // handleCellClick(row) {
    //   this.reportBuildingId = row.id;
    //   this.detailedInformation(this.reportBuildingId);
    // },
    //维护单体信息
    maintenanceMonomer() {
      this.addedBuildingWindows = true;
    },
    //删除单体
    async deleteMonomerInformation(id) {
      this.$confirm("此操作将删除该信息，是否继续？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(async () => {
          const res = await this.$api.deleteMonomer(id);
          if (res.code == 0) {
            this.$messageSuccess({
              message: res.msg,
            });
            this.essentialInformation();
            this.requestForConstruction();
          } else {
            this.$messageError({
              message: res.msg,
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    //删除与修改
    handleCommand(id, command) {
      //删除
      if (command === "0") {
        this.deleteMonomerInformation(id);
      } else if (command === "1") {
        (this.pickerOptionsEnd = {
          disabledDate(data) {
            return "";
          },
        }),
          (this.pickerOptionsStart = {
            disabledDate(data) {
              return "";
            },
          }),
          (this.reportBuildingId = id);
        this.disableDialog = false;
        this.detailedInformation(this.reportBuildingId);
        this.buildingWindows = true;
      } else {
        this.reportBuildingId = id;
        this.detailedInformation(this.reportBuildingId);
        this.buildingWindows = true;
        this.disableDialog = true;
      }
    },
    // 上传
    uploadFile(param) {
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "layout");
      file.append("projectId", this.$route.query.projectId);
      const config = {
        onUploadProgress: (progressEvent) => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
           this.progress = complete == 100 ? 99 : complete;
        },
      };
      axios
        .post("/processDoc/uploadProcessDocTmp", file, config)
        .then((res) => {
          if (res.data.code == 0) {
            this.prjConstructionInfoDO.layout = res.data.data.cloudDocId;
            this.prjConstructionInfoDO.layoutName = res.data.data.fileName;
            this.progress=100
          } else {
            this.$messageError({ message: res.data.msg });
          }
          this.upload = false;
        });
      this.progress = 0;
    },
    // 下载
    download() {
      let a = document.createElement("a");
      a.style = "display: none";
      a.href = `/api/processDoc/downloadProcessDoc?cloudDocId=${this.prjConstructionInfoDO.layout}&view=2`;
      a.download = this.prjConstructionInfoDO.layoutName;
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn() {
      this.prjConstructionInfoDO.layoutName = "";
      this.prjConstructionInfoDO.layout = "";
    },
  },
};
</script>
<style scoped lang="scss">
.el-form-item--mini {
  margin-bottom: 12px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
}
.buttn {
  width: 64.5px;
  height: 29.5px;
  background: rgba(16, 143, 235, 1);
  border-radius: 8px;
  color: #fff;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.el-input__inner {
  width: 273px;
}
.control {
  text-align: right;
  margin-right: 45px;
}
.address {
  margin-left: -5px;
  /deep/ .el-input__inner {
    height: 28px;
    width: 552px;
  }
}
.communityName {
  /deep/ .el-input__inner {
    height: 28px;
    width: 410px;
  }
}
.mouse-pointer {
  width: 100%;
  background-color: rgba(255, 255, 255, 0.9);
  height: 36.8px;
  color: #3e3a39;
  border-radius: 0 0 5px 5px;
  cursor: default;
  position: relative;
}
.outline {
  width: 150px;
  text-align: center;
  height: 36.8px;
  line-height: 36.8px;
  cursor: pointer;
  position: absolute;
  left: 370px;
}
.residence-table {
  border-radius: 0px;
}
.mc-form /deep/ .threeColumn,
.mc-form /deep/ .el-col-8 .el-input {
  width: 183.66px;
}
.mc-edit:hover {
  background: rgba(255, 255, 255, 0.6);
}
.mc-bg {
  background: rgba(255, 255, 255, 0.9);
}
</style>
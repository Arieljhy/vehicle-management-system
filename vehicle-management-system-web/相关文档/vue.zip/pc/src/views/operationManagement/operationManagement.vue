<template>
  <div style="position: relative">
    <transition leave-active-class="animated rollOut" enter-active-class="animated rollIn">
      <div v-show="showForm" class="content">
        <div class="back-gauge">
          <span style="padding-right:37.5px;position:relative;">
            <el-row class="con-head">
              <div style="width: 80px;height: 51.5px">
                <img :src="logo_2" style="width: 80px;height: 51.5px" />
              </div>
              <el-input
                v-model="fuzzyQuery"
                @keyup.enter.native="()=>{isFuzzyQuery = false;handleQuery()}"
                placeholder="请输入项目名称 / 保单号"
              >
                <el-button
                  slot="append"
                  icon="el-icon-search"
                  @click="()=>{isFuzzyQuery = false;handleQuery()}"
                ></el-button>
              </el-input>
            </el-row>
            <div
              v-show="omList.length===0"
              style="position: absolute;left: 50%;top: 50%;transform: translate(-50%,-50%);"
            >
              <img src="@/assets/imgs/noData.png" width="220" height="171" />
            </div>
            <div v-if="omList.length!==0">
              <div style="margin:47px 0 32px 0">
                <div :key="index" v-for="(item,index) of omList" :class="{'heJiaPass':item.zaoJiaMean}">
                  <el-row style="margin-left: 10px" :class="{'rowMt': item === 1}">
                    <el-col class="text-left" :span="21">
                      <span
                        class="con-title mouse-pointer"
                        @click="goForm(item)"
                      >{{item.projectName}}</span>
                    </el-col>
                    <el-form>
                      <el-col :span="20">
                        <el-row>
                          <el-col :span="10">
                            <el-form-item class="text-left" label="保单号：">
                              <div
                                class="policy"
                                :title="item.insContractNo"
                                style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                              >{{item.insContractNo}}</div>
                            </el-form-item>
                          </el-col>
                          <el-col :span="6">
                            <el-form-item class="text-left" label="区域：">
                              <span>{{item.district}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="8">
                            <el-form-item class="text-left" label="住宅性质：">
                              <span>{{item.dictValue}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="10">
                            <el-form-item class="text-left" label="项目进度：">
                              <span>{{item.projectChnStatus}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="6">
                            <el-form-item class="text-left" label="造价均值：">
                              <span>{{item.costPerMeter}}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :span="8">
                            <el-form-item class="text-left" label="推送时间：">
                              <span
                                v-if="item.buildInfoUrlDate"
                              >{{item.buildInfoUrlDate | filterDate("yyyy-MM-dd")}}</span>
                              <span v-else>{{'未推送'}}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :span="8">
                            <el-form-item class="text-left" label="业务状态：">
                              <span>{{item.taskChnName}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="10">
                            <el-form-item class="text-left" label="签单日期：">
                              <span>{{item.signDate | filterDate("yyyy-MM-dd")}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="14">
                            <el-form-item class="text-left" label="当前处理人：">
                              <span>{{item.processRoleId}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="16">
                            <el-form-item class="text-left" label="承保公司：">
                              <span>{{item.insOrgName}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="24" v-if="item.warning!=null" style="color:red">
                            <el-form-item class="text-left color" label="预警：">
                              <div
                                style="color:red"
                                :title="item.warning"
                                class="info-content"
                              >{{item.warning}}</div>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-col>
                      <!-- 暂时不开发 -->
                      <el-col :span="4">
                        <!-- <div
                          v-if="control.includes('operationManagementPush')"
                          class="text-left mouse-pointer btn-bg"
                          style="font-size:12.5px"
                        >
                          <img src="../../assets/imgs/operationManagement/btn-bg.png" />
                          <span @click="sendZJW(item.buildPermitNo)">查询施工许可</span>
                        </div>-->
                        <div
                          @click="cancellPolicy(item.projectId,item.insContractNo)"
                          class="text-left mouse-pointer btn-bg"
                          style="margin-top: 0.3px; font-size:12.5px"
                        >
                          <img src="../../assets/imgs/operationManagement/btn-bg.png" />
                          <span>撤销保单</span>
                        </div>
                        <div
                          class="text-left mouse-pointer btn-bg"
                          style="margin-top: 0.3px; font-size:12.5px"
                        >
                          <div
                            v-if="control.includes('operationManagementPush')&&$getversionData.lesseeId=='eidi-shanghai'"
                          >
                            <img src="../../assets/imgs/operationManagement/btn-bg.png" />
                            <span @click="doSubmitResult(item.projectId)">推送审核结果</span>
                          </div>
                        </div>
                        <div
                          v-if="control.includes('operationManagementPush')&&$getversionData.lesseeId=='eidi-shanghai'"
                          class="text-left mouse-pointer btn-bg"
                          style="margin-top: 0.3px;font-size:12.5px"
                        >
                          <img src="../../assets/imgs/operationManagement/btn-bg.png" />
                          <span @click="updateInfo(item.insContractNo,item.projectId)">同步单体信息</span>
                        </div>
                      </el-col>
                    </el-form>
                  </el-row>
                  <el-dialog
                    title="撤销保单"
                    :visible.sync="dialogVisible"
                    width="40%"
                    :close-on-click-modal="false"
                    size="mini"
                    class="dialog"
                    :show-close="false"
                  >
                    <el-form
                      label-width="60px"
                      style="padding-right: 20px;"
                      ref="form"
                      :model="form"
                      class="mc-form dialogForm"
                      size="mini"
                      label-position="left"
                      align="left"
                    >
                      <span
                        style="display: block;color: rgba(0,0,0,.87);font-size: 12px;font-weight: 700;text-transform: none;padding-bottom: 10px;"
                      >{{'请输入保单号确认撤销'}}</span>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="保单号:">
                            <el-input v-model="form.name"></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24" style="    padding-top: 30px;">
                          <el-form-item label="撤销原因:">
                            <el-input
                              style=" margin-left: 20px;"
                              v-model="form.delReason"
                              type="textarea"
                              :autosize=" {minRows: 1,maxRows:2}"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button
                        @click="dialogVisible = false;form.name = '';form.delReason=''"
                        size="mini"
                      >取 消</el-button>
                      <el-button type="primary" @click="rescindPrjs" size="mini">确 定</el-button>
                    </span>
                  </el-dialog>
                  <el-divider v-if="item !== 3"></el-divider>
                </div>
              </div>
              <el-pagination
                small
                style="position:absolute;bottom:0;left:50%;transform: translateX(-50%);"
                class="page-lucency"
                layout="prev, pager, next"
                v-if="!(loading&&omList.length===0)"
                :total="pagination.total"
                :current-page="pagination.currentPage"
                @current-change="handlePageChange"
              ></el-pagination>
            </div>
          </span>
          <span>
            <query title="OM" @doQuery="handleQuery"></query>
          </span>
        </div>
      </div>
    </transition>
    <transition enter-active-class="animated rollIn" leave-active-class="animated rollOut">
      <div v-show="!showForm" class="faster" style="position: absolute; top: 0;">
        <div id="top">
          <flow-chart :current="current" @goBack="showForm = true" />
          <basic-information v-show="schedule.includes('BasicInformation')" :disabled="true" />
          <bstablish-information
            v-show="schedule.includes('BstablishInformation')"
            :disabled="true"
            showMyCase="basicBstablish"
            ref="basicBstablish"
          />
          <underwriting-information
            v-show="schedule.includes('UnderwritingInformation')"
            ref="underwriting"
            :disabled="true"
            showMyCase="UnderwritingInformation"
          />
          <insurance-review
            v-show="schedule.includes('InsuranceReview')"
            :disabled="true"
            ref="insuranceReview"
            taskType="underwrite"
            title="保险审核"
          />
          <risk-plan v-show="schedule.includes('RiskPlan')" ref="riskPlan" :disabled="true" />
          <insurance-review
            v-show="schedule.includes('RiskPlanReview')"
            :disabled="true"
            title="风险管理计划审核"
            taskType="checkRiskCtrlPlan"
          />
          <risk-report-list
            v-show="schedule.includes('RiskReportList')"
            ref="riskReportList"
            :disabled="true"
          />
          <risk-events-list
            v-show="schedule.includes('RiskEventsList')"
            ref="riskEventsList"
            :disabled="true"
          />
          <risk-final-report
            v-show="schedule.includes('RiskFinalReport')"
            ref="riskFinalReport"
            :disabled="true"
          />
          <insurance-coverage
            ref="insuranceCoverage"
            v-show="schedule.includes('InsuranceCoverage')"
            :disabled="true"
          />
          <insurance-review
            v-show="schedule.includes('CopyRiskPlanReview')"
            :disabled="true"
            title="竣工保险审核"
            taskType="insuranceReview"
          />
          <project-returns ref="ProjectReturns" v-show="schedule.includes('ProjectReturns')" />
          <project-claims ref="ProjectClaims" v-show="schedule.includes('ProjectClaims')" />
          <el-button @click="goTop" id="go-top" circle :style="screen_width">
            <i class="el-icon-arrow-up"></i>
          </el-button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getList, getNode } from "@/assets/js/utils";
import http from "@/common/request";
import Query from "@/components/Query";
import logo_2 from "@/assets/imgs/projectInquiry/logo-2.png";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import ProjectClaims from "@/components/ProjectSummary/ProjectClaims"; //理赔列表
import ProjectReturns from "@/components/ProjectSummary/ProjectReturns"; //项目回访
export default {
  name: "OperationManagement",
  components: {
    Query,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    UnderwritingInformation,
    RiskPlan,
    InsuranceReview,
    InsuranceCoverage,
    RiskReportList,
    RiskEventsList,
    RiskFinalReport,
    ProjectClaims,
    ProjectReturns
  },
  data() {
    return {
      insContractNo1: "",
      projectIds: "",
      form: {
        name: "",
        delReason: ""
      },
      dialogVisible: false,
      current: {
        finished: [],
        current: []
      },
      logo_2,
      showForm: true,
      schedule: [],
      fuzzyQuery: "",
      omList: [],
      pagination: {
        pageSize: 10,
        currentPage: 1,
        total: 0
      },
      heJiaPass: [
        "startRiskPlan",
        "insertRiskCtrlPlan",
        "checkRiskCtrlPlan",
        "riskCtrlMgr",
        "riskReportMent",
        "settleClaims"
      ]
    };
  },
  computed: {
    ...mapGetters(["OMQueryParams", "control", "loading"]),
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  methods: {
    ...mapActions(['getHeJia']),
    //撤销保单
    cancellPolicy(row, insContractNo) {
      this.projectIds = row;
      this.dialogVisible = true;
      this.insContractNo1 = insContractNo;
      // this.$confirm("此操作撤销该保单, 是否继续?", "提示", {
      //   confirmButtonText: "确定",
      //   cancelButtonText: "取消",
      //   type: "warning"
      // })
      //   .then(async () => {
      //     const res = await this.$api.rescindPrj(projectId);
      //     if (res.code == 0) {
      //       this.$messageSuccess({ message: "撤销成功" });
      //       this.handleQuery()
      //     } else {
      //       this.$messageError({ message: "操作失败，请联系管理员" });
      //     }
      //   })
      //   .catch(() => {
      //     this.$message({
      //       type: "info",
      //       message: "已取消撤销"
      //     });
      //   });
    },
    rescindPrjs() {
      if (this.form.delReason) {
        if (this.form.name) {
          if (this.form.name == this.insContractNo1) {
            this.rescindPrj({
              projectId: this.projectIds,
              delReason: this.form.delReason
            });
            this.form.name = "";
            this.form.delReason = "";
          } else {
            this.$messageSuccess({ message: "请输入正确保单号" });
            this.form.name = "";
          }
        } else {
          this.dialogVisible = false;
        }
      } else {
        this.$messageSuccess({ message: "请输入撤单原因" });
      }
    },
    async rescindPrj(projectId) {
      const res = await this.$api.rescindPrj(projectId);
      if (res.code == 0) {
        this.$messageSuccess({ message: "撤销成功" });
        this.dialogVisible = false;
        this.handleQuery();
      } else {
        this.$messageError({ message: "操作失败，请联系管理员" });
      }
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    //回到顶部按钮
    showGoTop() {
      if (!this.showForm) {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },
    // 展示表单
    goForm(row) {
      let item = { ...row };
      item.taskName = getNode(item);
      this.showForm = false;
      const data = {
        newProject: getList(0),
        insertInsureInfo: getList(2),
        underwrite: getList(3),
        startRiskPlan: getList(3),
        insertRiskCtrlPlan: getList(4),
        checkRiskCtrlPlan: getList(7),
        riskCtrlMgr: getList(7),
        insertCompletedInfo: getList(9),
        insuranceReview: getList(10),
        riskReportMent: getList(11),
        settleClaims: getList()
      };
      this.getHeJia(row.zaoJiaMean)
      this.schedule = data[item.taskName];
      switch (item.taskName) {
        case "newProject":
          this.current = {
            current: ["enteringIns"],
            finished: ["newProject"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "insertInsureInfo":
          this.current = {
            current: ["insuranceAudit"],
            finished: ["newProject", "enteringIns"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "underwrite":
          this.current = {
            current: ["launchRisk"],
            finished: ["newProject", "enteringIns", "insuranceAudit"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "startRiskPlan":
          this.current = {
            current: ["enteringRisk"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "insertRiskCtrlPlan":
          this.current = {
            current: ["checkRisk"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          break;
        case "checkRiskCtrlPlan":
          this.current = {
            current: ["riskManage"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          break;
        case "riskCtrlMgr":
          this.current = {
            current: ["entreingCompleted"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          break;
        case "insertCompletedInfo":
          this.current = {
            current: ["insuranceCheck"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          break;
        case "insuranceReview":
          this.current = {
            current: ["riskReturn"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          break;
        case "riskReportMent":
          this.current = {
            current: ["claim"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck",
              "riskReturn"
            ],
            projectId: item.projectId
          };
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.underwriting.init(item.projectId);
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          this.$refs.ProjectReturns.projectReturn(item.projectId);
          this.$refs.ProjectClaims.projectClaim(item.projectId);
          break;
        case "settleClaims":
          this.current = {
            current: ["projectCompletion"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck",
              "riskReturn",
              "claim"
            ],
            projectId: item.projectId
          };
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          this.$refs.ProjectReturns.projectReturn(item.projectId);
          this.$refs.ProjectClaims.projectClaim(item.projectId);
          break;
      }
      if (item.taskName != "newProject") {
        this.$refs.underwriting.init(item.projectId);
      }
      if (
        item.taskName != "newProject" &&
        item.taskName != "insertInsureInfo"
      ) {
        this.$refs.insuranceReview.insuranceReview({
          projectId: item.projectId
        });
      }
    },
    async handleQuery(params) {
      if (params) {
        this.params = params;
      }
      const { isFresh, queryParams } = this.params || {};
      if (isFresh) {
        this.pagination = {
          pageSize: 10,
          currentPage: 1,
          total: 0
        };
      }
      this.$store.dispatch("loading", true);
      //如果第一次有fuzzyQuery查询条件，则currentPage为1，否则当前分页取当前页
      if (this.fuzzyQuery !== "" && !this.isFuzzyQuery) {
        this.isFuzzyQuery = true;
        this.pagination.currentPage = 1;
      }
      const { currentPage, pageSize } = this.pagination;
      const {
        code,
        data: { total, rows },
        msg
      } = await this.$api.getProjectList({
        ...queryParams,
        offset: currentPage,
        limit: pageSize,
        ...(this.fuzzyQuery && { fuzzyQuery: this.fuzzyQuery })
      });
      if (code === 0) {
        this.pagination.total = total;
        this.omList = rows;
        this.omList.map(item => {
          if (item.warning && item.warning.indexOf("造价均值") > -1) {
            if (this.heJiaPass.includes(item.taskName)) {
              item.zaoJiaMean = true;
            }
          }
        });
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    sendZJW(buildPermitNo) {
      this.$api.sendZJW({ buildPermitNo }).then(res => {
        const { code, msg: message } = res;
        if (code === 0) {
          this.$messageSuccess({ message });
        } else {
          this.$messageError({ message });
        }
      });
    },
    async doSubmitResult(projectId) {
      const res = await this.$api.pushBdshInfo(projectId);
      if (res.code == 0) {
        this.$messageSuccess({
          message: res.msg
        });
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    async updateInfo(insContractNo, projectId) {
      const res = await this.$api.singleZJW({
        insContractNo: insContractNo,
        projectId: projectId
      });
      if (res.code == 0) {
        this.$messageSuccess({
          message: "同步单体成功"
        });
      } else {
        this.$messageError({
          message: "同步单体失败,请稍后重试"
        });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      if (this.params) {
        this.params.isFresh = false;
      }
      this.handleQuery();
    }
  },
  created() {
    this.handleQuery();
  },
  mounted() {
    window.addEventListener("scroll", this.showGoTop, true);
  },

  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  }
};
</script>
<style scoped lang="scss">
.rowMt {
  margin-top: 33.5px;
}
.news {
  height: 45px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  span {
    margin-left: 16px;
  }
}
.content {
  .btn-bg {
    &:hover {
      opacity: 0.8;
    }
    position: relative;
    font-size: 12px;
    color: #fff;
    img {
      height: 24px;
      width: 116px;
    }
    span {
      position: absolute;
      top: 3px;
      left: 20px;
    }
  }
  min-height: 493px;
  background-color: rgba(255, 255, 255, 0.9);
  .con-head {
    $bule: #297ae3;
    display: flex;
    align-items: flex-end;
    .el-image {
      margin-left: 5px;
    }
    .el-input {
      width: 585px;
      $height: 39.5px;
      /deep/ .el-input__inner {
        background-color: rgba(255, 255, 255, 0);
        $color: #e7edf7;
        border-radius: 0;
        height: $height;
        line-height: $height;
        border: 1px solid $bule;
        &::-webkit-input-placeholder {
          color: $color;
        }
        &::-moz-placeholder {
          color: $color;
        }
        &:-ms-input-placeholder {
          color: $color;
        }
      }
    }
    /deep/ .el-input-group__append {
      background: $bule;
      border-radius: 0;
      border: 0;
      padding: 0;
      width: 49px;
      height: 39.5px;
    }
    /deep/ .el-button {
      margin: 0;
      padding: 0;
      color: #fff;
      font-size: 25px;
    }
  }
  .back-gauge {
    display: flex;
    padding: 27px 29px 18.5px 29px;
    .el-input {
      margin-left: 20px;
    }
  }
  $bule: #297ae3;
  .con-title {
    font-size: 14.5px;
    color: $bule;
    font-weight: bold;
    padding-bottom: 1.5px;
    border-bottom: 1.5px solid $bule;
  }
  .el-form {
    $height: 13.5px;
    $color: rgba(62, 58, 57, 1);
    $font: 12.5px;
    .el-form-item {
      margin: 8px 0 0 0;
      font-weight: bold;
      height: $height;
      /deep/ .el-form-item__label {
        text-align: left;
        font-size: $font;
        color: $color;
        line-height: $height !important;
        padding: 0 !important;
      }
      /deep/ .el-form-item__content {
        font-size: $font;
        color: $color;
        line-height: $height !important;
      }
    }
  }
  .el-divider {
    margin: 5px 0 13px 0;
    background-color: $bule;
    width: 678px;
    height: 1.5px;
  }
}
.info-content {
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  line-height: 15px;
}
.color /deep/ .el-form-item__label {
  color: red !important;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialogForm /deep/ .el-form-item__label {
  margin-top: 6px;
}
.heJiaPass {
  background-image: url(../../assets/imgs/hejia.png);
  background-repeat: no-repeat;
  background-size: 72px;
  background-position: 53% 38%;
}
</style>
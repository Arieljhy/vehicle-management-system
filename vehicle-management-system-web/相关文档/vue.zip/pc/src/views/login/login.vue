<template>
  <div style="min-width:1300px">
    <!-- 登录弹框 -->
    <el-dialog
      class="login-dialog"
      :show-close="true"
      :before-close="handleClose"
      :lock-scroll="false"
      :visible.sync="loginDialog"
      width="425px"
      top="24vh"
      :close-on-click-modal="false"
    >
      <el-form ref="loginForm" :rules="rulesLoginForm" :model="loginForm">
        <el-row
          :class="[!findPassword ? 'tall' : 'low']"
          style="position: relative"
          class="text-left"
        >
          <el-col :span="24" :class="[!findPassword ? 'mb42' : 'mb27']">
            <img
              src="@/assets/imgs/IDILogo.png"
              class="inline-block"
              style="width: 71px;height: 46px;margin: 0 49px 0 21px;"
            />
            <span
              style="font-size: 19px;font-weight: 500;color:#474747;position: absolute;top: 20px"
            >{{!findPassword ? '账号密码登录' : '找回密码'}}</span>
          </el-col>
          <el-col :span="24">
            <el-form-item prop="userId">
              <el-input v-model="loginForm.userId" clearable :placeholder="'请输入手机号'"></el-input>
            </el-form-item>
          </el-col>
          <el-col v-if="!findPassword" :span="24">
            <el-form-item prop="password">
              <el-input
                @keyup.enter.native="loginOn('loginForm')"
                v-model="loginForm.password"
                clearable
                placeholder="请输入密码"
                type="password"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="15">
            <el-form-item prop="loginCode">
              <el-input
                maxlength="4"
                @keyup.enter.native="loginOn('loginForm')"
                style="width: 218px"
                v-model="loginForm.loginCode"
                clearable
                placeholder="请输入验证码"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-button
              :disabled="times != '发送验证码'"
              class="verification-code"
              @click="getLoginCode(loginForm.userId)"
            >{{times}}</el-button>
          </el-col>
          <el-col v-if="findPassword" :span="24">
            <el-form-item prop="password">
              <el-input v-model="loginForm.password" placeholder="新密码" clearable type="password"></el-input>
            </el-form-item>
          </el-col>
          <el-col v-if="findPassword" :span="24">
            <el-form-item prop="againPassword">
              <el-input
                v-model="loginForm.againPassword"
                placeholder="确认新密码"
                clearable
                type="password"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-button
              type="primary"
              :loading="fullscreenLoading"
              style="font-size:17px;font-weight:500;width: 100%;height:48px;"
              @click="loginOn('loginForm')"
            >{{!findPassword ? '登 录' : '确 认'}}</el-button>
          </el-col>
          <el-col :span="24" v-if="!findPassword" class="text-right">
            <el-button
              type="text"
              style="padding: 15px 0 0 0;color:#B4B4B4;"
              @click="changeType()"
            >忘记密码</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>
    <!-- :style="background" -->
    <div class="bg" :style="background">
      <el-row>
        <el-col class="corner-btn text-right" :span="24">
          <el-button size="mini" type="primary" round @click="scrollInteView('info')">信息公开</el-button>
          <el-button
            class="btn-sample"
            size="mini"
            type="primary"
            round
            @click="scrollInteView('file')"
          >样本文件</el-button>
        </el-col>
        <el-col :span="24" class="title">
          <div>
            <img :src="imgLogo[$getversionData.control]" />
            <img :src="headerTitle[$getversionData.control]" />
          </div>
        </el-col>
        <el-col
          class="units"
          :style="height"
          :class="{ 'mt24' : index === 0 }"
          :span="24"
          v-for="(unit, index) of $getversionData.units"
          :key="unit"
        >{{ unit }}</el-col>
        <el-col :span="24">
          <button
            ref="getMb"
            class="loginBtn mouse-pointer"
            @click="changeType('loginImmediately')"
          >立即登录</button>
        </el-col>
      </el-row>
    </div>

    <div class="content" v-if="home">
      <el-row>
        <el-col class="pr14" :span="12">
          <el-col :span="24" class="text-left">
            <el-col :span="24" class="bor-bottom">
              <span class="msg-title" id="info">信息公开</span>
            </el-col>
            <el-col :span="24">
              <ul>
                <li :key="item.content" v-for="item in disInforList">
                  <span class="mouse-pointer after" @click="sendDetail(item,'a')">
                    <div class="mesSpan inline-block">《 {{item.title}} 》</div>
                    <div class="inline-block float-right">{{item.createdDate | filterDate}}</div>
                  </span>
                </li>
              </ul>
              <el-button class="more" @click="open(1)">
                MORE
                <i class="ml13 el-icon-arrow-right"></i>
              </el-button>
            </el-col>
          </el-col>
        </el-col>
        <el-col
          v-for="item of 2"
          :key="item"
          :class="[{ 'mt73': item === 2 }, item === 1 ? 'pl14' : 'pr14']"
          :span="12"
        >
          <img :src="message[$getversionData.control]" style="width:498px; height:241px;" />
        </el-col>
        <el-col :span="12" class="mt73 pl14 text-left">
          <el-col :span="24" class="bor-bottom">
            <span class="msg-title" id="file">样本文件</span>
          </el-col>
          <el-col :span="24">
            <ul>
              <li :key="item.content" v-for="item in sampleFileList">
                <span class="mouse-pointer after" @click="sendDetail(item,'a')">
                  <div class="mesSpan inline-block">《 {{item.title}} 》</div>
                  <div class="inline-block float-right">{{item.createdDate | filterDate}}</div>
                </span>
              </li>
            </ul>
            <el-button class="more" @click="open(2)">
              MORE
              <i class="ml13 el-icon-arrow-right"></i>
            </el-button>
          </el-col>
        </el-col>
      </el-row>
    </div>
    <!-- 信息公开 -->
    <div class="content" v-if="breviary" style="height:500px">
      <el-row class="text-left mc-title" style="margin-left:23px">
        <div @click="getBack()" class="mouse-pointer">
          <i class="el-icon-arrow-left blue font-bold"></i>
          <span style="font-size: 14.5px;" class="blue font-bold">返回</span>
        </div>
      </el-row>
      <el-tabs v-model="activeName" :tab-position="tabPosition" @tab-click="handleClick">
        <el-tab-pane label="信息公开" name="first">
          <el-row>
            <el-col :span="24" class="divider">
              <div class="dividers"></div>
            </el-col>
            <el-col :span="24">
              <ul>
                <li :key="item.content" v-for="item in disInforLists">
                  <span class="mouse-pointer" @click="sendDetail(item)">
                    <div class="mesSpan inline-block">《 {{item.title}} 》</div>
                    <div class="inline-block float-right">{{item.createdDate | filterDate}}</div>
                  </span>
                </li>
              </ul>
            </el-col>
            <el-col :span="24">
              <el-pagination
                small
                class="page-lucency text-right mt10 control"
                layout="prev, pager, next"
                :total="this.total"
                :current-page="this.offset"
                :page-size="this.limit"
                @current-change="handleCurrentChange"
              ></el-pagination>
            </el-col>
          </el-row>
        </el-tab-pane>
        <el-tab-pane label="样本文件" name="second">
          <el-row>
            <el-col :span="24" class="divider">
              <div class="dividers"></div>
            </el-col>
            <el-col :span="24">
              <ul>
                <li :key="item.content" v-for="item in sampleFileLists">
                  <span class="mouse-pointer" @click="sendDetail(item)">
                    <div class="mesSpan inline-block">《 {{item.title}} 》</div>
                    <div class="inline-block float-right">{{item.createdDate | filterDate}}</div>
                  </span>
                </li>
              </ul>
            </el-col>
            <el-col :span="24">
              <el-pagination
                small
                class="page-lucency text-right mt10 control"
                layout="prev, pager, next"
                :total="this.total"
                :current-page="this.offsets"
                :page-size="this.limit"
                @current-change="handleCurrentChangeSap"
              ></el-pagination>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 信息详情 -->
    <div class="content" v-if="newDetail" style="height:500px">
      <el-row class="text-left mc-title" style="margin-left:23px">
        <!-- 列表跳转的 -->
        <div @click="getBackDetail()" class="mouse-pointer" v-show="this.displays!='a' ">
          <i class="el-icon-arrow-left blue font-bold"></i>
          <span style="font-size: 14.5px;" class="blue font-bold">返回</span>
        </div>
        <!-- 直接跳转的 -->
        <div @click="getBackDetailing()" class="mouse-pointer" v-show="this.displays=='a' ">
          <i class="el-icon-arrow-left blue font-bold"></i>
          <span style="font-size: 14.5px;" class="blue font-bold">返回</span>
        </div>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="font-size:28px;font-weight:600;">{{newsDetails.title}}</span>
          <br />
          <span style="font-size:15px;line-height:48px">{{newsDetails.createdDate | filterDate}}</span>
          <el-divider></el-divider>
          <div class="fileContent word">
            <p style="text-align:left">{{newsDetails.content}}</p>
            <div v-show="newsDetails.fileOriginalName!= null&&newsDetails.fileOriginalName!= ''">
              <span>附件下载：</span>
              <a
                class="mouse-pointer"
                style="color:blue"
                @click="downloadBtn()"
              >{{newsDetails.fileOriginalName}}</a>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <!--  -->
    <div class="foot" :style="backgroundFoot">
      <el-row class="foot-con">
        <el-col :span="19">
          <el-col :span="24">
            <div class="links">友情链接</div>
          </el-col>
          <el-col :span="24">
            <el-col
              class="text-left link"
              :span="12"
              v-for="(item,index ) in $getversionData.orgList"
              :key="index"
            >
              <a :href="item.href" target="_blank">{{item.address}}</a>
            </el-col>
          </el-col>
        </el-col>
        <el-col :span="5">
          <el-col :span="24">
            <!-- <el-col :span="11"> -->
            <!-- <div class="qr-code inline-block"> -->
            <!-- 马鞍山版本 -->
            <!-- <img src="../../assets/imgs/prod-QR.png" /> -->
            <!-- <img src="../../assets/imgs/uat-QR.png" /> -->
            <!-- 阳泉版本 -->
            <!-- <img src="../../assets/imgs/yq-QR-prod.png" /> -->
            <!-- <img src="../../assets/imgs/yq-QR-uat.png" /> -->
            <!-- <div class="explain">应用下载</div> -->
            <!-- </div> -->
            <!-- </el-col> -->
            <el-col :span="2"></el-col>
            <el-col :span="11">
              <div class="qr-code inline-block">
                <img src="../../assets/imgs/wxGzh.jpg" />
                <div class="explain">公众号</div>
              </div>
            </el-col>
          </el-col>
        </el-col>
        <el-col :span="24" class="hotline text-right">
          <!-- <span style="margin-right: 30px">如有疑问，请拨打咨询电话021-68577274</span> -->
          <span style="margin-right: 30px">{{$getversionData.phone}}</span>
        </el-col>
      </el-row>
      <el-row>
        <el-divider></el-divider>
        <el-col :span="24" class="copy-right">版权所有 复制必究 京ICP备09068819号</el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import md5 from "js-md5";
import http from "@/common/request";
import imgLogomas from "@/assets/imgs/logo.png";
import imgLogobj from "@/assets/imgs/logobj.png";
import imgLogosh from "@/assets/imgs/logosh.png";
import MASmessage from "@/assets/imgs/MASmessage.jpg";
import BJmessage from "@/assets/imgs/message.png";
import SHmessage from "@/assets/imgs/SHmessage.png";
import YQmessage from "@/assets/imgs/YQmessage.jpg";
import IDIheaderTitlemas from "@/assets/imgs/headerTitle.png";
import IDIheaderTitleyq from "@/assets/imgs/yqheaderTitle.png";
import IDIheaderTitlebj from "@/assets/imgs/bjheaderTitle.png";
import IDIheaderTitlesh from "@/assets/imgs/shheaderTitle.png";
import BJimg from "@/assets/imgs/headerBg.jpg";
import MASimg from "@/assets/imgs/MASheaderBg.jpg";
import YQimg from "@/assets/imgs/YQheaderBg.jpg";
import SHimg from "@/assets/imgs/SHheaderBg.jpg";
import SHxia from "@/assets/imgs/SHxia.jpg";
import { versionData } from "@/assets/js/versionData.js";
export default {
  name: "login",
  data() {
    return {
      versionData,
      imgLogo: {
        yangquan: imgLogomas,
        beijing: imgLogobj,
        maanshan: imgLogomas,
        shanghai: imgLogosh
      },
      headerTitle: {
        yangquan: IDIheaderTitleyq,
        beijing: IDIheaderTitlebj,
        maanshan: IDIheaderTitlemas,
        shanghai: IDIheaderTitlesh
      },
      message: {
        beijing: BJmessage,
        maanshan: MASmessage,
        shanghai: SHmessage,
        yangquan: YQmessage
      },
      bgimg: {
        beijing: BJimg,
        maanshan: MASimg,
        shanghai: SHimg,
        yangquan: YQimg
      },
      footimg: {
        beijing: BJimg,
        maanshan: MASimg,
        shanghai: SHimg,
        yangquan: YQimg
      },
      fullscreenLoading: false,
      times: "发送验证码",
      interval: "",
      findPassword: false,
      lesseeId: this.$getversionData.lesseeId,
      loginDialog: false,
      input: "",
      disInforList: [], //信息公开
      sampleFileList: [], //样例文件
      disInforLists: [], //全部信息公开
      sampleFileLists: [], //全部样例文件
      loginForm: {
        userId: "", //账号
        password: "", //密码
        loginCode: "" //验证码
      }, //登录输入框
      rulesLoginForm: {
        userId: [
          {
            required: true,
            message: "请填写手机号",
            trigger: "blur"
          }
        ],
        password: [
          {
            required: true,
            message: "请输入密码",
            trigger: "blur"
          }
        ],
        loginCode: [
          {
            required: true,
            message: "请输入验证码",
            trigger: "blur"
          }
        ],
        newPassword: [
          {
            required: true,
            message: "请输入新密码",
            trigger: "blur"
          }
        ],
        againPassword: [
          {
            required: true,
            message: "请输入新密码",
            trigger: "blur"
          }
        ]
      }, //表单验证
      activeName: "first",
      home: true,
      breviary: false,
      newDetail: false,
      tabPosition: "left",
      // 分页
      total: 0,
      limit: 12, //每页几条数据
      offset: 1, //第几页
      offsets: 1, //第几页
      newsDetails: {},
      displays: ""
    };
  },
  created() {
    this.messageList();
    if (sessionStorage[this.versionData[process.env.VUE_APP_CITY].token]) {
      http
        .get("/login", { tenantId: this.$getversionData.lesseeId })
        .then(res => {
          if (res.code == 0)
            if (
              res.data.roleType == "INS" ||
              res.data.roleType == "TIS" ||
              res.data.roleType == "OP" ||
              res.data.roleType == "GOV" ||
              res.data.roleType == "SINS" ||
              res.data.roleType == "RINS" ||
              res.data.roleType == "SGF"
            )
              this.$router.push(res.data.rolePath);
        });
    }
  },
  computed: {
    background() {
      return {
        background:
          "url(" + this.bgimg[this.$getversionData.control] + ")" + "no-repeat",
        "background-size": "cover"
      };
    },
    backgroundFoot() {
      return {
        background:
          "url(" +
          this.footimg[this.$getversionData.control] +
          ")" +
          "no-repeat",
        "background-position": " 0 bottom",
        "background-size": "cover"
      };
    },
    height() {
      return {
        height: this.$getversionData.bgheight + "px",
        "line-height": this.$getversionData.bgheight + "px"
      };
    }
  },
  methods: {
    ...mapActions(["login", "getInsOrg"]),
    //校验密码
    validPwd() {
      var regex = new RegExp("(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}");
      if (!regex.test(this.loginForm.password)) {
        this.$messageError({
          message: "密码长度为8~30位且必须包含字母、数字，请及时修改!"
        });
        return false;
      }
      if (
        this.loginForm.password != this.loginForm.againPassword &&
        this.loginForm.againPassword &&
        this.loginForm.password
      ) {
        this.$messageError({ message: "两次密码输入不一致！" });
        return false;
      } else {
        return true;
      }
    },
    //登录弹框关闭
    handleClose() {
      (this.fullscreenLoading = false), (this.loginDialog = false);
    },
    // 获取验证码
    async getLoginCode(userId) {
      if (!userId) {
        return false;
      }
      let time = 59;
      this.times = "59s";
      this.interval = setInterval(() => {
        if (time) {
          time--;
          this.times = `${time}s`;
        } else {
          this.times = "发送验证码";
          clearInterval(this.interval);
        }
      }, 1000);
      let data = !this.findPassword ? { userId: userId } : { mobile: userId };
      data.tenantId = this.$getversionData.lesseeId;
      const res = await this.$api.getLoginCode(data);
      if (res && res.code == 1) {
        this.$messageError({
          message: res.msg
        });
        clearInterval(this.interval);
        this.times = "发送验证码";
      }
    },
    //登录 忘记密码
    changeType(flag) {
      if (this.$refs["loginForm"]) {
        this.$refs["loginForm"].resetFields();
      }
      this.loginForm = {};
      clearInterval(this.interval);
      this.times = "发送验证码";
      if (flag == "loginImmediately") {
        this.findPassword = false;
        this.loginDialog = true;
        this.rulesLoginForm.userId[0].message = "请输入账号";
      } else {
        this.fullscreenLoading = false;
        this.findPassword = true;
        this.rulesLoginForm.userId[0].message = "请输入手机号";
      }
    },
    //登录 修改密码
    loginOn(loginForm) {
      // sessionStorage.clear();//清理地图缓存
      this.$refs[loginForm].validate(valid => {
        if (valid) {
          if (!this.findPassword) {
            const { password } = this.loginForm;
            const loginForm = {
              ...this.loginForm,
              password: md5(password),
              tenantId: this.$getversionData.lesseeId,
              loginType: "password",
              loginBase: "PC"
            };
            this.fullscreenLoading = true;
            this.login(loginForm)
              .then(res => {
                this.fullscreenLoading = false;
                if (res && res.code == 0) {
                  this.getInsOrg(res.data.insOrgId);
                  if (
                    res.data.roleType == "INS" ||
                    res.data.roleType == "TIS" ||
                    res.data.roleType == "OP" ||
                    res.data.roleType == "GOV" ||
                    res.data.roleType == "SINS" ||
                    res.data.roleType == "RINS" ||
                    res.data.roleType == "SGF"
                  )
                    this.$router.push(res.data.rolePath);
                  // this.loginDialog = false;
                } else {
                  this.$messageError({
                    message: res.msg
                  });
                }
              })
              .catch(err => {
                this.fullscreenLoading = false;
                console.log("999999999999999999999999999");
              });
          } else {
            if (!this.validPwd()) {
              return;
            }
            const { password, userId, loginCode } = this.loginForm;

            const data = {
              password: md5(password),
              mobile: userId,
              loginCode
            };
            this.$api.findPwd(data).then(res => {
              if (res && res.code == 0) {
                this.loginDialog = false;
                this.$messageSuccess({
                  message: res.msg
                });
              } else {
                this.$messageError({
                  message: res.msg
                });
              }
            });
          }
        }
      });
    },
    //跳转到信息公开、跳转到样本文件
    scrollInteView(flag) {
      if (this.home) {
        document.getElementById(flag).scrollIntoView();
      } else {
        this.home = true;
        this.breviary = false;
        this.newDetail = false;
      }
    },
    // 首页信息
    async messageList() {
      //type InformationDisclosure：信息公开   SampleFile：样例文件
      //信息公开
      let data = {
        type: "InformationDisclosure",
        limit: 4,
        offset: 1,
        lesseeId: this.lesseeId
      };
      const resDis = await this.$api.messageList(data);
      this.disInforList = resDis.data.rows;
      //样例文件
      const resSap = await this.$api.messageList({
        ...data,
        type: "SampleFile"
      });
      this.sampleFileList = resSap.data.rows;
    },
    // 全部信息
    async messageLists() {
      //信息公开
      let data = {
        type: "InformationDisclosure",
        limit: this.limit,
        offset: this.offset,
        lesseeId: this.lesseeId
      };
      const resDis = await this.$api.messageList(data);
      this.disInforLists = resDis.data.rows;
      this.total = resDis.data.total;
    },
    // 样本信息
    async sapmessageLists() {
      let data = {
        type: "SampleFile",
        limit: this.limit,
        offset: this.offsets,
        lesseeId: this.lesseeId
      };
      const resSap = await this.$api.messageList(data);
      this.sampleFileLists = resSap.data.rows;
      this.total = resSap.data.total;
    },
    // 详情(信息/样本)
    async messageListDetail(item) {
      const keywords = {
        id: item.id,
        lesseeId: this.lesseeId
      };
      const data = await this.$api.messageListDetail(keywords);
      this.newsDetails = data.data;
    },
    // 全部列表more
    open(flag) {
      if (flag == "1") {
        this.activeName = "first";
        this.messageLists();
        (this.home = false), (this.breviary = true);
      } else if (flag == "2") {
        this.activeName = "second";
        this.sapmessageLists();
        (this.home = false), (this.breviary = true);
      }
    },
    // tab切换
    handleClick(tab) {
      if (tab.name === "first") {
        this.messageLists();
      } else if (tab.name === "second") {
        this.sapmessageLists();
      }
    },
    // 返回
    getBack() {
      (this.home = true), (this.breviary = false);
    },
    getBackDetail() {
      this.home = false;
      this.breviary = true;
      this.newDetail = false;
    },
    getBackDetailing() {
      this.home = true;
      this.breviary = false;
      this.newDetail = false;
    },
    // 新闻详情(信息)
    sendDetail(item, flag) {
      this.displays = flag;
      this.messageListDetail(item);
      this.home = false;
      this.breviary = false;
      this.newDetail = true;
    },
    // 分页
    handleCurrentChange(val) {
      this.offset = val;
      this.messageLists();
    },
    handleCurrentChangeSap(val) {
      this.offsets = val;
      this.sapmessageLists();
    },
    // 文件下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.newsDetails.fileOriginalName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessFileNotLogging?cloudDocId=" +
        this.newsDetails.fileLocation +
        "&view=2&lesseeId=" +
        this.lesseeId;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    getMb() {
      let clientHeight =
        document.documentElement.clientHeight || document.body.clientHeight;
      let marginBottom = clientHeight - 592;
      if (marginBottom <= 0) {
        marginBottom = 126;
      }
      this.$refs.getMb.style.marginBottom = `${marginBottom}px`;
    }
  },
  mounted() {
    window.addEventListener("resize", this.getMb);
    this.getMb();
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.getMb);
  }
};
</script>
<style lang="scss" scoped>
.verification-code {
  color: #108feb;
  margin-left: 4.5px;
  width: 131px;
  height: 49px;
  font-size: 15px;
  font-weight: 500;
  border-radius: 0px;
}
.is-disabled {
  color: #c8cbd2;
}
.tall {
  padding: 0 12px 51px 12px;
}
.low {
  padding: 0 12px 28px 12px;
}
.mb42 {
  margin-bottom: 42px;
}
.mb27 {
  margin-bottom: 27px;
}
.mt24 {
  margin-top: 24px;
}
.mt73 {
  margin-top: 73px;
}
.ml13 {
  margin-left: 13px;
}
.pl14 {
  padding-left: 14px;
}
.pr14 {
  padding-right: 14px;
}
.login-dialog {
  /deep/ {
    .el-dialog__body {
      padding-top: 8px;
      padding-bottom: 0;
    }
    .el-dialog__header {
      i {
        font-size: 21px;
      }
    }
    .el-form-item {
      margin-bottom: 19px;
      .el-input__inner {
        height: 50px;
        line-height: 50px;
      }
    }
  }
}
/deep/.el-input__inner {
  border-radius: 0px;
}
/deep/.el-input--prefix input {
  padding-left: 60px;
  border-color: #666666;
  border-radius: 0px;
  border: 1px solid;
}
.foot {
  width: 100%;
  height: 294px;
  .foot-con {
    padding: 55px 76px 0 96px;
    .links {
      width: 94px;
      height: 33px;
      background-color: #1271ce;
      font-size: 19px;
      font-family: Source Han Sans CN;
      font-weight: bold;
      color: rgba(255, 255, 255, 1);
      line-height: 33px;
      margin-bottom: 15px;
    }
    .link {
      color: rgba($color: #fff, $alpha: 0.9);
      font-size: 18px;
      height: 30px;
    }
    .link /deep/ a {
      color: rgba($color: #fff, $alpha: 0.9);
      font-size: 18px;
      height: 30px;
      text-decoration: none;
    }
    .qr-code {
      height: 98px;
      width: 97px;
      background: rgba(255, 255, 255, 0.45);
      border-radius: 6px;
      img {
        width: 83px;
        height: 83px;
        margin-top: 8px;
      }
    }
    .explain {
      font-size: 14px;
      margin-top: 11px;
      font-family: Microsoft YaHei;
      color: rgba(255, 255, 255, 1);
    }
    .hotline {
      font-size: 16px;
      font-family: Source Han Sans CN;
      color: rgba(255, 255, 255, 1);
      line-height: 48px;
    }
  }
  .el-divider--horizontal {
    margin-top: 0;
    height: 3px;
  }
  .el-divider {
    background-color: #1271ce;
  }
  .copy-right {
    font-size: 16px;
    font-family: Microsoft YaHei;
    color: rgba(255, 255, 255, 1);
  }
}
.bg {
  .corner-btn {
    padding-top: 28px;
    button {
      background: rgba(255, 255, 255, 0.6);
      border: 0px;
      font-size: 18px;
      color: rgba(119, 117, 117, 0.6);
      width: 107px;
      height: 30px;
    }
    .btn-sample {
      margin: 0 76px 0 35px;
    }
    button:hover {
      color: #1271ce;
    }
  }
  .title {
    margin-top: 134px;
    text-align: center;
    div {
      position: relative;
      img:first-child {
        height: 100px;
        width: 110px;
        margin-right: 11px;
      }
      img:nth-last-child(1) {
        width: 1072px;
        height: 82px;
        position: relative;
        top: 7px;
      }
    }
  }
  .units {
    text-align: center;
    color: rgba(255, 255, 255, 0.9);
    font-size: 24px;
  }
  .loginBtn {
    margin-top: 40px;
    width: 175px;
    height: 56px;
    background: rgb(18, 113, 206);
    opacity: 0.8;
    border: 0px;
    color: #ffffff;
    font-size: 26px;
  }
}
.content {
  width: 1024px;
  height: 562px;
  padding: 54px 0;
  margin: 0 auto;
  .bor-bottom {
    border-bottom: 2px solid #0e050b;
    padding: 0 0 13px 0 !important;
  }
  .msg-title {
    font-weight: bold;
    color: #222;
    font-size: 21px;
    padding-bottom: 12px;
    border-bottom: 3px solid #1271ce;
  }
  ul {
    margin: 11px 0 0 0;
    padding: 0;
    color: #000000;
    li {
      height: 16px;
      line-height: 16px;
      margin-bottom: 24px;
      margin-left: -6px;
      list-style-position: inside;
      .mesSpan {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        width: 345px;
      }
    }
  }
  .more {
    padding: 0;
    border-color: #1271ce;
    border-radius: 0;
    color: #1271ce;
    width: 92px;
    height: 29px;
    font-size: 10px;
    margin-left: -5px;
    margin-top: 0px;
  }
}
.el-tab-pane {
  text-align: left;
  .divider {
    border: 1px #000 solid;
    margin: 5px 0;
  }
  .dividers {
    width: 84px;
    position: absolute;
    top: 4px;
    left: 0px;
    border-top: 4px #1271ce solid;
  }
  .mouse-pointer:hover {
    color: #1271ce;
  }
  li {
    padding-left: 15px;
  }
}
.after:hover {
  color: #1271ce;
}
.el-tabs--left /deep/ .is-left {
  text-align: right;
  font-weight: 600;
}
.el-divider--horizontal {
  margin-top: 0;
  height: 3px;
}
.el-divider {
  background-color: #1271ce;
}
.page-lucency {
  /deep/ button {
    color: #000 !important;
  }
  /deep/ .el-pager li {
    color: #000 !important;
  }
  /deep/ .el-pager .active {
    background-color: rgba(41, 122, 227, 1) !important;
    color: #fff !important;
    border-radius: 50%;
  }
}
// 自动换行
.word {
  text-align: left;
  height: 380px;
  word-wrap: break-word; //自动换行
  overflow: overlay;
}

// 滚动条样式
.fileContent {
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 5px;
    box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    -webkit-box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    background-color: rgb(199, 197, 197);
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    background-color: rgba(158, 159, 160, 0.8);
  }
}
</style>

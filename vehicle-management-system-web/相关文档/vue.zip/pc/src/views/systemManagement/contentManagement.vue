<template>
  <div style=" position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>内容管理</span>
        </div>
      </el-row>
      <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
        <el-row>
          <el-col :span="7" style="height:100%">
            <div
              class="content-left"
              style="border-radius: 0px 0px 6px 6px;min-height: 495px;background-color: rgba(255, 255, 255, 0.9);"
            >
              <el-table
                ref="singleTable"
                :data="orgList"
                row-key="orgId"
                class="mc-table"
                height="495px"
                highlight-current-row
                @cell-click="cellClick"
              >
                <el-table-column prop="orgName" label="类别"></el-table-column>
              </el-table>
            </div>
          </el-col>
          <el-col :span="17">
            <el-table
              class="mc-table"
              tooltip-effect="light"
              :data="userList"
              style="width: 100%;border-radius: 0 0 5px 0;font-size: 12px;"
              @row-dblclick="dbGoVisitDetails"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="80"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="80" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="title" align="center" label="标题" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column
                prop="createdBy"
                align="center"
                label="创建人"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column
                prop="createdDate"
                align="center"
                label="创建日期"
                :show-overflow-tooltip="true"
              >
                <template slot-scope="scope">{{ scope.row.createdDate| filterDate}}</template>
              </el-table-column>
              <el-table-column
                prop="status"
                align="center"
                label="状态"
                width="100"
                :show-overflow-tooltip="true"
              >
                <template slot-scope="scope">
                  <div v-if="scope.row.status==0">草稿</div>
                  <div v-if="scope.row.status==1">正文</div>
                </template>
              </el-table-column>
              <el-table-column align="center" width="100">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommand(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item icon="el-icon-remove-outline" command="1">删除</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-edit-outline" command="2">修改</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-pagination
          small
          class="text-center mt10 control block page-lucency"
          @current-change="handleCurrentChangePaging"
          :current-page.sync="offset"
          :page-size="this.limit"
          layout="prev, pager, next"
          :total="this.total"
        ></el-pagination>
        <img
          class="project-collection mouse-pointer"
          id="addAccount"
          draggable="true"
          src="@/assets/imgs/addForm.png"
          width="64"
          height="64"
          @click="goRiskReportDetails('','new')"
        />
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  name: "NewAccount",
  data() {
    return {
      rules: {
        title: [{ required: true, message: "请输入项目名称", trigger: "blur" }],
        status: [
          { required: true, message: "请选择活动资源", trigger: "change" }
        ],
        fileOriginalName: [
          { required: true, message: "请上传报告", trigger: "change" }
        ]
      },
      upload: false,
      addedBuildingWindows: false,
      limit: 10, //每页几条数据
      offset: 1, //第几页
      total: undefined,
      orgList: [{ orgName: "样本文件" }, { orgName: "信息公开" }],
      userList: [{}],
      currentRow: "",
      currentTime: undefined, //当前时间
      total: undefined,
      type: "SampleFile",
      flag: false,
      verificationPass: false,
      dialogUserList: {
        fileOriginalName: ""
      },
      title: "样本文件"
    };
  },
  created() {
    this.flag = true;
    this.type = "SampleFile";
    this.messageLists();
  },
  mounted() {
    //判断点击table的颜色
    this.$refs.singleTable.setCurrentRow(this.orgList[0]);
  },
  methods: {
    // //判断显示table
    cellClick(row) {
      this.offset = undefined;
      this.orgName = row.orgName;
      if (this.orgName == "样本文件") {
        this.title = this.orgName;
        this.flag = true;
        this.offset = 1;
        this.type = "SampleFile";
        this.messageLists();
      } else {
        this.title = this.orgName;
        this.flag = false;
        this.offset = 1;
        this.type = "InformationDisclosure";
        this.messageLists();
      }
    },
    //弹窗关闭
    residentialClosingButton() {
      this.addedBuildingWindows = false;
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      this.messageLists();
    },
    //list
    async messageLists() {
      const rpid = {
        limit: this.limit,
        offset: this.offset,
        type: this.type
      };
      const res = await this.$api.messageLists(rpid);
      this.userList = res.data.rows;
      this.total = res.data.total;
    },
    //删除
    async messageDelete(num) {
      this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          const res = await this.$api.messageDelete(num);
          if (res.code == 0) {
            this.$messageSuccess({
              message: res.msg
            });
            this.messageLists();
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    handleCommand(item, command) {
      if (command === "0") {
        //查看
        this.goRiskReportDetails(item.id, "view");
      } else if (command === "1") {
        //删除数据
        this.messageDelete(item.id);
      } else if (command === "2") {
        //修改
        this.goRiskReportDetails(item.id, "edit");
      }
    },
    //查看view、修改edit
    goRiskReportDetails(id, types) {
      this.$router.push({
        path: "/contentManagementRevision",
        query: {
          id: id,
          types: types,
          type: this.type
        }
      });
    },
    //上传
    async uploadFile(param) {
      //上传
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      let data = {
        projectId: this.projectId
      };
      file.append("projectId", "IDIHomePage");
      file.append("fileIcon", this.type);
      this.$api.processDoc(file).then(res => {
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.dialogUserList.fileLocation = res.data.cloudDocId;
          this.dialogUserList.fileOriginalName = res.data.fileName;
          this.url = res.data.cloudDocId;
        } else {
          this.$messageError({
            message: res.msg
          });
        }
        this.upload = false;
      });
    },
    //下载
    downloadBtn() {
      var a = document.createElement("a");
      var fileOriginalName = this.dialogUserList.fileOriginalName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = fileOriginalName;
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn() {
      this.dialogUserList.fileOriginalName = "";
      this.url = "";
    },
    handleChange(file) {},
    //双击进入详情
    dbGoVisitDetails(row) {
      this.goRiskReportDetails(row.id, "view");
    },
    backMytodo() {
      this.$router.push("/systemManagement");
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 10px;
  bottom: 15px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.iconBlue {
  color: #2a7be3;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.content-left {
  border-radius: 0px 0px 0px 6px;
  //margin-right: 35px;
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 300px;
}
.el-dropdown-menu--small .el-dropdown-menu__item {
  font-size: 13.5px;
}
.dialog {
  min-height: 495px;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.mc-table/deep/.current-row > td {
  background: #9fb6cd !important;
}
</style>
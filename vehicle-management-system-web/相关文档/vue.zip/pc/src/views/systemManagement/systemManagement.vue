<template>
  <div class="systemManagement">
    <el-row>
      <el-col v-if="control.includes('systemManagementAccount')" :span="4">
        <router-link :to="{path: '/accountManagement'}">
          <div class="mouse-pointer">
            <img src="../../assets/imgs/zhanghu.png"/>
            <div class="size">账户管理</div>
          </div>
        </router-link>
      </el-col>
      <el-col v-if="control.includes('systemManagementJianShe')" :span="4">
        <router-link :to="{path:'/accountManagement',query:{isConstructingUnit:true}}">
          <div>
            <img src="../../assets/imgs/constructingUnit.png"/>
            <div class="size">建设单位</div>           
          </div>
        </router-link>
      </el-col>
      <el-col v-if="control.includes('systemManagementInsurance')" :span="4">
        <router-link :to="{path: '/InsuranceTreaty'}">
          <div class="mouse-pointer">
            <img src="../../assets/imgs/baoxian.png"/>
            <div class="size">保险条款</div>
          </div>
        </router-link>
      </el-col>
      <!-- <el-col v-if="control.includes('systemManagementData')" :span="4">
        <router-link :to="{path:'/dataUnlock'}">
        <div class="mouse-pointer">
          <img src="../../assets/imgs/shuju.png"/>
          <div class="size">数据解锁</div>
        </div>
        </router-link>
      </el-col> -->
      <el-col v-if="control.includes('systemManagementODS')" :span="4">
         <router-link :to="{path: '/odsWarranty'}">
        <div class="mouse-pointer">
          <img src="../../assets/imgs/ods.png"/>
          <div class="size">ODS保单</div>
        </div>
         </router-link>
      </el-col>
        <el-col v-if="control.includes('systemManagementRisk')" :span="4">
          <router-link :to="{path: '/odsRiskEvent'}">
        <div  class="mouse-pointer">
            <img src="../../assets/imgs/ods.png">
            <div class="size">ODS风险事件 </div>
        </div>
          </router-link>
      </el-col>
      <el-col v-if="control.includes('systemManagementGZ')" :span="4">
        <router-link :to="{path:'/odsSettlement'}">
        <div class="mouse-pointer" >
          <img src="../../assets/imgs/ods.png"/>
          <div class="size">ODS理赔</div>
        </div>
        </router-link>
      </el-col>
      <el-col v-if="control.includes('systemManagementContent')" :span="4">
        <router-link :to="{path: '/contentManagement'}">
          <div class="mouse-pointer">
            <img src="../../assets/imgs/neirong.png">
            <div class="size">内容管理 </div>
          </div>
        </router-link>
      </el-col>
      
      <el-col v-if="control.includes('systemManagementCost')" :span="4">
        <router-link :to="{path: '/costThreshold'}">
          <div class="mouse-pointer">
            <img src="../../assets/imgs/zaojia.png"/>
            <div class="size">阈值管理</div>
          </div>
        </router-link>
        </el-col>
      <el-col v-if="control.includes('systemManagementValidateRules')" :span="4" >
        <router-link :to="{path: '/messageManagement'}">
        <div class="mouse-pointer">
          <img src="../../assets/imgs/youjian.png"/>
          <div class="size">消息管理</div>
        </div>
        </router-link>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "SystemManagement",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["app", "control"])
  },
  data() {
    return {
      index: "1"
    };
  },
  methods: {
    guarantee() {
      //ods保单
      this.$router.push("/odsWarranty");
    },
    handleRisk() {
      //风险事件
      this.$router.push("/riskEvent");
    },
    handleReinsurance() {
      //共再保体
      this.$router.push("/reinsurance");
    },
    handleCheckout() {
      //检验规则
      this.$router.push("/reinsurance");
    }
  },
  created(){
  }
};
</script>
<style lang="scss" scoped>
.systemManagement {
  padding: 0 50px;
  min-height: 493px;
  border-radius: 6px;
  background-color: rgba(255, 255, 255, 0.9);
  .el-col {
    margin-top: 54.5px;
    $height: 74px;
    a {
      text-decoration: none;
    }
    img {
      width: $height;
      height: $height;
    }
  }
}
.size {
  font-size: 14.5px;
  font-family: Source Han Sans CN;
  font-weight: bold;
  color: rgba(62, 58, 57, 1);
  padding-top: 11.5px;
}
</style>
<template>
  <div style=" position: relative">
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          ref="ruleForm"
          :rules="rules"
          :disabled="$route.query.type=='view'"
          :model="getUnderwritingInformation.insBasicInfoDO"
        >
          <el-row>
            <el-col :span="23">
              <el-form-item label="项目名称：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.projectName"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="保单号：" prop="insContractNo">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.insContractNo"
                  class="login-form-input"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="牵头保险公司：" required>
                <el-select
                  v-model="getUnderwritingInformation.insBasicInfoDO.insOrgId"
                  @change="getCode(getOrgId.insOrgList, getUnderwritingInformation.insBasicInfoDO.insOrgId, 'insOrgList')"
                  placeholder="请选择"
                  disabled
                >
                  <el-option
                    v-for="item in getOrgId.insOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item required class="mc-multi-row" label="牵头保险公司社会统一信用编码：">
                <el-input disabled v-model="getUnderwritingInformation.insBasicInfoDO.insOrgCode"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="保险单号：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.insContractNo"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目报建号：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.buildPermitNo"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保险分类：" prop="insCategory">
                <el-select
                  clearable
                  v-model="getUnderwritingInformation.insBasicInfoDO.insCategory"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_CATEGORIES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                    :disabled="$route.query.type=='view'"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="保险种类：" prop="insType">
                <el-select
                  v-model="getUnderwritingInformation.insBasicInfoDO.insType"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_TYPES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                    :disabled="$route.query.type=='view'"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="风险管理机构：" prop="tisOrgId">
                <el-select
                  clearable
                  v-model="getUnderwritingInformation.insBasicInfoDO.tisOrgId"
                  @change="getCode(getOrgId.tisOrgList, getUnderwritingInformation.insBasicInfoDO.tisOrgId, 'tisOrgList')"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.tisOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item required class="mc-multi-row" label="风险管理机构社会统一信用编码：">
                <el-input disabled v-model="getUnderwritingInformation.insBasicInfoDO.tisOrgCode"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保险费率(%)：">
                <el-input disabled v-model="premiumRateShow"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-form-item class="area" label="被保人名称：" prop="insuredOrgName">
                <el-select
                  clearable
                  v-model="getUnderwritingInformation.insBasicInfoDO.insuredOrgName"
                  @change="getCode(getOrgId.bldOrgList, getUnderwritingInformation.insBasicInfoDO.insuredOrgName, 'bldOrgList')"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.bldOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8" style="margin-left: 20px">
              <el-form-item label-width="162px" class="mc-multi-row" label="被保人社会统一信用编码">
                <el-input
                  disabled
                  style="width: 183.5px"
                  v-model="getUnderwritingInformation.insBasicInfoDO.insuredOrgCode"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="国家：">
                <el-input disabled v-model="getUnderwritingInformation.insBasicInfoDO.nation"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="省：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.province"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="城市：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.city"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="所在区域：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.district"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="总建筑面积(㎡)：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.totalFloorage"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="地下室面积(㎡)：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.basementFloorage"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row>
            <!-- 共保信息开始 -->
            <el-col :span="23">
              <el-form-item label="共保信息：" prop="list">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.list"
                  style="display: none"
                ></el-input>
                <el-table
                  :data="getUnderwritingInformation.insBasicInfoDO.coshares"
                  class="mc-table table_list"
                  style="width: 100%"
                >
                  <el-table-column prop="ins_org_id" align="center" label="共保公司">
                    <template slot-scope="scope">
                      <el-select
                      filterable
                        v-model="scope.row.insOrgId"
                        placeholder="请选择"
                        @change="insOrgIdChange(scope.row,scope.$index)"
                      >
                        <el-option
                          v-for="item in [...getOrgId.sinsOrgList, ...getOrgId.insOrgList]"
                          :key="item.orgId"
                          :label="item.orgName"
                          :value="item.orgId"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="承保比例(%)">
                    <template slot-scope="scope">
                      <format-input
                        text-align="left"
                        empty-value="0"
                        :max="100"
                        :min="0"
                        :precision="2"
                        v-model="scope.row.sharePercent"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="个人绩效(%)">
                    <template slot-scope="scope">
                      <format-input
                        text-align="left"
                        empty-value="0"
                        :max="100"
                        :precision="2"
                        :min="0"
                        v-model="scope.row.personalPerformance"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column v-if="$route.query.type!=='view'" width="80px" align="left">
                    <template slot-scope="solt" slot="header">
                      <i
                        @click="add('coinsurance')"
                        class="el-icon-circle-plus-outline mouse-pointer"
                        style="font-size:20px;line-height:40px"
                      ></i>
                    </template>
                    <template slot-scope="scope">
                      <i
                        @click="del(scope.$index, getUnderwritingInformation.insBasicInfoDO.coshares)"
                        class="el-icon-remove-outline font-size20 mouse-pointer"
                        style="font-size:20px;line-height:40px"
                      ></i>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
            <!-- 再保信息 -->
            <el-col :span="23">
              <el-form-item label="再保信息：">
                <el-table
                  :data="getUnderwritingInformation.insBasicInfoDO.reshares"
                  class="mc-table table_list"
                  style="width: 100%;"
                >
                  <el-table-column align="center" label="再保险公司">
                    <template slot-scope="scope">
                      <el-select
                      filterable
                        v-model="scope.row.reinsOrgId"
                        placeholder="请选择"
                        @change="handleItemChange(scope.row,scope.$index)"
                      >
                        <el-option
                          v-for="item in getOrgId.rinsOrgList"
                          :key="item.orgId"
                          :label="item.orgName"
                          :value="item.orgId"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="承保比例(%)">
                    <template slot-scope="scope">
                      <format-input
                        text-align="left"
                        empty-value="0"
                        :max="100"
                        :min="0"
                        :precision="2"
                        v-model="scope.row.reinsPercent"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column v-if="$route.query.type!=='view'" width="80px" align="left">
                    <template slot-scope="solt" slot="header">
                      <i
                        @click="add('reinsurance')"
                        class="el-icon-circle-plus-outline mouse-pointer"
                        style="font-size:20px;line-height:40px"
                      ></i>
                    </template>
                    <template slot-scope="scope">
                      <i
                        @click="del(scope.$index, getUnderwritingInformation.insBasicInfoDO.reshares)"
                        class="el-icon-remove-outline font-size20 mouse-pointer"
                        style="font-size:20px;line-height:40px"
                      ></i>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="总保险费(元)：" required>
                <format-input
                  text-align="left"
                  empty-value="0"
                  :precision="2"
                  required
                  v-model="getUnderwritingInformation.insBasicInfoDO.totalPremium"
                  :disabled="$route.query.type=='view'"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保险金额(元)：" required>
                <format-input
                  text-align="left"
                  empty-value="0"
                  :precision="2"
                  v-model="getUnderwritingInformation.insBasicInfoDO.totalCoverage"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="免赔额(元)：" required>
                <format-input
                  text-align="left"
                  empty-value="0"
                  :precision="2"
                  v-model="getUnderwritingInformation.insBasicInfoDO.deductibleAmount"
                />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row>
            <el-col :span="8">
              <el-form-item label="接单保险公司：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.applicant"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="地址：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.landAddr"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class="mc-multi-row" label="造价均值(元/平米)：">
                <!-- <el-input disabled v-model="averageCostShow"></el-input> -->
                <format-input
                 :disabled="$route.query.type=='view'"
                  :readOnly="readOnlyFlag"
                  empty-value="0"
                  text-align="left"
                  :precision="2"
                  v-model="averageCostShow"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="保险起期：" prop="policyStartDate">
                <el-date-picker
                  :clearable="false"
                  :picker-options="startDateValid"
                  @change="validData(getUnderwritingInformation.insBasicInfoDO.policyStartDate, getUnderwritingInformation.insBasicInfoDO.policyEndDate)"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  v-model="getUnderwritingInformation.insBasicInfoDO.policyStartDate"
                  type="date"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保险止期：" prop="policyEndDate">
                <el-date-picker
                  :picker-options="endDateValid"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  @change="validData(getUnderwritingInformation.insBasicInfoDO.policyStartDate, getUnderwritingInformation.insBasicInfoDO.policyEndDate)"
                  :clearable="false"
                  v-model="getUnderwritingInformation.insBasicInfoDO.policyEndDate"
                  type="date"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保单签发日期：" prop="signDate">
                <el-date-picker
                  :clearable="false"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :picker-options="dateValid"
                  v-model="getUnderwritingInformation.insBasicInfoDO.signDate"
                  type="date"
                  placeholder="选择日期"
                  :disabled="$route.query.type=='view'"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
            <el-form-item label="是否主承：" prop="isMainIns">
              <el-radio-group v-model="getUnderwritingInformation.insBasicInfoDO.isMainIns">
                <el-radio label="Y">是</el-radio>
                <el-radio label="N">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
            <el-col :span="8">
              <el-form-item label="保单版本：">
                <el-radio-group v-model="getUnderwritingInformation.insBasicInfoDO.contractType">
                  <el-radio label="NEW" disabled>新保单</el-radio>
                  <el-radio label="OLD" disabled>旧保单</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="主险责任范围：">
                <el-table
                  :data="getUnderwritingInformation.insBasicInfoDO.mainAreas"
                  style="width: 100%"
                  class="table_list mc-table"
                  ref="mainTable"
                  tooltip-effect="dark"
                >
                  <!-- <el-table-column type="selection" width="55"></el-table-column> -->
                  <el-table-column prop="clause" label="保险条款"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                  <el-table-column align="center" label="责任起期">
                    <template slot-scope="scope">
                      <!-- <span>{{ scope.row.policyStartDate | filterDate}}</span> -->
                      <el-date-picker
                        disabled
                        :clearable="false"
                        value-format="yyyy-MM-dd HH:mm:ss"
                        v-model="scope.row.mainStartDate"
                        type="date"
                        placeholder="选择日期"
                      ></el-date-picker>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="责任止期">
                    <template slot-scope="scope">
                      <el-date-picker
                        disabled
                        :clearable="false"
                        value-format="yyyy-MM-dd HH:mm:ss"
                        v-model="scope.row.mainEndDate"
                        type="date"
                        placeholder="选择日期"
                      ></el-date-picker>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row>
            <el-col :span="23">
              <el-form-item label="附加险责任范围：">
                <el-table
                  :data="getUnderwritingInformation.insBasicInfoDO.addAreas"
                  style="width: 100%"
                  class="table_list mc-table"
                  ref="otherTable"
                  tooltip-effect="dark"
                  disabled
                >
                  <!-- <el-table-column type="selection" width="55"></el-table-column> -->
                  <el-table-column prop="clause" label="保险条款"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                  <el-table-column align="center" label="责任起期">
                    <template slot-scope="scope">
                      <!-- <span>{{ scope.row.policyStartDate | filterDate}}</span> -->
                      <el-date-picker
                        disabled
                        :clearable="false"
                        value-format="yyyy-MM-dd HH:mm:ss"
                        v-model="scope.row.addStartDate"
                        type="date"
                        placeholder="选择日期"
                      ></el-date-picker>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="责任止期">
                    <template slot-scope="scope">
                      <el-date-picker
                        disabled
                        :clearable="false"
                        value-format="yyyy-MM-dd HH:mm:ss"
                        v-model="scope.row.addEndDate"
                        type="date"
                        placeholder="选择日期"
                      ></el-date-picker>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div style="text-align: right; margin-top: 30px;" class="btns">
          <el-button
            type="primary"
            size="mini"
            @click="initiationProcess()"
            v-if="$route.query.type=='edit'"
          >确定</el-button>
          <el-button size="mini" id="buildingList" @click="mailConfirmationBtn()">关闭</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import formatInput from "@/components/formatInput";
import MessageEdit from "@/components/Message.vue";
import imgUpload from "@/assets/imgs/put.png";
let blurValid = { required: true, message: "请输入", trigger: "blur" };
let changeValid = { required: true, message: "请选择", trigger: "change" };
export default {
  name: "MailBrowsing",
  components: {
    MessageEdit,
    formatInput
  },
  computed: {
    ...mapGetters(["app", "listBaseData", "getOrgId"]),
    averageCostShow() {
      //造价均值
      let averageCost = (
        Math.round(
          (
            this.getUnderwritingInformation.insBasicInfoDO.totalCoverage /
            this.getUnderwritingInformation.insBasicInfoDO.totalFloorage
          ).toFixed(3) * 100
        ) / 100
      ).toFixed(2);
      if (
        averageCost == "NaN" ||
        averageCost == "" ||
        averageCost == "Infinity"
      ) {
        return 0;
      }
      return averageCost;
    },
    premiumRateShow() {
      //保险费率
      let premiumRate = (
        Math.round(
          (
            (this.getUnderwritingInformation.insBasicInfoDO.totalPremium /
              this.getUnderwritingInformation.insBasicInfoDO.totalCoverage) *
            100
          ).toFixed(5) * 10000
        ) / 10000
      ).toFixed(4);
      if (
        premiumRate == "NaN" ||
        premiumRate == "" ||
        premiumRate == "Infinity"
      ) {
        return 0;
      }
      return premiumRate;
    }
  },
  data() {
    return {
      readOnlyFlag: true,
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      endDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      tenantId: undefined,
      rules: {
        insContractNo: [blurValid],
        coinsuranceAgreementName: [changeValid],
        insurancePolicyName: [changeValid],
        riskManageQuotationName: [changeValid],
        insuredOrgName: [changeValid],
        tisOrgId: [changeValid],
        insCategory: [changeValid],
        typeOfIns: [changeValid],
        signDate: [{ required: true, message: "请选择", trigger: "change" }],
        policyEndDate: [changeValid],
        policyStartDate: [changeValid],
        isMainIns: [changeValid],
        list: [changeValid]
      },
      verificationPass: false,
      getUnderwritingInformation: {
        insBasicInfoDO: {
          insuredOrgId: "",
          list: "5555"
        }
      },
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      multipleSelection: []
    };
  },
  created() {
    this.tenantId = JSON.parse(
      sessionStorage.getItem(this.$getversionData.userInfo)
    ).tenantId;
    this.odsInsurancePolicyDetails();
  },
  methods: {
    async odsInsurancePolicyDetails() {
      const rid = {
        id: this.$route.query.id,
        tenantId: this.tenantId
      };
      const res = await this.$api.odsInsurancePolicyDetails(rid);
      this.getUnderwritingInformation.insBasicInfoDO = res.data;
      this.getUnderwritingInformation.insBasicInfoDO.list = "55555";
    },

    getCode(list, id, flag) {
      for (let item of list) {
        if (item.orgId == id) {
          if (flag == "insOrgList") {
            return (this.getUnderwritingInformation.insBasicInfoDO.insOrgCode =
              item.orgCode);
          } else if (flag == "tisOrgList") {
            return (this.getUnderwritingInformation.insBasicInfoDO.tisOrgCode =
              item.orgCode);
          } else if (flag === "bldOrgList") {
            return (this.getUnderwritingInformation.insBasicInfoDO.insuredOrgCode =
              item.orgCode);
          }
        }
      }
    },
    //添加行
    add(flag) {
      if (flag == "coinsurance") {
        if (this.getUnderwritingInformation.insBasicInfoDO.coshares == null) {
          this.getUnderwritingInformation.insBasicInfoDO.coshares = [];
          let dialogNewPic = {};
          this.getUnderwritingInformation.insBasicInfoDO.coshares.push(
            dialogNewPic
          );
        } else {
          let dialogNewPic = {};
          this.getUnderwritingInformation.insBasicInfoDO.coshares.push(
            dialogNewPic
          );
        }
      } else {
        if (this.getUnderwritingInformation.insBasicInfoDO.reshares == null) {
          this.getUnderwritingInformation.insBasicInfoDO.reshares = [];
          let dialogNewPic = {};
          this.getUnderwritingInformation.insBasicInfoDO.reshares.push(
            dialogNewPic
          );
        } else {
          let dialogNewPic = {};
          this.getUnderwritingInformation.insBasicInfoDO.reshares.push(
            dialogNewPic
          );
        }
      }
    },
    insOrgIdChange(row, index) {
      this.getUnderwritingInformation.insBasicInfoDO.coshares.map(
        (item, index1) => {
          if (index != index1) {
            if (row.insOrgId == item.insOrgId) {
              this.$messageError({ message: "机构已选择" });
              row.insOrgId = "";
            }
          }
        }
      );
    },
    handleItemChange(row, index) {
      this.getUnderwritingInformation.insBasicInfoDO.reshares.map(
        (item, index1) => {
          if (index != index1) {
            if (row.reinsOrgId == item.reinsOrgId) {
              this.$messageError({ message: "机构已选择" });
              row.reinsOrgId = "";
            }
          }
        }
      );
    },
    //保存
    async odsInsurancePolicySubmission() {
      this.$refs["ruleForm"].validate(valid => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      // 承保比例之和
      const arry = this.getUnderwritingInformation.insBasicInfoDO.coshares;
      const strarr = [];
      for (let i in arry) {
        strarr.push(arry[i]["sharePercent"]);
        if (!arry[i].insOrgId || !arry[i].sharePercent) {
          this.$messageError({
            message: "请将共保信息补充完整"
          });
          return false;
        }
      }
      const numb = eval(strarr.join("+"));
      if (numb != 100) {
        this.$messageError({
          message: "共保承保比例之和必须为100"
        });
        return false;
      } else if (
        this.getUnderwritingInformation.insBasicInfoDO.totalFloorage <= 0
      ) {
        this.$messageError({
          message: "总建筑面积必须大于0"
        });
        return false;
      } else if (
        this.getUnderwritingInformation.insBasicInfoDO.totalCoverage <= 0
      ) {
        this.$messageError({
          message: "保险金额必须大于0"
        });
        return false;
      } else if (
        this.getUnderwritingInformation.insBasicInfoDO.totalPremium <= 0
      ) {
        this.$messageError({
          message: "总保险费必须大于0"
        });
        return false;
      }
      //  else if (
      //   this.getUnderwritingInformation.mainInsLiabilitiesDOList.length <= 0
      // ) {
      //   // this.$messageError({
      //   //   message: "请选择主险责任范围"
      //   // });
      //   // return false;
      // }
      if (this.verificationPass) {
        const res = await this.$api.odsInsurancePolicySubmission(
          this.getUnderwritingInformation.insBasicInfoDO
        );
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    //删除
    del(index, list) {
      list.splice(index, 1);
    },
    //日期校验
    validData(start, end) {
      if (start) {
        this.endDateValid = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          }
        };
      } else {
        this.endDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
      if (end) {
        this.startDateValid = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          }
        };
      } else {
        this.startDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
    },
    //关闭按钮
    mailConfirmationBtn() {
      this.$router.go(-1);
    },
    //发起流程
    initiationProcess() {
      this.odsInsurancePolicySubmission();
    }
  }
};
</script>
<style lang="scss" scoped>
.odd-table {
  font-size: 13px;
  white-space: nowrap;
}
.el-table_1_column_5 .cell {
  font-size: 12px;
}
.el-table_2_column_1 .cell {
  padding-left: 14px;
  padding-right: 0px;
}
.beijing {
  text-align: right;
  margin-top: 30px;
  margin-right: 17.5px;
  cursor: pointer;
  position: relative;
}
.control {
  text-align: right;
  margin-right: 45px;
}
.shizi {
  text-align: center;
  padding-top: 15px;
  padding-left: 25px;
  font-size: 26px;
  font-weight: bold;
  color: #e2e2e2ff;
}
.typeface {
  padding-top: 10px;
  text-align: center;
  height: 10px;
  font-size: 10.5px;
  font-family: Source Han Sans CN;
  font-weight: bold;
  color: rgba(226, 226, 226, 1);
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 0px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.outline {
  width: 150px;
  text-align: center;
  height: 36.8px;
  line-height: 36.8px;
  cursor: pointer;
  position: absolute;
  left: 370px;
}
.residence-table {
  border-radius: 0px;
}
.liucheng {
  position: absolute;
  bottom: 9px;
  right: 7px;
  font-size: 8.5px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
}
</style>
<template>
  <div class="content">
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-form class="mc-form" label-width="100px" size="mini" label-position="left" align="left">
      <el-row>
        <el-col :span="8">
          <el-form-item label="编号:">
            <el-input v-model="caseDetails.apple"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="类型:">
            <el-select v-model="value" >
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="名称:">
            <el-input v-model="caseDetails.apple"></el-input>
          </el-form-item>
        </el-col>
      </el-row>

      <!-- 提交 -->
      <el-col :span="22" class="text-right" style="padding: 280px 35px 65.5px 0;">
        <el-button size="mini">保存</el-button>
        <el-button type="primary" style="opacity: 0.8;background-color: #108FEB" size="mini">提交</el-button>
        <el-button size="mini" @click="close()">关闭</el-button>
      </el-col>
    </el-form>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "NewReinsurance",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["app"])
  },
  data() {
    return {
      caseDetails: [
        {
          apple: "111"
        }
      ],
      options: [
        {
          value: "选项1",
          label: "黄金糕"
        },
        {
          value: "选项2",
          label: "双皮奶"
        },
        {
          value: "选项3",
          label: "蚵仔煎"
        },
        {
          value: "选项4",
          label: "龙须面"
        },
      ],
      value: ""
    };
  },
  methods: {
    ...mapActions(["hasNews"]),
    initNews() {
      this.hasNews(false);
    },
    close(){
         this.$router.push("/reinsurance")
    }
  },
  created() {}
};
</script>
<style scoped lang="scss" rel="stylesheet/scss">
.content {
    box-sizing: border-box;
  width: 100%;
  height: 456px;
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
}
</style>
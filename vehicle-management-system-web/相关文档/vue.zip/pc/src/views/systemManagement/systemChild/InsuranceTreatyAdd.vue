<template>
  <div class="content">
    <el-row>
      <el-col :span="2" class="goback">
        <div @click="$router.replace({name:'InsuranceTreaty'})">
          <i class="el-icon-arrow-left"></i>
          <span>保险条款</span>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col class="text-left" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
      </el-col>
    </el-row>
    <div
      :class="{'form-content':!params.id}"
      :span="24"
      v-for="(item,index) in formData"
      :key="index"
    >
      <el-form
        class="mc-form"
        :ref="`insuranceForm${index}`"
        :model="item"
        label-width="100px"
        size="mini"
        label-position="left"
        :rules="rules"
        align="left"
      >
        <el-row>
          <el-row>
            <img
              class="remove-img"
              v-show="formData&&formData.length>1"
              @click="handleViewRemove(index)"
              :src="removeImg"
              width="18.5"
              height="18.5"
            />
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="期限：" prop="deadline">
                <el-input :disabled="params.read" v-model="item.deadline" placeholder="单位：年"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="条款名称：" prop="clause">
                <el-input :disabled="params.read" v-model="item.clause"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="保单版本：" prop="version">
                <el-radio-group :disabled="params.read" v-model="item.version">
                  <el-radio label="NEW">新保单</el-radio>
                  <el-radio label="OLD">旧保单</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="类型：" prop="type">
                <el-radio-group :disabled="params.read" v-model="item.type">
                  <el-radio label="M">主险</el-radio>
                  <el-radio label="A">附加险</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="描述：">
              <el-input
                type="textarea"
                :disabled="params.read"
                :autosize=" {minRows: 4}"
                placeholder="请输入内容"
                v-model="item.description"
              ></el-input>
            </el-form-item>
          </el-row>
        </el-row>
      </el-form>
    </div>
    <el-row
      v-if="!params.id"
      class="text-right"
      style="font-size:12.5px;font-weight:400;color:#3E3A39;cursor:pointer;"
    >
      <span @click="handleViewAdd">
        <img
          width="18.5"
          height="18.5"
          :src="require('@/assets/imgs/add.png')"
          style="vertical-align:middle"
        />
        <span>继续添加</span>
      </span>
    </el-row>
    <el-row style="border-top: 1.5px solid #297AE3;padding-top: 19px; margin-top: 21.5px;">
      <el-form>
        <el-form-item label="保险条款：">
          <el-table class="mc-table" :data="insLiabilityList">
            <el-table-column type='index' label="序号" width="100" />
            <el-table-column prop="version" label="保单版本" width="100">
              <template slot-scope="scope">{{$getValueByCode("insuranceVersion",scope.row.version)}}</template>
            </el-table-column>
            <el-table-column prop="type" label="类型" width="100">
              <template slot-scope="scope">{{$getValueByCode("insuranceType",scope.row.type)}}</template>
            </el-table-column>
            <el-table-column prop="deadline" label="期限(年)" width="100" :show-overflow-tooltip="true" />
            <el-table-column prop="clause" label="条款名称" width="200" :show-overflow-tooltip="true" />
            <el-table-column prop="description" label="描述" :show-overflow-tooltip="true" />
          </el-table>
        </el-form-item>
      </el-form>
    </el-row>
    <!-- 提交 -->
    <el-row>
      <el-col :span="22" class="text-right" style="padding: 11px 0 27.5px 0">
        <el-button
          type="primary"
          style="background-color: #108FEB"
          size="mini"
          @click="handleSave"
        >确定</el-button>
        <el-button size="mini" @click="$router.push({ name: 'InsuranceTreaty'});">关闭</el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import removeImg from "@/assets/imgs/remove.png";
export default {
  name: "InsuranceTreatyt",
  components: {
    MessageEdit
  },
  computed: {
    params() {
      const { read, id, insOrgId } = this.$route.query;
      this.formData[0].insOrgId = insOrgId;
      return { read, id, insOrgId };
    }
  },
  data() {
    return {
      removeImg,
      formData: [{}],
      insLiabilityList: [],
      caseDetails: {},
      rules: {
        liabilitiesCode: [
          { required: true, message: "请输入代码", trigger: "change" }
        ],
        deadline: [{ required: true, message: "请输入期限" }],
        clause: [{ required: true, message: "请输入条款名称" }],
        version: [
          { required: true, message: "请选择保单版本", trigger: "change" }
        ],
        type: [{ required: true, message: "请选择类型", trigger: "change" }]
      }
    };
  },
  methods: {
    ...mapActions(["hasNews"]),
    initNews() {
      this.hasNews(false);
    },
    handleViewAdd() {
      this.formData.push({
        insOrgId: this.params.insOrgId,
        liabilitiesCode: "",
        deadline: "",
        clause: "",
        version: "",
        type: "",
        description: ""
      });
    },
    handleViewRemove(index) {
      this.formData.length > 1 && this.formData.splice(index, 1);
    },
    async handleQuery() {
      const { id } = this.params;
      if (id) {
        const { code, data, msg } = await this.$api.showInsLiability(id);
        if (code === 0) {
          const {
            liabilitiesCode,
            deadline,
            clause,
            version,
            type,
            description
          } = data;
          this.caseDetails = {
            liabilitiesCode0: liabilitiesCode,
            deadline0: deadline,
            clause0: clause,
            version0: version,
            type0: type,
            description0: description
          };
          this.formData = [data];
        } else {
          this.$messageError({ message: msg });
        }
      }
    },
    handleSave() {
      let isValid = true;
      this.formData.forEach((item, index) => {
        this.$refs[`insuranceForm${index}`][0].validate(valid => {
          isValid = valid === false ? false : isValid;
        });
      });
      if (isValid) {
        this.doSave();
      } else {
        this.$messageError({ message: "请完善信息！" });
      }
    },
    async doSave() {
      const { id } = this.params;
      if (id) {
        //修改
        const { code, msg } = await this.$api.updateInsLiability(
          this.formData[0]
        );
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.$router.push({ name: "InsuranceTreaty" });
        } else {
          this.$messageError({ message: msg });
        }
      } else {
        //新增
        const { code, msg } = await this.$api.addLiability(this.formData);
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.$router.push({ name: "InsuranceTreaty" });
        } else {
          this.$messageError({ message: msg });
        }
      }
    },
    async handleListQuery() {
      this.$store.dispatch("loading", true);
      const {
        code,
        data: { total, rows },
        msg
      } = await this.$api.insLiabilities({
        insOrgId: this.params.insOrgId
      });
      if (code === 0) {
        this.insLiabilityList = rows;
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    }
  },
  created() {
    this.initNews();
    this.handleQuery();
    this.handleListQuery();
  }
};
</script>
<style scoped lang="scss" rel="stylesheet/scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
}
.form-content {
  &:first-of-type {
    margin: 30px 0 18px;
  }
  border: 1px dashed #fff;
  border-radius: 8px;
  margin: 18px 0;
  padding: 18px 10px 0 10px;
  &:hover {
    background: rgba(255, 255, 255, 0.6);
  }
  .remove-img {
    float: right;
    cursor: pointer;
  }
}
</style>
<template>
  <div style=" position: relative">
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
          <el-row>
            <el-col :span="12">
              <el-form-item label="模板名称：">
                <el-input v-model="mailDetails.templateName" :disabled="$route.query.type=='view'"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="主题模板：">
                <el-input
                  v-model="mailDetails.templateSubject"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="正文模板：">
                <!-- <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  v-model="mailDetails.templateContent"
                  :disabled="$route.query.type=='view'"
                ></el-input>-->
                <div class="fileContent" id="contentSend"></div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="备注：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2}"
                  placeholder="请输入内容"
                  v-model="mailDetails.remarks"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="收件人：">
                <el-table
                  class="mc-table residence-table"
                  :data="mailDetails.templateAcs"
                  style="width: 100%"
                >
                  <el-table-column
                    type="index"
                    prop="buildingName"
                    align="center"
                    label="序号"
                    width="100"
                  ></el-table-column>
                  <el-table-column prop="orgName" align="center" label="机构名称">
                    <template slot-scope="scope">
                      <span @click="mechanism(scope.row,scope.$index)">
                        <el-cascader
                          v-model="scope.row.orgNames"
                          :options="goodsOptions"
                          size="mini"
                          style="width: 300px"
                          :props="defaultData"
                          @change="handleItemChange(scope.row)"
                          :disabled="$route.query.type=='view'"
                        ></el-cascader>
                      </span>
                    </template>
                  </el-table-column>
                  <!-- <el-table-column prop="acUserIds" align="center" label="收件人"></el-table-column> -->
                  <el-table-column prop="ccUserIds" align="center" label="抄送人">
                    <template slot-scope="scope">
                      <span @click="copyPerson(scope.row,scope.$index)">
                        <el-input
                          :disabled="$route.query.type=='view'"
                          readonly
                          v-model="scope.row.ccUserIds"
                        ></el-input>
                      </span>
                    </template>
                  </el-table-column>
                  <!-- <el-table-column prop="bccUserIds" align="center" label="密送人"></el-table-column> -->
                  <el-table-column width="80" align="left" v-if="$route.query.type=='edit'">
                    <template slot="header">
                      <div
                        class="el-icon-circle-plus-outline mouse-pointer"
                        style="font-size:20px;line-height:40px"
                        @click="addParticipant"
                      ></div>
                    </template>
                    <template slot-scope="scope">
                      <div
                        class="el-icon-remove-outline mouse-pointer"
                        style="font-size:20px; margin-left: 10px"
                        @click="delParticipant(scope.$index)"
                      ></div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row style="text-align: right; margin-top: 30px" class="btns">
            <el-button
              size="mini"
              type="primary"
              @click="mailPreservation()"
              v-if="$route.query.type=='edit'"
            >确定</el-button>
            <el-button size="mini" @click="mailConfirmationBtn()">关闭</el-button>
          </el-row>
        </el-form>
      </div>
      <el-dialog title="抄送人" :visible.sync="buildingWindows" width="615px" class="dialog" :close-on-click-modal="false">
        <el-row style="border:1px #ccc solid;max-height:300px;overflow-x: auto;">
          <el-row>
            <el-table
              class="mc-table residence-table"
              :data="residentialBuildingInformation"
              @select="checkedList"
              @select-all="checkedLists"
              ref="multipleTable"
            >
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="username" align="center" label="抄送人"></el-table-column>
            </el-table>
          </el-row>
        </el-row>
        <el-row style="text-align: right; margin-top: 30px" class="btns">
          <el-button size="mini" type="primary" @click="determine()">确定</el-button>
          <el-button size="mini" @click="confirmationBtn()">关闭</el-button>
        </el-row>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import imgUpload from "@/assets/imgs/put.png";
export default {
  name: "MailBrowsing",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["app"])
  },
  data() {
    return {
      flag: false,
      selectedOptions: "",
      defaultData: {
        //联级选择
        value: "orgId",
        label: "orgName",
        children: "childrens"
      },
      goodsOptions: [],
      orgindex: null,
      index: null,
      riskBlding: [],
      insOrgIds: "",
      buildingWindows: false,
      orgType: "",
      unitData: { rows: [] },
      queryUnit: false,
      Tables: false,
      total: 0,
      limit: 6, //每页几条数据
      offset: 1, //第几页
      radio: "",
      textarea2: "",
      imgUpload,
      mailDetails: {
        templateAcs: []
      },
      multipleSelection: [],
      residentialBuildingInformation: [],
      flag: false,
      orgindex: null,
      orgfalg: false,
      newOrgId: false
    };
  },
  created() {
    this.emailTemplateDetail();
    this.searchUnit();
  },
  methods: {
    //机构查询
    mechanism(row, index) {
      this.orgindex = index;
      // if (!this.orgindex == index) {
      //   this.newOrgId = true;
      // }
      this.searchUnit();
    },
    //机构
    async searchUnit() {
      const res = await this.$api.orgListTree();
      this.goodsOptions = res.data;
    },
    handleItemChange(row) {
      const orgId = row.orgNames.slice(-1);
      const newOrgid = orgId.toString();
      row.orgId = newOrgid;
      this.orgfalg = true;
      if (
        this.orgfalg &&
        this.mailDetails.templateAcs[this.orgindex].ccUserIds
      ) {
        this.mailDetails.templateAcs[this.orgindex].ccUserIds = "";
        this.orgfalg = false;
      }
      const _this = this;
      this.mailDetails.templateAcs.map((item, index) => {
        if (_this.orgindex != index) {
          if (row.orgId == item.orgId) {
            this.$messageError({ message: "机构已选择" });
            row.orgNames = [];
          }
        }
      });
    },
    //抄送人
    async searchUser(index) {
      if (this.mailDetails.templateAcs[index].orgId) {
        const rpid = {
          isAdmin: false,
          insOrgIds: this.mailDetails.templateAcs[index].orgId
        };
        const res = await this.$api.searchUser(rpid);
        this.residentialBuildingInformation = res;
        if (this.mailDetails.templateAcs[index].ccUserIds) {
          this.riskBlding = this.mailDetails.templateAcs[index].ccUserIds.split(
            ","
          );
        }
        for (var i = 0; i < this.riskBlding.length; i++) {
          if (
            this.riskBlding[i] == "" ||
            this.riskBlding[i] == null ||
            typeof this.riskBlding[i] == undefined
          ) {
            this.riskBlding.splice(i, 1);
            i = i - 1;
          }
        }
        for (let item of this.riskBlding) {
          for (let item2 of this.residentialBuildingInformation) {
            if (item == item2.userId) {
              setTimeout(() => {
                this.$refs.multipleTable.toggleRowSelection(item2);
              });
            }
          }
        }
      } else {
        this.buildingWindows = false;
        this.$messageError({ message: "请选择机构" });
      }
    },
    //抄送人
    copyPerson(row, index) {
      this.index = index;
      this.insOrgIds = row.orgId;
      if (this.$route.query.type == "edit") {
        this.Tables = true;
        this.buildingWindows = true;
        this.searchUser(index);
      }
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex(item => {
        return item.userId == row.userId;
      });
      if (isCkeck < 0) {
        for (let [index, item2] of this.riskBlding.entries()) {
          if (item2 == row.userId) {
            this.$delete(this.riskBlding, index);
          }
        }
      } else {
        this.riskBlding.push(row.userId);
      }
    },
    determine(index) {
      this.mailDetails.templateAcs.map((item, index) => {
        if (this.index == index) {
          item.ccUserIds = this.riskBlding.join();
        }
      });
      this.buildingWindows = false;
      this.riskBlding = [];
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.riskBlding) {
            if (item2 == item.userId) {
              flag = true;
            }
          }
          if (!flag) {
            this.riskBlding.push(item.userId);
            this.mailDetails.templateAcs.ccUserIds = this.riskBlding.join();
          }
        }
      } else {
        this.riskBlding = [];
        this.mailDetails.templateAcs.ccUserIds = this.riskBlding.join();
      }
    },
    //添加参与人
    addParticipant() {
      let newPic = {
        organizationName: "",
        ccUserIds: "",
        orgId: "",
        orgNames: "",
        templateId: ""
      };
      this.mailDetails.templateAcs.push(newPic);
    },
    //删除参与人
    delParticipant(index) {
      this.mailDetails.templateAcs.splice(index, 1);
    },

    //保存
    async messagePreservation() {
      let status = false;
      for (let item of this.mailDetails.templateAcs) {
        if (!item.ccUserIds) {
          status = true;
        }
      }
      if (status) {
        this.$messageError({ message: "请填写抄送人" });
        return !status;
      }
      const res = await this.$api.messagePreservation(this.mailDetails);
      if (res.code == 0) {
        this.$messageSuccess({
          message: res.msg
        });
        this.$router.go(-1);
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    //详情
    async emailTemplateDetail() {
      const res = await this.$api.emailTemplateDetail(this.$route.query.id);
      this.mailDetails = res.templateDO;
      document.getElementById(
        "contentSend"
      ).innerHTML = this.mailDetails.templateContent;
    },
    //确定按钮
    mailPreservation() {
      this.messagePreservation();
    },
    //关闭按钮
    mailConfirmationBtn() {
      this.$router.go(-1);
    },
    //关闭
    confirmationBtn() {
      this.buildingWindows = false;
    }
  }
};
</script>
<style lang="scss" scoped>
.odd-table {
  font-size: 13px;
  white-space: nowrap;
}
.el-table_1_column_5 .cell {
  font-size: 12px;
}
.el-table_2_column_1 .cell {
  padding-left: 14px;
  padding-right: 0px;
}
.beijing {
  position: absolute;
  right: 25px;
  bottom: 30px;
  opacity: 0.7;
  width: 76.5px;
  height: 76.5px;
  background: #297ae3ff;
  border-radius: 8px;
  cursor: pointer;
}
.control {
  text-align: right;
  margin-right: 45px;
}
.shizi {
  text-align: center;
  padding-top: 15px;
  padding-left: 25px;
  font-size: 26px;
  font-weight: bold;
  color: #e2e2e2ff;
}
.typeface {
  padding-top: 10px;
  text-align: center;
  height: 10px;
  font-size: 10.5px;
  font-family: Source Han Sans CN;
  font-weight: bold;
  color: rgba(226, 226, 226, 1);
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 0px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.outline {
  width: 150px;
  text-align: center;
  height: 36.8px;
  line-height: 36.8px;
  cursor: pointer;
  position: absolute;
  left: 370px;
}
.residence-table {
  border-radius: 0px;
}
.dialog /deep/ .el-dialog {
  width: 815px;
}
.dialog /deep/ .el-dialog__body {
  padding: 20px 20px;
}
.dialog /deep/ .el-dialog__header {
  padding: 8px;
  background: rgba(16, 143, 235, 0.6);
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.fileContent {
  width: 96.5%;
  height: 250px;
  overflow: overlay;
  background-color: rgba(181, 186, 196, 0.5);
  border: 1px #dad6d6 solid;
  border-radius: 4px;
  color: #000;
  padding: 0 15px;
}
// 滚动条样式
.fileContent {
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 5px;
    box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    -webkit-box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    background-color: rgba(255, 255, 255, 1);
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    background-color: rgba(158, 159, 160, 0.8);
  }
}
</style>
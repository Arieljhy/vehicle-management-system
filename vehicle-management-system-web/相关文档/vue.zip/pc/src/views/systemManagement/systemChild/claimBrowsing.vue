<template>
  <div style=" position: relative">
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          :rules="rules"
          ref="ruleForm"
          :model="dataList"
          :disabled="$route.query.type=='view'"
        >
          <el-row>
            <el-col :span="12">
              <el-form-item label="保单号：" prop="insContractNo">
                <el-input v-model="dataList.insContractNo"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="报案号：" prop="insCaseReportId">
                <el-input v-model="dataList.insCaseReportId" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="报案栋号：">
                <el-input v-model="dataList.claimBuildingId"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="赔案号：">
                <el-input v-model="dataList.insClaimId" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="报案人名称：" prop="caseReporter">
                <el-input v-model="dataList.caseReporter"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="理赔进度：">
                <el-select v-model="dataList.claimHandleProgress" clearable placeholder="请选择">
                  <el-option
                    v-for="item in listBaseData.IDI_CLAIM_HANDLE_PROGRESS"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="赔偿金额：">
                <format-input
                  empty-value="0"
                  text-align="left"
                  :precision="2"
                  v-model="dataList.claimAmount"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="赔偿条款名称：">
                <el-input v-model="dataList.claimTermName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="赔偿项目名称：">
                <el-input v-model="dataList.claimItemName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="报案受理公司：" prop="claimHanleCompany">
                <el-input v-model="dataList.claimHanleCompany"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="赔偿日期：">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="dataList.claimDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="报案日期：">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="dataList.caseRreportDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="案发地址：">
                <el-input v-model="dataList.address" type="textarea" :autosize=" {minRows: 2}"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row style="text-align: right; margin-top: 70px" class="btns">
          <el-button
            type="primary"
            size="mini"
            @click="initiationProcess()"
            v-if="$route.query.type=='edit'"
          >提交</el-button>
          <el-button size="mini" @click="mailConfirmationBtn()">关闭</el-button>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import formatInput from "@/components/formatInput";
export default {
  name: "MailBrowsing",
  components: {
    MessageEdit,
    formatInput
  },

  computed: {
    ...mapGetters(["app", "listBaseData"])
  },

  data() {
    return {
      // 表单校验
      rules: {
        insContractNo: [
          { required: true, message: "请输入保单号", trigger: "blur" }
        ],
        caseReporter: [
          { required: true, message: "请输入报案人名称", trigger: "blur" }
        ],
        claimHanleCompany: [
          { required: true, message: "请输入报案受理公司", trigger: "blur" }
        ]
      },
      dataList: {},
      tenantId: undefined,
      verificationPass: false
    };
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    if (this.$route.query.type == "edit") {
      this.querySettlement();
    } else {
      this.odsDetails();
    }
  },
  methods: {
    //查询有无此项目
    async querySettlement() {
      const res = await this.$api.enquiryPolicy({
        type: "理赔",
        insContractNo: this.$route.query.insContractNo
      });
      if (res.code == 500) {
        this.open(res.msg);
      } else {
        this.odsDetails();
      }
    },
    open(res) {
      this.$alert(res, {
        confirmButtonText: "确定",
        callback: action => {
          this.mailConfirmationBtn();
        }
      });
    },
    //保存
    async odsDetailsSubmission() {
      this.$refs["ruleForm"].validate(valid => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      if (this.verificationPass) {
        const res = await this.$api.odsDetailsSubmission(this.dataList);
        if (res.code === 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    async odsDetails() {
      const rpid = {
        id: this.$route.query.id,
        tenantId: this.tenantId
      };
      const res = await this.$api.odsDetails(rpid);
      this.dataList = res.data;
    },
    //关闭按钮
    mailConfirmationBtn() {
      this.$router.go(-1);
    },
    //提交
    initiationProcess() {
      this.odsDetailsSubmission();
    }
  }
};
</script>
<style lang="scss" scoped>
.odd-table {
  font-size: 13px;
  white-space: nowrap;
}
.el-table_1_column_5 .cell {
  font-size: 12px;
}
.el-table_2_column_1 .cell {
  padding-left: 14px;
  padding-right: 0px;
}
.beijing {
  text-align: right;
  margin-top: 30px;
  margin-right: 17.5px;
  cursor: pointer;
  position: relative;
}
.control {
  text-align: right;
  margin-right: 45px;
}
.shizi {
  text-align: center;
  padding-top: 15px;
  padding-left: 25px;
  font-size: 26px;
  font-weight: bold;
  color: #e2e2e2ff;
}
.typeface {
  padding-top: 10px;
  text-align: center;
  height: 10px;
  font-size: 10.5px;
  font-family: Source Han Sans CN;
  font-weight: bold;
  color: rgba(226, 226, 226, 1);
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 0px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.outline {
  width: 150px;
  text-align: center;
  height: 36.8px;
  line-height: 36.8px;
  cursor: pointer;
  position: absolute;
  left: 370px;
}
.residence-table {
  border-radius: 0px;
}
.liucheng {
  position: absolute;
  bottom: 9px;
  right: 7px;
  font-size: 12.5px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
}
</style>
<template>
  <div class="content">
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-form
      class="mc-form"
      label-width="100px"
      size="mini"
      label-position="left"
      align="left"
      :model="caseDetails"
      :rules="rules"
      ref="ruleForm"
    >
      <el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="标题：" prop="title">
              <el-input v-model="caseDetails.title" :disabled="$route.query.types=='view'"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-form-item label="摘要：">
            <el-input
              type="textarea"
              :autosize=" {minRows: 4}"
              placeholder="请输入内容"
              v-model="caseDetails.content"
              :disabled="$route.query.types=='view'"
            ></el-input>
          </el-form-item>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="状态：" prop="status">
              <el-radio
                v-model="caseDetails.status"
                label="0"
                :disabled="$route.query.types=='view'"
              >草稿</el-radio>
              <el-radio
                v-model="caseDetails.status"
                label="1"
                :disabled="$route.query.types=='view'"
              >正文</el-radio>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="上传文件：" prop="fileOriginalName">
              <el-input v-model="caseDetails.fileOriginalName" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3">
              <img v-if="!upload" src="@/assets/imgs/put.png" class="img-upload" />
              <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
              <!-- <img v-if="upload" src="@/assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="uploadFile"
                :show-file-list="false"
                :on-change="handleChange"
              >
                <el-button
                  size="mini"
                  type="primary"
                  v-if="$route.query.types=='edit'||$route.query.types=='new'"
                >上传</el-button>
              </el-upload>
              <el-button
                size="mini"
                @click="delBtn()"
                v-if="$route.query.types=='edit'||$route.query.types=='new'"
              >删除</el-button>
              <el-button size="mini" @click="downloadBtn()" :disabled="disabled">下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <!-- 提交 -->
        <el-col :span="24" class="text-right" style="margin-top: 70px;margin-bottom: 30px;">
          <el-button
            type="primary"
            size="mini"
            v-if="$route.query.types=='edit'||$route.query.types=='new'"
            @click="saveReturnVisit"
          >提交</el-button>
          <el-button size="mini" @click="close">关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import axios from 'axios';
export default {
  name: "ContentManagementRevision",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["app"])
  },
  data() {
    return {
      progress:0,
      disabled: true,
      rules: {
        title: [{ required: true, message: "请输入项目名称", trigger: "blur" }],
        status: [
          { required: true, message: "请选择活动资源", trigger: "change" }
        ],
        fileOriginalName: [
          { required: true, message: "请上传报告", trigger: "blur" }
        ]
      },
      upload: false,
      fileOriginalName: "",
      verificationPass: false,
      index: "",
      radio: "1",
      radios: "1",
      fileList: [],
      caseDetails: {
        fileOriginalName: ""
      }
    };
  },
  created() {
    if (this.$route.query.types != "new") {
      this.messageListDetails();
    }
  },
  methods: {
    //请求
    async messageListDetails() {
      const res = await this.$api.messageListDetails(this.$route.query.id);
      this.caseDetails = res.data;
      this.url = res.data.fileLocation;
      if (this.caseDetails.fileOriginalName) {
        this.disabled = false;
      }
    },
    //保存
    saveReturnVisit() {
      if (this.$route.query.types == "new") {
        this.messageSave();
      } else {
        this.messagePut();
      }
    },
    //新增文件
    async messageSave() {
      this.$refs["ruleForm"].validate(valid => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      this.caseDetails.type = this.$route.query.type;
      if (this.verificationPass) {
        const res = await this.$api.messageSave(this.caseDetails);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    //保存请求
    async messagePut() {
      this.$refs["ruleForm"].validate(valid => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      if (this.verificationPass) {
        const res = await this.$api.messagePut(this.caseDetails);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    //上传
    async uploadFile(param) {
      //上传
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      let data = {
        projectId: this.projectId
      };
      file.append("projectId", "IDIHomePage");
      file.append("fileIcon", this.$route.query.type);
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
           this.progress = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.progress=100
          this.$messageSuccess({
            message: res.data.msg
          });
          this.disabled = false;
          this.caseDetails.fileLocation = res.data.data.cloudDocId;
          this.caseDetails.fileOriginalName = res.data.data.fileName;
          this.url = res.data.data.cloudDocId;
        } else {
          this.$messageError({
            message: res.data.msg
          });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    //下载
    downloadBtn() {
      var a = document.createElement("a");
      var fileOriginalName = this.caseDetails.fileOriginalName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = fileOriginalName;
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn() {
      this.caseDetails.fileOriginalName = "";
      this.url = "";
      this.disabled = true;
    },
    ...mapActions(["hasNews"]),
    initNews() {
      this.hasNews(false);
    },
    // 返回上一级
    close() {
      this.$router.go(-1);
    },
    // 上传文件
    uploadClick() {},
    handleChange(file) {}
  }
};
</script>
<style scoped lang="scss" rel="stylesheet/scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
}
</style>
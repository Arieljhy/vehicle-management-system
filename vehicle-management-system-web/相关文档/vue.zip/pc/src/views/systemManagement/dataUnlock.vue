<template>
  <div style="position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>数据解锁</span>
        </div>
      </el-row>
      <el-table
        class="mc-table table1"
        tooltip-effect="light"
        :data="caseDetails.tableData"
        style="width: 100%"
      >
        <!-- <el-table-column type="index" align="center" label="序号" width="100"></el-table-column> -->
        <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
        <el-table-column prop="role" align="center" label="用户编号" width="80">
          <template slot-scope="scope">
            <span :class="{'active': isActive&&scope.$index==index}">{{scope.row.role}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="role" align="center" label="对象名称">
          <template slot-scope="scope">
            <span :class="{'active': isActive&&scope.$index==index}">{{scope.row.role}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="role" align="center" label="报案号">
          <template slot-scope="scope">
            <span :class="{'active': isActive&&scope.$index==index}">{{scope.row.role}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="role" align="center" label="客户端地址">
          <template slot-scope="scope">
            <span :class="{'active': isActive&&scope.$index==index}">{{scope.row.role}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="role" align="center" label="创建日期">
          <template slot-scope="scope">
            <span
              :class="{'active': isActive&&scope.$index==index||scope.row.a==1}"
            >{{scope.row.role}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center">
          <template slot-scope="scope">
            <div @click="isLock(scope.row,scope.$index)">
              <el-image :src="scope.row.isLock ? lock : unlock" style="width:16px;cursor:pointer;" />
            </div>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        small
        class="text-center mt10 control block page-lucency"
        @current-change="handleCurrentChangePaging"
        :current-page.sync="offset"
        :page-size="this.limit"
        layout="prev, pager, next"
        :total="10"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import lock from "@/assets/imgs/shangsuo.png";
import unlock from "@/assets/imgs/jiesuo.png";
export default {
  name: "VerificationRule",
  data() {
    return {
      lock,
      unlock,
      isActive: false,
      limit: 6, //每页几条数据
      offset: 1, //第几页
      total: undefined,
      value1: "",
      index: undefined,
      caseDetails: {
        apple: "apple",
        tableData: [
          { name: "2", role: "保险公司" },
          { name: "1", role: "保险公司" },
          { name: "2", role: "保险公司" },
          { name: "2", role: "保险公司" },
          { name: "2", role: "保险公司" }
        ]
      },
      locks: false
    };
  },
  methods: {
    isLock(row, index) {
      this.$nextTick(() => {
        this.$set(row, "isLock", !row.isLock);
      });
      if (!row.isLock) {
        this.index = index;
        this.isActive = true;
      }else{
        this.isActive = false;
      }
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
    },
    backMytodo() {
      this.$router.go(-1);
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 60px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.active {
  // color: #918f8f;
  color: red
}
</style>
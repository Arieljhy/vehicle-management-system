<template>
  <div style="position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>ODS保单</span>
        </div>
      </el-row>
      <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
        <el-row>
          <el-col :span="24">
            <el-table
              :data="odsInsuranceList"
              style="width: 100%  font-size: 12.5px; "
              class="table_list mc-table odd-table"
              ref="multipleTable"
              tooltip-effect="dark"
              :cell-style="cellStyle"
              :header-cell-style="headCellStyle"
              @selection-change="handleSelectionChange"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="50"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="50" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="date" align="center" label="状态" width="50">
                <template slot-scope="scope">
                  <span v-if="scope.row.projectId">
                    <i class="el-icon-success" style="color:#48d916"></i>
                  </span>
                  <span v-else>
                    <i class="el-icon-error" style="color:red"></i>
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="address" align="center" label="项目名称" width="180" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="insContractNo" align="center" label="保险单号" width="200" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="insOrgName" align="center" label="保险公司" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="policyStartDate" align="center" label="保险开始日期">
                <template slot-scope="scope">{{ scope.row.policyStartDate| filterDate}}</template>
              </el-table-column>
              <el-table-column prop="policyEndDate" align="center" label="保险终止日期">
                <template slot-scope="scope">{{ scope.row.policyEndDate| filterDate}}</template>
              </el-table-column>
              <el-table-column align="center" width="100">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommand(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item
                        icon="el-icon-edit-outline"
                        command="2"
                        v-show="!scope.row.projectId"
                      >修改</el-dropdown-item>
                      <!-- scope.row.sqlStatus==false -->
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-pagination
          small
          class="text-center mt10 control block page-lucency"
          @current-change="handleSelectionChange"
          :current-page.sync="offset"
          :page-size="this.limit"
          layout="prev, pager, next"
          :total="this.total"
        ></el-pagination>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "OdsWarranty",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["app"])
  },
  data() {
    return {
      icon: true, //判断成功
      odsInsuranceList: [],
      total: undefined,
      limit: 10, //弹窗展示数据
      offset: 1 //第几页
    };
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    // this.insOrgId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).insOrgId;
    this.odsInsurancePolicy();
  },
  methods: {
    ...mapActions([
      "loading"
    ]),
    cellStyle({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 4) {
        return "font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
      } else {
        return "font-size:12.5px";
      }
    },
    headCellStyle({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return "padding-left: 0px;padding-right:0px";
      } else {
        return "";
      }
    },
    //分页
    handleSelectionChange(val) {
      this.offset = val;
      this.odsInsurancePolicy();
    },
    //请求
    async odsInsurancePolicy() {
      this.$store.dispatch("loading", true);
      const rpid = {
        tenantId: this.tenantId,
        // insOrgId: this.insOrgId,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.odsInsurancePolicy(rpid);
      this.$store.dispatch("loading", false);
      this.odsInsuranceList = res.rows;
      this.total = res.total;
    },
    backMytodo() {
      this.$router.go(-1);
    },
    handleCommand(item, command) {
      if (command === "0") {
        //查看
        this.goRiskReportDetails(item.id, "view");
      } else if (command === "1") {
        //删除数据
      } else if (command === "2") {
        //修改
        this.goRiskReportDetails(item.id, "edit");
      }
    },
    //查看view、修改edit
    goRiskReportDetails(id, type) {
      this.$router.push({
        path: "/odsWarrantyBrowse",
        query: {
          id: id,
          type: type
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.odd-table {
  font-size: 12.5px;
  white-space: nowrap;
}
.el-table_1_column_5 .cell {
  font-size: 12.5px;
}
.el-table_2_column_1 .cell {
  padding-left: 14px;
  padding-right: 0px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.control {
  position: absolute;
  bottom: 10px;
  right: 0px;
  left: 70px;
}
</style>
<template>
  <div style="position: relative">
    <div class="content">
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
      </el-col>
      <el-form
        class="mc-form"
        label-width="137px"
        size="mini"
        :model="caseDetails.riskEventDO"
        ref="ruleForm"
        :rules="rules"
        label-position="left"
        align="left"
      >
        <el-row>
          <el-col :span="8">
            <el-form-item label="风险事件名称：" prop="riskEventName">
              <el-input
                v-model="caseDetails.riskEventDO.riskEventName"
                :disabled="$route.query.type=='view' "
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="所属楼栋：" prop="unitId">
              <span @click="storiedBuilding">
                <el-input
                  v-model="caseDetails.riskEventDO.unitId"
                  :disabled="$route.query.type=='view' "
                  readonly
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="风险等级：" prop="riskLevel">
              <el-select
                v-model="caseDetails.riskEventDO.riskLevel"
                placeholder="请选择"
                :disabled="$route.query.type=='view' "
              >
                <el-option
                  v-for="item in listBaseData.IDI_RISK_EVENT_LEVEL"
                  :disabled="$route.query.type=='view' "
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="风险事件类型：">
              <el-select
                v-model="caseDetails.riskEventDO.riskEventType"
                clearable
                placeholder="请选择"
                :disabled="$route.query.type=='view' "
              >
                <el-option
                  v-for="item in listBaseData.IDI_RISK_EVENT_TYPE"
                  :disabled="$route.query.type=='view' "
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="发生时间：">
              <el-date-picker
                v-model="caseDetails.riskEventDO.riskFoundTime"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :disabled="$route.query.type=='view'"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="建议整改截止日期:" class="mc-multi-row" prop="proposedAmendDeadline">
              <el-date-picker
                v-model="caseDetails.riskEventDO.proposedAmendDeadline"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :disabled="$route.query.type=='view' "
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="项目阶段：">
              <el-select
                v-model="caseDetails.riskEventDO.constructionStage"
                clearable
                placeholder="请选择"
                :disabled="$route.query.type=='view' "
              >
                <el-option
                  v-for="item in listBaseData.IDI_PROJ_PROCESS"
                  :disabled="$route.query.type=='view' "
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="形象进度：">
              <el-input
                v-model="caseDetails.riskEventDO.projectVisualProgress"
                :disabled="$route.query.type=='view' "
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="检查方式：">
              <el-checkbox-group v-model="caseDetails.riskEventDO.checkMethods">
                <el-checkbox
                  v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                  :disabled="$route.query.type=='view'"
                  :key="item.dictKey"
                  :label="item.dictKey"
                >{{item.dictValue}}</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="缺陷描述：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                placeholder="请输入内容"
                v-model="caseDetails.riskEventDO.riskDesc"
                :disabled="$route.query.type=='view' "
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="整改建议方案：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                placeholder="请输入内容"
                v-model="caseDetails.riskEventDO.proposedAmendPlan"
                :disabled="$route.query.type=='view' "
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="现场图片：">
              <el-table class="mc-table" :data="caseDetails.riskEventPicDO" style="width: 100%">
                <el-table-column prop="address" align="center" label="内容" width="350px">
                  <template slot-scope="scope">
                    <el-upload
                      action
                      list-type="picture-card"
                      :http-request="(file) => { uploadFile(file, scope.$index) }"
                      :show-file-list="false"
                      v-if="scope.row.show"
                      :before-upload="beforeAvatarUpload"
                    >
                      <i class="el-icon-plus"></i>
                    </el-upload>
                    <img v-else width="75%" height="160px" :src="scope.row.imgUrl" />
                  </template>
                  <!-- <template slot-scope="scope">
                  <el-input size="mini" v-model="scope.row.picPath"></el-input>
                  </template>-->
                </el-table-column>
                <el-table-column prop="date" align="center" label="描述">
                  <template slot-scope="scope">
                    <el-input
                      :disabled="$route.query.type=='view'"
                      type="textarea"
                      :autosize=" {minRows: 8}"
                      v-model="scope.row.picDescription"
                    ></el-input>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="mobile"
                  align="center"
                  width="180"
                  v-if="!$route.query.type=='view'|| $route.query.type=='edit'"
                >
                  <template slot="header">
                    <div
                      class="el-icon-circle-plus-outline mouse-pointer"
                      style="font-size:20px;line-height:40px"
                      @click="addLivePic"
                    ></div>
                  </template>
                  <template slot-scope="scope">
                    <div
                      class="el-icon-remove-outline mouse-pointer"
                      style="font-size:20px;"
                      @click="delLivePic(scope.$index)"
                    ></div>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="参与人：">
              <el-table class="mc-table" :data="caseDetails.userDO" style="width: 100%">
                <el-table-column prop="mobile" align="center" label="联系电话">
                  <template slot-scope="scope">
                    <el-input
                      v-model="scope.row.mobile"
                      size="mini"
                      placeholder="请录入联系电话"
                      @blur="checkUser(scope.row)"
                      disabled
                    />
                  </template>
                </el-table-column>
                <el-table-column prop="name" align="center" label="姓名">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.name" size="mini" disabled />
                  </template>
                </el-table-column>
                <el-table-column prop="major" align="center" label="专业领域">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.major" size="mini" disabled />
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-dialog title="住宅楼信息" :visible.sync="buildingWindows" width="900px" class="dialog" :close-on-click-modal="false">
        <el-row style="border:1px #ccc solid">
          <el-row>
            <el-table
              class="mc-table residence-table"
              :data="residentialBuildingInformation"
              @select="checkedList"
              @select-all="checkedLists"
              ref="multipleTable"
            >
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="buildingName" align="center" label="竣工后楼栋门牌号"></el-table-column>
              <el-table-column prop="unitId" align="center" label="单体编号"></el-table-column>
              <el-table-column prop="unitName" align="center" label="单体名称"></el-table-column>
              <el-table-column prop="buildingType" align="center" label="类别"></el-table-column>
              <el-table-column prop="totalStories" align="center" label="总层数"></el-table-column>
              <el-table-column prop="totalUnits" align="center" label="总户数"></el-table-column>
            </el-table>
          </el-row>
        </el-row>
        <el-pagination
          small
          class="text-center mt10 control block page-lucency"
          @current-change="handleCurrentChangePaging"
          :current-page.sync="offset"
          :page-size="this.limit"
          layout="prev, pager, next"
          :total="this.total"
        ></el-pagination>
        <el-row style="text-align: right; margin-top: 30px" class="btns">
          <el-button size="mini" @click="confirmationBtn()">关闭</el-button>
        </el-row>
      </el-dialog>
      <el-row style="text-align: right; margin-top: 20px" class="btns">
        <el-button
          v-if="$route.query.type!=='view'"
          size="mini"
          type="primary"
          @click="saveRectification(1)"
        >提交</el-button>
        <el-button size="mini" @click="shutbtn()">关闭</el-button>
      </el-row>
    </div>
  </div>
</template>

<script>
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import { mapGetters, mapActions } from "vuex";
import { orgType } from "@/assets/js/codes";
import md5 from "js-md5";
import config from '@/common/config';
export default {
  name: "riskRectficationBase",
  components: {
    BasicInformation
  },
  computed: {
    ...mapGetters(["listBaseData", "getOrgId"])
  },
  data() {
    return {
      tenantId: undefined,
      show: true,
      limit: 6, //每页几条数据
      offset: 1, //第几页
      residentialBuildingInformation: undefined, //报建信息住宅楼
      buildingWindows: false,
      orgTypes: [...orgType],
      rules: {
        riskEventName: [
          {
            required: true,
            message: "请录入风险事件名称",
            trigger: "blur"
          }
        ],
        unitId: [
          {
            required: true,
            message: "请选择所属楼栋",
            trigger: "change"
          }
        ],
        riskLevel: [
          {
            required: true,
            message: "请选择风险等级",
            trigger: "change"
          }
        ],
        proposedAmendDeadline: [
          {
            // type: "date",
            required: true,
            message: "请录入建议整改截止日期",
            trigger: "change"
          }
        ]
      },
      dialogAddUser: false,
      userInfo: {},
      orgIds: [],
      roleList: [],
      addNewUserFlag: false,
      dialogVisible: false,
      total: undefined,
      riskBlding: [],
      caseDetails: {
        riskEventDO: {
          checkMethods: []
        },
        riskEventPicDO: [],
        userDO: []
      }
    };
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    if (this.$route.query.type == "edit") {
      this.querySettlement();
    } else {
      this.odsRiskEventDetails();
    }
  },
  methods: {
       //查询有无此项目
    async querySettlement() {
      const res = await this.$api.enquiryPolicy({
        type: "风控管理",
        insContractNo: this.$route.query.insContractNo
      });
      if (res.code == 500) {
        this.open(res.msg);
      } else {
        this.odsRiskEventDetails();
      }
    },
    open(res) {
      this.$alert(res, {
        confirmButtonText: "确定",
        callback: action => {
          this.shutbtn();
        }
      });
    },
    //请求数据
    async odsRiskEventDetails() {
      const rpid = {
        tenantId: this.tenantId,
        id: this.$route.query.id
      };
      const res = await this.$api.odsRiskEventDetails(rpid);
      this.caseDetails.riskEventDO = res.data.riskEventDO;
      this.caseDetails.riskEventPicDO = res.data.riskEventPicDO;
      this.caseDetails.userDO = res.data.userDO;
      this.caseDetails.riskEventPicDO.map((item, index) => {
        item.show = item.picPath ? false : true;
        item.imgUrl =
         `/api/anyShare/fileOperation/downloadDocument?cloudDocId=${item.picPath}&view=1`;
      });
    },
    //确定按钮
    cancelBtn() {
      this.buildingWindows = false;
    },
    //关闭按钮
    shutbtn() {
      this.$router.go(-1);
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex(item => {
        return item.unitId == row.unitId;
      });
      if (isCkeck < 0) {
        for (let [index, item2] of this.riskBlding.entries()) {
          if (item2 == row.unitId) {
            this.$delete(this.riskBlding, index);
            this.caseDetails.riskEventDO.unitId = this.riskBlding.join();
          }
        }
      } else {
        this.riskBlding.push(row.unitId);
        this.caseDetails.riskEventDO.unitId = this.riskBlding.join();
      }
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.riskBlding) {
            if (item2 == item.unitId) {
              flag = true;
            }
          }
          if (!flag) {
            this.riskBlding.push(item.unitId);
            this.caseDetails.riskEventDO.unitId = this.riskBlding.join();
          }
        }
      } else {
        this.riskBlding = [];
        this.caseDetails.riskEventDO.unitId = this.riskBlding.join();
      }
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      this.riskRequestForConstruction();
    },
    //确定按钮
    confirmationBtn() {
      this.buildingWindows = false;
    },
    //所属楼栋弹窗
    storiedBuilding() {
      if (this.$route.query.type === "edit") {
        this.buildingWindows = true;
        this.riskRequestForConstruction();
      }
    },
    async riskRequestForConstruction() {
      const reportBuildingData = {
        projectId: this.$route.query.projectId,
        offset: this.offset,
        limit: this.limit
      };
      const res = await this.$api.buildingInformation(reportBuildingData);
      this.total = res.data.total;
      this.residentialBuildingInformation = res.data.rows;
      if (this.$route.query.type === "edit") {
        this.riskBlding = this.caseDetails.riskEventDO.unitId.split(",");
        for (var i = 0; i < this.riskBlding.length; i++) {
          if (
            this.riskBlding[i] == "" ||
            this.riskBlding[i] == null ||
            typeof this.riskBlding[i] == undefined
          ) {
            this.riskBlding.splice(i, 1);
            i = i - 1;
          }
        }
      }
      for (let item of this.riskBlding) {
        for (let item2 of this.residentialBuildingInformation) {
          if (item == item2.unitId) {
            setTimeout(() => {
              this.$refs.multipleTable.toggleRowSelection(item2);
            });
          }
        }
      }
    },
    //添加现场图片
    addLivePic() {
      let newPic = {
        picType: "1",
        picPath: "",
        picDescription: null,
        picName: "",
        show: true
      };
      this.caseDetails.riskEventPicDO.push(newPic);
    },
    //删除现场图片
    delLivePic(index) {
      this.caseDetails.riskEventPicDO.splice(index, 1);
    },
    //上传校验
    beforeAvatarUpload(file) {
      var isJPG = false;
      switch (file.type) {
        case "image/png":
          isJPG = true;
          break;
        case "image/jpeg":
          isJPG = true;
          break;
        case "image/jpg":
          isJPG = true;
          break;
        case "image/gif":
          isJPG = true;
          break;
        case "image/tiff":
          isJPG = true;
          break;
        default:
          isJPG = false;
          break;
      }
      if (!isJPG) {
        this.$message.error("请上传正确的图片格式!");
        this.show = true;
      }
      return isJPG;
    },
    //上传
    uploadFile(param, rpid) {
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "riskEventPic");
      file.append("projectId", this.$route.query.projectId);
      this.$api.pictureProcessDoc(file).then(res => {
        if (res.code == 0) {
          this.caseDetails.riskEventPicDO.map((item, index) => {
            if (rpid == index) {
              item.picPath = res.data.cloudDocId;
              item.picName = res.data.fileName;
              item.show = item.picPath ? false : true;
              item.imgUrl = 
              `/api/anyShare/fileOperation/downloadDocument?cloudDocId=${item.picPath}&view=1`;
            }
          });
        } else {
          this.$messageError({ message: res.msg });
        }
      });
    },
    //提交
    async saveRectification(flag) {
      let _this = this;
      //表单校验
      this.verificationPass = false;
      if (this.$route.query.type === "edit") {
        let status = false;
        this.$refs["ruleForm"].validate(valid => {
          for (let item of _this.caseDetails.riskEventPicDO) {
            if (!item.imgUrl) {
              status = true;
            }
          }
          if (status) {
            this.$messageError({ message: "请上传图片" });
            return !status;
          }
          if (valid) {
            this.verificationPass = true;
          } else {
            return false;
          }
        });
      }
      if (this.verificationPass) {
        const keywordsBase = {
          riskEventDO: this.caseDetails.riskEventDO,
          riskEventPicDO: this.caseDetails.riskEventPicDO,
          userDO: this.caseDetails.userDO
        };
        keywordsBase.riskEventDO.projectId = this.$route.query.projectId;
        if (this.$route.query.type === "edit") {
          const res = await this.$api.odsRiskEventPreservation(keywordsBase);
          if (res.code === 0) {
            this.$messageSuccess({
              message: res.msg
            });
            this.$router.go(-1)
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        }
      }
    }
  }
};
</script>
<style scoped lang="scss">
.mc-addUser /deep/ .el-select--mini {
  width: 100%;
}
.mc-multi-row /deep/ .el-form-item__label {
  line-height: 15px;
  text-align: right;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
</style>
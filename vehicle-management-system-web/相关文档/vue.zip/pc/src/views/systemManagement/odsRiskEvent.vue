<template>
  <div style="position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>ODS风险事件</span>
        </div>
      </el-row>
      <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
        <el-row>
          <el-col :span="7" style="height:100%">
            <div
              class="content-left"
              style="border-radius: 0px 0px 6px 6px;min-height: 495px;background-color: rgba(255, 255, 255, 0.9);"
            >
              <el-table
                ref="singleTable"
                :data="orgList"
                row-key="orgId"
                class="mc-table"
                height="495px"
                highlight-current-row
                @current-change="handleCurrentChange"
                @cell-click="cellClick"
              >
                <el-table-column prop="orgName" label="类别"></el-table-column>
                <!-- <el-table-column width="56" align="center">
                  <template slot="header">
                    <el-dropdown size="small" trigger="click" @command="handleCommands(command)">
                      <span
                        style="font-size: 13.5px; color: #fff"
                        class="mouse-pointer el-dropdown-link"
                      >操作</span>
                      <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item command="delete">
                          <i class="el-icon-remove-outline iconBlue"></i>删除
                        </el-dropdown-item>
                        <el-dropdown-item command="update">
                          <i class="el-icon-edit-outline iconBlue"></i>修改
                        </el-dropdown-item>
                        <el-dropdown-item command="show">
                          <i class="el-icon-view iconBlue"></i>详情
                        </el-dropdown-item>
                      </el-dropdown-menu>
                    </el-dropdown>
                  </template>
                </el-table-column>-->
              </el-table>
            </div>
          </el-col>
          <!-- 风险事件 -->
          <el-col :span="17" v-show="riskEvents">
            <el-table
              :data="odsEventList"
              style="width: 100%;font-size: 12px;border-radius: 0 0 5px 0;"
              class="table_list mc-table odd-table"
              ref="multipleTable"
              tooltip-effect="dark"
              @selection-change="handleSelectionChange"
              @row-dblclick="dbGoRiskEvent"
              :cell-style="cellStyle"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="50"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="50" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="idiRiskEventId" align="center" label="状态" width="50">
                <template slot-scope="scope">
                  <span v-if="scope.row.idiRiskEventId">
                    <i class="el-icon-success" style="color:#48d916;font-size: 15px;"></i>
                  </span>
                  <span v-else>
                    <i class="el-icon-error" style="color:red;font-size: 15px;"></i>
                  </span>
                </template>
              </el-table-column>
              <el-table-column
                prop="insContractNo"
                align="center"
                label="保单号"
                width="180"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
              <el-table-column prop="riskLevel" align="center" label="风险等级">
                <template
                  slot-scope="scope"
                >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
              </el-table-column>
              <el-table-column prop="riskEventType" align="center" label="风险事件类型">
                <template
                  slot-scope="scope"
                >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
              </el-table-column>
              <!-- <el-table-column prop="riskFoundTime" align="center" label="发生时间">
                <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
              </el-table-column>-->
              <el-table-column align="center" width="60">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommandRiskEvent(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item
                        icon="el-icon-edit-outline"
                        command="2"
                        v-show="!scope.row.idiRiskEventId"
                      >修改</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
          <!-- 整改信息 -->
          <el-col :span="17" v-show="rectificationReport">
            <el-table
              :data="odsRiskEventRepairList"
              style="width: 100%  font-size: 12px; border-radius: 0 0 5px 0;"
              class="table_list mc-table odd-table"
              ref="multipleTable"
              tooltip-effect="dark"
              @selection-change="handleSelectionChange"
              @row-dblclick="dbGoRiskEventRepair"
              :cell-style="cellStyle"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="50"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="50" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="date" align="center" label="状态" width="50">
                <template slot-scope="scope">
                  <span v-if="scope.row.idiRiskEventRepairId">
                    <i class="el-icon-success" style="color:#48d916;font-size: 15px;"></i>
                  </span>
                  <span v-else>
                    <i class="el-icon-error" style="color:red;font-size: 15px;"></i>
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="riskPepairTime" align="center" label="整改时间"></el-table-column>
              <el-table-column prop="amendProgress" align="center" label="整改进度(%)"></el-table-column>
              <el-table-column prop="projectPhase" align="center" label="项目阶段">
                <template
                  slot-scope="scope"
                >{{scope.row.projectPhase | filterCode(listBaseData.IDI_PROJ_PROCESS,'dictValue','dictKey')}}</template>
              </el-table-column>
              <el-table-column align="center">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommandRectification(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item
                        icon="el-icon-edit-outline"
                        command="2"
                        v-show="!scope.row.idiRiskEventRepairId"
                      >修改</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
          <!-- 评估报告 -->
          <el-col :span="17" v-show="riskReporting">
            <el-table
              :data="odsRiskEventReportList"
              style="width: 100%  font-size: 12px; border-radius: 0 0 5px 0;"
              class="table_list mc-table odd-table"
              ref="multipleTable"
              tooltip-effect="dark"
              @selection-change="handleSelectionChange"
              @row-dblclick="dbGoRiskReporting"
              :cell-style="cellStyle"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="50"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="50" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="date" align="center" label="状态" width="50">
                <template slot-scope="scope">
                  <span v-if="scope.row.idiRiskEventReportId">
                    <i class="el-icon-success" style="color:#48d916;font-size: 15px;"></i>
                  </span>
                  <span v-else>
                    <i class="el-icon-error" style="color:red;font-size: 15px;"></i>
                  </span>
                </template>
              </el-table-column>
              <el-table-column
                prop="insContractNo"
                align="center"
                label="保单号"
                width="200"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column
                prop="name"
                align="center"
                label="报告名称"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column prop="reporteDate" align="center" label="报告时间">
                <template slot-scope="scope">{{ scope.row.reporteDate| filterDate}}</template>
              </el-table-column>
              <el-table-column align="center">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommandRiskReporting(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item
                        icon="el-icon-edit-outline"
                        command="2"
                        v-show="!scope.row.idiRiskEventReportId"
                      >修改</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
          <!-- 回访报告 -->
          <el-col :span="17" v-show="riskReturnVisit">
            <el-table
              :data="odsRiskCheckReportList"
              style="width: 100%  font-size: 12px;border-radius: 0 0 5px 0; "
              class="table_list mc-table odd-table"
              ref="multipleTable"
              tooltip-effect="dark"
              @selection-change="handleSelectionChange"
              @row-dblclick="dbGoReturnVisit"
              :cell-style="cellStyle"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="50"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="50" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="date" align="center" label="状态" width="50">
                <template slot-scope="scope">
                  <span v-if="scope.row.idiRiskCheckReportId">
                    <i class="el-icon-success" style="color:#48d916;font-size: 15px;"></i>
                  </span>
                  <span v-else>
                    <i class="el-icon-error" style="color:red;font-size: 15px;"></i>
                  </span>
                </template>
              </el-table-column>
              <el-table-column
                prop="insContractNo"
                align="center"
                label="保单号"
                width="180"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column
                prop="reportScope"
                align="center"
                label="报告所涉及的承保范围"
                width="170"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column
                prop="revistSummary"
                align="center"
                label="回访小结"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column prop="surveyDate" align="center" label="回访时间">
                <template slot-scope="scope">{{ scope.row.surveyDate| filterDate}}</template>
              </el-table-column>
              <el-table-column align="center" width="80">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommandReturnVisit(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item
                        icon="el-icon-edit-outline"
                        command="2"
                        v-show="!scope.row.idiRiskCheckReportId"
                      >修改</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-pagination
          small
          class="text-center mt10 control block page-lucency"
          @current-change="handleCurrentChangePaging"
          :current-page.sync="offset"
          :page-size="this.limit"
          layout="prev, pager, next"
          :total="this.total"
        ></el-pagination>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "SystemManagement",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["district", "listBaseData", "getBasicBstablish"])
  },
  data() {
    return {
      currentRow: null,
      total: undefined,
      limit: 10, //弹窗展示数据
      offset: 1, //第几页
      tenantId: undefined,
      insOrgId: undefined,
      riskEvents: true,
      riskReporting: false,
      rectificationReport: false,
      riskReturnVisit: false,
      orgList: [
        { orgName: "风险事件信息" },
        { orgName: "风险评估报告" },
        { orgName: "风险回访报告" },
        { orgName: "整改信息" }
      ],
      odsEventList: [],
      odsRiskEventRepairList: [],
      odsRiskEventReportList: [],
      odsRiskCheckReportList: [],
      multipleSelection: []
    };
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    // this.insOrgId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).insOrgId;
    this.odsRiskEvent();
  },
  mounted() {
    //判断点击table的颜色
    this.$refs.singleTable.setCurrentRow(this.orgList[0]);
  },
  methods: {
    cellStyle({ row, column, rowIndex, columnIndex }) {
      return "font-size:12.5px";
    },
    //双击进入详情
    dbGoRiskEvent(row) {
      this.goRiskEvent(row.id, "", "view");
    },
    dbGoRiskEventRepair(row) {
      this.goRectification(row.id, "view");
    },
    dbGoReturnVisit(row) {
      this.goReturnVisit(row.id, "", "view");
    },
    dbGoRiskReporting(row) {
      this.goRiskReporting(row.id, "", "", "view");
    },
    handleCurrentChange(val) {
      this.currentRow = val;
    },
    //风险事件列表
    async odsRiskEvent() {
      const rpid = {
        tenantId: this.tenantId,
        // insOrgId: this.insOrgId,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.odsRiskEvent(rpid);
      this.odsEventList = res.rows;
      this.total = res.total;
    },
    //整改列表
    async odsRiskEventRepair() {
      const rpid = {
        tenantId: this.tenantId,
        // insOrgId: this.insOrgId,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.odsRiskEventRepair(rpid);
      this.odsRiskEventRepairList = res.rows;
      this.total = res.total;
    },
    //风险报告列表
    async odsRiskEventReport() {
      const rpid = {
        tenantId: this.tenantId,
        // insOrgId: this.insOrgId,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.odsRiskEventReport(rpid);
      this.odsRiskEventReportList = res.rows;
      this.total = res.total;
    },
    //回访报告列表
    async odsRiskCheckReport() {
      const rpid = {
        tenantId: this.tenantId,
        // insOrgId: this.insOrgId,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.odsRiskCheckReport(rpid);
      this.odsRiskCheckReportList = res.rows;
      this.total = res.total;
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      if (this.riskReporting) {
        this.odsRiskEventReport();
      } else if (this.rectificationReport) {
        this.odsRiskEventRepair();
      } else if (this.riskReturnVisit) {
        this.odsRiskCheckReport();
      } else {
        this.odsRiskEvent();
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    backMytodo() {
      this.$router.go(-1);
    },
    //判断显示table
    cellClick(row) {
      this.offset = undefined;
      this.orgName = row.orgName;
      if (this.orgName == "风险评估报告") {
        (this.riskReporting = true),
          (this.riskEvents = false),
          (this.riskReturnVisit = false),
          (this.rectificationReport = false);
        this.offset = 1;
        this.odsRiskEventReport();
      } else if (this.orgName == "整改信息") {
        (this.rectificationReport = true),
          (this.riskReporting = false),
          (this.riskReturnVisit = false),
          (this.riskEvents = false);
        this.offset = 1;
        this.odsRiskEventRepair();
      } else if (this.orgName == "风险回访报告") {
        (this.riskReturnVisit = true),
          (this.rectificationReport = false),
          (this.riskReporting = false),
          (this.riskEvents = false);
        this.offset = 1;
        this.odsRiskCheckReport();
      } else {
        (this.riskReturnVisit = false),
          (this.rectificationReport = false),
          (this.riskReporting = false),
          (this.riskEvents = true);
        this.offset = 1;
        this.odsRiskEvent();
      }
    },
    //进入风险事件详情,修改页面
    handleCommandRiskEvent(item, command) {
      if (command === "0") {
        //查看
        this.goRiskEvent(item.id, item.projectId, item.insContractNo, "view");
      } else if (command === "1") {
        //删除数据
        this.$message("删除成功");
      } else if (command === "2") {
        //修改
        this.goRiskEvent(item.id, item.projectId, item.insContractNo, "edit");
      }
    },
    //查看风险事件view、修改edit
    goRiskEvent(id, projectId, insContractNo, type) {
      this.$router.push({
        path: "/odsRiskRectificationBase",
        query: {
          id: id,
          projectId: projectId,
          type: type,
          insContractNo: insContractNo
        }
      });
    },
    //进入报告详情
    handleCommandRiskReporting(item, command) {
      if (command === "0") {
        //查看
        this.goRiskReporting(
          item.id,
          item.reportId,
          item.projectId,
          item.insContractNo,
          "view"
        );
      } else if (command === "1") {
        //删除数据
        this.$message("删除成功");
      } else if (command === "2") {
        //修改
        this.goRiskReporting(
          item.id,
          item.reportId,
          item.projectId,
          item.insContractNo,
          "edit"
        );
      }
    },
    //查看报告事件
    goRiskReporting(id, reportId, projectId, insContractNo, type) {
      this.$router.push({
        path: "/odsRiskReportAmend",
        query: {
          id: id,
          reportId: reportId,
          projectId: projectId,
          type: type,
          insContractNo: insContractNo
        }
      });
    },
    //进入整改详情
    handleCommandRectification(item, command) {
      if (command === "0") {
        //查看
        this.goRectification(
          item.id,
          item.projectId,
          item.insContractNo,
          "view"
        );
      } else if (command === "1") {
        //删除数据
        this.$message("删除成功");
      } else if (command === "2") {
        //修改
        this.goRectification(
          item.id,
          item.projectId,
          item.insContractNo,
          "edit"
        );
      }
    },
    //查看整改事件
    goRectification(id, projectId, insContractNo, type) {
      this.$router.push({
        path: "/odsRectificationDetails",
        query: {
          id: id,
          projectId: projectId,
          type: type,
          insContractNo: insContractNo
        }
      });
    },
    //进入回访
    handleCommandReturnVisit(item, command) {
      if (command === "0") {
        //查看
        this.goReturnVisit(item.id, item.projectId, item.insContractNo, "view");
      } else if (command === "1") {
        //删除数据ite.insContractNo,
        this.$message("删除成功");
      } else if (command === "2") {
        //修改
        this.goReturnVisit(item.id, item.projectId, item.insContractNo, "edit");
      }
    },
    //查看回访事件
    goReturnVisit(id, projectId, insContractNo, type) {
      this.$router.push({
        path: "/odsReturnVisitDetails",
        query: {
          id: id,
          projectId: projectId,
          type: type,
          insContractNo: insContractNo
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.odd-table {
  font-size: 13px;
  white-space: nowrap;
}
.el-table_1_column_5 .cell {
  font-size: 12px;
}
.el-table_2_column_1 .cell {
  padding-left: 14px;
  padding-right: 0px;
}
.liucheng {
  position: absolute;
  bottom: 9px;
  right: 7px;
  font-size: 12.5px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 300px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.mc-table/deep/.current-row > td {
  background: #9fb6cd !important;
}
</style>
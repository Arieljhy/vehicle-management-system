<template>
  <div class="content">
    <el-row>
      <el-col :span="3" class="goback">
        <div @click="$router.replace({name:'AccountManagement',query:{isConstructingUnit:params.isConstructingUnit}})">
          <i class="el-icon-arrow-left"></i>
          <span>{{params.isConstructingUnit?'建设单位':'账户管理'}}</span>
        </div>
      </el-col>
    </el-row>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-form
      class="mc-form"
      ref="orgForm"
      :rules="rules"
      :model="caseDetails"
      label-width="148px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <!-- <el-col :span="8">
          <el-form-item label="编号：" prop="orgId">
            <el-input :disabled="params.read" v-model="caseDetails.orgId"></el-input>
          </el-form-item>
        </el-col>-->
        <el-col :span="8">
          <el-form-item label="上级机构：">
            <el-input :disabled="true" v-model="caseDetails.orgPname"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item class="mc-multi-row" label="社会统一信用编码：" prop="orgCode">
            <el-input :disabled="!!(params.read||params.orgId)" v-model="caseDetails.orgCode"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="机构类型：">
            <el-input :disabled="true" v-model="caseDetails.orgTypeName"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8" v-if="caseDetails.orgType !='INS'&&caseDetails.orgType!='SINS'">
          <el-form-item label="名称：" prop="orgName">
            <el-input :disabled="params.read" v-model="caseDetails.orgName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8" v-if="caseDetails.orgType =='INS'||caseDetails.orgType=='SINS'">
          <el-form-item label="名称：" prop="orgName">
            <el-select
              v-model="caseDetails.orgName"
              filterable
              :disabled="params.read"
              placeholder="请输入关键词"
              @change="selectChange(caseDetails.orgName)"
              >
              <el-option
                v-for="(item,index) in options"
                :key="index"
                :label="item.orgName"
                :value="index">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="联系人名称：">
            <el-input :disabled="params.read" v-model="caseDetails.contacts"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="联系人电话：" prop="contactTel">
            <el-input :disabled="params.read" v-model="caseDetails.contactTel"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8" v-if="caseDetails.orgType !='INS'&&caseDetails.orgType!='SINS'">
          <el-form-item label="简称：" prop="orgSimpleName">
            <el-input :disabled="params.read" v-model="caseDetails.orgSimpleName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8" v-if="caseDetails.orgType =='INS'||caseDetails.orgType=='SINS'">
          <el-form-item label="简称：" prop="orgSimpleName">
            <el-input disabled v-model="caseDetails.orgSimpleName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8" v-if="caseDetails.orgType==='INS'||caseDetails.orgType==='OP'">
          <el-form-item label="报案热线：" prop="reportTelephone">
            <el-input :disabled="params.read" v-model="caseDetails.reportTelephone"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="备注：">
            <el-input
              style="width:96%"
              type="textarea"
              :autosize=" {minRows: 2.5}"
              placeholder="请输入内容"
              :disabled="params.read"
              v-model="caseDetails.orgDesc"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="22" class="text-right" style="padding: 163px 0 63.5px 0">
          <el-button
            v-if="!params.read"
            type="primary"
            style="background-color: #108FEB"
            size="mini"
            @click="handleSave"
          >确定</el-button>
          <el-button size="mini" @click="$router.replace({name:'AccountManagement',query:{isConstructingUnit:params.isConstructingUnit}})">关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";

export default {
  name: "NewAccount",
  data() {
    return {
      options: [],//全称 
      caseDetails: {
        orgPname: "",
        orgId: "",
        orgCode: "",
        orgTypeName: "",
        orgType: "",
        orgName: "",
        orgDesc: "",
        orgSimpleName: ""
      },
      rules: {
        orgId: [{ required: true, message: "请输入编号" }],
        orgCode: [{ required: true, message: "请输入社会统一信用编码" }],
        orgName: [{ required: true, message: "请输入名称" }],
        orgSimpleName: [{ required: true, message: "请输入简称" }],
        contactTel: [
          {
            validator: (rule, value, callback) => {
              if (
                !value ||
                /^((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)$/.test(
                  value
                )
              ) {
                callback();
              } else {
                callback(new Error("请输入正确的联系人电话"));
              }
            }
          }
        ],
        reportTelephone:[
          {
            required: true,
            message: "请输入报案热线"
            // validator: (rule, value, callback) => {
            //   if(!value){
            //     callback(new Error("请输入报案热线"));
            //   }
            //   else if(/^((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)$/.test(value)
            //   ) {
            //     callback();
            //   } else {
            //     callback(new Error("请输入正确的报案热线"));
            //   }
            // }
          }
        ],
      }
    };
  },
  props: {
    routePath: {
      type: String,
      required: false,
      default: ""
    }
  },
  computed: {
    ...mapGetters(["userInfo"]),
    params() {
      return {
        orgPname: this.$route.query.orgPname,
        orgId: this.$route.query.orgId,
        orgPid: this.$route.query.orgPid,
        orgTypeName: this.$route.query.orgTypeName,
        isConstructingUnit:this.$route.query.isConstructingUnit,
        read: this.$route.query.read
      };
    }
  },
  methods: {
    ...mapActions(["hasNews","getOrgId",]),
    getFullName(){
      let keyWords = { fuzzyQuery:this.caseDetails.orgName };
      http.get("/sysconfig/Org/fuzzyQueryOrgInfo",keyWords).then(res=>{
        if(res.code == 0){
          this.options = res.data;
        }
      })
    },
    selectChange(flag){
      this.options.map((item,index)=>{
        if(index==flag){
          this.caseDetails.orgSimpleName = item.orgSimpleName;
        }
      })
    },
    initNews() {
      this.hasNews(false);
    },
    handleSave() {
      this.$refs.orgForm.validate(valid => {
        if (valid) {
          this.doSaveOrUpdate();
        } else {
          this.$messageError({ message: "请完善信息！" });
        }
      });
    },
    async doSaveOrUpdate() {
      const { orgId } = this.params;
      this.$store.dispatch("loading", true);
      if (orgId) {
        //修改
        const { code, msg } = await this.$api.updateOrg(this.caseDetails);
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.getOrgId()
          this.$router.push({ name: "AccountManagement",query:{isConstructingUnit:this.params.isConstructingUnit}});
        } else {
          this.$messageError({ message: msg });
        }
      } else {
        //新增
        const { code, msg } = await this.$api.addOrg(this.caseDetails);
        if (code === 0) {
          this.$messageSuccess({ message: msg });
           this.getOrgId()
          this.$router.push({ name: "AccountManagement",query:{isConstructingUnit:this.params.isConstructingUnit} });
        } else {
          this.$messageError({ message: msg });
        }
      }

      this.$store.dispatch("loading", false);
    },
    async queryDetail() {
      const { orgId } = this.params;
      if (orgId) {
        const {
          code,
          data,
          msg
        } = await this.$api.orgList(orgId);
        if (code === 0) {
          this.caseDetails = data;
        } else {
          this.$messageError({ message: msg });
        }
      }
    }
  },
  created() {
    this.caseDetails.orgPname = this.params.orgPname;
    this.caseDetails.orgId = this.params.orgId;
    this.caseDetails.orgPid = this.params.orgPid;
    this.caseDetails.orgTypeName = this.params.orgTypeName;
    this.caseDetails.orgType = this.$route.query.orgType;
    if(this.caseDetails.orgType=='INS'||this.caseDetails.orgType=='SINS'){
      this.getFullName();//获取全称
    }
    this.initNews();
    this.queryDetail();
  }
};
</script>
<style scoped lang="scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
}
/deep/ .el-form-item__label {
  font-weight: 500;
  // line-height: 1.5;
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>
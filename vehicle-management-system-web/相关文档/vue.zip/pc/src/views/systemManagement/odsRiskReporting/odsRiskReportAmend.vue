<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          :rules="rules"
          ref="ruleForm"
          :model="riskReportingData.riskReportDO"
        >
          <el-row>
            <el-col :span="12">
              <el-form-item label="项目名称：" prop="name">
                <el-input
                  v-model="riskReportingData.riskReportDO.name"
                  :disabled="$route.query.type=='view'"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-if="$route.query.type=='edit'">
            <el-col :span="24">
              <el-form-item>
                <template slot-scope="scope">
                  <el-table
                    class="mc-table"
                    :data="riskReportingData.riskEventReports"
                    style="width: 100%"
                    ref="multipleTable"
                  >
                    <el-table-column type="index" label="序号" align="center" width="80"></el-table-column>
                    <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
                    <el-table-column
                      prop="riskEventType"
                      align="center"
                      label="风险事件类型"
                      show-overflow-tooltip
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column
                      prop="riskLevel"
                      align="center"
                      label="风险等级"
                      show-overflow-tooltip
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="最初报告时间" show-overflow-tooltip>
                      <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="建议整改截止日期" show-overflow-tooltip>
                      <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
                    </el-table-column>
                    <el-table-column prop="riskEventStatus" align="center" label="业务状态">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                    </el-table-column>
                  </el-table>
                </template>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="承保意见：">
                <el-table
                  class="mc-table"
                  style="width: 100%"
                  :data="riskReportingData.riskReportItemDO"
                >
                  <el-table-column prop="insScope" align="center" label="保险责任范围"></el-table-column>
                  <el-table-column prop="insPeriod" align="center" label="期限(年)" width="150"></el-table-column>
                  <el-table-column prop="liabilitiesType" align="center" label="保险类型" width="150"></el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2 , maxRows: 4}"
                        style="opacity:0.2 color:#3E3A39;"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        class="tex"
                        placeholder="请输入内容"
                        :disabled="$route.query.type=='view'"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报告人：">
                <el-input
                  v-model="riskReportingData.riskReportDO.reporter"
                  :disabled="$route.query.type=='view'"
                  readonly
                  @click.native="openAgency({title: '报告人', type: 'BGR',num:'2' })"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="审核人：">
                <el-input
                  v-model="riskReportingData.riskReportDO.reviewer"
                  :disabled="$route.query.type=='view'"
                  readonly
                  @click.native="openAgency({title: '审核人', type: 'SHR' ,num:'2'})"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="批准人：">
                <el-input
                  v-model="riskReportingData.riskReportDO.approver"
                  :disabled="$route.query.type=='view'"
                  readonly
                  @click.native="openAgency({title: '批准人', type: 'PZR',num:'2' })"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="上传报告：" prop="fileName">
                <el-input v-model="riskReportingData.riskReportDO.fileName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-col :span="3" style="position: relative; left: 10px">
                <img v-if="!upload" :src="imgUpload" class="img-upload" />
                <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
                <!-- <img v-if="upload" src="@/assets/imgs/gif.gif" class="img-upload" /> -->
              </el-col>
              <el-col :span="21">
                <el-upload
                  class="inline-block mlr97"
                  action
                  :http-request="uploadFile"
                  :show-file-list="false"
                  :on-change="handleChange"
                >
                  <el-button size="mini" type="primary" v-if="$route.query.type=='edit'">上传</el-button>
                </el-upload>
                <el-button size="mini" @click="delBtn()" v-if="$route.query.type=='edit'">删除</el-button>
                <el-button size="mini" @click="downloadBtn()" :disabled="disabled">下载</el-button>
              </el-col>
            </el-col>
          </el-row>
          <el-row style="text-align: right; margin-top: 70px" class="btns">
            <el-button
              size="mini"
              type="primary"
              @click="saveReturnVisit(1)"
              v-if="$route.query.type=='edit'"
            >提交</el-button>
            <el-button size="mini" @click="shutbtn()">关闭</el-button>
          </el-row>
        </el-form>
      </div>
    </div>
    <el-dialog class="dialog" :title="title" :visible.sync="openVisible" width="615px" :close-on-click-modal="false">
      <select-agency
        :type="type"
        :title="title"
        @getAngency="getAngency"
        v-if="openVisible"
        :num="num"
        :project="project"
      ></select-agency>
    </el-dialog>
  </div>
</template>
<script>
import MessageEdit from "@/components/Message.vue";
import { mapGetters, mapActions } from "vuex";
import imgUpload from "@/assets/imgs/put.png";
import SelectAgency from "@/components/selectAgency.vue";
 import axios from 'axios'; 
export default {
  components: {
    MessageEdit,
    SelectAgency
  },
  name: "AddNewProject", //风险评估报告修改页面
  data() {
    return {
      progress:0,
      disabled: true,
      upload: false,
      openVisible: false,
      type: "",
      title: "",
      num: "",
      project: "",
      rules: {
        name: [{ required: true, message: "请输入项目名称", trigger: "blur" }],
        fileName: [{ required: true, message: "请上传报告", trigger: "change" }]
      },
      imgUpload,
      insRemark: "", //建议
      search: undefined,
      fileName: "",
      url: "",
      tenantId: undefined,
      verificationPass: false,
      cloudPath: "", //文件临时位置
      assessmentReportFile: "", //上传文件成功后URL
      riskReportingData: {
        riskReportDO: {},
        riskReportItemDO: [], //建议
        riskEventReports: [],
        riskEventReportRelDO: []
      }
    };
  },
  computed: {
    ...mapGetters(["district", "listBaseData", "getBasicBstablish"])
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    if (this.$route.query.type == "edit") {
      this.querySettlement();
    } else {
      this.riskAssessment();
    }
  },
  mounted() {
    this.$refs["ruleForm"].resetFields();
  },
  methods: {
    //查询有无此项目
    async querySettlement() {
      const res = await this.$api.enquiryPolicy({
        type: "风控管理",
        insContractNo: this.$route.query.insContractNo
      });
      if (res.code == 500) {
        this.open(res.msg);
      } else {
        this.riskAssessment();
      }
    },
    open(res) {
      this.$alert(res, {
        confirmButtonText: "确定",
        callback: action => {
          this.shutbtn();
        }
      });
    },
    openAgency(data) {
      this.openVisible = true;
      this.type = data.type;
      this.title = data.title;
      this.nun = data.num;
      this.project = this.$route.query.projectId;
    },
    getAngency(value) {
      if (value.type == "BGR") {
        this.riskReportingData.riskReportDO.reporter = value.username;
      } else if (value.type == "SHR") {
        this.riskReportingData.riskReportDO.reviewer = value.username;
      } else if (value.type == "PZR") {
        this.riskReportingData.riskReportDO.approver = value.username;
      }
      this.openVisible = false;
    },
    //请求风险数据
    async riskAssessment() {
      const rid = {
        tenantId: this.tenantId,
        id: this.$route.query.id
      };
      const res = await this.$api.odsRiskEventReportDetails(rid);
      this.total = res.data.total;
      this.riskReportingData.riskReportDO = res.data.riskReportDO;
      this.url = this.riskReportingData.riskReportDO.assessmentReportFile;
      this.riskReportingData.riskReportItemDO = res.data.riskReportItemDO;
      this.riskReportingData.riskEventReports = res.data.riskEventReports;
      this.riskReportingData.riskEventReportRelDO =
        res.data.riskEventReportRelDO;
      if (this.riskReportingData.riskReportDO.fileName) {
        this.disabled = false;
      }
    },
    shutbtn() {
      //关闭按钮
      this.$router.go(-1);
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
    },
    //表单校验
    async saveReturnVisit(flag) {
      this.$refs["ruleForm"].validate(valid => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      if (this.verificationPass) {
        this.$store.dispatch("loading", true);
        const keywords = this.riskReportingData;
        const res = await this.$api.odsRiskEventReportPreservation(keywords);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$store.dispatch("loading", false);
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    handleChange(file) {},
    //下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.riskReportingData.riskReportDO.fileName;
      a.style = "display: none";
      a.href =
        "/api/anyShare/fileOperation/downloadDocument?cloudDocId=" +
        this.url +
        "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    async uploadFile(param) {
      //上传
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      this.projectId = this.$route.query.projectId;
      let data = {
        projectId: this.projectId
      };
      file.append("projectId", this.projectId);
      file.append("fileIcon", "assessmentReportFile");
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this.progress = complete == 100 ? 99 : complete;c
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.progress=100
          this.$messageSuccess({
            message: res.data.msg
          });
          this.disabled = false;
          this.assessmentReportFile = res.data.data.cloudDocId;
          this.riskReportingData.riskReportDO.assessmentReportFile = this.assessmentReportFile;
          this.riskReportingData.riskReportDO.fileName = res.data.data.fileName;
          this.url = res.data.data.cloudDocId;
        } else {
          this.$messageError({
            message: res.data.msg
          });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    // 删除
    delBtn() {
      this.riskReportingData.riskReportDO.fileName = "";
      this.url = "";
      this.disabled = true;
    }
  }
};
</script>
<style scoped lang="scss">
.el-form-item--mini {
  margin-bottom: 12px;
}
.rid {
  margin-right: 150px;
}
.lucency {
  opacity: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
}
.buttn {
  width: 64.5px;
  height: 29.5px;
  background: rgba(16, 143, 235, 1);
  border-radius: 8px;
  color: #fff;
}
.control {
  text-align: right;
  margin-bottom: 20px;
}
.tex {
  width: 318px;
}
.el-icon-search {
  position: absolute;
  top: 7px;
  left: 345px;
  font-size: 14px;
  color: #a6adb5;
}
.con-head {
  margin-top: 25px;
  margin-bottom: 15px;
  .el-input {
    /deep/ .el-input__inner {
      height: 28px;
      border-radius: 0;
      border: 1px solid #297ae3;
    }
  }
  /deep/ .el-input-group__append {
    background: #297ae3;
    border-radius: 0;
    border: 0;
    padding: 0;
    width: 38px;
    height: 28px;
  }
  /deep/ .el-button {
    color: #fff;
    font-size: 20px;
  }
}
.el-input--mini /deep/ .el-input__inner {
  border: none;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
</style>
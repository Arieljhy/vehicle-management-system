<template>
  <div style="position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>造价阈值</span>
        </div>
      </el-row>
      <el-table
        class="mc-table"
        tooltip-effect="light"
        :data="costThresholdLIst"
        style="width: 100%"
        @row-dblclick="dbGoRiskEvent"
      >
        <el-table-column type="index" align="center" label="序号"></el-table-column>
        <el-table-column prop="ruleCname" align="center" label="阈值类型"></el-table-column>
        <el-table-column prop="ruleValue" align="center" label="造价阈值"></el-table-column>
        <el-table-column prop="createdBy" align="center" label="创建人"></el-table-column>
        <el-table-column prop="createdDate" align="center" label="创建日期">
          <template slot-scope="scope">{{ scope.row.createdDate | filterDate}}</template>
        </el-table-column>
        <el-table-column prop="status" align="center" label="状态">
          <template slot-scope="scope">
            <div v-if="scope.row.status=='DISABLE'">禁用</div>
            <div v-if="scope.row.status=='ACTIVED'">有效</div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="操作" width="120">
          <template slot-scope="scope">
            <el-button @click="operateCostThreshold(scope.row.id)" style="cursor:pointer;"  size="mini"
                type="primary">修改</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <el-pagination
        small
        class="text-center mt10 control block page-lucency"
        @current-change="handleCurrentChangePaging"
        :current-page.sync="offset"
        :page-size="this.limit"
        layout="prev, pager, next"
        :total="this.total"
      ></el-pagination> -->
      <el-dialog title="造价阈值" :visible.sync="dialogVisible" width="900px" class="dialog" :close-on-click-modal="false">
        <el-form
          class="mc-form"
          label-width="100px"
          size="mini"
          label-position="left"
          align="left"
          :model="caseDetails"
          ref="caseDetails"
        >
          <el-row style="border:1px #ccc solid">
            <el-row style="padding: 10px 0 5px;">
              <el-col :span="11">
                <el-form-item label="阈值类型：">
                  <el-input v-model="caseDetails.ruleCname" disabled></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="造价阈值：" class="is-required">
                  <format-input
                    v-model="caseDetails.ruleValue"
                    :error="error"
                    :required="true"
                    text-align="left"
                    :precision="6"
                  ></format-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="22">
                <el-form-item label="备注：">
                  <el-input
                    style="width:100%"
                    type="textarea"
                    :autosize=" {minRows: 4}"
                    placeholder="请输入内容"
                    v-model="caseDetails.remarks"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="状态：">
                  <el-radio-group v-model="caseDetails.status">
                    <el-radio label="DISABLE">禁用</el-radio>
                    <el-radio label="ACTIVED">有效</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
          </el-row>
          <el-row style="text-align: right; margin-top: 30px" class="btns">
            <el-button size="mini" type="primary" @click="confirmationBtn('caseDetails')">保存</el-button>
            <el-button size="small" class="btn" @click="cancelBtn()">取消</el-button>
          </el-row>
        </el-form>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import formatInput from "@/components/formatInput";
export default {
  name: "CostThreshold",
  components: {
    formatInput
  },
  data() {
    return {
      error: false,
      dialogVisible: false,
      caseDetails: {
        ruleValue: ""
      },
      costThresholdLIst: [],
      limit: 6, //每页几条数据
      offset: 1, //第几页
      total: undefined
    };
  },
  created() {
    this.costThreshold();
  },
  methods: {
    //请求造价阈值list
    async costThreshold() {
      const res = await this.$api.costThreshold();
      this.costThresholdLIst = res.bussinessRuleDOs;
      this.total=res.total
    },
    //修改阈值
    async thresholdModification(id) {
      const res = await this.$api.thresholdModification(id);
      this.caseDetails = res.bussinessRuleDO;
    },
    //保存阈值
    async thresholdPreservation() {
      const participation = {
        id: this.caseDetails.id,
        remarks: this.caseDetails.remarks,
        ruleValue: this.caseDetails.ruleValue,
        status: this.caseDetails.status
      };
      const res = await this.$api.thresholdPreservation(participation);
      if (res.code == 0) {
        this.$messageSuccess({
          message: "成功"
        });
        this.dialogVisible = false;
        this.costThreshold();
      } else {
        this.$messageError({
          message: "失败 "
        });
      }
    },
    operateCostThreshold(id) {
      this.thresholdModification(id);
      this.dialogVisible = true;
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      this.costThreshold()
    },
    backMytodo() {
      this.$router.go(-1);
    },
    //双击进入详情
    dbGoRiskEvent(row) {
      this.dialogVisible = true;
      this.thresholdModification(row.id);
    },
    cancelBtn() {
      this.dialogVisible = false;
    },
    confirmationBtn(formName) {
      this.$refs[formName].validate(valid => {
        this.error = true;
        let valids = [this.caseDetails.ruleValue];
        for (let v of valids) {
          if (!v && v != 0) {
            return false;
          }
        }
        if (this.caseDetails.ruleValue > 0) {
          if (valid) {
            this.thresholdPreservation();
          } else {
            this.$messageError({
              message: "请完善信息"
            });
          }
        }else{
          this.$messageError({
              message: "请输入大于0的数"
            });
        }
      });
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 60px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
</style>
<template>
  <div class="content">
    <el-row>
      <el-col :span="3" class="goback">
        <div
          @click="$router.replace({name:'AccountManagement',query:{isConstructingUnit:params.isConstructingUnit}})"
        >
          <i class="el-icon-arrow-left"></i>
          <span>{{params.isConstructingUnit?'建设单位':'账户管理'}}</span>
        </div>
      </el-col>
    </el-row>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-form
      class="mc-form"
      :model="caseDetails"
      ref="userForm"
      :rules="rules"
      label-width="148px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="账号：" prop="userId">
            <el-input
              autocomplete="new-password"
              :disabled="!!(params.userId||params.read) || readThreeFlag"
              v-model="caseDetails.userId"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="密码：" prop="password">
            <input type="password" style="position: absolute;z-index: -999" />
            <el-input
              autocomplete="new-password"
              :disabled="params.read || readThreeFlag"
              @blur="handlePassword"
              type="password"
              v-model="caseDetails.password"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="名称：" prop="username">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.username"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="性别：">
            <el-radio-group v-model="caseDetails.sex" :disabled="params.read || readThreeFlag">
              <el-radio :label="1">男</el-radio>
              <el-radio :label="0">女</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="证件号码：" prop="idCard">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.idCard"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="出生日期：">
            <el-date-picker
              class="date"
              type="date"
              :disabled="params.read || readThreeFlag"
              value-format="yyyy-MM-dd"
              v-model="caseDetails.birth"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="手机号：" prop="mobile">
            <el-input
              :disabled="params.read || readThreeFlag"
              v-model="caseDetails.mobile"
              @blur="checkMobile()"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="办公电话：" prop="telephone">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.telephone"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="邮箱：" prop="email">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.email"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="专业领域：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.professional"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="最高学历：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.educationLevel"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="所学专业：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.major"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="角色：" prop="roleId">
            <el-select :disabled="params.read" v-model="caseDetails.roleId">
              <el-option
                v-for="item in roleList"
                :key="item.roleId"
                :label="item.roleName"
                :value="`${item.roleId}`"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="状态：" prop="status">
            <el-radio-group :disabled="params.read" v-model="caseDetails.status">
              <el-radio :label="1">有效</el-radio>
              <el-radio :label="0">无效</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="8" v-if="$route.query.addOrEdit||$route.query.read">
          <el-form-item label="所属机构：" prop="orgName">
            <el-select :disabled="params.read" v-model="caseDetails.orgName" filterable @change="orgOnChange">
              <el-option
                v-for="item in orgList"
                :key="item.orgId"
                :label="item.orgName"
                :value="`${item.orgId}`"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="住宅性质：" prop="listTransHouseProperty">
            <el-checkbox-group :disabled="params.read" v-model="caseDetails.listTransHouseProperty">
              <el-checkbox
                v-for="item in listBaseData.IDI_PROJECT_TYPES"
                :key="item.dictKey"
                :label="item.dictKey"
              >{{item.dictValue}}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="可查看项目区域：">
            <el-table
              class="mc-table district-table"
              tooltip-effect="light"
              :data="caseDetails.listTransArea"
              style="width: 100%;border-radius:2px;"
            >
              <el-table-column prop="province" align="center" label="省">
                <template slot-scope="scope">
                  <span v-if="params.read">{{scope.row.province}}</span>
                  <el-select
                    v-else
                    v-model="scope.row.provinceId"
                    @change="queryCity(scope.row.provinceId,scope.$index)"
                  >
                    <el-option
                      :value="item.provinceId"
                      :label="item.province"
                      v-for="(item,index) in provinceList"
                      :key="index"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="city" align="center" label="市">
                <template slot-scope="scope">
                  <span v-if="params.read">{{scope.row.city}}</span>
                  <el-select
                    v-else
                    v-model="scope.row.cityId"
                    @change="queryDistrict(scope.row.cityId,scope.$index)"
                  >
                    <el-option
                      :value="item.cityId"
                      :label="item.city"
                      v-for="(item,index) in scope.row.cityList"
                      :key="index"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="district" align="center" label="区/县">
                <template slot-scope="scope">
                  <span v-if="params.read">{{scope.row.district}}</span>
                  <el-select
                    v-else
                    v-model="scope.row.districtId"
                    @change="handleItemChange(scope.row,scope.$index)"
                  >
                    <el-option
                      v-for="row in scope.row.districtList"
                      :key="row.id"
                      :label="row.district"
                      :value="row.transId"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column v-if="!params.read" prop="district" align="center">
                <template slot="header" solt-scope="scope">
                  <i @click="doRowAdd" class="el-icon-circle-plus-outline"></i>
                </template>
                <template slot-scope="scope">
                  <i @click="doRowDel(scope.$index)" class="el-icon-remove-outline"></i>
                </template>
              </el-table-column>
            </el-table>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="备注：">
            <el-input
              type="textarea"
              :autosize="{minRows: 2.5}"
              :disabled="params.read"
              placeholder="请输入内容"
              v-model="caseDetails.remark"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23" class="text-right" style="padding: 55px 0 22.5px 0">
          <el-button
            v-if="!params.read"
            type="primary"
            style="background-color: #108FEB"
            size="mini"
            @click="handleSave"
          >确定</el-button>
          <el-button
            size="mini"
            @click="$router.push({name:'AccountManagement',query:{isConstructingUnit:params.isConstructingUnit}})"
          >关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import md5 from "js-md5";
import http from "@/common/request";
export default {
  name: "AccountNew",
  data() {
    return {
      caseDetails: {
        listTransHouseProperty: [],
        listTransArea: [],
        userId: "",
        password: "",
        username: "",
        read: "",
        idCard: "",
        birth: "",
        telephone: "",
        email: "",
        professional: "",
        educationLevel: "",
        major: "",
        mobile: "",
        insOrgId: ""
      },
      orgIdNew:"",
      orgNameNew:"",
      orgList:[],
      readThreeFlag: false,
      roleList: [],
      provinceList: [],
      cityList: [],
      districtList: [],
      rules: {
        userId: [{ required: true, message: "请输入账号" }],
        password: [
          {
            required: true,
            message: "请输入至少八位的密码",
            min: 8,
            trigger: "blur"
          }
        ],
        username: [{ required: true, message: "请输入名称" }],
        idCard: [
          {
            validator: (rule, value, callback) => {
              if (
                !value ||
                /(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$)/.test(
                  value
                )
              ) {
                callback();
              } else {
                callback(new Error("请输入正确的证件号码"));
              }
            }
          }
        ],
        mobile: [
          {
            required: true,
            message: "请输入手机号",
            validator: (rule, value, callback) => {
              if (/^[1]([3-9])[0-9]{9}$/.test(value)) {
                callback();
              } else {
                callback(new Error("请输入正确的手机号"));
              }
            }
          }
        ],
        telephone: [
          {
            message: "请输入办公电话",
            validator: (rule, value, callback) => {
              if (
                !value ||
                /^((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)$/.test(
                  value
                )
              ) {
                callback();
              } else {
                callback(new Error("请输入正确的办公电话"));
              }
            }
          }
        ],
        email: [
          {
            required: true,
            message: "请输入邮箱",
            validator: (rule, value, callback) => {
              if (
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
                  value
                )
              ) {
                callback();
              } else {
                callback(new Error("请输入正确的邮箱"));
              }
            }
          }
        ],
        status: [{ required: true, message: "请选择状态" }],
        roleId: [{ required: true, message: "请选择角色" }],
        orgName: [{ required: true, message: "请选择所属机构" }],
        listTransHouseProperty: [{ required: true, message: "请选择住宅性质" }]
      }
    };
  },
  props: {
    routePath: {
      type: String,
      required: false,
      default: ""
    }
  },
  computed: {
    params() {
      const {
        read,
        userId,
        insOrgId,
        orgType,
        isConstructingUnit
      } = this.$route.query;
      return {
        read,
        userId,
        insOrgId,
        orgType,
        isConstructingUnit
      };
    },
    ...mapGetters(["listBaseData"])
  },
  methods: {
    ...mapActions(["hasNews"]),
    initNews() {
      this.hasNews(false);
    },
    handleItemChange(row, index) {
      this.caseDetails.listTransArea.map((item, index1) => {
        if (index != index1) {
          if (row.districtId == item.districtId) {
            this.$messageError({ message: "区/县已选择" });
            row.districtId= "";
          }
        }
      });
    },
    //检测手机号码是否注册过
    checkMobile() {
      if (/^[1]([3-9])[0-9]{9}$/.test(this.caseDetails.mobile)) {
        http
          .get("/sys/user/getUserByMobile", {
            mobile: this.caseDetails.mobile,
            tenantId: this.$getversionData.lesseeId
          })
          .then(res => {
            //code=0,号码没有注册过；code=1，号码在本平台已经注册；code=2，号码在其他平台注册过
            if (res.code == 1 && this.$route.query.insOrgId) {
              this.caseDetails.mobile = "";
              this.$messageError({ message: res.msg });
            } else if (res.code == 2 && this.$route.query.insOrgId) {
              this.$confirm(
                "此手机号已在其他平台注册，是否在本平台创建账号？",
                "提示",
                {
                  confirmButtonText: "",
                  cancelButtonText: "",
                  type: "warning"
                }
              )
                .then(() => {
                  this.readThreeFlag = true;
                  this.caseDetails.userId = res.data.userId;
                  this.caseDetails.password = res.data.password;
                  this.caseDetails.username = res.data.username;
                  this.caseDetails.read = res.data.read;
                  this.caseDetails.idCard = res.data.idCard;
                  this.caseDetails.birth = res.data.birth;
                  this.caseDetails.telephone = res.data.telephone;
                  this.caseDetails.email = res.data.email;
                  this.caseDetails.professional = res.data.professional;
                  this.caseDetails.educationLevel = res.data.educationLevel;
                  this.caseDetails.major = res.data.major;
                  this.caseDetails.tenantId = this.$getversionData.lesseeId;
                  this.caseDetails.insOrgId = this.$route.query.insOrgId;
                  this.caseDetails.addFlag = "1";
                  this.$refs.userForm.clearValidate();
                })
                .catch(() => {
                  this.caseDetails.mobile = "";
                  this.caseDetails.addFlag = "";
                });
            }
          });
      }
    },
    handlePassword() {
      var regex = new RegExp(
        /((^(?=.*[a-z])(?=.*[A-Z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[A-Z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[a-z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[\da-zA-Z\W]{8,30}$))/
      );
      if (!regex.test(this.caseDetails.password)) {
        this.$messageError({
          message:
            "密码长度为8~30位且必须包含大小写字母、数字、特殊字符至少三项，请及时修改!"
        });
        return;
      }
    },
    async handleQuery() {
      const { userId } = this.params;
      if (userId) {
        const { code, msg, data,orgList } = await this.$api.selectUserByUserId({
          userId,
          tenantId: this.$getversionData.lesseeId
        });
        if (code === 0) {
          this.oldPassword = data.password;
          this.caseDetails = {
            ...data,
            listTransArea: [],
            listTransHouseProperty: []
          };
          this.orgList = orgList;
        } else {
          this.$messageError({ message: msg });
        }
        const {
          code: res,
          msg: message,
          data: { listTransArea, listTransHouseProperty }
        } = await this.$api.userTrans({ userId });
        if (res === 0) {
          if (!this.params.read) {
            this.caseDetails.listTransArea = listTransArea.map(
              (item, index) => {
                this.queryCity(item.provinceId, index);
                this.queryDistrict(item.cityId, index);
                return {
                  districtId: item.transId,
                  cityId: item.cityId,
                  provinceId: item.provinceId
                };
              }
            );
          } else {
            this.caseDetails.listTransArea = listTransArea;
          }
          this.caseDetails.listTransHouseProperty = listTransHouseProperty.map(
            item => item.transId
          );
        } else {
          this.$messageError({ message });
        }
      }
    },
    orgOnChange(val) {
      this.orgIdNew = val;
      this.orgList.forEach(el=>{
        if(el.orgId == val) {
          this.orgNameNew = el.orgName;
        }
      })
    },
    handleSave() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          this.doSaveOrUpdate();
        } else {
          this.$messageError({ message: "请完善信息！" });
        }
      });
    },
    async doSaveOrUpdate() {
      if (this.oldPassword != this.caseDetails.password&&!this.readThreeFlag) {
        var regex = new RegExp(
          /((^(?=.*[a-z])(?=.*[A-Z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[A-Z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[a-z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[\da-zA-Z\W]{8,30}$))/
        );
        if (!regex.test(this.caseDetails.password)) {
          this.$messageError({
            message:
              "密码长度为8~30位且必须包含大小写字母、数字、特殊字符至少三项，请及时修改!"
          });
          return false;
        }
      }
      this.$store.dispatch("loading", true);
      const { insOrgId, userId } = this.params;
      this.caseDetails.listTransArea = this.caseDetails.listTransArea.filter(
        el => {
          return el.provinceId != null;
        }
      );
      this.caseDetails.listTransArea = this.caseDetails.listTransArea.map(
        item => {
          let districtObj,
            cityObj,
            provinceObj = null;
          const {
            districtId,
            cityId,
            provinceId,
            districtList,
            cityList
          } = item;
          if (districtId) {
            districtObj = districtList.filter(
              item => item.transId === districtId
            )[0];
          } else if (cityId) {
            cityObj = cityList.filter(item => item.cityId === cityId)[0];
          } else if (provinceId) {
            provinceObj = this.provinceList.filter(
              item => item.provinceId === provinceId
            )[0];
          }
          return districtId
            ? districtObj
            : cityId
            ? { ...cityObj, flagId: cityObj.cityId }
            : { ...provinceObj, flagId: provinceObj.provinceId };
        }
      );
      if (userId) {
        const { code, msg } = await this.$api.updateUser({
          ...this.caseDetails,
          insOrgId:this.orgIdNew?this.orgIdNew:this.caseDetails.insOrgId,
          orgName:this.orgNameNew,
          listTransHouseProperty: this.caseDetails.listTransHouseProperty.map(
            item => ({ transId: item })
          ),
          ...(this.caseDetails.password !== this.oldPassword && {
            password: md5(this.caseDetails.password)
          })
        });
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.$router.push({
            name: "AccountManagement",
            query: { isConstructingUnit: this.params.isConstructingUnit }
          });
        } else {
          this.$messageError({ message: msg });
        }
      } else {
        //新增
        const { code, msg } = await this.$api.addUser({
          ...this.caseDetails,
          listTransHouseProperty: this.caseDetails.listTransHouseProperty.map(
            item => ({ transId: item })
          ),
          password: md5(this.caseDetails.password),
          tenantId: this.$getversionData.lesseeId,
          insOrgId
        });
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.$router.push({
            name: "AccountManagement",
            query: { isConstructingUnit: this.params.isConstructingUnit }
          });
        } else {
          this.$messageError({ message: msg });
        }
      }
      this.$store.dispatch("loading", false);
    },
    async queryRoleList() {
      const { code, msg, data } = await this.$api.listRoleByuserId({
        orgType: this.params.orgType,
        tenantId: this.$getversionData.lesseeId
      });
      if (code === 0) {
        this.roleList = data;
      } else {
        this.$messageError({ message: msg });
      }
    },
    doRowAdd(scope) {
      this.caseDetails.listTransArea.push({});
    },
    doRowDel(curIndex) {
      const ind = this.caseDetails.listTransArea.findIndex(
        (item, index) => index === curIndex
      );
      this.caseDetails.listTransArea.splice(ind, 1);
    },
    //查询市
    async queryCity(provinceId, index) {
      let { code, msg: message, data } = await this.$api.sysFindAreaAreaCity({
        provinceId
      });
      if (code === 0) {
        let temp = {};
        this.$set(
          this.caseDetails.listTransArea[index],
          "cityList",
          data.filter(item => {
            if (!temp[item.cityId]) {
              temp[item.cityId] = item.cityId;
              return true;
            }
          })
        );
      } else {
        this.$messageError({ message });
      }
    },
    //查询区域
    async queryDistrict(cityId, index) {
      let { code, msg: message, data } = await this.$api.sysFindAreaDistrict({
        cityId
      });
      if (code === 0) {
        this.$set(this.caseDetails.listTransArea[index], "districtList", data);
      } else {
        this.$messageError({ message });
      }
    }
  },
  async created() {
    this.initNews();
    this.handleQuery();
    this.queryRoleList();
    //查询省
    let { code, msg: message, data } = await this.$api.sysFindAreaProvince({});
    if (code === 0) {
      this.provinceList = data;
      // if (this.params.userId) {
      //   await this.queryCity(data[0].provinceId);
      //   await this.queryDistrict((this.cityList[0] || {}).cityId);
      // }
    } else {
      this.$messageError({ message });
    }
  }
};
</script>
<style scoped lang="scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
  .district-table {
    font-size: 12.5px;
  }
}
/deep/ .el-form-item__label {
  font-weight: 500;
}
/deep/ .el-form-item__content {
  .el-icon-view {
    display: none;
  }
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>
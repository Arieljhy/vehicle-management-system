<template>
  <div class="content">
    <!-- 返回键 -->
    <el-row>
      <div @click="$router.push('/systemManagement')" class="case_title mouse-pointer">
        <i class="el-icon-arrow-left"></i>
        <span>{{isConstructingUnit?'建设单位':'账户管理'}}</span>
      </div>
    </el-row>
    <el-row>
      <el-col :span="8">
        <div class="content-left">
          <div class="searchStyle" v-if="!isConstructingUnit">
            <el-input
              placeholder="请输入内容"
              v-model="searchWords"
              >
              <i slot="prefix" class="el-input__icon el-icon-search"></i>
            </el-input>            
          </div>
          <el-table
            :data="searchResult"
            row-key="orgId"
            class="mc-table"
            height="495px"
            ref="singleTable"
            :expand-row-keys="expands"
            highlight-current-row
            @current-change="handleCurrentChange"
            @expand-change = "expandChange"
            :tree-props="{children: 'childrens', hasChildren: 'hasChildren'}"
          >
            <el-table-column prop="orgName" label="名称"></el-table-column>
            <el-table-column width="56" align="center">
              <!-- <template slot="header">
                <span
                  style="font-size: 15.5px; color: #fff"
                  class="mouse-pointer el-dropdown-link"
                  @click="$router.push({name: 'NewAccount',query: {orgPname: currentRow.orgName,orgType: currentRow.orgType}})"
                >
                  <i class="el-icon-circle-plus-outline" style="color:#fff;"></i>
                </span>
              </template>-->
              <template slot-scope="scope">
                <el-dropdown
                  v-if="scope.row.orgName !== '业主'&&scope.row.orgName !== '运营方'"
                  placement="bottom"
                  size="small"
                  trigger="click"
                  @command="(command)=>handleCommand(command,scope.row)"
                >
                  <span
                    style="font-size: 13.5px; color: #fff"
                    class="mouse-pointer el-dropdown-link"
                  >
                    <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
                  </span>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="add">
                      <i class="el-icon-circle-plus-outline iconBlue"></i>新增
                    </el-dropdown-item>
                    <el-dropdown-item
                      v-if="!isConstructingUnit"
                      command="delete"
                    >
                      <!-- <i class="el-icon-remove-outline iconBlue"></i>删除 -->
                    </el-dropdown-item>
                    <el-dropdown-item command="update">
                      <i class="el-icon-edit-outline iconBlue"></i>修改
                    </el-dropdown-item>
                    <el-dropdown-item command="show">
                      <i class="el-icon-view iconBlue"></i>详情
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-col>
      <el-col :span="16">
        <div class="content-right" id="contentRight">
          <el-table class="mc-table" tooltip-effect="light" :data="userList" style="width: 100%">
            <!-- <el-table-column align="center" label="序号" width="80" :show-overflow-tooltip="true">
              <template slot-scope="scope">{{scope.$index+1}}</template>
            </el-table-column> -->
            <el-table-column type="index" align="center" label="序号" width="80" :index='(index)=>{return(index+1)+(pagination.currentPage-1)*pagination.pageSize}'></el-table-column>
            <el-table-column prop="userId" align="center" label="账号" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column
              prop="username"
              align="center"
              label="名称"
              :show-overflow-tooltip="true"
            ></el-table-column>
            <el-table-column prop="mobile" align="center" label="手机" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column prop="email" align="center" label="邮箱" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column prop="roleName" align="center" label="角色" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column prop="status" align="center" label="状态" :show-overflow-tooltip="true">
              <template
                slot-scope="scope"
              >{{scope.row.status==1?"有效":(scope.row.status==0?"无效":"")}}</template>
            </el-table-column>
            <el-table-column align="center">
              <template slot-scope="scope">
                <el-dropdown
                  placement="bottom"
                  size="small"
                  trigger="click"
                  @command="command=>handleUserCommand(command,scope.row.userId)"
                >
                  <span class="el-dropdown-link">
                    <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
                  </span>
                  <el-dropdown-menu slot="dropdown">
                    <!-- <el-dropdown-item command="delete">
                      <i class="el-icon-remove-outline iconBlue"></i>删除
                    </el-dropdown-item> -->
                    <el-dropdown-item command="update">
                      <i class="el-icon-edit-outline iconBlue"></i>修改
                    </el-dropdown-item>
                    <el-dropdown-item command="show">
                      <i class="el-icon-view iconBlue"></i>详情
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            small
            class="text-center mt10 block page-lucency"
            layout="prev, pager, next"
            @current-change="handlePageChange"
            :current-page.sync="pagination.currentPage"
            :page-size="pagination.pageSize"
            :total="pagination.total"
          ></el-pagination>
        </div>
      </el-col>
    </el-row>
    <img
      v-show="(currentRow.orgPid!=='root'||currentRow.orgName === '业主'||currentRow.orgName==='运营方')"
      class="project-collection mouse-pointer"
      id="addAccount"
      draggable="true"
      src="@/assets/imgs/addForm.png"
      width="64"
      height="64"
      @click="$router.push({ name: 'AccountNew',query:{insOrgId:currentRow.orgId,orgType:currentRow.orgType,isConstructingUnit} });"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "NewAccount",
  data() {
    return {
      searchWords:"",
      orgList: [],
      userList: [],
      currentRow: "",
      pagination: {
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      expands:[]
    };
  },
  computed: {
    ...mapGetters(["userInfo"]),
    isConstructingUnit() {
      return this.$route.query.isConstructingUnit;
    },
    searchResult() {
      //获取搜索结果
      if(this.searchWords==""){
        return this.orgList
      }else{
        return this.convert(this.orgList,this.searchWords)
      }
    },
  },
  methods: {

    expandChange(row, expandedRows){
      let that = this
      if(expandedRows){
        that.expands.push(row.orgId)
      }else {
         that.expands = []
      }
      sessionStorage.setItem('IDI_orgId',JSON.stringify(that.expands))
    },
    async handleCommand(command, row) {
      switch (command) {
        case "add": {
          this.$router.push({
            name: "NewAccount",
            query: {
              orgPid: row.orgId,
              orgPname: row.orgName,
              orgType: row.orgType,
              orgTypeName: row.orgTypeName,
              isConstructingUnit: this.isConstructingUnit
            }
          });
          break;
        }
        case "delete": {
          this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(async () => {
              const { code, msg } = await this.$api.deleteOrg(row.orgId);
              if (code === 0) {
                this.$messageSuccess({ message: msg });
                this.handleQuery();
              } else {
                this.$messageError({ message: msg });
              }
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消删除"
              });
            });
          break;
        }
        case "update": {
          this.$router.push({
            name: "NewAccount",
            query: {
              orgId: row.orgId,
              isConstructingUnit: this.isConstructingUnit
            }
          });
          break;
        }
        case "show": {
          this.$router.push({
            name: "NewAccount",
            query: {
              orgId: row.orgId,
              read: true,
              isConstructingUnit: this.isConstructingUnit
            }
          });
          break;
        }
      }
    },
    async handleUserCommand(command, userId) {
      switch (command) {
        case "delete": {
          this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(async () => {
              this.$store.dispatch("loading", true);
              const { code, msg } = await this.$api.deleteUser({ userId });
              if (code === 0) {
                this.$messageSuccess({ message: msg });
                this.handleUserQuery();
              } else {
                this.$messageError({ message: msg });
              }
              this.$store.dispatch("loading", false);
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消删除"
              });
            });
          break;
        }
        case "update": {
          this.$router.push({
            name: "AccountNew",
            query: { userId, isConstructingUnit: this.isConstructingUnit,orgType:this.currentRow.orgType,addOrEdit:'update' }
          });
          break;
        }
        case "show": {
          this.$router.push({
            name: "AccountNew",
            query: {
              userId,
              read: true,
              isConstructingUnit: this.isConstructingUnit
            }
          });
          break;
        }
      }
    },
    async handleCurrentChange(currentRow) {
      this.currentRow = currentRow;
      sessionStorage.setItem('IDI_org',JSON.stringify(this.currentRow))
      this.handleUserQuery();
    },
    async handleQuery() {
      this.$store.dispatch("loading", true);
      const { code, data, msg } = this.isConstructingUnit
        ? await this.$api.listTreeJianShe()
        : await this.$api.orgListTree();
      if (code === 0) {
        this.orgList = data;
       
        if (data && data.length > 0) {
          if(sessionStorage.getItem('IDI_org')){
            this.currentRow = JSON.parse(sessionStorage.getItem('IDI_org'))
            this.expands = JSON.parse(sessionStorage.getItem('IDI_orgId'))
          }else{
            this.currentRow = data[0];
            this.expands = []
          }
          this.$refs.singleTable.setCurrentRow(this.currentRow);
          // this.currentRow = data[0];
          this.handleUserQuery();
        }
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    //根据机构id查询用户列表
    async handleUserQuery() {
       if(!this.currentRow){
        return;
      }
      const { pageSize, currentPage } = this.pagination;
      //limit,每页有多少条，offset,第几页
      const {
        code,
        msg,
        data: { rows, total }
      } = await this.$api.userList({
        tenantId: this.$getversionData.lesseeId,
        InsOrgId: this.currentRow.orgId,
        limit: pageSize,
        offset: currentPage
      });
      if (code === 0) {
        this.userList = rows;
        this.pagination.total = total;
      } else {
        this.$messageError({ message: msg });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleUserQuery();
    },
    convert(arr,keywords) {
      const newArr = [...JSON.parse(JSON.stringify(arr))];
      newArr.map((item) => {
        if (item.childrens&&item.childrens.length>0) {
          item.childrens = this.convert(item.childrens,keywords)
        }
        return item
      })
      return newArr.filter((item) => (item.orgName && item.orgName.indexOf(keywords) >= 0) || (item.childrens&&item.childrens.length>0))
    }

  },
  created() {
    this.handleQuery();
  },
  mounted() {
    this.$doScrollStyle();
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 10px;
  bottom: 15px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.iconBlue {
  color: #2a7be3;
}
.content {
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.content-left {
  border-radius: 0px 0px 0px 6px;
  background:rgba(255,255,255,.2);
  position: relative;
  //margin-right: 35px;
}
.content-right {
  border-radius: 0px 0px 6px 0px;
  position: relative;
  min-height: 490px;
  //margin-left: 35px;
  display: flex;
  flex-direction: column;
}
.page-lucency {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  bottom: 0px;
}
.el-dropdown-menu--small .el-dropdown-menu__item {
  font-size: 13.5px;
}
.mc-table/deep/.current-row > td {
  background: #9fb6cd !important;
}
.searchStyle {
  z-index: 2000;
  width: 80%;
  margin-left: 20px;
  position: absolute;
  right: 0;
  top: 5px;
  /deep/.el-input__inner{
    // border-radius: 10px;
    height: 30px;
    line-height: 30px;
    border: none;
    background-color: rgba(255, 255, 255, 1);
  }
  /deep/.el-input__icon{
    line-height: 30px;
  }
}
</style>
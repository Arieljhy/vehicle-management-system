<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px 35px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">本次整改信息</span>
        </el-col>
        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          :model="dialogCaseDetails"
          :rules="rules"
          ref="ruleForms"
          :disabled="$route.query.type=='view'"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="整改进度(%)：" prop="amendProgress">
                <format-input
                  v-model="dialogCaseDetails.amendProgress"
                  text-align="left"
                  empty-value="0"
                  :max="100"
                  :min="0"
                ></format-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="形象进度：">
                <el-input v-model="dialogCaseDetails.projectVisualProgress"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="检查人：">
                <el-input
                  v-model="dialogCaseDetails.checkPtcp"
                  readonly
                  @click.native="openAgency({title: '检查人', type: 'JCR',num:'5' })"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="整改时间：" prop="riskPepairTime">
                <el-date-picker
                  v-model="dialogCaseDetails.riskPepairTime"
                  value-format="yyyy-MM-dd"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目阶段：">
                <el-select
                  style="width:266px"
                  v-model="dialogCaseDetails.projectPhase"
                  clearable
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_PROJ_PROCESS"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="检查方式：">
                <el-checkbox-group v-model="dialogCaseDetails.checkMethods">
                  <el-checkbox
                    v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                    :disabled="$route.query.type=='view'"
                    :key="item.dictKey"
                    :label="item.dictKey"
                  >{{item.dictValue}}</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="整改描述：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  placeholder="请输入内容"
                  v-model="dialogCaseDetails.amendActionDesc"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="整改图片：">
                <el-table
                  class="mc-table"
                  :data="dialogCaseDetails.imagePathList"
                  style="width: 100%;"
                >
                  <el-table-column prop="address" align="center" label="内容">
                    <template slot-scope="scope">
                      <el-upload
                        action
                        list-type="picture-card"
                        :http-request="(file) => { uploadFile(file, scope.$index,'falg') }"
                        :show-file-list="false"
                        v-if="scope.row.show"
                        :before-upload="beforeAvatarUpload"
                      >
                        <i class="el-icon-plus"></i>
                      </el-upload>
                      <img v-else width="75%" height="160px" :src="scope.row.imgUrl" />
                    </template>
                  </el-table-column>
                  <el-table-column prop="date" align="center" label="描述">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 8}"
                        v-model="scope.row.picDescription"
                      ></el-input>
                    </template>
                  </el-table-column>
                  <el-table-column
                    prop="mobile"
                    align="center"
                    width="80px"
                    v-if="$route.query.type!=='view'"
                  >
                    <template slot="header">
                      <div
                        class="el-icon-circle-plus-outline mouse-pointer"
                        style="font-size:20px;line-height:40px"
                        @click="dialogAddLivePics()"
                      ></div>
                    </template>
                    <template slot-scope="scope">
                      <div
                        class="el-icon-remove-outline mouse-pointer"
                        style="font-size:20px;"
                        @click="dialogDelLivePics(scope.$index)"
                      ></div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row style="text-align: right; margin-top: 50px" class="dialogBtn">
          <el-button
            size="mini"
            type="primary"
            @click="dialogSaveRectification(1)"
            v-if="$route.query.type!=='view'"
          >提交</el-button>
          <el-button size="mini" @click="dialogCloseRectification">关闭</el-button>
        </el-row>
      </div>
    </div>
    <el-dialog class="dialog" :title="title" :visible.sync="openVisible" width="615px" :close-on-click-modal="false">
      <select-agency
        :type="type"
        :title="title"
        @getAngency="getAngency"
        v-if="openVisible"
        :num="num"
        :project="project"
      ></select-agency>
    </el-dialog>
  </div>
</template>
<script>
import { async } from "q";
import { mapGetters, mapActions } from "vuex";
import formatInput from "@/components/formatInput";
import config from "@/common/config";
import SelectAgency from "@/components/selectAgency.vue";
export default {
  name: "RiskReportManagement",
  components: {
    formatInput,
    SelectAgency
  },
  data() {
    return {
      rules: {
        amendProgress: [
          { required: true, message: "请输入内容", trigger: "blur" }
        ],
        riskPepairTime: [
          { required: true, message: "请选择日期", trigger: "change" }
        ]
      },
      tenantId: undefined,
      radio: "",
      textarea: "",
      dialogImageUrl: "",
      dialogVisible: false,
      caseDetails: {
        riskEventDO: {},
        riskEventPicDO: [],
        userDO: [],
        rectificationInfo: {
          riskEventId: "", //风险事件编号
          riskPepairTime: "", // 整改时间
          projectPhase: "", // 项目阶段
          amendProgress: "", // 整改进度
          amendActionDesc: "", // 整改描述
          projectVisualProgress: "", // 形象进度
          checkMethod: "", // 检查方式
          checkPtcp: "", // 检查人
          imagePathList: []
        },
        rectificationHistoryList: []
      },
      rectificationEdit: false,
      verificationPass: false,
      dialogCaseDetails: {
        //弹窗数据
        imagePathList: [],
        checkMethods: []
      },
      disabled: "",
      rid: "",
      openVisible: false,
      type: "",
      title: "",
      num: "",
      project: ""
    };
  },
  computed: {
    ...mapGetters(["listBaseData", "getOrgId"])
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    if (this.$route.query.type == "edit") {
      this.querySettlement();
    } else {
      this.odsRiskEventRepairDetails();
    }
  },
  methods: {
    //查询有无此项目
    async querySettlement() {
      const res = await this.$api.enquiryPolicy({
        type: "风控管理",
        insContractNo: this.$route.query.insContractNo
      });
      if (res.code == 500) {
        this.open(res.msg);
      } else {
        this.odsRiskEventRepairDetails();
      }
    },
    open(res) {
      this.$alert(res, {
        confirmButtonText: "确定",
        callback: action => {
          this.closeRectification();
        }
      });
    },
    openAgency(data) {
      this.openVisible = true;
      this.type = data.type;
      this.title = data.title;
      this.num = data.num;
      this.project = this.$route.query.projectId;
    },
    getAngency(value) {
      this.dialogCaseDetails.checkPtcp = value.username;
      this.openVisible = false;
    },
    //请求数据
    async odsRiskEventRepairDetails() {
      const rid = {
        id: this.$route.query.id,
        tenantId: this.tenantId
      };
      const res = await this.$api.odsRiskEventRepairDetails(rid);
      this.dialogCaseDetails = res.data;
      this.dialogCaseDetails.imagePathList.map((item, index) => {
        item.imgUrl =
          `/api/anyShare/fileOperation/downloadDocument?cloudDocId=${item.picPath}&view=1`;
      });
    },
    //弹窗关闭
    dialogCloseRectification() {
      this.$router.go(-1);
    },
    //弹窗增加
    dialogAddLivePics() {
      let dialogNewPic = {
        picType: "2",
        picPath: "",
        picDescription: "",
        picName: "",
        show: true
      };
      this.dialogCaseDetails.imagePathList.push(dialogNewPic);
    },
    //弹窗删除
    dialogDelLivePics(index) {
      this.dialogCaseDetails.imagePathList.splice(index, 1);
    },
    //上传校验
    beforeAvatarUpload(file) {
      var isJPG = false;
      switch (file.type) {
        case "image/png":
          isJPG = true;
          break;
        case "image/jpeg":
          isJPG = true;
          break;
        case "image/jpg":
          isJPG = true;
          break;
        case "image/gif":
          isJPG = true;
          break;
        case "image/tiff":
          isJPG = true;
          break;
        default:
          isJPG = false;
          break;
      }
      if (!isJPG) {
        this.$message.error("请上传正确的图片格式!");
        this.show = true;
      }
      return isJPG;
    },
    //上传
    uploadFile(param, rpid, falg) {
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "riskEventRepairPic");
      file.append("projectId", this.$route.query.projectId);
      this.$api.pictureProcessDoc(file).then(res => {
        if (res.code == 0) {
          if (falg) {
            this.dialogCaseDetails.dialogRectificationInfo.imagePathList.map(
              (item, index) => {
                if (rpid == index) {
                  item.picPath = res.data.cloudDocId;
                  item.picName = res.data.fileName;
                  item.show = item.picPath ? false : true;
                  item.imgUrl =
                    `/api/anyShare/fileOperation/downloadDocument?cloudDocId=${item.picPath}&view=1`;
                }
              }
            );
          } else {
            this.caseDetails.rectificationInfo.imagePathList.map(
              (item, index) => {
                if (rpid == index) {
                  item.picPath = res.data.cloudDocId;
                  item.picName = res.data.fileName;
                  item.show = item.picPath ? false : true;
                  item.imgUrl =
                    `/api/anyShare/fileOperation/downloadDocument?cloudDocId=${item.picPath}&view=1`;
                }
              }
            );
          }
        } else {
          this.$messageError({ message: res.msg });
        }
      });
    },
    //弹窗保存提交
    async dialogSaveRectification(flag) {
      this.$refs["ruleForms"].validate(valid => {
        if (valid) {
          this.verificationPass = true;
        } else {
          return false;
        }
      });
      if (this.verificationPass) {
        let keywordsBase = this.dialogCaseDetails;
        const res = await this.$api.odsRiskEventRepairPreservation(
          keywordsBase
        );
        if (res.code === 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.closeRectification();
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
    },
    closeRectification() {
      this.$router.go(-1);
    },
    //删除
    async deleteRectification() {
      const res = await this.$api.deleteRectificationEvent(this.rid);
      if (res.code === 0) {
        this.$messageSuccess({
          message: res.msg
        });
        this.getRectificationHistoryInfo();
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    //获取整改基本信息
    async getRectificationBaseInfo() {
      const projectId = this.$route.query.id;
      const res = await this.$api.rectificationBaseInfo(projectId);
      this.caseDetails.riskEventDO = res.data.riskEventDO;
      this.caseDetails.riskEventPicDO = res.data.riskEventPicDO;
      this.caseDetails.riskEventPicDO.map((item, index) => {
        item.show = item.picPath ? false : true;
        item.imgUrl =
          `/api/anyShare/fileOperation/downloadDocument?cloudDocId=${item.picPath}&view=1`;
      });
      this.caseDetails.userDO = res.data.userDO || [];
    },
    //获取本次整改基本信息
    async getRectificationHistoryInfo() {
      const keywords = {
        riskEventId: this.$route.query.id,
        offset: 1,
        limit: 5
      };
      const res = await this.$api.rectificationHistoryInfo(keywords);
      this.caseDetails.rectificationHistoryList = res.data.rows;
      this.caseDetails.total = res.data.total;
    }
  }
};
</script>
<style scoped lang="scss">
.content {
  background: rgba(255, 255, 255, 0.9);
}
.el-form-item--mini {
  margin-bottom: 12px;
}
.lucency {
  opacity: 0;
}
.btns {
  position: fixed;
  right: 210px;
  bottom: 20px;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
</style>
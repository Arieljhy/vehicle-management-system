<template>
  <div style=" position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>ODS理赔</span>
        </div>
        <!-- IDI_CLAIM_HANDLE_PROGRESS -->
      </el-row>
      <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
        <el-row>
          <el-col :span="24">
            <div class="content-right" id="contentRight">
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="userList"
                style="width: 100%"
                @row-dblclick="dbGoVisitDetails"
              >
                <!-- <el-table-column type="index" align="center" label="序号" width="80"></el-table-column> -->
                <el-table-column type="index" align="center" label="序号" width="80" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
                <el-table-column prop="date" align="center" label="状态" width="80">
                  <template slot-scope="scope">
                    <span v-if="scope.row.claimId">
                      <i class="el-icon-success" style="color:#48d916;font-size: 15px;"></i>
                    </span>
                    <span v-else>
                      <i class="el-icon-error" style="color:red;font-size: 15px;"></i>
                    </span>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="insContractNo"
                  align="center"
                  label="保单号"
                  :show-overflow-tooltip="true"
                ></el-table-column>
                <el-table-column
                  prop="insCaseReportId"
                  align="center"
                  label="报案号"
                  :show-overflow-tooltip="true"
                ></el-table-column>
                <el-table-column
                  prop="insClaimId"
                  align="center"
                  label="赔案号"
                  :show-overflow-tooltip="true"
                ></el-table-column>
                <el-table-column
                  prop="caseRreportDate"
                  align="center"
                  label="报案日期"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">{{ scope.row.caseRreportDate | filterDate}}</template>
                </el-table-column>
                <el-table-column
                  prop="claimDate"
                  align="center"
                  label="赔偿日期"
                  :show-overflow-tooltip="true"
                >
                  <template slot-scope="scope">{{ scope.row.claimDate | filterDate}}</template>
                </el-table-column>
                <el-table-column align="center" width="100">
                  <template slot-scope="scope">
                    <el-dropdown
                      placement="bottom"
                      size="small"
                      trigger="click"
                      @command="handleCommand(scope.row,$event)"
                    >
                      <span class="el-dropdown-link">
                        <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                      </span>
                      <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item
                          icon="el-icon-edit-outline"
                          command="2"
                          v-if="!scope.row.claimId"
                        >修改</el-dropdown-item>
                        <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                      </el-dropdown-menu>
                    </el-dropdown>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-col>
        </el-row>
      </el-form>
      <el-pagination
        small
        class="text-center mt10 control block page-lucency"
        @current-change="handleCurrentChangePaging"
        :current-page.sync="offset"
        :page-size="this.limit"
        layout="prev, pager, next"
        :total="this.total"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "NewAccount",
  data() {
    return {
      tenantId: undefined,
      insOrgId: undefined,
      addedBuildingWindows: false,
      limit: 6, //每页几条数据
      offset: 1, //第几页
      total: undefined,
      userList: []
    };
  },
  created() {
    this.tenantId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).tenantId;
    // this.insOrgId = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).insOrgId;
    this.hasNews(true);
    this.odsDetailsList();
  },
  methods: {
    ...mapActions(["hasNews"]),
    // 接口
    async odsDetailsList() {
      const keywords = {
        tenantId: this.tenantId,
        // insOrgId: this.insOrgId,
        offset: this.offset,
        limit: this.limit
      };
      const res = await this.$api.odsDetailsList(keywords);
      this.userList = res.rows;
      this.total = res.total;
    },
    //弹窗关闭
    residentialClosingButton() {
      this.addedBuildingWindows = false;
    },
    //新增
    newContent() {
      this.addedBuildingWindows = true;
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
    },
    handleCurrentChange() {},
    handleCommand(item, command) {
      if (command === "0") {
        //查看
        this.goRiskReportDetails(item.id, item.insContractNo, "view");
      } else if (command === "1") {
        //删除数据
        this.$message("删除成功");
      } else if (command === "2") {
        //修改
        this.goRiskReportDetails(item.id, item.insContractNo, "edit");
      }
    },
    //查看view、修改edit
    goRiskReportDetails(id, insContractNo, type) {
      this.$router.push({
        path: "/claimBrowsing",
        query: {
          id: id,
          insContractNo: insContractNo,
          type: type
        }
      });
    },
    //双击进入详情
    dbGoVisitDetails(row) {
      this.goRiskReportDetails(row.id, "view");
    },
    backMytodo() {
      this.$router.push("/systemManagement");
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 10px;
  bottom: 15px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.iconBlue {
  color: #2a7be3;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.content-left {
  border-radius: 0px 0px 0px 6px;
  //margin-right: 35px;
}
.content-right {
  border-radius: 0px 0px 6px 0px;
  //margin-left: 35px;
  display: flex;
  flex-direction: column;
}
.page-lucency {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  bottom: 20px;
}
.el-dropdown-menu--small .el-dropdown-menu__item {
  font-size: 13.5px;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 50%;
}
</style>
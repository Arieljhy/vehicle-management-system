<template>
  <div class="content">
    <el-row>
      <!-- 返回键 -->
      <el-row>
        <div @click="$router.push('/systemManagement')" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>保险条款</span>
        </div>
      </el-row>
      <el-col :span="8" class="retract">
        <el-table
          class="mc-table"
          @current-change="handleCurrentChange"
          highlight-current-row
          height="495px"
          tooltip-effect="light"
          :data="orgList"
          row-key="orgId"
          :tree-props="{children: 'childrens', hasChildren: 'hasChildren'}"
        >
          <el-table-column prop="orgName" align="left" label="名称"></el-table-column>
        </el-table>
      </el-col>
      <el-col :span="16" class="content-right">
        <el-table
          class="mc-table"
          tooltip-effect="light"
          :data="insLiabilityList"
          style="width: 100%"
        >
          <!-- <el-table-column align="center" label="序号" width="60">
            <template slot-scope="scope">{{scope.$index+1}}</template>
          </el-table-column> -->
          <el-table-column type="index" align="center" label="序号" width="80" :index='(index)=>{return(index+1)+(pagination.currentPage-1)*pagination.pageSize}'></el-table-column>
          <el-table-column prop="version" align="center" label="保单版本" width="100">
            <template slot-scope="scope">{{$getValueByCode("insuranceVersion",scope.row.version)}}</template>
          </el-table-column>
          <el-table-column prop="type" align="center" label="类型" width="100">
            <template slot-scope="scope">{{$getValueByCode("insuranceType",scope.row.type)}}</template>
          </el-table-column>
          <el-table-column
            prop="deadline"
            align="center"
            label="期限(年)"
            width="70"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column
            prop="clause"
            align="center"
            label="条款名称"
            width="100"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column
            prop="description"
            align="center"
            label="描述"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column align="center">
            <template slot-scope="scope">
              <el-dropdown
                placement="bottom"
                size="small"
                trigger="click"
                @command="command=>handleCommandChange(command,scope.row.id,scope.row.version)"
              >
                <i class="el-icon-more"></i>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item icon="el-icon-remove-outline" command="delete">删除</el-dropdown-item>
                  <el-dropdown-item icon="el-icon-edit-outline" command="update">修改</el-dropdown-item>
                  <el-dropdown-item icon="el-icon-view" command="show">详情</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          small
          class="page-lucency"
          layout="prev, pager, next"
          @current-change="handlePageChange"
          :current-page.sync="pagination.currentPage"
          :page-size="pagination.pageSize"
          :total="pagination.total"
        ></el-pagination>
      </el-col>
    </el-row>
    <img
      v-show="currentRow.orgPid!=='root'&&currentRow.orgType === 'INS'"
      class="project-collection mouse-pointer"
      id="addAccount"
      draggable="true"
      src="@/assets/imgs/addForm.png"
      width="64"
      height="64"
      @click="orgList&&orgList.length>0&&Add()"
    />
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "InsuranceTreatyt",
  components: {
    MessageEdit
  },
  data() {
    return {
      orgId: null,
      orgList: [],
      insLiabilityList: [],
      currentRow: {},
      pagination: {
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      roleType: null
    };
  },
  created() {
    this.roleType = JSON.parse(sessionStorage.getItem("eidi.ins")).orgType;
    if (this.roleType == "OP") {
      this.orgId = "";
    } else {
      this.orgId = JSON.parse(sessionStorage.getItem("eidi.ins")).orgId;
    }
    this.handleQuery();
  },
  mounted() {
    this.$doScrollStyle();
  },
  methods: {
    async handleQuery() {
      this.$store.dispatch("loading", true);
      let keywords = { orgId: this.orgId };
      const { code, data, msg } = await this.$api.listTreeLicenilities(
        keywords
      );
      if (code === 0) {
        this.orgList = data;
        if (data && data.length > 0) {
          this.currentRow = data[0];
          this.handleInsuranceQuery();
        }
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    async handleInsuranceQuery() {
      this.$store.dispatch("loading", true);
      const { pageSize, currentPage } = this.pagination;
      //limit:每页有多少条，offset:第几页
      const {
        code,
        data: { total, rows },
        msg
      } = await this.$api.insLiabilities({
        insOrgId: this.currentRow.orgId,
        limit: pageSize,
        offset: currentPage
      });
      if (code === 0) {
        this.insLiabilityList = rows;
        this.pagination.total = total;
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    handleCurrentChange(currentRow) {
      this.currentRow = currentRow;
      this.handleInsuranceQuery();
    },
    async handleCommandChange(command, id, version) {
      switch (command) {
        case "delete": {
          this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(async () => {
              const { code, msg } = await this.$api.deleteInsLiability({
                id,
                insOrgId: this.currentRow.orgId,
                version
              });
              if (code === 0) {
                this.$messageSuccess({ message: msg });
                this.handleInsuranceQuery();
              } else {
                this.$messageError({ message: msg });
              }
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消删除"
              });
            });

          break;
        }
        case "update": {
          this.$router.push({
            name: "InsuranceTreatyAdd",
            query: { id, insOrgId: this.currentRow.orgId }
          });
          break;
        }
        case "show": {
          this.$router.push({
            name: "InsuranceTreatyAdd",
            query: { read: true, id, insOrgId: this.currentRow.orgId }
          });
          break;
        }
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleInsuranceQuery();
    },
    Add() {
      this.$router.push({
        name: "InsuranceTreatyAdd",
        query: { insOrgId: this.currentRow.orgId }
      });
    }
  }
};
</script>
<style scoped lang="scss" rel="stylesheet/scss">
.content {
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.content-right {
  position: relative;
  min-height: 490px;
}
.el-table th > .cell {
  height: 39px !important;
  line-height: 39px !important;
}
.el-table > .cell {
  height: 38px;
  line-height: 38px;
}
.retract {
  border-radius: 0 0 0 6px;
  background: rgba(255, 255, 255, 0.2);
}

// .retract /deep/ .el-table /deep/ .cell {
//   padding-left: 30px;
// }
.el-icon-more {
  color: #2a7be3;
  font-size: 20px;
}
// table透明
.mc-table /deep/ .el-table__row {
  background-color: rgba(255, 255, 255, 0.1);
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.project-collection {
  position: absolute;
  right: 10px;
  bottom: 15px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.page-lucency {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  bottom: 20px;
}
.el-dropdown-menu {
  background: rgba(255, 255, 255, 0.8);
  cursor: pointer;
}
</style>
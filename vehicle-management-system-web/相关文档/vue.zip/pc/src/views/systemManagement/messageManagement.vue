<template>
  <div style=" position: relative">
    <div class="content">
      <el-row>
        <div @click="backMytodo" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>消息管理</span>
        </div>
      </el-row>
      <el-form class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
        <el-row>
          <el-col :span="7" style="height:100%">
            <div
              class="content-left"
              style="border-radius: 0px 0px 6px 6px;min-height: 495px;background-color: rgba(255, 255, 255, 0.9);"
            >
              <el-table
                ref="singleTable"
                :data="orgList"
                row-key="orgId"
                class="mc-table"
                height="495px"
                highlight-current-row
                @cell-click="cellClick"
              >
                <el-table-column prop="orgName" label="模板类型"></el-table-column>
              </el-table>
            </div>
          </el-col>
          <el-col :span="17">
            <el-table
              class="mc-table"
              tooltip-effect="light"
              :data="administrationList"
              style="width: 100%;border-radius: 0 0 5px 0;font-size: 12px;"
              @row-dblclick="dbGoVisitDetails"
            >
              <!-- <el-table-column type="index" prop="date" align="center" label="序号" width="150"></el-table-column> -->
              <el-table-column type="index" prop="date" align="center" label="序号" width="150" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="address" align="center" label="状态">
                <template slot-scope="scope">
                  <div v-if="scope.row.status=='DISABLE'">禁用</div>
                  <div v-if="scope.row.status=='ACTIVED'">有效</div>
                </template>
              </el-table-column>
              <el-table-column prop="templateName" align="center" label="模版名称"></el-table-column>
              <el-table-column prop="modifiedDate" align="center" label="最后修改时间">
                <template slot-scope="scope">{{ scope.row.modifiedDate | filterDate}}</template>
              </el-table-column>
              <el-table-column prop="address" align="center" width="120px">
                <template slot-scope="scope">
                  <el-dropdown
                    placement="bottom"
                    size="small"
                    trigger="click"
                    @command="handleCommand(scope.row,$event)"
                  >
                    <span class="el-dropdown-link">
                      <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                      <!-- <el-dropdown-item icon="el-icon-remove-outline" command="1">删除</el-dropdown-item> -->
                      <el-dropdown-item icon="el-icon-edit-outline" command="2">修改</el-dropdown-item>
                      <el-dropdown-item icon="el-icon-view" command="0">详情</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-pagination
          small
          class="text-center mt10 control block page-lucency"
          @current-change="handleCurrentChangePaging"
          :current-page.sync="offset"
          :page-size="this.limit"
          layout="prev, pager, next"
          :total="this.total"
        ></el-pagination>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import formatInput from "@/components/formatInput";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "MailManagement",
  components: {
    MessageEdit,
    formatInput
  },
  computed: {
    ...mapGetters(["app"])
  },
  data() {
    return {
      orgList: [
        { orgName: "流程节点提醒", code: "Process node" },
        { orgName: "业务规则提醒", code: "Business rule" },
        { orgName: "任务提醒", code: "Task reminder" }
      ],
      value: "",
      limit: 10, //每页几条数据
      offset: 1, //第几页
      total: undefined,
      index: "1",
      administrationList: [],
      multipleSelection: [],
      templateType: "Process node"
    };
  },
  created() {
    this.emailTemplate();
  },
  mounted() {
    //判断点击table的颜色
    this.$refs.singleTable.setCurrentRow(this.orgList[0]);
  },
  methods: {
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    //分页
    handleCurrentChangePaging(val) {
      this.offset = val;
      this.emailTemplate();
    },
    //列表请求
    async emailTemplate() {
      const rid = {
        templateType: this.templateType,
        limit: this.limit,
        offset: this.offset
      };
      const res = await this.$api.emailTemplate(rid);
      this.administrationList = res.rows;
      this.total = res.total;
    },
    //点击table
    cellClick(row) {
      this.offset = 1;
      this.templateType = row.code;
      this.emailTemplate();
    },
    handleCommand(item, command) {
      if (command === "0") {
        //查看
        this.goRiskReportDetails(item.id, "view");
      } else if (command === "1") {
        //删除数据
      } else if (command === "2") {
        //修改
        this.goRiskReportDetails(item.id, "edit");
      }
    },
    //查看view、修改edit
    goRiskReportDetails(id, type) {
      this.$router.push({
        path: "/mailBrowsing",
        query: {
          id: id,
          type: type
        }
      });
    },
    //双击进入详情
    dbGoVisitDetails(row) {
      this.goRiskReportDetails(row.id, "view");
    },
    backMytodo() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="scss" scoped>
.odd-table {
  font-size: 13px;
  white-space: nowrap;
}
.el-table_1_column_5 .cell {
  font-size: 12px;
}
.el-table_2_column_1 .cell {
  padding-left: 14px;
  padding-right: 0px;
}
.beijing {
  position: absolute;
  right: 25px;
  bottom: 30px;
  opacity: 0.7;
  width: 76.5px;
  height: 76.5px;
  background: #297ae3ff;
  border-radius: 8px;
  cursor: pointer;
}
.control {
  position: absolute;
  bottom: 30px;
  right: 0px;
  left: 300px;
}
.shizi {
  text-align: center;
  padding-top: 15px;
  padding-left: 25px;
  font-size: 26px;
  font-weight: bold;
  color: #e2e2e2ff;
}
.typeface {
  padding-top: 10px;
  text-align: center;
  height: 10px;
  font-size: 10.5px;
  font-family: Source Han Sans CN;
  font-weight: bold;
  color: rgba(226, 226, 226, 1);
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  width: 150px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.mc-table/deep/.current-row > td {
  background: #9fb6cd !important;
}
</style>
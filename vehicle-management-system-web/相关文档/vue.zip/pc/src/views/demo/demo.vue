<template>
  <div class="home">
    <el-row>
      <el-upload action :http-request="uploadFile" :show-file-list="false">
        <el-button size="small" type="primary">点击上传</el-button>
        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
      </el-upload>
    </el-row>
    <!-- formatInput用法 -->
    <el-row>
      <h2>input 千分位</h2> {{$getversionData}}
      model:{{ amount }}
      <div>
        <format-input
          currency="¥"
          clearable
          :precision="2"
          v-model="amount"
          :max="10000000"
          :min="-10000000"
          empty-value="-"
          :minus="true"
          text-align="right"
        />
      </div>
      <h2>input 千分位-百分号</h2>
      model:{{ percent1 }}
      <div>
        <format-input type="percent" :precision="4" v-model="percent1" :minus="true" />
      </div>
      <p>precision-小数点位数</p>
      <p>currency-自定义符号</p>
      <p>currencySymbolPosition-自定义符号位置</p>
      <p>clearable-清空</p>
      <p>separator-分隔符</p>
      <p>emptyValue-值为空或0时自定义显示内容</p>
      <p>read-only="true"-只显示文本</p>
      <p>max-最大值</p>
      <p>min-最小值</p>
      <p>minus-boolean-是否启动负数和最小值</p>
      <p>text-align -string- 文本对齐方式</p>
    </el-row>
    <!-- formatInput校验 -->
    <el-form :inline="true" :model="form" :rules="rules" ref="ruleForm" label-width="140px">
      <el-form-item class="is-required" label="formatInput校验">
        <formatInput :error="error" :required="true" style="width: 222px" v-model="form.email" />
      </el-form-item>
      <el-form-item class="text-left" label="input校验" prop="phone">
        <el-input style="width: 222px;" v-model="form.phone"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="formValid">提交</el-button>
      </el-form-item>
    </el-form>

    <el-row>
      <el-col :span="24">
        <!-- <HelloWorld msg="Welcome to Your Vue.js App" /> -->
        <vue-qr
          :text="downloadData.url"
          :margin="0"
          colorDark="RGB(203,164,59)"
          colorLight="#fff"
          :logoSrc="downloadData.icon + '?cache'"
          :logoScale="0.22"
          :size="90"
        ></vue-qr>
      </el-col>
    </el-row>
    <div>
      <button @click="openAgency('')">添加机构人</button>
      <el-dialog
        class="dialog user-dialog"
        :title="title"
        :visible.sync="openVisible"
        width="800px"
        :close-on-click-modal="false"
      >
        <select-agency :type="type" :title="title" @getAngency="getAngency" v-if="openVisible"></select-agency>
      </el-dialog>
    </div>
    <div title="展示全部内容">123123123</div>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from "@/components/HelloWorld.vue";
import formatInput from "@/components/formatInput";
import upload from "@/common/request/index.js";
import SelectAgency from "@/components/selectAgency.vue";
import vueQr from "vue-qr";
import erweima from "@/assets/imgs/erweima.png";
import http from "@/common/request";
// 引入基本模板

// import fileApi from "@/common/api/demo/index";
// import echartApi from "@/common/api/echart/index";
export default {
  name: "home",
  components: {
    HelloWorld,
    formatInput,
    SelectAgency,
    vueQr
  },
  data() {
    return {
      erweima,
      downloadData: {
        url:
          "http://172.16.19.175:8080/search/search?content=feb5e4e7c21032969f50163e3426fcb3a8b76e0e211943958610f1344f442ccd",
        icon: erweima
      },
      form: {},
      error: false,
      rules: {
        phone: [{ required: true, message: "请输入", trigger: "blur" }]
      },
      amount: "12332",
      percent1: "12",
      beijingData: {
        data: [
          { name: "延庆区", value: 2 },
          { name: "怀柔区", value: 4 },
          { name: "密云区", value: 5 },
          { name: "昌平区", value: 10 },
          { name: "顺义区", value: 2 },
          { name: "平谷区", value: 6 },
          { name: "门头沟区", value: 2 },
          { name: "海淀区", value: 4 },
          { name: "朝阳区", value: 2 },
          { name: "石景山区", value: 3 },
          { name: "西城区", value: 8 },
          { name: "东城区", value: 7 },
          { name: "丰台区", value: 8 },
          { name: "房山区", value: 3 },
          { name: "大兴区", value: 0 },
          { name: "通州区", value: 9 }
        ],
        title: {
          text: "未整改风险事件分布图demo", //地图标题
          x: "",
          y: "",
          top: "",
          left: "" //标题位置
        },
        dataRange: {
          show: true, //是否显示图例
          min: 0,
          max: 10, //图例标识最大值
          text: ["High", "Low"],
          color: ["#f8b9ce", "#00adef", "#8ec63f", "#f36523", "#ed207b"] //颜色渐变
        }
      },
      shanghaiData: {
        title: {
          text: ""
        },
        data: [
          // { name: '黄浦区', value: 2 },
          // { name: '普陀区', value: 2 },
          // { name: '崇明县', value: 2 },
          // { name: '宝山区', value: 2 },
          // { name: '杨浦区', value: 2 },
          // { name: '虹口区', value: 2 },
        ]
      },
      pagerCount: 5,
      pageSize: 10,
      total: 60,
      id: "",
      option: {
        title: { text: "北京市各区保费收入占比", x: "center" },
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
          orient: "vertical",
          x: "right",
          top: 35
        },
        series: [
          {
            name: "访问来源",
            type: "pie",
            radius: ["50%", "70%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: "30",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: [
              { value: 335, name: "直接访问" },
              { value: 310, name: "邮件营销" },
              { value: 234, name: "联盟广告" },
              { value: 135, name: "视频广告" },
              { value: 1548, name: "搜索引擎" }
            ]
          }
        ]
      },
      type: {},
      openVisible: false,
      type: "",
      title: ""
    };
  },
  created() {
    // this.demo();
    // this.chart();
    // this.myDemo();
    this.checkER();
    this.messa();
  },
  methods: {
    messa() {
      const list = ["apple", "pire"];
      const mydata = {
        appleName: "zhongguo",
        appleId: "22",
        pireName: "323432",
        pireId: "wrwe",
        pigName: "",
        pigeId: ""
      };
      const rightList = [];
      list.map((ob, index) => {
        for (var item in mydata) {
          const keywords = { key: "", value: "" };
          if (item.indexOf(ob) > -1) {
            keywords.key = mydata[ob + "Id"];
            keywords.value = mydata[ob + "Name"];
          }
          if (keywords.key) {
            rightList.push(keywords);
          }
        }
      });

      console.log(rightList);
      console.log(this.quchong(rightList));
      return this.quchong(rightList)
    },
    quchong(arr) {
      var obj = {};
      arr = arr.reduce(function(item, next) {
        obj[next.key] ? "" : (obj[next.key] = true && item.push(next));
        return item;
      }, []);
      return arr
    },
    checkER() {
      http
        .get("/project/blockchain/", "eidi-beijing2019112210154114002")
        .then(res => {
          console.log(res);
          this.downloadData.url =
            "http://172.16.19.175:8080/search/search?content=" +
            res.data.underwritingHash;
        });
    },
    openAgency() {
      this.openVisible = true;
      this.type = "canyuren";
    },
    getAngency(value) {
      this.openVisible = false;
    },
    uploadFile(param) {
      let file = new FormData();
      file.append("file", param.file);
      let data = {
        taskName: "taskName11",
        projectId: "projectId1"
      };
      file.append("taskName", "taskName11");
      file.append("projectId", "projectId1");
      upload.post("/processDoc/uploadProcessDocTmp", file).then(res => {});
    },

    formValid() {
      this.$refs["ruleForm"].validate(valid => {
        this.error = true;
        let valids = [this.form.email];
        for (let v of valids) {
          if (!v && v != 0) {
            return false;
          }
        }
        if (valid) {
          console.log("校验通过");
        }
      });
    },
    async demo() {
      const account = { insex: 1 };
      // const res = await this.$api.demo(account);
      // this.fileList = res;
      // console.log(res);
    },
    async chart() {
      const account = { insex: 1 };
      const res = await this.$api.myChart(account);
      this.fileList = res;
      this.shanghaiData = res.myChart.shanghaiData;
      console.log(this.shanghaiData);
    },
    handleSizeChange(v) {
      console.log(`每页 ${v} 条`);
    },
    handleCurrentChange(v) {
      console.log(`当前页: ${v}`);
    },
    myDemo() {
      const lists = [
        {
          result: [{ name: "5", value: 22 }, { name: "6", value: 33 }],
          name: "平安财险"
        },
        { result: [{ name: "12", value: 44 }], name: "平安财险" }
      ];

      lists.map((item, num) => {
        item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        item.result.map(itemChild => {
          item.data.map((list, index) => {
            if (itemChild.name == index + 1) {
              item.data.splice(index, 1, itemChild.value);
            }
          });
        });
      });
      console.log(lists);
    }
  },
  mounted() {}
};
</script>
<style>
</style>

<template>
  <div>
    <el-dialog title="请重新登录" :visible.sync="relogin" width="30%">
      <span>这是一段信息</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="goLogin()">确 定</el-button>
      </span>
    </el-dialog>
    <!--  :before-close="handleClose"  -->
    <el-dialog
      v-if="infoDropdown.changePwd"
      :title="infoDropdown.command == 'changePassword' ? '修改密码' : '个人信息'"
      class="change-pwd"
      :visible.sync="infoDropdown.changePwd"
      width="299.5px"
      top="34vh"
      :show-close="close"
      :close-on-click-modal="false"
    >
      <el-form :model="loginForm" :rules="rules" ref="ruleForm" label-width="75px">
        <el-row class="dialog-body">
          <el-col :class="[infoDropdown.command == 'info' ? 'mt5' : 'mt10']" :span="24">
            <img
              :src="infoDropdown.command == 'info' ? userInfo.userImage ? userInfo.userImage:imgs : logoIDI"
              :class="[infoDropdown.command == 'info' ? 'head-portrait' : 'logo']"
            />
          </el-col>
          <el-col v-if="infoDropdown.command == 'changePassword'" :span="24">
            <el-col style="margin-top: 15px" :span="24">
              <el-form-item label="原密码：" prop="oldPwd">
                <el-input type="password" v-model="loginForm.oldPwd"></el-input>
              </el-form-item>
            </el-col>
            <el-col style="margin-top: 27px" :span="24">
              <el-form-item label="输入新密码：" prop="password">
                <el-input type="password" v-model="loginForm.password"></el-input>
              </el-form-item>
            </el-col>
            <el-col style="margin-top: 27px" :span="24">
              <el-form-item label="确认新密码：" prop="againPwd">
                <el-input type="password" v-model="loginForm.againPwd"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
          <el-col v-else :span="24">
            <el-col class="mt5" :span="24">
              <el-form-item label="姓名：" class="text-left">
                <span>{{userInfo.username}}</span>
              </el-form-item>
            </el-col>
            <el-col class="mt10" :span="24">
              <el-form-item label="证件号：" class="text-left">
                <div :title="userInfo.idCard" class="hide_more_text">{{userInfo.idCard}}</div>
              </el-form-item>
            </el-col>
            <el-col class="mt10" :span="24">
              <el-form-item label="用户名：" class="text-left">
                <div :title="userInfo.userId" class="hide_more_text">{{userInfo.userId}}</div>
              </el-form-item>
            </el-col>
            <el-col class="mt10" :span="24">
              <el-form-item label="邮箱：" class="text-left">
                <div class="hide_more_text" :title="userInfo.email">{{userInfo.email}}</div>
              </el-form-item>
            </el-col>
            <el-col class="mt10" :span="24">
              <el-form-item label="手机号：" class="text-left">
                <span>{{userInfo.mobile}}</span>
              </el-form-item>
            </el-col>
            <el-col class="mt10" :span="24">
              <el-form-item label="备注：" class="text-left">
                <div :title="userInfo.remark" class="hide_more_text">{{userInfo.remark}}</div>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row class="change-btn" v-show="infoDropdown.command == 'changePassword'">
          <el-col :span="12">
            <el-button class="reset" @click="loginForm = {}">重置</el-button>
          </el-col>
          <el-col :span="12">
            <el-button class="confirm" type="primary" @click="changePassword">确 定</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>

    <!-- <img src="../../assets/imgs/birdsNest.jpg" class="bg-img" /> -->
    <img :src="birdsNes[$getversionData.control]" class="bg-img" />
    <div class="container">
      <head-menu style="position: fixed;width: 1189px;"></head-menu>
      <div
        v-loading="loading"
        element-loading-text="Loading..."
        element-loading-background="rgba(255, 255, 255, 0.5)"
      >
        <div id="getHeight">
          <router-view style="margin-bottom: 20px"></router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
let valid = { required: true, message: "请输入", trigger: "blur" };
import md5 from "js-md5";
import headMenu from "./headMenu";
import logoIDI from "@/assets/imgs/IDILogo.png";
import { mapGetters, mapActions } from "vuex";
import MASbirdsNes from "../../assets/imgs/MASbirdsNest.jpg";
import BJbirdsNes from "../../assets/imgs/birdsNest.jpg";
import SHbirdsNes from "@/assets/imgs/SHbirdsNes.jpg";
import YQbirdsNes from "@/assets/imgs/YQbirdsNest-new.jpg";
export default {
  name: "home",
  components: { headMenu },
  data() {
    return {
      imgs: require("../../assets/imgs/user.png"),
      close: true,
      birdsNes: {
        beijing: BJbirdsNes,
        maanshan: MASbirdsNes,
        shanghai: SHbirdsNes,
        yangquan: YQbirdsNes
      },
      logoIDI,
      loginForm: {},
      input: "",
      contentHeight: 0,
      rules: {
        againPwd: [
          {
            required: true,
            message: "请输入至少8位的新密码",
            min: 8,
            trigger: "blur"
          }
        ],
        password: [
          {
            required: true,
            message: "请输入至少8位的新密码",
            min: 8,
            trigger: "blur"
          }
        ],
        oldPwd: [valid]
      }
    };
  },
  computed: {
    ...mapGetters([
      "isManageSystem",
      "loading",
      "relogin",
      "listBaseData",
      "userInfo",
      "infoDropdown"
    ])
  },
  methods: {
    ...mapActions([
      "getMenu",
      "selects",
      "reloginDialog",
      "districts",
      "getOrgId",
      "getInsOrg",
      "manageAuthlogout"
    ]),
    handleClose() {
      if (this.infoDropdown.command == "changePassword") {
        this.$refs.ruleForm.resetFields();
        this.loginForm = {};
      }
      this.$store.commit("SHOWINFO", { changePwd: false });
    },
    countHeight() {
      let clientHeight =
        document.documentElement.clientHeight || document.body.clientHeight;
      document.getElementById("getHeight").style.height = `${clientHeight -
        200}px`;
    },
    goLogin() {
      this.$router.push({
        path: "/login"
      });
      this.reloginDialog(false);
    },
    //修改密码
    changePassword() {
      this.$refs["ruleForm"].validate(v => {
        if (v) {
          var regex = new RegExp(
            /((^(?=.*[a-z])(?=.*[A-Z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[A-Z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[a-z])(?=.*\W)[\da-zA-Z\W]{8,30}$)|(^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[\da-zA-Z\W]{8,30}$))/
          );
          if (!regex.test(this.loginForm.password)) {
            this.$messageError({
              message:
                "密码至少8位且必须包含大小写字母、数字、特殊字符至少三项，请及时修改!"
            });
            return;
          }
          if (
            this.loginForm.password &&
            this.loginForm.againPwd &&
            this.loginForm.password !== this.loginForm.againPwd
          ) {
            this.$messageError({
              message: "两次密码输入不一致！"
            });
            return false;
          }
          let oldPassword = md5(this.loginForm.oldPwd);
          let password = md5(this.loginForm.password);
          this.$api.changePwd({ oldPassword, password }).then(res => {
            if (res.code === 0) {
              this.$store.commit("SHOWINFO", { changePwd: false });
              this.$messageSuccess({
                message: res.msg
              });
              let that=this
              setTimeout(() => {
                that.$api
                  .logout({
                    userId: that.userInfo.userId,
                    tenantId: that.$getversionData.lesseeId,
                    logoutStatus:"0"
                  })
                  .then(res => {
                    if (res && res.code == 0) {
                      that.$EventBus.$emit("LOCK_EVENT");
                      that.$EventBus.$emit("TIPS_EVENT");
                      that.manageAuthlogout();
                      that.$router.push({
                        name: "login"
                      });
                    }
                  });
              }, 1500);
            } else if (res.code === 1) {
              this.$messageError({
                message: res.msg
              });
            }
          });
        }
      });
    }
  },
  mounted() {
    // 动态计算高度
    window.addEventListener("resize", this.countHeight);
    this.countHeight();
  },
  created() {
    if (this.userInfo.newUser == 0) {
      this.infoDropdown.changePwd = true;
      this.infoDropdown.command = "changePassword";
      this.close = false;
    } else {
      this.close = true;
    }
    // this.$store.dispatch('loading', true)
    if (!this.isManageSystem) {
      this.getMenu();
      this.selects();
      this.districts();
      this.getOrgId();
    }
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.countHeight);
  }
};
</script>

<style lang="scss" scoped>
.logo {
  width: 63px;
  height: 41px;
}
.head-portrait {
  width: 62px;
  height: 62px;
  border-radius: 50%;
}
.change-pwd {
  .change-btn {
    $pd: 8px;
    %btn {
      width: 100%;
      border: 0;
      font-size: 14.5px;
      padding-top: $pd;
      padding-bottom: $pd;
    }
    .reset {
      @extend %btn;
      background-color: rgba(221, 222, 223, 0.8);
      color: #000;
      border-radius: 0 0 0 5px;
    }
    .confirm {
      @extend %btn;
      border-radius: 0 0 5px 0;
      background: rgba(70, 136, 221, 0.8);
      color: #fff;
    }
  }
  /deep/ {
    .el-form-item__label:before {
      content: "" !important;
      margin: 0 !important;
    }
    .el-dialog {
      background: url(../../assets/imgs/changePwdBg.png) no-repeat;
      background-size: cover;
      height: 300px;
      border-radius: 5px;
      background-color: rgba(255, 255, 255, 0);
      .dialog-body {
        padding: 0 32.5px 48px 32.5px;
        background-color: rgba(255, 255, 255, 0); // 图片带颜色
      }
    }
    .el-dialog__body {
      padding: 0;
      $height: 20px;
      .el-form-item {
        margin: 0;
        .el-form-item__label {
          height: $height;
          line-height: $height;
          padding: 0;
          font-size: 12.5px;
          color: rgba(62, 58, 57, 1);
        }
        .el-form-item__content {
          height: $height;
          line-height: $height;
        }
        .el-input__inner {
          background-color: rgba(255, 255, 255, 0);
          border-radius: 0;
          border-top: 0;
          height: $height;
          line-height: $height;
          border-right: 0;
          border-left: 0;
          border-bottom: 1px solid rgba(170, 170, 170, 0.6);
        }
      }
    }
    .el-dialog__header {
      border-radius: 5px 5px 0 0;
      background: rgba(70, 136, 221, 0); //图片带颜色
      .el-dialog__headerbtn {
        top: 7px;
        right: 11px;
        i {
          color: #fff;
        }
      }
      .el-dialog__title {
        color: #fff;
        font-size: 12.5px;
        font-weight: 500;
      }
      padding-top: 4px;
      padding-bottom: 10px;
    }
  }
}
.bg-img {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  filter:blur(5px);
}
.container {
  width: 1189px;
  margin: 0 auto;
  padding-top: 42px;
}
#getHeight {
  margin-top: 157px;
  overflow: auto;
  scroll-behavior: smooth;
  &::-webkit-scrollbar {
    width: 8px;
    height: 0;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 5px;
    box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    -webkit-box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    background-color: rgba(255, 255, 255, 0.8);
  }
  &::-webkit-scrollbar-button,
  &::-webkit-resizer,
  &::-webkit-scrollbar-corner,
  &::-webkit-scrollbar-track {
    display: none;
  }
}
.hide_more_text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>

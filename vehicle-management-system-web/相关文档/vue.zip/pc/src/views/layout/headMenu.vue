<template>
  <div>
    <el-row class="logo-header">
      <span class="float-left">
        <img src="../../assets/imgs/logo.png" class="logo" />
        <span class="company-name">{{isManageSystem?"IDI 管理平台": $getversionData.city+"IDI 平台"}}</span>
      </span>
      <span class="info">
        <span
          style="padding: 0 10px;color: #FFF;  position: relative;top: -4px;"
        >欢迎{{this.userInfo.username}}</span>
        <el-dropdown @command="infoSelect" placement="bottom" trigger="click">
          <img class="manager mouse-pointer" src="../../assets/imgs/guanliyuan.png" />
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="info" icon="el-icon-user">个人信息</el-dropdown-item>
            <el-dropdown-item command="changePassword" icon="el-icon-edit-outline">修改密码</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>

        <span style="position: relative" @click="dialogVisible = true">
          <!-- <img class="message mouse-pointer" src="../../assets/imgs/email-icon.png" />
          <div class="inline-block tip">{{this.reads}}</div> -->
          <el-badge :value="parseInt(this.reads)" :max="99" class="item">
            <img class="message mouse-pointer" src="../../assets/imgs/email-icon.png" />
          </el-badge>
        </span>
        <img
          @click="logOut"
          style="margin-left: 27px"
          class="manager mouse-pointer"
          src="../../assets/imgs/tuichu.png"
        />
      </span>
    </el-row>
    <el-row>
      <el-menu
        @select="initNews"
        :default-active="$route.meta.activePath || $route.path"
        mode="horizontal"
        background-color="rgba(255,255,255, 0.5)"
        text-color="#000"
        active-text-color="#fff"
        :router="true"
      >
        <el-menu-item v-for="menu of menus" :key="menu.path" :index="menu.path">{{menu.title}}</el-menu-item>
        <div v-if="$route.meta.fuzzyQuery && $route.path!='/riskManagement'">
          <el-input
            placeholder="请输入项目名称 / 保单号"
            v-model="fuzzyQuery.value"
            class="float-right search"
            @keyup.enter.native="caseFuzzyQuery"
          >
            <el-button slot="append" icon="el-icon-search" @click="caseFuzzyQuery"></el-button>
          </el-input>
        </div>
         <div v-if="$route.meta.fuzzyQuery && $route.path=='/riskManagement'">
          <el-input
            :placeholder="showRiskPage=='riskEvent'?'请输入项目名称 / 保单号 / 风险事件名称 / 风险事件编号':'请输入项目名称 / 保单号'"
            v-model="fuzzyQuery.value"
            class="float-right search"
            @keyup.enter.native="caseFuzzyQuery"
          >
            <el-button slot="append" icon="el-icon-search" @click="caseFuzzyQuery"></el-button>
          </el-input>
        </div>
      </el-menu>
      <message-edit />
    </el-row>
    <!-- 站内信息 -->
    <el-dialog
      class="dialog"
      title="站内信息"
      :append-to-body="true"
      :visible.sync="dialogVisible"
      center
    >
      <el-row class="nav">
        <el-col style="width:95px">
          <img src="../../assets/imgs/projectInquiry/logo-2.png" style="width:45px;margin:5px" />
        </el-col>
        <el-row
          v-show="this.activeName === 'third' && this.detail==false||this.activeName === 'fourth' && this.sendDetail==false"
          style="width:100%;text-align:center;line-height:38px"
        >
          <el-col :span="7">
            <span v-show="this.activeName === 'third'">发件人</span>
            <span v-show="this.activeName === 'fourth'">收件人</span>
          </el-col>
          <el-col :span="7">
            <span>主题</span>
          </el-col>
          <el-col :span="7">
            <span>时间</span>
          </el-col>
        </el-row>
      </el-row>
      <el-row style="margin:10px 0px">
        <el-tabs :tab-position="tabPosition" v-model="activeName" @tab-click="handleClick">
          <!-- 写消息 -->
          <el-tab-pane name="first">
            <span slot="label">
              <i class="el-icon-edit-outline"></i>写消息
            </span>
            <el-form
              label-width="80px"
              size="mini"
              label-position="left"
              align="left"
              :model="abb"
              :rules="rules"
              ref="abb"
              style="padding:5px 20px"
            >
              <el-row>
                <el-col :span="23">
                  <el-form-item label="收件人" prop="userIds">
                    <el-select
                      v-model="abb.userIds"
                      multiple
                      filterable
                      style="width:561px"
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in options"
                        :key="item.userId"
                        :label="item.username"
                        :value="item.userId"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="主题" prop="topic">
                    <el-input v-model="abb.topic"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="正文" prop="message" class="text-left">
                    <el-input
                      v-model="message"
                      type="textarea"
                      size="mini"
                      :autosize=" {minRows:10,maxRows: 0.5}"
                    ></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <el-row>
              <el-col :span="22" class="text-right" style="padding: 23px 0 63.5px 0">
                <el-button type="primary" size="mini" @click="send('abb')">发送</el-button>
                <el-button size="mini" @click="dialogVisible = false">关闭</el-button>
              </el-col>
            </el-row>
          </el-tab-pane>
          <!-- 群消息 -->
          <el-tab-pane name="second">
            <span slot="label">
              <i class="el-icon-s-custom"></i>群消息
            </span>
            <el-form
              label-width="80px"
              size="mini"
              label-position="left"
              align="left"
              :model="flock"
              :rules="rules"
              ref="flock"
              style="padding:5px 20px"
            >
              <el-row>
                <el-col :span="23">
                  <el-form-item label="机构" prop="insOrgIds">
                    <el-select
                      v-model="flock.insOrgIds"
                      multiple
                      filterable
                      style="width:561px"
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="items in organizations"
                        :key="items.orgId"
                        :label="items.orgName"
                        :value="items.orgId"
                      ></el-option>
                      <el-option
                        v-for="items in allOrganizations"
                        :key="items.orgId"
                        :label="items.orgName"
                        :value="items.orgId"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="角色" prop="roleIds">
                    <el-select
                      v-model="flock.roleIds"
                      multiple
                      filterable
                      style="width:561px"
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in roles"
                        :key="item.roleId"
                        :label="item.roleName"
                        :value="item.roleId"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="主题" prop="topics">
                    <el-input v-model="flock.topics" style="width:561px"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="23">
                  <el-form-item label="正文" prop="messages" class="text-left">
                    <el-input
                      v-model="messages"
                      type="textarea"
                      size="mini"
                      :autosize=" {minRows:10,maxRows: 0.5}"
                    ></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <el-row>
              <el-col :span="22" class="text-right" style="padding: 23px 0 63.5px 0">
                <el-button type="primary" size="mini" @click="massTexting('flock')">发送</el-button>
                <el-button size="mini" @click="dialogVisible =false">关闭</el-button>
              </el-col>
            </el-row>
          </el-tab-pane>
          <!-- 站内信（发件人） -->
          <el-tab-pane name="third">
            <span slot="label">
              <i class="el-icon-message"></i>站内信
            </span>
            <div v-if="list">
              <el-row>
                <div v-for="(item,index) of allMessages" :key="index">
                  <el-row
                    style="margin-left:-12px;text-align:center;"
                    class="underline mouse-pointer"
                    @click.native="status(item)"
                    :class="{unreadStyle: item.read=='0'}"
                  >
                    <el-col style="width:5px;position: absolute;left: 60px;">
                      <span class="policy el-icon-message"></span>
                    </el-col>
                    <el-col :span="8">
                      <span class="policy">&nbsp;{{item.sender}}</span>
                    </el-col>
                    <el-col :span="8">
                      <span class="policy">&nbsp;{{item.topic}}</span>
                    </el-col>
                    <el-col :span="7">
                      <span class="policy">{{item.sendDate | filterDate}}</span>
                    </el-col>
                  </el-row>
                </div>
              </el-row>
              <el-pagination
                small
                v-show="this.total !=0"
                class="page-lucency text-right mt10 control"
                layout="prev, pager, next"
                :total="this.total"
                :current-page="this.offsets"
                :page-size="this.limit"
                @current-change="handleCurrentChangeAll"
              ></el-pagination>
              <div
                v-show="allMessages.length===0"
                style="position: absolute;left: 50%;top: 200px;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
            </div>
            <!-- 列表详情 -->
            <div v-if="details">
              <el-form
                class="mc-form"
                label-width="80px"
                size="mini"
                label-position="left"
                align="left"
                style="padding:5px 20px"
                disabled
              >
                <el-row>
                  <el-col :span="23">
                    <el-form-item label="发件人">
                      <el-input v-model="detail.sender" style="width:561px"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="23">
                    <el-form-item label="主题">
                      <el-input v-model="detail.topic" style="width:561px"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="23">
                    <el-form-item label="正文">
                      <div class="fileContent" id="content"></div>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
              <el-row>
                <el-col :span="22" class="text-right">
                  <el-button size="mini" @click="close()">关闭</el-button>
                </el-col>
              </el-row>
            </div>
          </el-tab-pane>
          <!-- 已发送 收件人）-->
          <el-tab-pane name="fourth">
            <span slot="label">
              <i class="el-icon-s-promotion"></i>已发送
            </span>
            <div v-if="sendList">
              <el-row>
                <div v-for="(item,index) of sendMessages" :key="index">
                  <el-row
                    class="underline mouse-pointer"
                    style="text-align:center; color:#000"
                    @click.native="sendStatus(item)"
                  >
                    <el-col :span="1" style="width:5px;margin-right: 10px;">
                      <span class="policy el-icon-message"></span>
                    </el-col>
                    <el-col
                      :span="8"
                      :title="item.receiver"
                      style="white-space: nowrap;text-overflow: ellipsis;overflow: hidden;word-break: break-all;"
                    >
                      <span class="policy">&nbsp;{{item.receiver}}</span>
                    </el-col>
                    <el-col :span="8">
                      <span class="policy">&nbsp;{{item.topic}}</span>
                    </el-col>
                    <el-col :span="7">
                      <span class="policy">{{item.sendDate | filterDate}}</span>
                    </el-col>
                  </el-row>
                </div>
              </el-row>
              <el-pagination
                small
                v-show="this.total !=0"
                class="page-lucency text-right mt10 control"
                layout="prev, pager, next"
                :total="this.total"
                :current-page="this.offset"
                :page-size="this.limit"
                @current-change="handleCurrentChange"
              ></el-pagination>
              <div
                v-show="sendMessages.length===0"
                style="position: absolute;left: 50%;top: 200px;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
            </div>
            <!-- 已发送列表详情 -->
            <div v-if="sendDetail">
              <el-form
                class="mc-form"
                label-width="80px"
                size="mini"
                label-position="left"
                align="left"
                style="padding:5px 20px"
                disabled
              >
                <el-row>
                  <el-col :span="23">
                    <el-form-item label="收件人">
                      <el-input v-model="lists.receiver" style="width:561px"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="23">
                    <el-form-item label="主题">
                      <el-input v-model="lists.topic" style="width:561px"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="23">
                    <el-form-item label="正文">
                      <div class="fileContent" id="contentSend"></div>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
              <el-row>
                <el-col :span="22" class="text-right">
                  <el-button size="mini" @click="sendClose()">关闭</el-button>
                </el-col>
              </el-row>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import { write } from "fs";

export default {
  name: "headMenu",
  components: { MessageEdit },
  data() {
    return {
      // 表单校验
      rules: {
        topic: [{ required: true, message: "请输入主题", trigger: "blur",pattern: '[^ \x22]+' }],
        topics: [{ required: true, message: "请输入主题", trigger: "blur",pattern: '[^ \x22]+' }],
        roleIds:[{required: true, message: "请选择角色", trigger: "change"}],
        insOrgIds:[{required: true, message: "请选择机构", trigger: "change"}],
        userIds: [{ required: true, message: "请选择收件人", trigger: "blur" }]
      },
      dialogVisible: false,
      dialogVisibleDetail: false,
      tabPosition: "left",
      activeName: "third",
      abb: {},
      flock: {
        insOrgIds:[],
        roleIds:[]
      },
      userIds: [],
      topic: "",
      message: "",
      sendTypeList: ["LocalMail"],
      // 收件人下拉
      options: [],
      // 选择机构
      organizations: {},
      // 所以机构
      allOrganizations: [],
      insOrgIds: [],
      topics: "",
      messages: "",
      // 选择角色
      roles: [],
      roleIds: [],
      roleName: [],
      // 收件人
      values: [],
      // 已发送
      sendMessages: [],
      // 站内信（收件人）
      allMessages: [],
      reads: "", //未读消息
      // 分页
      total: 0,
      limit: 11, //每页几条数据
      offset: 1, //第几页
      offsets: 1,
      detail: {},
      value: "",
      // fuzzyQuery: ""
      // 列表/详情切换
      list: true,
      details: false,
      sendList: true,
      sendDetail: false,
      lists: {}
    };
  },
  computed: {
    ...mapGetters([
      "isManageSystem",
      "menus",
      "userInfo",
      "showRiskPage",
      "fuzzyQuery"
    ])
  },
  created() {
    this.unreadMessage(); // 未读信息
  },
  methods: {
    ...mapActions([
      "manageAuthlogout",
      "hasNews",
      "riskTodo",
      "riskManagement",
      "reportManagement",
      "setFuzzyQuery",
      "riskTodoRun",
      "todorisk",
      "riskManagementRisk",
      'changeRiskPage'
    ]),
    initNews(path) {
      this.changeRiskPage('riskEvent')
      if (this.$route.path !== path) {
        this.hasNews(true);
      }
    },

    //模糊查询
    caseFuzzyQuery() {
      this.setFuzzyQuery(this.fuzzyQuery.value);
      this.$EventBus.$emit("QUERY_EVENT");
      const routeName = this.$route.name;
      const keywords = {
        fuzzyQuery: this.fuzzyQuery.value,
        offset: 1,
        limit: 4,
        sqlStatus: "1",
      };
      if (routeName === "MyToDo") {
        keywords.limit = 8;
        this.$store.dispatch("loading", true);
        this.riskTodo(keywords).then(() => {
          this.$store.dispatch("loading", false);
        });
      } else if (routeName === "RiskManagement") {
        keywords.insOrgId=JSON.parse(sessionStorage.getItem("eidi.ins")).orgId
        keywords.completeType = '0';
        this.$store.dispatch("loading", true);
        if (this.showRiskPage === "riskEvent") {
          this.riskManagement(keywords).then(() => {
            this.$store.dispatch("loading", false);
          });
        } else if (this.showRiskPage === "riskReport") {
          keywords.taskName = "riskCtrlMgr,riskReportMent";
          this.reportManagement(keywords).then(() => {
            this.$store.dispatch("loading", false);
          });
        }
      } else if (routeName === "MyToDoRisk") {
        this.$store.dispatch("loading", true);
        this.todorisk(keywords).then(() => {
          this.$store.dispatch("loading", false);
        });
      } else if (routeName === "MyToDoRun") {
        keywords.limit = 8;
        this.$store.dispatch("loading", true);
        this.riskTodoRun(keywords).then(() => {
          this.$store.dispatch("loading", false);
        });
      } else if (routeName === "RiskManagementRisk") {
        keywords.limit = 2;
        keywords.sqlStatus=''
        keywords.taskName = "riskCtrlMgr,riskReportMent";
        this.$store.dispatch("loading", true);
        this.riskManagementRisk(keywords).then(() => {
          this.$store.dispatch("loading", false);
        });
      }
    },
    //个人信息
    infoSelect(command) {
      this.$store.commit("SHOWINFO", { command, changePwd: true });
    },
    // 退出
    logOut() {
      if (this.isManageSystem) {
        this.$api.manageAuthlogout().then(res => {
          if (res && res.code == 0) {
            this.manageAuthlogout();
            this.$router.push({
              name: "manageSystemLogin"
            });
          }
        });
      } else {
        this.$api.logout({userId:this.userInfo.userId,tenantId:this.$getversionData.lesseeId,logoutStatus:"1"}).then(res => {
          if (res && res.code == 0) {
            this.$EventBus.$emit("LOCK_EVENT");
             this.$EventBus.$emit("TIPS_EVENT");
            this.manageAuthlogout();
            this.$router.push({
              name: "login"
            });
          }
        });
      }
    },
    // 接口调用
    // 根据 InsOrgId查询用户
    async select() {
      const keywords = {
        InsOrgId: this.userInfo.insOrgId
   
      };
      const data = await this.$api.userList(keywords);
      this.options = data.data.rows;
    },
    // 写消息
    async write() {
      this.$store.dispatch("loading", true);
      const keywords = {
        userIds: this.abb.userIds,
        topic: this.abb.topic,
        message: this.message,
        sendTypeList: this.sendTypeList
      };
      const res = await this.$api.writeMessage(keywords);
      if (res.code == 0) {
        this.$messageSuccess({
          message: res.msg
        });
        this.dialogVisible = false
        this.message = ''
        this.$refs.abb.resetFields()
      } else {
        this.$messageError({
          message: res.msg
        });
      }
      this.$store.dispatch("loading", false);
    },
    // 群消息
    async mass() {
      this.$store.dispatch("loading", true);
      const keywords = {
        insOrgIds: this.flock.insOrgIds,
        topic: this.flock.topics,
        message: this.messages,
        roleIds: this.flock.roleIds,
        sendTypeList: this.sendTypeList
      };
      const res = await this.$api.writeMessage(keywords);
      if (res.code == 0) {
        this.$messageSuccess({
          message: res.msg
        });
        this.dialogVisible =false
        this.messages = ''
        this.$refs.flock.resetFields()

      } else {
        this.$messageError({
          message: res.msg
        });
      }
      this.$store.dispatch("loading", false);
    },
    // 所有信息
    async allMessage() {
      const keywords = {
        limit: this.limit,
        offset: this.offsets
      };
      const data = await this.$api.allMessage(keywords);
      this.allMessages = data.data.rows;
      this.total = data.data.total;
    },
    // 未读消息
    async unreadMessage() {
      if (this.isManageSystem) {
        return;
      }
      const data = await this.$api.unreadMessage();
      this.reads = data.msg;
    },
    // 查询已发送
    async sendMessage() {
      const keywords = {
        limit: this.limit,
        offset: this.offset
      };
      const data = await this.$api.sendMessage(keywords);
      this.sendMessages = data.data.rows;
      this.total = data.data.total;
    },
    // 信息列表
    async messageDetail(item) {
      const keywords = {
        id: item.id
      };
      const data = await this.$api.messageDetail(keywords);
      this.detail = data.data;
    },
    // 角色查询其他
    async listRoleByuserId() {
      const keywords = {
        orgType: this.userInfo.roleType
      };
      const data = await this.$api.listRoleByuserId(keywords);
      this.roles = data.data;
    },
    // 机构查询其他
    async allOrgOperation() {
      const keywords = {
        orgType: this.userInfo.roleType
      };
      const data = await this.$api.mechanismList(keywords);
      this.allOrganizations = data.data.rows;
    },
    // 角色查询运营方
    async listRoleByuserIds() {
      const data = await this.$api.listRoleByuserId();
      this.roles = data.data;
    },
    // 机构查询运营方
    async allOrgOperations() {
      const data = await this.$api.mechanismList();
      this.allOrganizations = data.data.rows;
    },

    // async orgOperation() {
    //   const data = await this.$api.orgOperation(this.userInfo.insOrgId)
    //   this.organizations = [data.data]
    // },
    // // 所以机构
    // async allOrgOperation() {
    //   const data = await this.$api.orgOperation()
    //   this.allOrganizations = data.data.rows
    // },
    // 角色查询
    // async listRoleByuserId() {
    //   const data = await this.$api.listRoleByuserId()
    //   this.roles = data.data
    // },
    // 发送
    send(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.sendTypeList,
            this.userIds,
            this.topic,
            this.message,
            this.write();
        } else {
          this.$messageError({
            message: "请完善信息"
          });
        }
      });
    },
    // 群发
    massTexting(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.sendTypeList,
            this.flock.insOrgIds,
            this.topic,
            this.flock.roleIds,
            this.mass();
            // this.dialogVisible =false
        } else {
          this.$messageError({
            message: "请完善信息"
          });
        }
      });
    },
    // tabs切换
    handleClick(tab) {
      if (tab.name === "fourth") {
        this.sendMessage(); // 已发送
        this.sendList = true;
        this.sendDetail = false;
      } else if (tab.name === "third") {
        this.allMessage(); //站内信
        this.list = true;
        this.details = false;
        this.unreadMessage(); //未读信息
      }
    },
    // 关闭详情
    close() {
      this.list = true;
      this.details = false;
      this.unreadMessage(); //未读信息
    },
    sendClose() {
      this.sendList = true;
      this.sendDetail = false;
    },
    // 每个div
    status(item) {
      item.read = "1";
      this.messageDetail(item); //信息详情
      setTimeout(() => {
        document.getElementById("content").innerHTML = item.message;
      }, 10);
      this.list = false;
      this.details = true;
    },
    sendStatus(item) {
      this.lists = item;
      setTimeout(() => {
        document.getElementById("contentSend").innerHTML = item.message;
      }, 10);
      this.sendList = false;
      this.sendDetail = true;
    },
    // 分页
    handleCurrentChange(val) {
      this.offset = val;
      this.sendMessage();
    },
    handleCurrentChangeAll(val) {
      this.offsets = val;
      this.allMessage();
    },
     // 信息列表
    async messageDetails(id) {
      const keywords = {
        id
      };
      const data = await this.$api.messageDetail(keywords);
      this.detail = data.data;
      // setTimeout(() => {
       document.getElementById("content").innerHTML =  this.detail.message;
      // },10)
    },
  },
  mounted() {
    if (this.isManageSystem) {
      return;
    } else {
      this.$EventBus.$on("nodeClick", ({ id }) => {
        this.dialogVisible = true;
        this.messageDetails(id); //信息详情
        this.list = false;
        this.details = true;
      });
    }
  },
  watch: {
    dialogVisible(item) {
      if (this.dialogVisible == true) {
        this.select(); // 根据InsOrgId查询用户
        // this.sendMessage() // 已发送
        this.allMessage(); // 站内信
        // this.listRoleByuserId() // 角色
        this.activeName = "third";
        if (this.userInfo.insOrgId === "110007") {
          this.listRoleByuserIds(); // 所以角色
          this.allOrgOperation(); // 所以机构
        } else {
          this.listRoleByuserId(); // 当前角色
          this.allOrgOperation(); // 当前机构
        }
      }
      if (this.dialogVisible == false) { //弹窗关闭
        this.unreadMessage() // 未读数据
      }
    }
  }
};
</script>

<style scoped lang="scss">
.el-dropdown-menu {
  padding: 5px 0;
  border-radius: 3px 3px 5px 5px;
  .el-dropdown-menu__item {
    padding: 0 10px;
  }
}
.logo-header {
  position: relative;
  top: 0;
  .company-name {
    color: #fff;
    margin-left: 59px;
    font-size: 25px;
    font-weight: bold;
  }
  .logo {
    width: 50px;
    height: 45px;
    position: absolute;
    bottom: -5px;
  }
  .info {
    position: absolute;
    right: 0;
    bottom: 0;
  }
}
.manager {
  height: 20px;
  width: 20px;
}
.message {
  height: 20px;
  width: 27px;
  margin-left: 27px;
}
.tip {
  height: 14px;
  width: 14px;
  background-color: red;
  font-size: 10px;
  border-radius: 50%;
  line-height: 14.5px;
  color: #fff;
  position: absolute;
  top: -10px;
  right: -5px;
}
$bule: #297ae3 !important;
$height: 44px;
.el-menu {
  border: 0;
  margin-top: 35px;
  .el-menu-item {
    height: $height;
    line-height: $height;
    background-color: rgba(0, 0, 0, 0) !important;
    &:focus {
      background-color: rgba(0, 0, 0, 0);
    }
    &:hover {
      background-color: rgba(255, 255, 255, 0.5) !important;
      color: #000 !important;
    }
  }
  .is-active {
    background-color: $bule;
    border-bottom-color: $bule;
  }
}
.search {
  width: 420px;
  margin: 8px;
  & /deep/ .el-input__inner {
    height: 28px;
    background-color: rgba(255, 255, 255, 0);
    border: 1px solid #a7adb5;
    line-height: 28px;
    border-radius: 0;
    $color: #a7aeb7;
    &::-webkit-input-placeholder {
      color: $color;
    }
    &::-moz-placeholder {
      color: $color;
    }
    &:-ms-input-placeholder {
      color: $color;
    }
  }
  & /deep/ .el-input-group__append {
    background: $bule;
    border-radius: 0;
    border: 0;
    padding: 0 7px;
  }
  & /deep/ .el-button {
    margin: 0;
    padding: 0;
    color: #fff;
    font-size: 19px;
  }
}
.dialog {
  position: fixed;
  background: rgba(255, 255, 255, 0.5);
}
.dialog /deep/ .el-dialog {
  width: 815px;
  min-height: 540px;
  top: 2.5vh;
}
.dialog /deep/ .el-dialog__body {
  padding: 0px;
}
.dialog /deep/.el-dialog__header {
  padding: 8px;
  background-color: rgba(69, 138, 228, 0.8);
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/ .nav {
  height: 40px;
  background: #e3ebf5;
}
.dialog /deep/ .gap {
  width: 73px;
}
.el-tabs {
  height: 445px;
}
.el-tabs /deep/ .el-tabs__content {
  height: 445px;
}
.el-tabs /deep/ .el-tabs__content /deep/ .policy {
  line-height: 35px;
}
/deep/.el-form-item__label {
  color: #297ae3 !important;
}
// 分页定位
.dialog /deep/ .page-lucency {
  button {
    color: #000 !important;
  }
  .el-pager li {
    color: #000 !important;
  }
  .el-pager .active {
    background-color: rgba(41, 122, 227, 1) !important;
    color: #fff !important;
    border-radius: 50%;
  }
}
.dialog /deep/.underline {
  border-bottom: 1px #ccc solid;
  color: #ccc;
}
.dialog /deep/.unreadStyle {
  color: #000;
}
/deep/ .control {
  position: absolute;
  bottom: 10px;
  right: 20px;
  left: 0;
}
.fileContent {
  width: 532px;
  height: 250px;
  overflow: overlay;
  cursor: not-allowed; // 鼠标禁用样式
  // background: rgba(245, 247,250,1);
  border: 1px #dad6d6 solid;
  border-radius: 4px;
  // color: #C0C4CC;
  background: rgba(181, 186, 196, 0.5);
  color: #3e3a39;
  padding: 0 15px;
}
// 滚动条样式
.fileContent {
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 5px;
    box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    -webkit-box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    background-color: rgba(255, 255, 255, 1);
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    background-color: rgba(158, 159, 160, 0.8);
  }
}
// 99+
.el-badge /deep/ .el-badge__content {
  border-radius: 10px;
  color: #FFFFFF;
  display: inline-block;
  font-size: 12px;
  height: 17px;
  line-height: 17px;
  padding: 0px!important;
  min-width: 16px;
  text-align: center;
  white-space: nowrap;
  border: 1px solid #FFFFFF;
}
</style>

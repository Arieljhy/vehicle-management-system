<template>
  <div style="position: relative">
    <div class="content">
      <el-table class="mc-table" tooltip-effect="light" :data="tableData" style="width: 100%">
        <!-- <el-table-column type="index" align="center" label="序号" width="100px"></el-table-column> -->
        <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
        <el-table-column prop="projectName" align="center" label="项目名称"></el-table-column>
        <el-table-column prop="applicant" align="center" label="投保人"></el-table-column>
        <el-table-column align="center" label="创建时间">
          <template slot-scope="scope">{{ scope.row.createdDate | filterDate }}</template>
        </el-table-column>
        <el-table-column align="center" label="项目开始时间">
          <template slot-scope="scope">{{ scope.row.projectStartDate | filterDate }}</template>
        </el-table-column>
        <el-table-column align="center" width="100px">
          <template slot-scope="scope">
            <el-dropdown placement="bottom" size="small" trigger="click">
              <i class="el-icon-more"></i>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item
                  icon="el-icon-edit-outline"
                  @click.native="goClaims('view',scope.row)"
                >详情</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-view"
                  @click.native="goClaims('change', scope.row)"
                  v-if="scope.row.sqlStatus!=1"
                >修改</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-view"
                  @click.native="closeClaims(scope.row)"
                  v-if="scope.row.sqlStatus!=1&&userInfo.roleType == 'INS'"
                >删除</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      <div
        class="project-collection"
        @click="goClaims('new')"
        v-show="this.userInfo.roleType == 'INS'"
      >
        <i class="el-icon-plus"></i>
        <div>新增项目报价</div>
      </div>
      <el-pagination
        small
        class="page-lucency"
        layout="prev, pager, next"
        :total="this.total"
        :current-page="this.offset"
        :page-size="this.limit"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import imgUpload from "@/assets/imgs/put.png";
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "Quoation",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      // 分页
      total: 0,
      limit: 9, //每页几条数据
      offset: 1, //第几页
      tableData: []
    };
  },
  created() {
    if (this.userInfo.roleType == "INS") {
      this.quoation();
    } else if (this.userInfo.roleType == "TIS") {
      this.tisQuoation();
    }
  },
  methods: {
    //删除
    closeClaims(row) {
      this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(async () => {
          //删除数据
          const res = await this.$api.closeClaim({id:row.id});
          if (res.code == 0) {
            this.$messageSuccess({
              message: res.msg
            });
            if (this.userInfo.roleType == "INS") {
                this.quoation();
              } else if (this.userInfo.roleType == "TIS") {
                this.tisQuoation();
              }
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        })
    },
    // 保险list
    async quoation() {
      const keywords = {
        insOrgId: this.userInfo.insOrgId,
        offset: this.offset,
        limit: this.limit
      };
      const data = await this.$api.quotes(keywords);
      this.tableData = data.rows;
      this.total = data.total;
    },
    // tisList
    async tisQuoation() {
      const keywords = {
        tisOrgId: this.userInfo.insOrgId,
        offset: this.offset,
        limit: this.limit
      };
      const data = await this.$api.TisQuotes(keywords);
      this.tableData = data.rows;
      this.total = data.total;
    },
    // 新增项目
    goClaims(flag, row) {
      if (flag != "new") {
        this.$router.push({
          path: "/QuoationAddDetail",
          query: {
            flag: flag,
            id: row.id,
            projectId: row.projectId
          }
        });
      } else {
        this.$router.push({
          path: "/QuoationAddDetail",
          query: {
            flag: flag
          }
        });
      }
    },
    // 分页
    handleCurrentChange(val) {
      this.offset = val;
      if (this.userInfo.roleType == "INS") {
        this.quoation();
      } else if (this.userInfo.roleType == "TIS") {
        this.tisQuoation();
      }
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 50px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
// 分页位置
.page-lucency {
  position: absolute;
  right: 40%;
  bottom: 20px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
</style>
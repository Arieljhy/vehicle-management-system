<template>
  <div class="content">
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-row v-show="this.userInfo.roleType == 'INS'">
      <el-form
        :disabled="$route.query.flag=='view'"
        class="mc-form"
        label-width="148px"
        size="mini"
        label-position="left"
        align="left"
        :rules="rules"
        ref="quoationList"
        :model="quoationList"
      >
        <el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="项目名称：" prop="projectName">
                <el-input v-model="quoationList.projectName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目开始时间：" prop="projectStartDate">
                <el-date-picker
                  type="date"
                  size="mini"
                  placeholder="选择日期"
                  v-model="quoationList.projectStartDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="投保人：" prop="applicant">
                <el-input v-model="quoationList.applicant"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-if="this.$route.query.flag != 'view'">
            <el-col :span="24">
              <el-form-item label="机构列表：" prop="tisOrgNames">
                <span @click="storiedBuilding">
                  <el-input v-model="quoationList.tisOrgNames"></el-input>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-row>
      </el-form>
      <el-row>
        <el-table class="mc-table" tooltip-effect="light" :data="quoationList.listTisBidding" style="width: 100%">
          <el-table-column prop="tisOrgName" align="center" label="机构"></el-table-column>
          <el-table-column prop="modifiedDate" align="center" label="报价时间">
            <template slot-scope="scope">{{ scope.row.modifiedDate | filterDate}}</template>
          </el-table-column>
          <el-table-column prop="biddingFile" align="center" label="报价单"></el-table-column>
          <el-table-column prop="biddingAmount" align="center" label="报价金额"></el-table-column>
          <el-table-column align="center" width="120">
            <template slot-scope="scope">
              <el-button
                @click="downloadBtn(scope.row)"
                size="mini"
                type="primary"
                v-if="scope.row.biddingFile!=null"
              >下载报价单</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-row>
      <!-- 提交 -->
      <el-col :span="22" class="text-right" style="padding: 20px 0">
        <el-button
          size="mini"
          type="primary"
          @click="save('quoationList')"
          v-if="$route.query.flag!='view'"
        >保存</el-button>
        <el-button
          type="primary"
          @click="submit('quoationList')"
          size="mini"
          v-if="$route.query.flag!='view'"
        >提交</el-button>
        <el-button size="mini" @click="clock()">关闭</el-button>
      </el-col>
    </el-row>
    <el-row v-show="this.userInfo.roleType =='TIS'">
      <el-form
        :disabled="$route.query.flag=='view'"
        class="mc-form"
        label-width="148px"
        size="mini"
        label-position="left"
        align="left"
        :rules="rules"
        ref="tisQuoationList"
        :model="tisQuoationList"
      >
        <el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="项目名称：">
                <el-input disabled v-model="tisQuoationList.projectName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目开始时间：">
                <el-date-picker
                  disabled
                  type="date"
                  size="mini"
                  placeholder="选择日期"
                  v-model="tisQuoationList.projectStartDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="报价金额：" prop="biddingAmount">
                <format-input
                  empty-value="0"
                  text-align="left"
                  :precision="2"
                  :error="error"
                  v-model="tisQuoationList.biddingAmount"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报价单：" prop="biddingFile">
                <el-input disabled v-model="tisQuoationList.biddingFile"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-col :span="3">
                <img v-if="!upload" :src="imgUpload" class="img-upload" />
                <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
                <!-- <img v-if="upload" src="@/assets/imgs/gif.gif" class="img-upload" /> -->
              </el-col>
              <el-col :span="21">
                <el-upload
                  class="inline-block mlr97"
                  action
                  :http-request="uploadFile"
                  :show-file-list="false"
                >
                  <el-button size="mini" type="primary">上传</el-button>
                </el-upload>
                <el-button size="mini" @click="delBtn()">删除</el-button>
                <el-button id="layout" @click="download" size="mini" :disabled="disabled">下载</el-button>
              </el-col>
            </el-col>
          </el-row>
        </el-row>
      </el-form>
      <!-- 提交 -->
      <el-col :span="22" class="text-right" style="padding: 20px 0">
        <el-button
          size="mini"
          type="primary"
          @click="save('tisQuoationList')"
          v-if="$route.query.flag!='view'"
        >保存</el-button>
        <el-button
          type="primary"
          @click="tisSubmit('tisQuoationList')"
          size="mini"
          v-if="$route.query.flag!='view'"
        >提交</el-button>
        <el-button size="mini" @click="clock()">关闭</el-button>
      </el-col>
    </el-row>
    <el-dialog title="可选机构" :visible.sync="buildingWindows" width="500px" class="dialog" :close-on-click-modal="false">
      <el-row style="border:1px #ccc solid">
        <el-row>
          <el-table
            class="mc-table residence-table"
            :data="orgList"
            @select="checkedList"
            @select-all="checkedLists"
            ref="multipleTable"
          >
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="orgName" align="center" label="机构名称"></el-table-column>
          </el-table>
        </el-row>
      </el-row>
      <el-row style="text-align: right; margin-top: 30px" class="btns">
        <el-button size="mini" @click="confirmationBtn()">确定</el-button>
      </el-row>
    </el-dialog>
    <el-row></el-row>
  </div>
</template>
<script>
import imgUpload from "@/assets/imgs/put.png";
import { mapGetters, mapActions } from "vuex";
import formatInput from "@/components/formatInput";
import axios from 'axios';
export default {
  name: "QuoationAddDetail",
  props: {
    error: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  components: {
    formatInput
  },
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      progress:0,
      disabled: true,
      // 校验
      rules: {
        projectName: [
          { required: true, message: "请输入项目名称", trigger: "blur" }
        ],
        projectStartDate: [
          { required: true, message: "请选择日期", trigger: "blur" }
        ],
        tisOrgNames: [{ required: false }],
        applicant: [
          { required: true, message: "请输入投保人", trigger: "blur" }
        ],
        biddingAmount: [
          { required: true, message: "请输入报价金额", trigger: "blur" }
        ],
        biddingFile: [
          { required: true, message: "请上传报价单", trigger: "change" }
        ]
      },
      insurance: true,
      upload: false,
      buildingWindows: false, // 可选机构
      imgUpload,
      quoationList: {
        projectName: "", // 项目名称
        projectStartDate: "", //项目开始时间
        applicant: "", // 投保
        sqlStatus: "",
        insOrgId: ""
      },
      tisQuoationList: {
        projectName: "", // 项目名称
        projectStartDate: "", //项目开始时间
        biddingAmount: "", //报价金额
        biddingFile: "", // 报价单
        sqlStatus: "",
        insOrgId: ""
      },
      orgList: [], //机构
      riskBlding: [],
      riskName: [],
      submissionState: 1, // 提交
      saveState: 0, // 保存
      projectId: "",
      val: "",
      tableData: []
    };
  },
  created() {
    const userInfo = JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo));
    if (this.$route.query.flag != "new" && userInfo.roleType == "INS") {
      this.quoteDetail();
    } else if (userInfo.roleType == "TIS") {
      this.TisQuoteDetail();
    }
  },
  methods: {
    //下载
    downloadBtn(row) {
      var a = document.createElement("a");
      var filename = row.biddingFile;
      a.style = "display: none";
     a.href = `/api/bidding/tisProjectBidding/downloadDocument?biddingFileName=${row.biddingFile}&docCloudId=${row.biddingFilePath}`;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    //可选机构弹窗
    storiedBuilding() {
      this.buildingWindows = true;
      this.getOrg();
    },
    //确定按钮
    confirmationBtn(formName) {
      this.buildingWindows = false;
      this.quoationList.tisOrgIds = this.riskBlding.join();
      this.quoationList.tisOrgNames = this.riskName.join();
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex(item => {
        return item.orgId == row.orgId;
      });
      if (isCkeck < 0) {
        for (let [index, item2] of this.riskBlding.entries()) {
          if (item2 == row.orgId) {
            this.$delete(this.riskBlding, index);
            this.quoationList.tisOrgIds = this.riskBlding.join();
          }
        }
        for (let [index, item2] of this.riskName.entries()) {
          if (item2 == row.orgName) {
            this.$delete(this.riskName, index);
            this.quoationList.tisOrgIds = this.riskName.join();
          }
        }
      } else {
        this.riskBlding.push(row.orgId);
        this.riskName.push(row.orgName);
        // this.quoationList.tisOrgIds = this.riskBlding.join();
      }
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.riskBlding) {
            if (item2 == item.orgId) {
              flag = true;
            }
          }
          if (!flag) {
            this.riskBlding.push(item.orgId);
            this.riskName.push(item.orgName);
            this.quoationList.tisOrgIds = this.riskBlding.join();
          }
        }
      } else {
        this.riskName = [];
        this.riskBlding = [];
        this.quoationList.tisOrgIds = this.riskBlding.join();
      }
    },
    // 机构
    async getOrg() {
      const res = await this.$api.getOrgId();
      this.orgList = res.data.tisOrgList;
      for (let item of this.riskName) {
        for (let item2 of this.orgList) {
          if (item == item2.orgName) {
            setTimeout(() => {
              this.$refs.multipleTable.toggleRowSelection(item2);
            });
          }
        }
      }
    },
    // 提交
    submit(formName) {
      this.$refs[formName].validate(valid => {
        if (valid && this.quoationList.tisOrgIds) {
          this.quoationList.insOrgId = this.userInfo.insOrgId;
          this.quoationList.sqlStatus = this.submissionState; // 状态
          this.saveRequest();
        } else {
          this.$messageError({
            message: "请完善信息及机构列表"
          });
        }
      });
    },
    tisSubmit(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.tisQuoationList.insOrgId = this.userInfo.insOrgId;
          this.tisQuoationList.sqlStatus = this.submissionState; // 状态
          this.TisSaveRequest();
        } else {
          this.$messageError({
            message: "请完善信息"
          });
        }
      });
    },
    // 保存
    save(formName) {
      if (this.userInfo.roleType == "INS") {
        this.quoationList.insOrgId = this.userInfo.insOrgId;
        this.quoationList.sqlStatus = this.saveState; // 状态
        this.saveRequest();
      } else if (this.userInfo.roleType == "TIS") {
        this.tisQuoationList.insOrgId = this.userInfo.insOrgId;
        this.tisQuoationList.sqlStatus = this.saveState; // 状态
        this.TisSaveRequest();
      }
    },
    tisSave(formName) {},
    // 新增、修改、详情
    async saveRequest() {
      this.$store.dispatch("loading", true);
      if (this.$route.query.flag == "new") {
        const res = await this.$api.quotesave(this.quoationList);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      } else if (this.$route.query.flag == "change") {
        const res = await this.$api.quoteRevision(this.quoationList);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
      this.$store.dispatch("loading", false);
    },
    async quoteDetail() {
      const res = await this.$api.quoteDetail(this.$route.query.id);
      this.quoationList = res.data;
      this.quoationList.listTisBidding.map((item,index)=>{
       this.riskName.push(item.tisOrgName)
      })
    },
    // tis下修改、详情
    async TisSaveRequest() {
      this.$store.dispatch("loading", true);
      if (this.$route.query.flag == "change") {
        const res = await this.$api.TisQuoteRevision(this.tisQuoationList);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
      this.$store.dispatch("loading", false);
    },
    async TisQuoteDetail() {
      const res = await this.$api.TisQuoteDetail(this.$route.query.id);
      this.tisQuoationList = res.data;
      if (this.tisQuoationList.biddingFile) {
        this.disabled = false;
      }
       this.$refs["tisQuoationList"].resetFields();
    },
    // 上传
    uploadFile(param) {
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "layout");
      file.append("projectId", this.$route.query.projectId);
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this.progress = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.disabled = false;
          this.tisQuoationList.biddingFilePath = res.data.data.biddingFile;
          this.tisQuoationList.biddingFile = res.data.data.biddingFileName;
          this.progress=100
        } else {
          this.$messageError({ message: res.data.msg });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    // 下载
    download() {
      let a = document.createElement("a");
      a.style = "display: none";
      a.href = `/api/bidding/tisProjectBidding/downloadDocument?biddingFileName=${this.tisQuoationList.biddingFile}&docCloudId=${this.tisQuoationList.biddingFilePath}`;
      a.download = this.tisQuoationList.biddingFile;
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn() {
      this.tisQuoationList.layout = "";
      this.tisQuoationList.biddingFile = "";
      this.disabled = true;
    },
    // 返回上一级
    clock() {
      this.$router.go(-1);
    }
  },

  mounted() {
    let dom = document.getElementById("layout");
    dom.disabled = false;
    dom.classList.remove("is-disabled");
  }
};
</script>
<style scoped lang="scss">
// 分页位置
.page-lucency {
  position: absolute;
  right: 40%;
  bottom: 20px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
</style>
<template>
  <div class="content">
    <el-row v-if="hasBIAuthority||orgType=='OP'||orgType=='GOV'||orgType=='INS'">
      <el-col :span="18">&nbsp;</el-col>
      <el-col :span="6" style="text-align:right">
        <el-button
          size="mini"
          v-if="orgType=='OP'||orgType=='GOV'||orgType=='INS'"
          type="primary"
          @click="mothlyReport"
        >保险公司月报</el-button>
        <el-button
          size="mini"
          v-if="hasBIAuthority"
          type="primary"
          @click="dataCebter('loginImmediately')"
        >数据中心</el-button>
      </el-col>
    </el-row>
    <el-row :gutter="8" style="margin-top:2px">
      <el-col :span="8" v-for="(item,index) in echartList" :key="index">
        <div class="echart" @click="option(item)">
          <div v-show="item.variable" class="newclass" style="height:250px">
            <span>{{item.title}}</span>
          </div>
          <chart :ref="item.echartId" v-show="!item.variable"></chart>
        </div>
      </el-col>
    </el-row>
    <el-dialog
      class="login-dialog"
      :show-close="true"
      :before-close="handleClose"
      :lock-scroll="false"
      :visible.sync="loginDialog"
      width="425px"
      top="24vh"
      :close-on-click-modal="false"
    >
      <el-form ref="loginForm" :rules="rulesLoginForm" :model="loginForm">
        <el-row style="position: relative" class="text-left tall">
          <el-col :span="24" class="mb42" style="    margin-bottom: 20px;">
            <img
              src="@/assets/imgs/IDILogo.png"
              class="inline-block"
              style="width: 71px;height: 46px;margin: 0 49px 0 21px;"
            />
            <span
              style="font-size: 19px;font-weight: 500;color:#474747;position: absolute;top: 20px"
            >请确认密码</span>
          </el-col>
          <el-col :span="24">
            <el-form-item prop="userId">
              <el-input v-model="loginForm.userId" disabled placeholder="请输入账号"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item prop="password">
              <el-input
                @keyup.enter.native="loginOn('loginForm')"
                v-model="loginForm.password"
                clearable
                placeholder="请输入密码"
                type="password"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="24" style="margin-top: 50px;">
            <el-button
              type="primary"
              :loading="fullscreenLoading"
              style="font-size:17px;font-weight:500;width: 100%;height:48px;"
              @click="loginOn('loginForm')"
            >登 录</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>
    <el-pagination
      small
      class="page-lucency text-right mt10 control"
      layout="prev, pager, next"
      :total="this.total"
      :current-page="this.offset"
      :page-size="this.limit"
      @current-change="send"
    ></el-pagination>

    <el-dialog
      class="dialog"
      title="图表详情"
      :visible.sync="dialogVisible"
      width="860px"
      :append-to-body="true"
      :close-on-click-modal="false"
    >
      <div style="height:400px">
        <div v-show="variable" class="newclass newclassList" style="height:400px">
          <span>{{echartTitle}}</span>
        </div>
        <chart ref="items"></chart>
      </div>
    </el-dialog>
    <!-- 月报 -->
    <el-dialog
      class="monthReportDialog"
      title="保险公司月报"
      :append-to-body="true"
      :visible.sync="monthReportShow"
      :close-on-click-modal="false"
      center
    >
      <div style="text-align: center;" v-if="orgType=='OP'||orgType=='GOV'">
        <el-row>
          <el-input
            placeholder="请输入保险公司名称"
            v-model="fuzzyQuery"
            class="search"
            @keyup.enter.native="getList"
          >
            <el-button slot="append" icon="el-icon-search" @click="getList"></el-button>
          </el-input>
        </el-row>
      </div>
      <div v-if="orgType=='INS'">
        <el-form :model="uploadForm">
          <el-row>
            <el-col :span="8">
              <el-form-item label="报表日期" label-width="80px" style="text-align: left;" required>
                <el-date-picker
                  type="month"
                  placeholder="请选择月份"
                  v-model="uploadForm.month"
                  style="width: 100%;"
                  @change="changeDate"
                  :disabled="isDisabled"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="10">
              <el-form-item label="报表名称" label-width="80px">
                <el-input v-model="uploadForm.reportName" placeholder="请选择文件" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6" style="text-align:left;margin-top:5px">
              <el-col :span="5" v-if="isUpload" style="position:relative;left: 5px;">
                <el-progress type="circle" :percentage="uploadPercentage" :width="32"></el-progress>
              </el-col>
              <el-col :span="9">
                <el-upload
                  class="inline-block mlr97"
                  action
                  :http-request="(e) => {uploadFile(e);}"
                  :show-file-list="false"
                  :before-upload="beforeAvatarUpload"
                >
                  <el-button size="mini" type="primary" :disabled="isDisabled">上传</el-button>
                </el-upload>
              </el-col>
              <el-col :span="9" style="position:relative;right:-14px;">
                <el-button
                  size="mini"
                  type="primary"
                  :disabled="isDisabled"
                  @click="commitMonthlyReport"
                >提交</el-button>
                <el-popover v-model="visibleUpdate">
                  <p>当月报表已上传,是否要覆盖？</p>
                  <div style="text-align:right;margin:0">
                    <el-button size="mini" type="text" @click="cancelUpdate">取消</el-button>
                    <el-button size="mini" type="primary" @click="updateMonthlyReport">覆盖</el-button>
                  </div>
                </el-popover>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- <el-divider></el-divider> -->
      <el-row>
        <!-- table列表 -->
        <el-table :data="tableData" style="width: 100%" class="mc-table">
          <el-table-column
            type="index"
            label="序号"
            width="80"
            :index="
              (index) => {
                return index + 1 + (reportPage - 1) * reportPageSize;
              }
            "
          ></el-table-column>
          <el-table-column label="报表名称" :width="orgType=='OP'||orgType=='GOV'?'160':'300'">
            <template slot-scope="scope">
              <span
                :title="scope.row.reportName"
                style="
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                "
              >{{ scope.row.reportName }}</span>
            </template>
          </el-table-column>
          <el-table-column v-if="orgType=='OP'||orgType=='GOV'" label="保险公司" width="160">
            <template slot-scope="scope">
              <span
                :title="scope.row.orgName"
                style="
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                "
              >{{ scope.row.orgName }}</span>
            </template>
          </el-table-column>
          <el-table-column label="报表日期" width="100">
            <template slot-scope="scope">
              <span style="margin-left: 10px">{{ scope.row.month }}</span>
            </template>
          </el-table-column>
          <el-table-column width="auto" align="right">
            <template slot-scope="scope">
              <el-button
                style="margin-left: 10px"
                slot="reference"
                size="mini"
                type="primary"
                @click.stop="downLoad(scope.$index, scope.row, 'downLoad')"
              >下载</el-button>
              <!-- <el-button
                size="mini"
                type="primary"
                @click="viewOnline(scope.$index, scope.row, 'view')"
              >预览</el-button>-->
            </template>
          </el-table-column>
        </el-table>
        <!-- 报表分页 -->
        <el-pagination
          small
          class="pagination"
          layout="prev, pager, next"
          @current-change="handlePageChange"
          :current-page.sync="reportPage"
          :page-size="reportPageSize"
          :total="reportTotal"
        ></el-pagination>
      </el-row>
      <!-- <div class="viewPopover" v-if="visibleView">
        <el-popover v-model="visibleView">
            <i class="el-icon-circle-close" @click="closeView"></i>
            <el-image style="width: 100%; height: 100%;position:relative" :src="`${baseDownUrl}${imageUrl}`" fit="contain"></el-image>
        </el-popover>
      </div>-->
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import chart from "@/components/charts";
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import md5 from "js-md5";
import http from "@/common/request";
import axios from "axios";
export default {
  name: "Statistics",
  components: {
    chart
  },
  data() {
    return {
      pathwss: `wss://${document.location.host}/api/socket/echarts-socket/`,
      pathws: `ws://${document.location.host}/api/socket/echarts-socket/`,
      // pathws: `ws://172.23.100.193:9999/echarts-socket/`,//本地连生产的socket地址
      socket: "",
      tenantId: "",
      userId: "",
      params: "",
      echartList: [
        { data: [] },
        { data: [] },
        { data: [] },
        { data: [] },
        { data: [] },
        { data: [] }
      ],
      total: 0,
      limit: 6,
      offset: 0,
      dialogVisible: false,
      variable: false,
      echartTitle: "",
      charts: {
        maanshan: maanshan,
        beijing: beijing,
        shanghai: shanghai,
        yangquan: yangquan
      },
      fullscreenLoading: false,
      loginDialog: false,
      rulesLoginForm: {
        userId: [
          {
            required: true,
            message: "请填写账号",
            trigger: "blur"
          }
        ],
        password: [
          {
            required: true,
            message: "请输入密码",
            trigger: "blur"
          }
        ],
        loginCode: [
          {
            required: true,
            message: "请输入验证码",
            trigger: "blur"
          }
        ],
        newPassword: [
          {
            required: true,
            message: "请输入新密码",
            trigger: "blur"
          }
        ],
        againPassword: [
          {
            required: true,
            message: "请输入新密码",
            trigger: "blur"
          }
        ]
      }, //表单验证
      loginForm: {
        userId: "", //账号
        password: "", //密码
        loginCode: "" //验证码
      }, //登录输入框
      orgType: "",
      monthReportShow: false,
      fuzzyQuery: "",
      uploadForm: {
        month: "",
        reportName: "",
        reportCloudDocid: "",
        insOrgId: "",
        id: ""
      },
      isUpload: false,
      isDisabled: false,
      uploadPercentage: 0,
      tableData: [], //上传后的列表
      reportTotal: 0,
      reportPage: 1,
      reportPageSize: 5,
      currentPage: 1,
      uploadDocInfo: {
        uidFileName: "",
        cloudDocIdTmp: "",
        fileIcon: "checkReportFile",
        projectId: "baobiao"
      },
      visibleUpdate: false,
      visibleView: false,
      baseDownUrl: "/api/processDoc/downloadProcessDoc?cloudDocId=",
      imageUrl: "",
      findPassword: false,
      hasBIAuthority: ""
    };
  },
  mounted() {
    console.log(document.location.protocol);
    console.log(this.echartList);
    this.init();
    this.uploadForm.insOrgId = JSON.parse(
      sessionStorage.getItem(this.$getversionData.userInfo)
    ).insOrgId;
  },
  watch: {
    dialogVisible() {
      if (this.dialogVisible == false) {
        this.$refs.items.destroy();
      }
    }
  },
  computed: {
    ...mapGetters(["userInfo"])
  },
  methods: {
    // 月报
    mothlyReport() {
      this.uploadForm.month = "";
      this.uploadForm.reportName = "";
      this.monthReportShow = true;
      this.getList();
    },
    changeDate() {
      this.uploadForm.month = this.formatDate(this.uploadForm.month).substr(
        0,
        7
      );
    },
    formatDate(now) {
      let year = now.getFullYear();
      let month =
        now.getMonth() + 1 < 10
          ? "0" + (now.getMonth() + 1)
          : now.getMonth() + 1;
      return year + "-" + month;
    },
    cancelUpdate() {
      this.visibleUpdate = false;
      this.isDisabled = false;
      this.uploadForm.month = "";
      this.uploadForm.reportName = "";
    },
    async updateMonthlyReport() {
      const resUpdate = await http.post(
        "insMonthlyReport/update",
        this.uploadForm
      );
      if (resUpdate.code == 0) {
        this.$message.success("覆盖操作成功");
        this.uploadForm.month = "";
        this.uploadForm.reportName = "";
      } else {
        this.$message.error("覆盖操作失败,请重试!");
        this.uploadForm.month = "";
        this.uploadForm.reportName = "";
      }
      this.isDisabled = false;
      this.visibleUpdate = false;
      this.getList();
    },
    async commitMonthlyReport() {
      if (!this.uploadForm.month) {
        this.$message.error("请选择报表月份");
        return;
      }
      if (!this.uploadForm.reportName) {
        this.$message.error("请上传文件");
        return;
      }
      if (this.isUpload) {
        this.$message.error("文件上传尚未完成,不可提交");
      } else {
        this.isDisabled = true;
        const result = await http.post(
          "/processDoc/submitProcessDoc",
          this.uploadDocInfo
        );
        if (result.code == 0 && result.data.total > 0) {
          this.uploadForm.reportCloudDocid = result.data.rows[0].cloudDocId;
          this.uploadForm.reportName = result.data.rows[0].fileName;
          try {
            await http
              .post("insMonthlyReport/add", this.uploadForm)
              .then(res => {
                if (res.code == 0) {
                  this.$message.success("报表提交成功");
                  this.visibleUpdate = false;
                  this.uploadForm.month = "";
                  this.uploadForm.reportName = "";
                  this.isDisabled = false;
                  this.getList();
                } else if (res.code == 1) {
                  this.visibleUpdate = true;
                  this.uploadForm.id = res.id;
                } else {
                  this.isDisabled = false;
                  this.$message.error("报表提交失败");
                }
              });
          } catch (error) {
            this.isDisabled = false;
          }
        }
      }
    },
    beforeAvatarUpload(file) {
      const i = file.name.lastIndexOf(".");
      const extensions = file.name.substring(i);
      const fileSizeLimit = file.size / 1024 / 1024 < 100;
      if (
        extensions != ".pdf" &&
        extensions != ".jpeg" &&
        extensions != ".jpg" &&
        extensions != ".docx" &&
        extensions != ".doc"
      ) {
        this.$message.error("文件类型应为/pdf/jpeg/jpg/docx/doc格式!");
        return false;
      } else {
        if (!fileSizeLimit) {
          this.$message.error("文件大小不能超过100MB!");
          return false;
        }
      }
    },
    uploadFile(e) {
      this.uploadForm.reportName = e.file.name;
      this.isDisabled = true;
      this.isUpload = true;
      let file = new FormData();
      file.append("file", e.file);
      file.append("fileIcon", "checkReportFile");
      file.append("projectId", "baobiao");
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this.uploadPercentage = complete == 100 ? 99 : complete;
        }
      };
      axios
        .post("/processDoc/uploadProcessDocTmp", file, config)
        .then(resData => {
          if (resData.data.code == 0) {
            this.uploadForm.reportCloudDocid = resData.data.data.cloudDocId;
            this.uploadForm.reportName = resData.data.data.fileName;
            this.uploadDocInfo.uidFileName = resData.data.data.uidFileName;
            this.uploadDocInfo.cloudDocIdTmp = resData.data.data.cloudDocIdTmp;
            this.uploadPercentage = 100;
            this.$message.success("上传成功");
            this.isDisabled = false;
            this.isUpload = false;
          } else {
            this.$messageError({ message: resData.data.msg });
          }
        });
      this.uploadPercentage = 0;
    },
    handlePageChange(val) {
      // 切换分页
      this.reportPage = val;
      this.currentPage = val;
      this.getList();
    },
    async getList() {
      this.tableData = [];
      let keyWord = {
        offset: this.reportPage,
        limit: this.reportPageSize,
        fuzzyQuery: this.fuzzyQuery
      };
      const res = await http.post("/insMonthlyReport/list", keyWord);
      if (res.code == 0) {
        this.tableData.push(...res.data.rows);
        this.reportTotal = res.data.total;
      }
    },
    downLoad(index, row, flag) {
      //下载
      console.log(index, row, flag);
      let a = document.createElement("a");
      a.style = "display:none";
      a.download = row.reportName;
      a.href = `/api/processDoc/downloadProcessDoc?cloudDocId=${row.reportCloudDocid}`;
      document.body.appendChild(a);
      a.click();
    },
    // viewOnline(index, row, flag) {//预览
    //   console.log(index,row,)
    //   const i = row.reportName.lastIndexOf(".");
    //   const suffix = row.reportName.substring(i);
    //   if(suffix=='.jpg'||suffix=='.jpeg'){
    //     this.visibleView = true;
    //     this.imageUrl = row.reportCloudDocid;
    //   }else {
    //     let routeData = this.$router.resolve({
    //       path: "/previewFile",
    //       query: {
    //         docId: row.reportCloudDocid,
    //         tokenId: sessionStorage.getItem(this.$getversionData.token),
    //       }
    //     });
    //     window.open(routeData.href, "_blank");
    //   }
    //   // window.open(`/api/processDoc/downloadProcessDoc?cloudDocId=${row.reportCloudDocid}`,"_blank");
    // },
    // closeView() {//关闭预览弹窗
    //   this.visibleView = false;
    //   this.imageUrl = "";
    // },
    //登录弹框关闭
    handleClose() {
      (this.fullscreenLoading = false), (this.loginDialog = false);
    },
    //登录 忘记密码
    dataCebter(flag) {
      if (this.$refs["loginForm"]) {
        this.$refs["loginForm"].resetFields();
      }
      this.loginForm = {};
      this.loginForm.userId = JSON.parse(
        sessionStorage.getItem(this.$getversionData.userInfo)
      ).userId;
      if (flag == "loginImmediately") {
        this.findPassword = false;
        this.loginDialog = true;
        this.rulesLoginForm.userId[0].message = "请输入账号";
      } else {
        this.fullscreenLoading = false;
        this.findPassword = true;
        this.rulesLoginForm.userId[0].message = "请输入手机号";
      }
    },
    loginOn(loginForm) {
      this.$refs[loginForm].validate(valid => {
        if (valid) {
          const keyWord = {
            loginBase: "PC",
            loginCode: "1", //验证码
            loginType: "password",
            password: md5(this.loginForm.password),
            tenantId: this.$getversionData.lesseeId,
            userId: this.loginForm.userId
          };
          http.post("loginToBI", keyWord).then(res => {
            if (res.code == 0) {
              if (res.data[0].datasource == "uat") {
                window.open(res.data[0].url);
                this.handleClose();
              } else {
                this.$router.push({
                  path: "/dataCenter",
                  query: {
                    row: JSON.stringify(res.data)
                  }
                });
              }
            } else if (res.code == 1) {
              this.$messageSuccess({
                message: res.msg
              });
            } else {
              this.$messageError({
                message: res.msg
              });
            }
          });
        }
      });
    },
    init() {
      this.tenantId = JSON.parse(
        sessionStorage.getItem(this.$getversionData.userInfo)
      ).tenantId;
      this.userId = JSON.parse(
        sessionStorage.getItem(this.$getversionData.userInfo)
      ).userId;
      this.orgType = JSON.parse(sessionStorage.getItem("eidi.ins")).orgType;
      this.hasBIAuthority = JSON.parse(
        sessionStorage.getItem(this.$getversionData.hasBIAuthority)
      );
      if (typeof WebSocket === "undefined") {
        console.log("您的浏览器不支持WebSocket");
      } else {
        this.path =
          "https:" == document.location.protocol ? this.pathwss : this.pathws;
        this.socket = new WebSocket(
          this.path + this.tenantId + "/" + this.userId
        );
        this.socket.onopen = this.open;
        this.socket.onerror = this.error;
        this.socket.onmessage = this.getMessage;
      }
    },
    open() {
      this.send(1);
      console.log("WebSocket link success!");
    },
    error() {
      console.log("WebSocket link error!");
    },
    close() {
      console.log("WebSocket is closed!");
    },
    getMessage(data) {
      const getData = JSON.parse(data.data);
      if (getData.echartsTotal) {
        this.total = getData.echartsTotal;
      } else {
        if (getData.code == 0) {
          this.echartList.splice(getData.index, 1, getData.data);
          this.Echarts(this.echartList);
        }
      }
    },

    send(val) {
      this.echartList.map((item, index) => {
        if (item.echartId) {
          this.$refs[item.echartId][0].destroy();
        }
      });

      if (this.total > 0) {
        this.echartList = [];
        if (val * 6 < this.total) {
          for (let i = 0; i < 6; i++) {
            this.echartList.push({ data: [] });
          }
        } else {
          for (let i = 0; i < this.total - (val - 1) * 6; i++) {
            this.echartList.push({ data: [] });
          }
        }
      }

      this.params = `{
            userId:${this.userId},
            tenantId:${this.tenantId},
            province: ${this.$getversionData.province},
            city: ${this.$getversionData.city},
            offset:'${val}',
            bizType:'',
            limit:'6'
        }`;
      this.socket.send(this.params);
      this.socket.onmessage = this.getMessage;
      // this.Echarts(this.echartList);
    },
    close() {
      console.log("WebSocket is close!");
    },
    Echarts(echartDataList) {
      for (let [i, item] of echartDataList.entries()) {
        if (item.data.length == 0) {
          item.variable = true;
        } else if (item.echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: '{c}' //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of item.data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(category_option);
          }, 10);
        } else if (item.echartType === "lines") {
          // 多折线图
          let dateArr = [];
          let dateYM = new Date();
          let currentYear = dateYM.getFullYear();
          dateYM.setMonth(dateYM.getMonth() + 1, 1);
          for (let i = 0; i < 12; i++) {
            dateYM.setMonth(dateYM.getMonth() - 1);
            let dateM = dateYM.getMonth() + 1;
            dateM = dateM < 10 ? "0" + dateM : dateM;
            let dateArrItem = {
              name: dateYM.getFullYear() + "-" + dateM,
              value: 0
            };
            dateArr.unshift(dateArrItem);
          }
          let x_data = [];
          dateArr.map(arrItem => {
            x_data.push(arrItem.name);
          });
          let categorys_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              // formatter: '{c}' //鼠标滑过时候的显示
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            // legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: x_data
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          item.data.map(itemChild => {
            itemChild.name = itemChild.name;
            itemChild.type = "line";
            // itemChild.stack = "df";
            itemChild.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            itemChild.result.map(resultChild => {
              dateArr.map((arrItem, num) => {
                if (arrItem.name == resultChild.name) {
                  arrItem.value = resultChild.value;
                  itemChild.data.map((list, i) => {
                    if (num == i) {
                      itemChild.data.splice(i, 1, arrItem.value);
                    }
                  });
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(categorys_option);
          }, 10);
        } else if (item.echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            // legend: {
            //   selectedMode: false, //取消图例上的点击事件
            //   backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
            //   borderRadius: 10,
            //   orient: "vertical",
            //   icon: "circle",
            //   top: "30",
            //   right: "5",
            //   align: "left",
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: "bold"
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["50%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "20",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "900",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of item.data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(pie_option);
            this.$refs[item.echartId][0].editEcahrt(
              pie_option,
              this.$refs[item.echartId][0].id
            );
          }, 10);
        } else if (item.echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of item.data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(axas_option);
          }, 10);
        } else if (item.echartType === "boxplot") {
          // 盒须图
          let boxDataList = [];
          let boxDataName = [];
          for (let n of item.data) {
            boxDataList.push(n.value);
            boxDataName.push(n.name);
          }
          let data = echarts.dataTool.prepareBoxplotData(boxDataList);
          let boxplot_option = {
            title: [
              {
                text: item.title,
                left: "10",
                top: "15",
                textStyle: {
                  fontSize: "13",
                  fontWeight: "bold",
                  fontFamily: "Source Han Sans CN"
                }
              }
            ],
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "cross"
              },
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "10%"
            },
            xAxis: {
              type: "category",
              data: boxDataName,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              axisLabel: {
                formatter: "{value}"
              },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              name: "",
              splitArea: {
                show: true
              },
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: data.boxData,
                tooltip: {
                  formatter: function(param) {
                    return [
                      "Experiment " + param.name + ": ",
                      "upper: " + param.data[5],
                      "Q3: " + param.data[4],
                      "median: " + param.data[3],
                      "Q1: " + param.data[2],
                      "lower: " + param.data[1]
                    ].join("<br/>");
                  }
                }
              },
              {
                name: "outlier",
                type: "scatter",
                data: data.outliers
              }
            ]
          };

          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(boxplot_option);
          }, 10);
        } else if (item.echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: item.title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of item.data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            console.log(
              this.$getversionData.control,
              this.$getversionData.city
            );
            this.$refs[item.echartId][0].initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (item.echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            yAxis: {
              type: "category",
              axisLabel: {
                interval: 0
                // rotate: 25
              },
              data: []
            },
            series: [
              {
                type: "bar",
                // color: "#6cb1f4",
                label: {
                  normal: {
                    show: true,
                    position: "insideLeft"
                  }
                },
                data: [],
                itemStyle: {
                  normal: {
                    //每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                    color: function(params) {
                      var colorList = [];
                      for (var aa = 0; aa < item.data.length; aa++) {
                        colorList.push(
                          `#${Math.floor(Math.random() * 0xffffff).toString(
                            16
                          )}`
                        );
                      }
                      return colorList[params.dataIndex];
                    }
                  },
                  //鼠标悬停时：
                  emphasis: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: "rgba(0, 0, 0, 0.5)"
                  }
                }
              }
            ]
          };
          for (let n of item.data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(Yaxas_option);
          }, 10);
        } else if (item.echartType === "acrossColumnars") {
          // 多项横向柱状图
          // let cont =[]
          // item.data.map((items, num) => {
          //   // debugger
          //  cont = items.result

          // })
          let Yaxass_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {
            //   top: '4',
            //   right: '5',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: item.yList
            },
            // dataset: {
            //   source: cont
            // },
            // series:[
            //   {type: 'bar',stack:"gdd"},
            //   // {type: 'bar',stack:"gdd"},
            //   // {type: 'bar',stack:"gdd"}
            // ]
            series: item.data
          };
          item.data.map((itemChild, num) => {
            itemChild.type = "bar";
            itemChild.stack = "df";
            itemChild.data = [];
            item.yList.map(itemYear => {
              if (itemChild.value[itemYear]) {
                itemChild.data.push(itemChild.value[itemYear]);
              } else {
                itemChild.data.push(0);
              }
            });
          });
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(Yaxass_option);
          }, 10);
        } else if (item.echartType === "specialSector") {
          // 特殊扇形
          const datas = item.data;
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [62 - i * 8 + "%", 55 - i * 8 + "%"],
                center: ["50%", "54%"],
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "20",
                      align: "center"
                    },
                    formatter: ["{a| {c}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "900",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value.toFixed(2),
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: item.title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c}",
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            // legend: {
            //   backgroundColor: 'rgba(245,245,245,1)',  // 设置整个图例区域背景颜色
            //   borderRadius: 10,
            //   orient: 'vertical',
            //   right: '5',
            //   top: '12',
            //   align: 'left',
            //   textStyle: {
            //     // color: '#FFFFFF',
            //     fontSize: 10,
            //     font: 'Noto Sans SC'
            //   },
            //   data: item.data,
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            series: optionData.series,
            echartType: item.echartType
          };
          setTimeout(() => {
            this.$refs[item.echartId][0].initChart(spie_option);
          }, 10);
        }
      }
    },
    option(item) {
      this.newEchartId = item.echartId;
      this.echartTitle = item.title;
      this.dialogVisible = true;
      if (item.data.length == 0) {
        this.variable = true;
      } else if (item.echartType === "line") {
        // 折线图
        let category_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "17",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            trigger: "axis"
          },
          xAxis: {
            axisLabel: {
              fontSize: 12,
              interval: 0,
              rotate: 30
            },
            type: "category",
            data: []
          },
          yAxis: {
            type: "value",
            splitNumber: "4",
            scale: true,
            axisLabel: {
              fontSize: 11,
              formatter: function(value, index) {
                if (value >= 10000 && value < 1000000) {
                  value = value / 10000 + "万";
                } else if (value >= 1000000 && value < 10000000) {
                  value = value / 1000000 + "百万";
                } else if (value >= 10000000 && value < 100000000) {
                  value = value / 10000000 + "千万";
                } else if (value >= 100000000) {
                  value = value / 100000000 + "亿";
                }
                return value;
              }
            }
          },
          series: [
            {
              data: [],
              type: "line"
            }
          ],
          grid: {
            //Y轴显示不全
            left: 54
          }
        };
        for (let n of item.data) {
          if (typeof n.value !== "number") {
            continue;
          }
          category_option.xAxis.data = [...category_option.xAxis.data, n.name];
          category_option.series[0].data = [
            ...category_option.series[0].data,
            n.value
          ];
        }
        setTimeout(() => {
          this.$refs.items.initChart(category_option);
        }, 10);
      } else if (item.echartType === "sector") {
        // 圆形扇形图
        let pie_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "17",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            triggrer: "item",
            formatter: "{b}:{c} ({d}%)"
          },
          legend: {
            selectedMode: false,
            backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
            borderRadius: 10,
            orient: "vertical",
            icon: "circle",
            top: "30",
            right: "5",
            align: "left",
            textStyle: {
              fontSize: 10,
              fontWeight: "bold"
            },
            itemWidth: 10, //图标宽
            itemHeight: 10, //图标高
            itemGap: 10 //间距
          },
          color: [
            "#C81812",
            "#EFB70C",
            "#9F77FA",
            "#FB5277",
            "#297AE3",
            "#3CD323",
            "#E5E5E5",
            "#8C8C8C",
            "#FF33FF",
            "#CAFF70",
            "#3399FF",
            "#3366FF",
            "#CCCCFF",
            "#99FFCC",
            "#663333",
            "#00FFFF"
          ],
          series: [
            {
              name: "",
              type: "pie",
              radius: ["55%", "65%"],
              center: ["25%", "60%"],
              // hoverAnimation: false, //高亮不可用
              // hoverOffset: 5, // 高亮的大小
              label: {
                normal: {
                  show: false,
                  position: "center"
                },
                emphasis: {
                  show: true,
                  textStyle: {
                    fontSize: "17",
                    align: "center"
                  },
                  formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                  rich: {
                    a: {
                      fontSize: "23",
                      align: "center",
                      fontWeight: "400"
                    },
                    b: {
                      fontSize: "12",
                      align: "center",
                      fontWeight: "400",
                      color: "#68615f"
                    }
                  }
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              labelLine: {
                normal: {
                  lineStyle: {
                    color: "rgba(255, 255, 255, 0.3)"
                  },
                  smooth: 0.2,
                  length: 10,
                  length2: 20
                }
              },
              data: []
            }
          ]
        };
        for (let item of item.data) {
          if (typeof item.value !== "number") {
            continue;
          }
          pie_option.series[0].data.push({
            name: item.name,
            value: item.value
          });
        }
        setTimeout(() => {
          this.$refs.items.initChart(pie_option);
          this.$refs.items.editEcahrt(pie_option, this.$refs.items.id);
        }, 10);
      } else if (item.echartType === "columnar") {
        // 柱状图
        let axas_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "17",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          grid: {
            left: "1%",
            right: "1%",
            bottom: "1%",
            containLabel: true
          },
          xAxis: {
            type: "category",
            data: [],
            axisLabel: {
              interval: 0,
              rotate: 30
            }
          },
          yAxis: {
            type: "value"
          },
          series: [
            {
              type: "bar",
              label: {
                normal: {
                  show: true,
                  position: "insideRight"
                }
              },
              data: []
            }
          ]
        };
        for (let n of item.data) {
          if (typeof n.value !== "number") {
            continue;
          }
          axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
          axas_option.series[0].data = [...axas_option.series[0].data, n.value];
        }
        setTimeout(() => {
          this.$refs.items.initChart(axas_option);
        }, 10);
      } else if (item.echartType === "boxplot") {
        // 盒须图
        let boxDataList = [];
        let boxDataName = [];
        for (let n of item.data) {
          boxDataList.push(n.value);
          boxDataName.push(n.name);
        }
        let data = echarts.dataTool.prepareBoxplotData(boxDataList);
        let boxplot_option = {
          title: [
            {
              text: item.title,
              left: "10",
              top: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            }
          ],
          tooltip: {
            trigger: "item",
            axisPointer: {
              type: "cross"
            },
            position: function(pos, params, dom, rect, size) {
              var obj = { top: 60 };
              obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
              return obj;
            }
          },
          grid: {
            left: "10%",
            right: "10%",
            bottom: "10%"
          },
          xAxis: {
            type: "category",
            data: boxDataName,
            boundaryGap: true,
            nameGap: 30,
            splitArea: {
              show: false
            },
            axisLabel: {
              formatter: "{value}"
            },
            splitLine: {
              show: false
            }
          },
          yAxis: {
            type: "value",
            name: "",
            splitArea: {
              show: true
            },
            axisLabel: {
              fontSize: 11,
              formatter: function(value, index) {
                if (value >= 10000 && value < 1000000) {
                  value = value / 10000 + "万";
                } else if (value >= 1000000 && value < 10000000) {
                  value = value / 1000000 + "百万";
                } else if (value >= 10000000 && value < 100000000) {
                  value = value / 10000000 + "千万";
                } else if (value >= 100000000) {
                  value = value / 100000000 + "亿";
                }
                return value;
              }
            }
          },
          series: [
            {
              name: "boxplot",
              type: "boxplot",
              data: data.boxData,
              tooltip: {
                formatter: function(param) {
                  return [
                    "Experiment " + param.name + ": ",
                    "upper: " + param.data[5],
                    "Q3: " + param.data[4],
                    "median: " + param.data[3],
                    "Q1: " + param.data[2],
                    "lower: " + param.data[1]
                  ].join("<br/>");
                }
              }
            },
            {
              name: "outlier",
              type: "scatter",
              data: data.outliers
            }
          ]
        };
        setTimeout(() => {
          this.$refs.items.initChart(boxplot_option);
        }, 10);
      } else if (item.echartType === "map") {
        // 地图
        let map_option = {
          title: {
            // 设置标题
            text: item.title,
            x: "left",
            top: "3%",
            left: "3%",
            textStyle: {
              fontSize: "17",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          // dataRange: {
          //   show: true, //是否显示图例
          //   min: 0,
          //   max: 50, //图例标识最大值
          //   text: ["High", "Low"],
          //   inRange: {
          //     color: ['lightskyblue', 'yellow', 'orangered']
          //   }
          // },
          visualMap: {
            min: 0,
            max: 50,
            text: ["High", "Low"],
            inRange: {
              color: ["lightskyblue", "yellow", "orangered"]
            }
          },
          tooltip: {
            formatter: function(params, ticket, callback) {
              if (isNaN(params.value)) {
                params.value = "-";
                return (
                  params.seriesName +
                  "<br />" +
                  params.name +
                  "：" +
                  params.value
                );
              } else {
                return (
                  params.seriesName +
                  "<br />" +
                  params.name +
                  "：" +
                  params.value
                );
              }
            }
          }, // 鼠标移到图里面的浮动提示框
          series: [
            {
              name: this.$getversionData.city,
              type: "map",
              mapType: this.$getversionData.city,
              aspectScale: 0.5, //长宽比例
              width: "60%",
              height: "90%",
              data: [], // 存入 let data数据value值
              itemStyle: {
                borderColor: "#fff", //省份边框线颜色
                borderWidth: 1 //省份边框线宽度
              },
              label: {
                normal: {
                  show: true //显示省份标签
                },
                emphasis: {
                  show: true, //对应的鼠标悬浮效果
                  borderColor: "#01aef0"
                }
              },
              roam: true, //鼠标滚轮放大缩小
              scaleLimit: {
                //滚轮缩放的极限控制
                min: 0.4,
                max: 2.5
              }
            }
          ]
        };
        for (let item of item.data) {
          map_option.series[0].data.push({
            name: item.name,
            value: item.value
          });
        }
        setTimeout(() => {
          this.$refs.items.initChart(map_option, {
            name: "manashan",
            map: maanshan
          });
        }, 10);
      } else if (item.echartType === "lines") {
        // 多折线图
        let dateArr = [];
        let dateYM = new Date();
        let currentYear = dateYM.getFullYear();
        dateYM.setMonth(dateYM.getMonth() + 1, 1);
        for (let i = 0; i < 12; i++) {
          dateYM.setMonth(dateYM.getMonth() - 1);
          let dateM = dateYM.getMonth() + 1;
          dateM = dateM < 10 ? "0" + dateM : dateM;
          let dateArrItem = {
            name: dateYM.getFullYear() + "-" + dateM,
            value: 0
          };
          dateArr.unshift(dateArrItem);
        }
        let x_data = [];
        dateArr.map(arrItem => {
          x_data.push(arrItem.name);
        });
        let categorys_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "13",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            trigger: "axis",
            position: function(pos, params, dom, rect, size) {
              var obj = { top: 60 };
              obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
              return obj;
            }
          },
          // legend: {},
          xAxis: {
            axisLabel: {
              fontSize: 12,
              interval: 0,
              rotate: 15
            },
            type: "category",
            data: x_data
          },
          yAxis: {
            type: "value",
            splitNumber: "4",
            scale: true,
            axisLabel: {
              fontSize: 11,
              formatter: function(value, index) {
                if (value >= 10000 && value < 1000000) {
                  value = value / 10000 + "万";
                } else if (value >= 1000000 && value < 10000000) {
                  value = value / 1000000 + "百万";
                } else if (value >= 10000000 && value < 100000000) {
                  value = value / 10000000 + "千万";
                } else if (value >= 100000000) {
                  value = value / 100000000 + "亿";
                }
                return value;
              }
            }
          },
          series: item.data,
          grid: {
            //Y轴显示不全
            left: 54
          }
        };
        item.data.map(itemChild => {
          itemChild.name = itemChild.name;
          itemChild.type = "line";
          // itemChild.stack = "df";
          itemChild.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          itemChild.result.map(resultChild => {
            dateArr.map((arrItem, num) => {
              if (arrItem.name == resultChild.name) {
                arrItem.value = resultChild.value;
                itemChild.data.map((list, i) => {
                  if (num == i) {
                    itemChild.data.splice(i, 1, arrItem.value);
                  }
                });
              }
            });
          });
        });
        setTimeout(() => {
          this.$refs.items.initChart(categorys_option);
        }, 10);
      } else if (item.echartType === "acrossColumnar") {
        // 横向柱状图
        let Yaxas_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "13",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          // legend: {

          //   top: '12',
          //   right: '13',
          //   textStyle: {
          //     fontSize: 10,
          //     fontWeight: 'bold'
          //   },
          //   itemWidth: 10, //图标宽
          //   itemHeight: 10, //图标高
          //   itemGap: 10 //间距
          // },
          grid: {
            left: "1%",
            right: "1%",
            bottom: "1%",
            containLabel: true
          },
          xAxis: {
            type: "value",
            axisLabel: {
              interval: 0,
              rotate: 30,
              formatter: function(value, index) {
                if (value >= 10000 && value < 1000000) {
                  value = value / 10000 + "万";
                } else if (value >= 1000000 && value < 10000000) {
                  value = value / 1000000 + "百万";
                } else if (value >= 10000000 && value < 100000000) {
                  value = value / 10000000 + "千万";
                } else if (value >= 100000000) {
                  value = value / 100000000 + "亿";
                }
                return value;
              }
            }
          },
          yAxis: {
            type: "category",
            axisLabel: {
              interval: 0
            },
            data: []
          },
          series: [
            {
              type: "bar",
              // color: "#6cb1f4",
              label: {
                normal: {
                  show: true,
                  position: "insideLeft"
                }
              },
              data: [],
              itemStyle: {
                //通常情况下：
                normal: {
                  //每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                  color: function(params) {
                    var colorList = [];
                    for (var aa = 0; aa < item.data.length; aa++) {
                      colorList.push(
                        `#${Math.floor(Math.random() * 0xffffff).toString(16)}`
                      );
                    }
                    return colorList[params.dataIndex];
                  }
                },
                //鼠标悬停时：
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: "rgba(0, 0, 0, 0.5)"
                }
              }
            }
          ]
        };
        for (let n of item.data) {
          if (typeof n.value !== "number") {
            continue;
          }
          Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
          Yaxas_option.series[0].data = [
            ...Yaxas_option.series[0].data,
            n.value
          ];
        }
        setTimeout(() => {
          this.$refs.items.initChart(Yaxas_option);
        }, 10);
      } else if (item.echartType === "acrossColumnars") {
        // 多项横向柱状图
        let Yaxass_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "13",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          legend: {
            selectedMode: false,
            top: "12",
            right: "13",
            textStyle: {
              fontSize: 10,
              fontWeight: "bold"
            },
            itemWidth: 10, //图标宽
            itemHeight: 10, //图标高
            itemGap: 10 //间距
          },
          grid: {
            left: "1%",
            right: "1%",
            bottom: "1%",
            containLabel: true
          },
          xAxis: {
            type: "value",
            axisLabel: {
              interval: 0,
              rotate: 30
            }
          },
          yAxis: {
            type: "category",
            data: item.yList
          },
          series: item.data
        };
        item.data.map((itemChild, num) => {
          itemChild.type = "bar";
          itemChild.stack = "df";
          itemChild.data = [];
          item.yList.map(itemYear => {
            if (itemChild.value[itemYear]) {
              itemChild.data.push(itemChild.value[itemYear]);
            } else {
              itemChild.data.push(0);
            }
          });
        });
        setTimeout(() => {
          this.$refs.items.initChart(Yaxass_option);
        }, 10);
      } else if (item.echartType === "specialSector") {
        // 特殊扇形
        const datas = item.data;
        const arrName = getArrayValue(datas, "name");
        const arrValue = getArrayValue(datas, "value");
        const sumValue = eval(arrValue.join("+"));
        const objData = array2obj(datas, "name");
        const optionData = getData(datas);
        function getArrayValue(array, key) {
          var key = key || "value";
          var res = [];
          if (array) {
            array.forEach(function(t) {
              res.push(t[key]);
            });
          }
          return res;
        }
        function array2obj(array, key) {
          var resObj = {};
          for (var i = 0; i < array.length; i++) {
            resObj[array[i][key]] = array[i];
          }
          return resObj;
        }
        function getData(data) {
          var res = {
            series: [],
            yAxis: []
          };
          for (let i = 0; i < data.length; i++) {
            res.series.push({
              type: "pie",
              clockWise: false, //顺时加载
              hoverAnimation: false, //鼠标移入变大
              radius: [62 - i * 8 + "%", 55 - i * 8 + "%"],
              center: ["30%", "50%"],
              label: {
                normal: {
                  show: false,
                  position: "center"
                },
                emphasis: {
                  show: true,
                  textStyle: {
                    fontSize: "20",
                    align: "center"
                  },
                  formatter: ["{a| {c}}"].join("\n"),
                  rich: {
                    a: {
                      fontSize: "23",
                      align: "center",
                      fontWeight: "400"
                    },
                    b: {
                      fontSize: "12",
                      align: "center",
                      fontWeight: "900",
                      color: "#68615f"
                    }
                  }
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              labelLine: {
                normal: {
                  lineStyle: {
                    color: "rgba(255, 255, 255, 0.3)"
                  },
                  smooth: 0.2,
                  length: 10,
                  length2: 20
                }
              },
              itemStyle: {
                label: {
                  show: false
                },
                labelLine: {
                  show: false
                },
                borderWidth: 5
              },
              data: [
                {
                  value: data[i].value.toFixed(2),
                  name: data[i].name
                },
                {
                  value: sumValue - data[i].value,
                  name: "",
                  itemStyle: {
                    color: "rgba(0,0,0,0)",
                    borderWidth: 0
                  },
                  tooltip: {
                    show: false
                  },
                  hoverAnimation: false
                }
              ]
            });
          }
          return res;
        }
        let spie_option = {
          title: {
            text: item.title,
            x: "10",
            y: "15",
            textStyle: {
              fontSize: "13",
              fontWeight: "bold",
              fontFamily: "Source Han Sans CN"
            }
          },
          tooltip: {
            trigger: "item",
            formatter: "{b}: {c}",
            position: function(pos, params, dom, rect, size) {
              var obj = { top: 60 };
              obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
              return obj;
            }
          },
          legend: {
            selectedMode: false,
            backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
            borderRadius: 10,
            orient: "vertical",
            right: "5",
            top: "30",
            align: "left",
            textStyle: {
              // color: '#FFFFFF',
              fontSize: 10,
              font: "Noto Sans SC"
            },
            data: item.data,
            itemWidth: 10, //图标宽
            itemHeight: 10, //图标高
            itemGap: 10 //间距
          },
          series: optionData.series,
          echartType: item.echartType
        };
        setTimeout(() => {
          this.$refs.items.initChart(spie_option);
        }, 10);
      }
      if (item.data.length == 0) {
        this.variable = true;
      } else if (item.data.length != 0) {
        this.variable = false;
      }
    }
  },
  destroyed() {
    this.socket.onclose = this.close();
  }
};
</script>

<style scoped lang="scss">
.content {
  padding: 30px;
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  min-height: 550px;
  margin-bottom: 0 !important;
}
.echart {
  position: relative;
  height: 260px;
  margin: 8px 0;
  background: rgba(255, 255, 255, 0.9);
}
.newclass {
  background: url(../../assets/imgs/noData.png);
  background-size: 130px 160px;
  background-repeat: no-repeat;
  background-position: 123px 48px;
}
.newclass /deep/ span {
  font-size: 13px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 10px;
  left: 15px;
}
.monthReportDialog {
  position: fixed;
  background: rgba(255, 255, 255, 0.5);
  & /deep/ .el-dialog {
    width: 700px;
    min-height: 400px;
    top: 2.5vh;
  }
  & /deep/ .el-dialog__body {
    padding: 10px 16px 10px;
  }
  & /deep/.el-dialog__header {
    padding: 8px;
    background-color: rgba(69, 138, 228, 0.8);
  }
  & /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  & /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  & /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
  & /deep/ .el-input__inner {
    height: 28px;
    line-height: 28px;
  }
  &/deep/.el-form-item {
    margin-bottom: 5px;
  }
}
$bule: #297ae3 !important;
.search {
  width: 500px;
  margin: 8px;
  border-radius: 8px;
  & /deep/ .el-input__inner {
    height: 28px;
    background-color: rgba(255, 255, 255, 0);
    border: 1px solid #a7adb5;
    line-height: 28px;
    border-radius: 0;
    $color: #a7aeb7;
    &::-webkit-input-placeholder {
      color: $color;
    }
    &::-moz-placeholder {
      color: $color;
    }
    &:-ms-input-placeholder {
      color: $color;
    }
  }
  & /deep/ .el-input-group__append {
    background: $bule;
    border-radius: 0;
    border: 0;
    padding: 0 7px;
  }
  & /deep/ .el-button {
    margin: 0;
    padding: 0;
    color: #fff;
    font-size: 19px;
  }
}
.el-divider--horizontal {
  margin: 0 0 5px;
}
.pagination {
  text-align: center;
  padding-top: 10px;
}
.mc-table {
  &/deep/.el-table__empty-block {
    //无数据
    background-color: rgba(0, 0, 0, 0.03);
  }
}
.viewPopover {
  /deep/.el-popover {
    position: absolute;
    top: 0;
    left: -5px;
  }
  /deep/i {
    font-size: 20px;
    z-index: 1000;
    position: absolute;
    right: 0;
    top: 0;
  }
}
.newclassList {
  background: url(../../assets/imgs/noData.png);
  background-size: 200px 260px;
  background-repeat: no-repeat;
  background-position: 295px 30px;
}
.newclassList /deep/ span {
  font-size: 17px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 80px;
  left: 45px;
}
</style>


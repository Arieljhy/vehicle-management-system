<template>
  <div>
    <div>
      <div class="bg">
        <el-row>
          <el-col :span="24" class="title">
            <div>
              <img src="../../assets/imgs/IDIlogos.png" alt />
              <img src="../../assets/imgs/shujuzhong.png" alt />
            </div>
          </el-col>
          <el-col :span="24">
            <div
              ref="getMb"
              style="margin:0 auto;width:85%;display: flex;
            flex-direction: row;
            flex-wrap: wrap; justify-content:center;"
            >
              <div
                class="loginBtn mouse-pointer"
                v-for="item in list"
                :key="item.id"
                style="margin-right: 20px;"
                @click="handleClose(item)"
              >
                <span style="line-height:56px">{{item.urlName}}</span>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
import http from "@/common/request";
import md5 from "js-md5";
export default {
  data() {
    return {
      list: []
    };
  },
  created() {
    this.list = JSON.parse(this.$route.query.row);
  },
  methods: {
    //登录弹框关闭
    handleClose(item) {
      window.open(item.url);
    },
    getMb() {
      let clientHeight =
        document.documentElement.clientHeight || document.body.clientHeight;
      let marginBottom = clientHeight - 372.5;
      if (marginBottom <= 0) {
        marginBottom = 126;
      }
      this.$refs.getMb.style.marginBottom = `${marginBottom}px`;
    }
  },
  mounted() {
    window.addEventListener("resize", this.getMb);
    this.getMb();
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.getMb);
  }
};
</script>
<style lang="scss" scoped>
.bg {
  filter: brightness(1); //改变背景亮度
  width: 100%;
  height: 100%;
  background: url("../../assets/imgs/shujubj.png") no-repeat;
  background-size: cover;
}
.title {
  margin-top: 80px;
  text-align: center;
  div {
    position: relative;
    img:first-child {
      height: 100px;
      width: 110px;
      margin-right: 11px;
    }
    img:nth-last-child(1) {
      height: 100%;
      position: relative;
      top: 7px;
    }
  }
}
.loginBtn {
  margin-top: 118px;
  min-width: 175px;
  height: 56px;
  background: rgb(18, 113, 206);
  opacity: 0.8;
  border: 0px;
  color: #ffffff;
  font-size: 26px;
}
.tall {
  padding: 0 12px 51px 12px;
}
.low {
  padding: 0 12px 28px 12px;
}
.mb42 {
  margin-bottom: 42px;
}
</style>

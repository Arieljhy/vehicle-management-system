<template>
  <div>
    <div class="content">
      <div style="padding: 9.5px 43.5px">
        <el-divider class="mc-divider lucency"></el-divider>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
          :model="basicInfo"
          :rules="rules"
          ref="basicInfo"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="项目名称：" prop="project">
                <el-input v-model="basicInfo.project"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="项目地址：" prop="city">
                <el-select
                  class="miniColumn"
                  @change="getCity(basicInfo.province,'city')"
                  v-model="basicInfo.province"
                  placeholder="请选择"
                  disabled
                >
                  <el-option
                    v-for="item in district"
                    :key="item.province"
                    :label="item.province"
                    :value="item.province"
                  ></el-option>
                </el-select>
                <el-select
                  class="miniColumn ml5"
                  @change="getCity(basicInfo.city, 'county')"
                  v-model="basicInfo.city"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getCitys"
                    :key="item.name"
                    :label="item.name"
                    :value="item.name"
                  ></el-option>
                </el-select>
                <el-select class="miniColumn ml5" v-model="basicInfo.county" placeholder="请选择">
                  <el-option
                    v-for="item in countys"
                    :key="item.district"
                    :label="item.district"
                    :value="item.district"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12" prop="address" class="address">
              <el-input v-model="basicInfo.address"></el-input>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="住宅性质：" prop="buildingType">
                <el-radio-group
                  v-model="basicInfo.buildingType"
                  v-if="$getversionData.lesseeId!='eidi-maanshan'"
                >
                  <el-radio
                    v-for="item of listBaseData.IDI_PROJECT_TYPES"
                    :key="item.ddId"
                    :label="item.dictKey"
                  >{{item.dictValue}}</el-radio>
                </el-radio-group>
                <el-select v-model="basicInfo.buildingType" placeholder="请选择"   v-if="$getversionData.lesseeId=='eidi-maanshan'">
                  <el-option
                    v-for="item in listBaseData.IDI_PROJECT_TYPES"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12" class="communityName">
              <el-form-item label="小区名称：">
                <el-input v-model="basicInfo.communityName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="项目概述：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  placeholder="请输入内容"
                  v-model="basicInfo.description"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row style="text-align: right; margin-top: 70px;margin-bottom: 30px">
            <el-button type="primary" size="mini" @click="preserveClearing('basicInfo')">提交</el-button>
            <el-button size="mini" @click="closeRecord()">关闭</el-button>
          </el-row>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import MessageEdit from "@/components/Message.vue";
import { mapGetters, mapActions } from "vuex";
export default {
  components: {
    MessageEdit,
  },
  name: "AddNewProject",
  data() {
    return {
      rules: {
        project: [{ required: true, message: "请输项目名称", trigger: "blur" }],
        city: [
          { required: true, message: "请选择项目地址", trigger: "change" },
        ],
        buildingType: [
          { required: true, message: "请选择住宅性质", trigger: "change" },
        ],
        address: [{ required: true, message: "请输小区名称", trigger: "blur" }],
      },
      citys: [],
      basicInfo: {
        county: "",
        project: "", //项目名称
        communityName: "", //小区名称
        description: "", //项目描述
        buildingType: "",
        province: this.$getversionData.province, //省
        address: "",
      },
      countys: [],
      textarea: "",
      dictValue: "",
    };
  },
  computed: {
    ...mapGetters(["district", "listBaseData", "getCitys"]),
  },
  methods: {
    preserveClearing(formName) {
      //提交按钮
      this.$refs[formName].validate((valid) => {
        if (valid) {
        } else {
          return false;
        }
      });
      this.collectionRequest();
    },
    async collectionRequest() {
      if (
        this.basicInfo.project !== "" &&
        this.basicInfo.buildingType !== "" &&
        this.basicInfo.city !== "" &&
        this.basicInfo.county !== ""
      ) {
        const collectiondata = {
          projectName: this.basicInfo.project,
          communityName: this.basicInfo.communityName,
          projectInfo: this.basicInfo.description,
          buildingType: this.basicInfo.buildingType,
          province: this.basicInfo.province,
          city: this.basicInfo.city,
          district: this.basicInfo.county,
          address: this.basicInfo.address,
        };
        this.$store.dispatch("loading", true);
        const res = await this.$api.clearConnector(collectiondata);
        if (res.code == 0) {
          this.$messageSuccess({
            message: "提交成功",
          });
          this.$store.dispatch("loading", false);
          this.closeRecord();
        } else {
          this.$messageError({
            message: "提交失败 ",
          });
          this.$store.dispatch("loading", false);
        }
      } else {
        this.$messageError({
          message: "提交失败,请完善信息",
        });
        this.$store.dispatch("loading", false);
      }
    },
    closeRecord() {
      //关闭按钮
      this.$router.go(-1);
    },
    getCity(i, flag) {
      if (flag === "county") {
        this.basicInfo.county = "";
        let list = [];
        for (let item of this.district) {
          list = [...list, ...item.city];
        }
        for (let item of list) {
          if (i == item.name) {
            this.countys = item.area;
          }
        }
      } else if (flag === "city") {
        this.basicInfo.city = "";
        this.basicInfo.county = "";
        for (let city of this.district) {
          if (city.province == i) {
            this.citys = city.city;
          }
        }
      }
    },
  },
};
</script>
<style scoped lang="scss">
.el-form-item--mini {
  margin-bottom: 12px;
}
.rid {
  margin-right: 150px;
}
.lucency {
  opacity: 0;
}
.content {
  background: rgba(255, 255, 255, 0.9);
}
.address {
  margin-left: -5px;
  /deep/ .el-input__inner {
    height: 28px;
    width: 555px;
  }
}
.communityName {
  /deep/ .el-input__inner {
    height: 28px;
    width: 413px;
  }
}
</style>
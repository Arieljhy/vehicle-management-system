<template>
  <div>
    <div style="position: relative">
      <transition leave-active-class="animated rollOut" enter-active-class="animated rollIn">
        <div v-show="showForm" class="slow content">
          <div class="back-gauge">
            <span style="padding-right:37.5px;position:relative;">
              <el-row class="con-head">
                <div style="width: 80px;height: 51.5px">
                  <img :src="logo_2" style="width: 80px;height: 51.5px" />
                </div>
                <el-input
                  v-model="fuzzyQuery"
                  @keyup.enter.native="()=>{isFuzzyQuery = false;handleQuery()}"
                  placeholder="请输入项目名称 / 保单号"
                >
                  <el-button
                    @click="()=>{isFuzzyQuery = false;handleQuery()}"
                    slot="append"
                    icon="el-icon-search"
                  ></el-button>
                </el-input>
              </el-row>
              <div
                v-show="projectList.length===0"
                style="position: absolute;left: 50%;top: 50%;transform: translate(-50%,-50%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
              <div v-show="projectList.length!==0">
                <div style="margin:47px 0 32px 0">
                  <div
                    :key="index"
                    v-for="(item,index) of projectList"
                    :class="{'heJiaPass':item.zaoJiaMean}"
                  >
                    <el-row style="margin-left: 10px" :class="{'rowMt': item === 1}">
                      <el-col class="text-left" :span="20">
                        <span
                          @click="goForm(item)"
                          class="con-title mouse-pointer"
                        >{{item.projectName}}</span>
                      </el-col>
                      <el-col
                        :span="3"
                        v-if="roleType=='INS'&&item.taskName!='settleClaims'&&item.taskName!='newProject'&&item.taskName!='underwrite'&&item.taskName!='insertInsureInfo'"
                      >
                        <el-button
                          size="mini"
                          type="primary"
                          @click="insReinsuranceFun(item)"
                        >维护再保信息</el-button>
                      </el-col>
                      <el-form>
                        <el-col :span="16">
                          <el-form-item class="text-left" label="保险单号：">
                            <span class="policy">{{item.insContractNo}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="所在区域：">
                            <span>{{item.district}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="是否主承：">
                            <span v-if="item.isMainIns">{{item.isMainIns==='Y'?'是':'否'}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="住宅性质：">
                            <span>{{item.dictValue}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="签单日期：">
                            <span>{{item.signDate | filterDate("yyyy-MM-dd")}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="项目状态：">
                            <span>{{item.projectChnStatus}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="造价均值：">
                            <span>{{item.costPerMeter}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="8">
                          <el-form-item class="text-left" label="业务状态：">
                            <span>{{item.taskChnName}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                          <el-form-item class="text-left" label="当前处理人：">
                            <span>{{item.processRoleId}}</span>
                          </el-form-item>
                        </el-col>
                        <el-col :span="24" v-if="item.warning!=null" style="color:red">
                          <el-form-item class="text-left color" label="预警：">
                            <div
                              style="color:red"
                              :title="item.warning"
                              class="info-content"
                            >{{item.warning}}</div>
                          </el-form-item>
                        </el-col>
                      </el-form>
                    </el-row>
                    <el-divider v-if="item !== 3"></el-divider>
                  </div>
                </div>
                <el-pagination
                  small
                  style="position:absolute;bottom:0;left:50%;transform: translateX(-50%);"
                  class="page-lucency"
                  layout="prev, pager, next"
                  @current-change="handlePageChange"
                  :total="pagination.total"
                  :page-size="pagination.pageSize"
                  :current-page="pagination.currentPage"
                ></el-pagination>
              </div>
            </span>
            <span>
              <query :add="true" title="Project" @doQuery="handleQuery"></query>
            </span>
          </div>
        </div>
      </transition>
      <transition enter-active-class="animated rollIn" leave-active-class="animated rollOut">
        <div v-show="!showForm" class="faster" style="position: absolute; top: 0;">
          <div id="top">
            <flow-chart :current="current" @goBack="showForm = true" />
            <basic-information v-show="schedule.includes('BasicInformation')" :disabled="true" />
            <bstablish-information
              v-show="schedule.includes('BstablishInformation')"
              :disabled="true"
              showMyCase="basicBstablish"
              ref="basicBstablish"
            />
            <underwriting-information
              v-show="schedule.includes('UnderwritingInformation') && roleType!='TIS'"
              ref="underwriting"
              :disabled="true"
              showMyCase="UnderwritingInformation"
            />
            <insurance-review
              v-show="schedule.includes('InsuranceReview') && roleType!='TIS'"
              :disabled="true"
              ref="insuranceReview"
              taskType="underwrite"
              title="保险审核"
            />
            <risk-plan v-show="schedule.includes('RiskPlan')" ref="riskPlan" :disabled="true" />
            <insurance-review
              v-show="schedule.includes('RiskPlanReview')"
              :disabled="true"
              title="风险管理计划审核"
              taskType="checkRiskCtrlPlan"
            />
            <risk-report-list
              v-show="schedule.includes('RiskReportList')"
              ref="riskReportList"
              :disabled="true"
            />
            <risk-events-list
              v-show="schedule.includes('RiskEventsList')"
              ref="riskEventsList"
              :disabled="true"
            />
            <risk-final-report
              v-show="schedule.includes('RiskFinalReport')"
              ref="riskFinalReport"
              :disabled="true"
            />
            <insurance-coverage
              ref="insuranceCoverage"
              v-show="schedule.includes('InsuranceCoverage') && roleType!='TIS'"
              :disabled="true"
            />
            <insurance-review
              v-show="schedule.includes('CopyRiskPlanReview') && roleType!='TIS'"
              :disabled="true"
              title="竣工保险审核"
              taskType="insuranceReview"
            />
            <project-returns ref="ProjectReturns" v-show="schedule.includes('ProjectReturns')" />
            <project-claims
              ref="ProjectClaims"
              v-show="schedule.includes('ProjectClaims') && roleType!='TIS'"
            />
            <el-button @click="goTop" id="go-top" circle :style="screen_width">
              <i class="el-icon-arrow-up"></i>
            </el-button>
          </div>
        </div>
      </transition>
      <!-- 修改再保险信息 -->
      <el-dialog :visible.sync="buildingWindows" title="再保信息" width="900px" class="dialog">
        <el-form
          class="mc-form"
          label-width="100px"
          size="mini"
          label-position="left"
          align="left"
          :model="getUnderwritingInformation"
          :close-on-click-modal="false"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="再保信息：">
                <el-table
                  class="mc-table"
                  :data="getUnderwritingInformation.rows"
                  style="width: 100%;"
                >
                  <el-table-column align="center" label="再保险公司">
                    <template slot-scope="scope">
                      <el-select
                        filterable
                        v-model="scope.row.reinsOrgId"
                        placeholder="请选择"
                        @change="handleItemChange(scope.row,scope.$index)"
                      >
                        <el-option
                          v-for="item in getOrgId.rinsOrgList"
                          :key="item.orgId"
                          :label="item.orgName"
                          :value="item.orgId"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="承保比例(%)">
                    <template slot-scope="scope">
                      <format-input
                        text-align="left"
                        empty-value="0"
                        :max="100"
                        :min="0"
                        :precision="2"
                        v-model="scope.row.reinsPercent"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column prop="mobile" align="center" width="80px">
                    <template slot="header">
                      <div
                        class="el-icon-circle-plus-outline mouse-pointer"
                        style="font-size:20px;line-height:40px"
                        @click="dialogAddLivePics()"
                      ></div>
                    </template>
                    <template slot-scope="scope">
                      <div
                        class="el-icon-remove-outline mouse-pointer"
                        style="font-size:20px;"
                        @click="dialogDelLivePics(scope.$index)"
                      ></div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row style="text-align: right; margin-top: 50px" class="dialogBtn">
            <el-button size="mini" type="primary" @click="dialogSaveRectification(0)">保存</el-button>
            <el-button size="mini" @click="dialogSaveRectification">关闭</el-button>
          </el-row>
        </el-form>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getList, getNode } from "@/assets/js/utils";
import Query from "@/components/Query";
import formatInput from "@/components/formatInput";
import http from "@/common/request";
import logo_2 from "@/assets/imgs/projectInquiry/logo-2.png";
import MessageEdit from "@/components/Message.vue";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //竣工项目保险信息
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import ProjectClaims from "@/components/ProjectSummary/ProjectClaims"; //理赔列表
import ProjectReturns from "@/components/ProjectSummary/ProjectReturns"; //项目回访
export default {
  name: "ProjectInquiry",
  components: {
    Query,
    MessageEdit,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    UnderwritingInformation,
    RiskPlan,
    InsuranceReview,
    InsuranceCoverage,
    RiskReportList,
    RiskEventsList,
    RiskFinalReport,
    ProjectClaims,
    ProjectReturns,
    formatInput
  },
  data() {
    return {
      insContractNo: "",
      projectIds: "",
      getUnderwritingInformation: {},
      buildingWindows: false, //弹窗
      logo_2,
      showForm: true,
      schedule: [],
      fuzzyQuery: "",
      current: {
        finished: [],
        current: []
      },
      projectList: [],
      pagination: {
        pageSize: 10,
        currentPage: 1,
        total: 0
      },
      roleType: JSON.parse(
        sessionStorage.getItem(this.$getversionData.userInfo)
      ).roleType,
      heJiaPass: [
        "startRiskPlan",
        "insertRiskCtrlPlan",
        "checkRiskCtrlPlan",
        "riskCtrlMgr",
        "riskReportMent",
        "settleClaims"
      ]
    };
  },
  computed: {
    ...mapGetters(["projectQueryParams", "control", "getOrgId"]),
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  methods: {
    ...mapActions(['getHeJia']),
    handleItemChange(row, index) {
      this.getUnderwritingInformation.rows.map((item, index1) => {
        if (index != index1) {
          if (row.reinsOrgId == item.reinsOrgId) {
            this.$messageError({ message: "机构已选择" });
            row.reinsOrgId = "";
          }
        }
      });
    },
    dialogAddLivePics() {
      let newPic = {
        projectId: this.projectIds,
        insContractNo: this.insContractNo
      };
      this.getUnderwritingInformation.rows.push(newPic);
    },
    dialogDelLivePics(index) {
      this.getUnderwritingInformation.rows.splice(index, 1);
    },
    //编辑再保
    insReinsuranceFun(item) {
      this.projectIds = item.projectId;
      this.insContractNo = item.insContractNo;
      http
        .get("/insurance/InsReinsurance", { projectId: item.projectId })
        .then(res => {
          this.getUnderwritingInformation = res.data;
        });
      this.buildingWindows = true;
    },
    dialogSaveRectification(falg) {
      if (falg == 0) {
        for (let item of this.getUnderwritingInformation.rows) {
          if (!item.reinsOrgId) {
            this.$messageError({ message: "请选择机构" });
            return;
          }
        }
        http
          .post(
            "/insurance/InsReinsurance/batchSave/" + this.projectIds,
            this.getUnderwritingInformation.rows
          )
          .then(res => {
            if (res.code == 0) {
              this.buildingWindows = false;
            }
          });
      } else {
        this.buildingWindows = false;
      }
    },
    //打开表单
    goForm(row) {
      let item = { ...row };
      item.taskName = getNode(item);
      this.showForm = false;
      const data = {
        newProject: getList(0),
        insertInsureInfo: getList(2),
        underwrite: getList(3),
        startRiskPlan: getList(3),
        insertRiskCtrlPlan: getList(4),
        checkRiskCtrlPlan: getList(7),
        riskCtrlMgr: getList(7),
        insertCompletedInfo: getList(9),
        insuranceReview: getList(10),
        riskReportMent: getList(11),
        settleClaims: getList()
      };
      this.getHeJia(row.zaoJiaMean)
      this.schedule = data[item.taskName];
      switch (item.taskName) {
        case "newProject":
          this.current = {
            current: ["enteringIns"],
            finished: ["newProject"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "insertInsureInfo":
          this.current = {
            current: ["insuranceAudit"],
            finished: ["newProject", "enteringIns"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "underwrite":
          this.current = {
            current: ["launchRisk"],
            finished: ["newProject", "enteringIns", "insuranceAudit"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "startRiskPlan":
          this.current = {
            current: ["enteringRisk"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "insertRiskCtrlPlan":
          this.current = {
            current: ["checkRisk"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          break;
        case "checkRiskCtrlPlan":
          this.current = {
            current: ["riskManage"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          break;
        case "riskCtrlMgr":
          this.current = {
            current: ["entreingCompleted"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          break;
        case "insertCompletedInfo":
          this.current = {
            current: ["insuranceCheck"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted"
            ],
            projectId: item.projectId
          };
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          if (this.control.includes("instructions")) {
            this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
            this.$refs.insuranceCoverage.init(item.projectId);
          }
          break;
        case "insuranceReview":
          this.current = {
            current: ["riskReturn"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck"
            ],
            projectId: item.projectId
          };
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          if (this.control.includes("instructions")) {
            this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
            this.$refs.insuranceCoverage.init(item.projectId);
          }
          break;
        case "riskReportMent":
          this.current = {
            current: ["claim"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck",
              "riskReturn"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          if (this.control.includes("instructions")) {
            this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
            this.$refs.insuranceCoverage.init(item.projectId);
          }
          this.$refs.ProjectReturns.projectReturn(item.projectId);
          if (this.control.includes("claimsList")) {
            this.$refs.ProjectClaims.projectClaim(item.projectId);
          }
          break;
        case "settleClaims":
          this.current = {
            current: ["projectCompletion"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck",
              "riskReturn",
              "claim"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          if (this.control.includes("instructions")) {
            this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
            this.$refs.insuranceCoverage.init(item.projectId);
          }
          this.$refs.ProjectReturns.projectReturn(item.projectId);
          if (this.control.includes("claimsList")) {
            this.$refs.ProjectClaims.projectClaim(item.projectId);
          }
          break;
      }
      if (
        item.taskName != "newProject" &&
        this.control.includes("acceptInsurance")
      ) {
        this.$refs.underwriting.init(item.projectId);
      }
      if (
        this.control.includes("checkInsurance") &&
        item.taskName != "newProject" &&
        item.taskName != "insertInsureInfo"
      ) {
        this.$refs.insuranceReview.insuranceReview({
          projectId: item.projectId
        });
      }
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    //回到顶部按钮
    showGoTop() {
      if (!this.showForm) {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },
    async handleQuery(params) {
      if (params) {
        this.params = params;
      }
      const { isFresh, queryParams } = this.params || {};
      if (isFresh) {
        this.pagination = {
          pageSize: 10,
          currentPage: 1,
          total: 0
        };
      }
      //如果第一次有fuzzyQuery查询条件，则currentPage为1，否则当前分页取当前页
      if (this.fuzzyQuery !== "" && !this.isFuzzyQuery) {
        this.isFuzzyQuery = true;
        this.pagination.currentPage = 1;
      }
      this.$store.dispatch("loading", true);
      const { pageSize, currentPage } = this.pagination;
      //limit,每页有多少条，offset,第几页
      const {
        code,
        data: { rows, total },
        msg
      } = await this.$api.getProjectList({
        ...queryParams,
        offset: currentPage,
        limit: pageSize,
        ...(this.fuzzyQuery && { fuzzyQuery: this.fuzzyQuery })
      });
      if (code === 0) {
        this.pagination.total = total;
        this.projectList = rows;
        this.projectList.map(item => {
          if (item.warning && item.warning.indexOf("造价均值") > -1) {
            if (this.heJiaPass.includes(item.taskName)) {
              item.zaoJiaMean = true;
            }
          }
        });
      } else {
        this.messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      if (this.params) {
        this.params.isFresh = false;
      }
      this.handleQuery();
    }
  },
  created() {
    this.handleQuery();
  },
  mounted() {
    window.addEventListener("scroll", this.showGoTop, true);
  },

  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  }
};
</script>
<style scoped lang="scss">
.rowMt {
  margin-top: 33.5px;
}
.content {
  min-height: 493px;
  background-color: rgba(255, 255, 255, 0.9);
  .con-head {
    $bule: #297ae3;
    display: flex;
    align-items: flex-end;
    .el-image {
      margin-left: 5px;
    }
    .el-input {
      width: 585px;
      $height: 39.5px;
      /deep/ .el-input__inner {
        background-color: rgba(255, 255, 255, 0);
        $color: #e7edf7;
        border-radius: 0;
        height: $height;
        line-height: $height;
        border: 1px solid $bule;
        &::-webkit-input-placeholder {
          color: $color;
        }
        &::-moz-placeholder {
          color: $color;
        }
        &:-ms-input-placeholder {
          color: $color;
        }
      }
    }
    /deep/ .el-input-group__append {
      background: $bule;
      border-radius: 0;
      border: 0;
      padding: 0;
      width: 49px;
      height: 39.5px;
    }
    /deep/ .el-button {
      margin: 0;
      padding: 0;
      color: #fff;
      font-size: 25px;
    }
  }
  .back-gauge {
    display: flex;
    padding: 27px 29px 18.5px 29px;
    .el-input {
      margin-left: 20px;
    }
  }
  $bule: #297ae3;
  .con-title {
    font-size: 14.5px;
    color: $bule;
    font-weight: bold;
    padding-bottom: 1.5px;
    border-bottom: 1.5px solid $bule;
  }
  .el-form {
    $height: 13.5px;
    $color: rgba(62, 58, 57, 1);
    $font: 12.5px;
    .el-form-item {
      margin: 8px 0 0 0;
      font-weight: bold;
      height: $height;
      /deep/ .el-form-item__label {
        font-size: $font;
        color: $color;
        line-height: $height !important;
        padding: 0 !important;
      }
      /deep/ .el-form-item__content {
        font-size: $font;
        color: $color;
        line-height: $height !important;
      }
      .policy {
        font-weight: bold;
      }
    }
  }
  .el-divider {
    margin: 12.5px 0 13.5px 0;
    background-color: $bule;
    width: 678px;
    height: 1.5px;
  }
}
.div {
  cursor: pointer;
  background: #297ae3;
  width: 75px;
  height: 75px;
  margin-left: 300px;
  border-radius: 5px;

  span {
    width: 62px;
    height: 9px;
    font-size: 12px;
    font-family: Source Han Sans CN;
    font-weight: bold;
    color: rgba(226, 226, 226, 1);
  }
  img {
    padding-right: 26px;
    margin-top: 16.5px;
    height: 24px;
    width: 24px;
  }
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 266px;
}
.dialog /deep/.el-select.el-input--suffix.el-input__inner {
  width: 266px;
}
.heJiaPass {
  background-image: url(../../assets/imgs/hejia.png);
  background-repeat: no-repeat;
  background-size: 72px;
  background-position: 53% 38%;
}
</style>
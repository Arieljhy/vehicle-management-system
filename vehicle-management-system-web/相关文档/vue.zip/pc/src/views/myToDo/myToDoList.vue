<template>
  <div class="content_list">
    <el-row>
      <div @click="backMytodo" class="case_title mouse-pointer">
        <i class="el-icon-arrow-left"></i>
        <span>项目展开</span>
      </div>
    </el-row>
    <el-row :gutter="8" style="margin-top:2px">
      <el-col :span="6" v-for="item in mytodoList.rows" :key="item.id" style="margin-top:18px">
        <el-row>
          <div class="mouse-pointer" @click="goForm(taskType, item)">
            <el-col
              :span="24"
              class="title"
              style="background:rgba(41,122,227,0.56)"
              v-if="taskType==='insertInsureInfo'"
            >
              <div style="height:37px;line-height: 37px;">录入保险审核信息</div>
            </el-col>
            <el-col
              :span="24"
              class="title"
              style="background:rgba(255,154,42,0.56)"
              v-if="taskType==='checkRiskCtrlPlan'"
            >
              <div style="height:37px;line-height: 37px;">审核风险管理工作计划</div>
            </el-col>
            <el-col
              :span="24"
              class="title"
              style="background:rgba(5,207,173,0.56)"
              v-if="taskType==='insertCompletedInfo'"
            >
              <div style="height:37px;line-height: 37px;">录入竣工项目保险信息</div>
            </el-col>
          </div>
        </el-row>
        <el-row class="case">
          <div class="mouse-pointer" @click="goForm(taskType, item)">
            <el-col
              :span="6"
              :offset="1"
              class="date leftContent"
              :class="[mc_data]"
              v-if="item.mydate.case_month"
            >
              <span>{{item.mydate.case_month}}</span>
              <div class="days" :style="mc_data_color">{{item.mydate.case_day}}</div>
              <div class="year days" :style="mc_date_color">{{item.mydate.case_year}}</div>
            </el-col>
            <el-col :span="6" :offset="1" class="none_info" v-if="!item.mydate.case_month"></el-col>
            <el-col :span="16" class="rightContent">
              <div
                style="margin-top:12px"
                class="edit_text"
                :title="item.projectName"
              >{{item.projectName}}&nbsp;</div>
              <div
                v-if="item.insContractNo!=null"
                style="margin-top:12px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                :title="item.insContractNo"
              >保单号：{{item.insContractNo}}</div>
              <div
                v-else
                style="margin-top:12px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
              >保单号：未填写</div>
              <div style="margin-top:5px">住宅性质：{{item.dictValue}}</div>
              <div style="margin-top:5px">阶段：{{item.projectChnStatus}}</div>
            </el-col>
          </div>
          <div
            v-if="item.status=='UNAPPROVED' && (item.taskName=='insertInsureInfo' || item.taskName=='insertCompletedInfo')"
            class="reject_info"
          ></div>
        </el-row>
      </el-col>
      <div
        v-show="mytodoList.rows.length===0"
        style="position: absolute;left: 50%;top: 50%;transform: translate(-50%,67%);"
      >
        <img src="@/assets/imgs/noData.png" width="220" height="171" />
      </div>
    </el-row>
    <el-pagination
      small
      class="page-lucency text-right mt10 control"
      layout="prev, pager, next"
      :page-size="8"
      @current-change="handleCurrentChange"
      :total="mytodoList.total"
      v-show="mytodoList.total!=0"
      :current-page.sync="currentPage"
    ></el-pagination>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "MytodoList",
  data() {
    return {
      listTotal: 0,
      currentPage:1
    };
  },
  mounted() {
    this.$EventBus.$on("QUERY_EVENT", () => {
      this.mytodoList.total = 0;
      this.currentPage = 1;
    });
  },
  computed: {
    ...mapGetters(["fuzzyQuery", "screen"]),
    mc_data() {
      switch (this.taskType) {
        case "insertInsureInfo":
          return "date1";
        case "checkRiskCtrlPlan":
          return "date2";
        case "insertCompletedInfo":
          return "date3";
      }
    },
    mc_data_color() {
      switch (this.taskType) {
        case "insertInsureInfo":
          return { color: "#7eafed", lineHeight: "20px" };
        case "checkRiskCtrlPlan":
          return { color: "#F8C184", lineHeight: "20px" };
        case "insertCompletedInfo":
          return { color: "#65D8C5", lineHeight: "20px" };
      }
    },
    mc_date_color() {
      switch (this.taskType) {
        case "insertInsureInfo":
          return { color: "#7eafed", lineHeight: "14px" };
        case "checkRiskCtrlPlan":
          return { color: "#F8C184", lineHeight: "14px" };
        case "insertCompletedInfo":
          return { color: "#65D8C5", lineHeight: "14px" };
      }
    }
  },
  props: {
    mytodoList: {
      type: Object
    },
    taskType: {
      type: String
    }
  },
  methods: {
    ...mapActions(["riskTodo"]),
    handleCurrentChange(val) {
      this.currentPage = val
      this.getmytodo(val, this.fuzzyQuery.value);
    },
    //返回待办首页
    backMytodo() {
      this.$emit("backMytodo", "2222");
    },
    //展示大表单
    goForm(flag, item) {
      this.$emit("goForm", flag, item);
    },
    async getmytodo(val, fuzzyQuery) {
      const keywords = {
        taskName: this.taskType,
        offset: val,
        limit: 8,
        fuzzyQuery: fuzzyQuery,
        beginSignDate:this.screen.beginSignDate,
        buildingType: this.screen.buildingType,
        city: this.screen.city,
        district: this.screen.district,
        endSignDate: this.screen.endSignDate,
        insContractNo: this.screen.insContractNo,
        isMainIns: this.screen.isMainIns,
        maxCostPerMeter: this.screen.maxCostPerMeter,
        minCostPerMeter: this.screen.minCostPerMeter,
        orgId: this.screen.orgId,
        projectName: this.screen.projectName,
        province: this.screen.province,
      };
      this.$store.dispatch("loading", true);
      this.riskTodo(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    },
    getDate(date) {
      const monthsInEng = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec"
      ];
      const newDate = new Date(date.replace(/-/g, "/"));
      const mydate = {
        case_year: newDate.getFullYear(),
        case_month: monthsInEng[newDate.getMonth()],
        case_day: newDate.getDate()
      };
      return mydate;
    }
  }
};
</script>
<style scoped lang="scss">
.content_list {
  padding: 31.5px 43.5px;
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  height: 430px;
}
.case {
  background: rgba(255, 255, 255, 0.9);
  box-shadow: 0px 5px 4px 0px rgba(0, 0, 0, 0.28);
  border-radius: 0px 0px 6px 6px;
}
.control {
  position: absolute;
  bottom: 30px;
  right: 30px;
  left: 0;
}
.days {
  color: #7eafed;
  font-size: 29px;
  font-weight: bold;
  margin-left: -10px;
  line-height: 24px;
}
.year {
  font-size: 9px;
  line-height: 16px;
}
.title {
  color: #fff;
}

.leftContent span {
  color: #fff;
  line-height: 22px;
  font-weight: bold;
}
.date {
  height: 102px;
  margin-top: 25px;
  background-repeat: no-repeat;
  background-size: 90% 62%;
}
.date1 {
  background-image: url(../../assets/imgs/todo/todo1.png);
}
.date2 {
  background-image: url(../../assets/imgs/todo/todo2.png);
}
.date3 {
  background-image: url(../../assets/imgs/todo/todo3.png);
}
.rightContent {
  text-align: left;
  font-size: 9px;
  font-weight: bold;
}
.rightContent p {
  font-weight: bold;
  font-size: 11px;
  margin-top: 18px;
}
.case_title {
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.none_info {
  background-image: url(../../assets/imgs/none_info.png);
  background-repeat: no-repeat;
  background-size: 86% 65%;
  height: 95px;
  margin-top: 32px;
}
.reject_info {
  background-image: url(../../assets/imgs/bohui.png);
  background-repeat: no-repeat;
  background-size: 34% 79%;
  height: 110px;
  background-position: center;
}
.edit_text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
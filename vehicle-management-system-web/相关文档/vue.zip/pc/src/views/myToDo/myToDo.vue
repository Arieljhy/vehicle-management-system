<template>
  <div>
    <div style="position: relative">
      <transition
        :duration="4000"
        :enter-active-class="showMyCase == 'mytodo' ? 'animated zoomInLeft' : 'animated slideInLeft'"
        :leave-active-class="showMyCase == 'mytodoList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div v-show="showMyCase==='mytodo'">
          <el-row>
            <el-col :span="8">
              <div class="echart">
                <span
                  class="el-icon-edit-outline mouse-pointer"
                  @click="selectEchart(0)"
                  style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
                >自定义</span>
                <div v-show="this.variable" class="newclass" style="height:240px">
                  <span>{{this.echartTitle}}</span>
                </div>
                <chart ref="chart"></chart>
              </div>
              <!-- 无数据时 -->
              <div
                v-show="this.dataShow.length===0"
                style="position: absolute;left: 15%;top: 150px;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
              <div class="echart" style="margin-top:7px">
                <span
                  class="el-icon-edit-outline mouse-pointer"
                  @click="selectEchart(1)"
                  style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
                >自定义</span>
                <div v-show="this.variabletwo" class="newclass" style="height:240px">
                  <span>{{this.echartTitletwo}}</span>
                </div>
                <chart ref="chartLine"></chart>
              </div>
              <!-- 无数据时 -->
              <div
                v-show="this.dataShow.length===0"
                style="position: absolute;left: 15%;top: 400px;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
            </el-col>
            <el-col :span="1">
              <div class="content1"></div>
              <div class="content1"></div>
            </el-col>
            <el-col :span="15">
              <div>
                <el-row>
                  <el-col :span="12">
                    <div
                      class="content case_blue mouse-pointer"
                      style="margin-bottom: 7px;margin-left:7px"
                    >
                      <el-row>
                        <el-col :span="24" class="title">
                          <p>录入保险审核信息</p>
                        </el-col>
                      </el-row>
                      <el-row>
                        <div
                          @click="selectCase('insertInsureInfo')"
                          v-if="riskTodoAll.insertInsure.projectId"
                        >
                          <el-col
                            :span="6"
                            :offset="1"
                            class="date leftContent"
                            v-if="riskTodoAll.insertInsure.mydate.case_month"
                          >
                            <span>{{riskTodoAll.insertInsure.mydate.case_month}}</span>
                            <div
                              class="days"
                              style="line-height: 40px"
                            >{{riskTodoAll.insertInsure.mydate.case_day}}</div>
                            <div
                              class="year days"
                              style="line-height: 14px"
                            >{{riskTodoAll.insertInsure.mydate.case_year}}</div>
                          </el-col>
                          <el-col
                            :span="6"
                            :offset="1"
                            class="none_info"
                            v-if="!riskTodoAll.insertInsure.mydate.case_month"
                          ></el-col>
                          <el-col :span="16" :offset="1" class="rightContent">
                            <div
                              :title="riskTodoAll.insertInsure.projectName"
                              style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                            >{{riskTodoAll.insertInsure.projectName}}&nbsp;</div>
                            <div
                              v-if="riskTodoAll.insertInsure.insContractNo!=null"
                              :title="riskTodoAll.insertInsure.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;margin-top:6px"
                            >保单号：{{riskTodoAll.insertInsure.insContractNo}}</div>
                            <div v-else style="margin-top:6px">保单号：未填写</div>
                            <div style="margin-top:6px">住宅性质：{{riskTodoAll.insertInsure.dictValue}}</div>
                            <div
                              style="margin-top:6px"
                            >阶段：{{riskTodoAll.insertInsure.projectChnStatus}}</div>
                          </el-col>
                        </div>
                        <div
                          v-if="!riskTodoAll.insertInsure.projectId"
                          class="none_list none_listbase"
                        >
                          <div style="padding-top: 121px;font-size: 13px;font-weight: 600;">暂无信息</div>
                        </div>
                        <div v-if="riskTodoAll.insertInsure.status=='UNAPPROVED'" class="bohui"></div>
                      </el-row>
                    </div>
                  </el-col>
                  <el-col :span="12">
                    <div
                      class="content case_yellow mouse-pointer"
                      style="margin-bottom: 7px;margin-left:7px"
                    >
                      <el-row>
                        <el-col :span="24" class="title">
                          <p>审核风险管理工作计划</p>
                        </el-col>
                      </el-row>
                      <el-row>
                        <div
                          @click="selectCase('checkRiskCtrlPlan')"
                          v-if="riskTodoAll.checkRiskCtrlPlan.projectId"
                        >
                          <el-col
                            :span="6"
                            :offset="1"
                            class="date date1 leftContent"
                            v-if="riskTodoAll.checkRiskCtrlPlan.mydate.case_month"
                          >
                            <span>{{riskTodoAll.checkRiskCtrlPlan.mydate.case_month}}</span>
                            <div
                              class="days"
                              style="color:#F8C184;line-height: 40px;"
                            >{{riskTodoAll.checkRiskCtrlPlan.mydate.case_day}}</div>
                            <div
                              class="year days"
                              style="color:#F8C184;line-height: 14px;"
                            >{{riskTodoAll.checkRiskCtrlPlan.mydate.case_year}}</div>
                          </el-col>
                          <el-col
                            :span="6"
                            :offset="1"
                            class="none_info1"
                            v-if="!riskTodoAll.checkRiskCtrlPlan.mydate.case_month"
                          ></el-col>
                          <el-col :span="16" :offset="1" class="rightContent">
                            <div
                              :title="riskTodoAll.checkRiskCtrlPlan.projectName"
                              style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                            >{{riskTodoAll.checkRiskCtrlPlan.projectName}}&nbsp;</div>
                            <div
                              v-if="riskTodoAll.checkRiskCtrlPlan.insContractNo!==null"
                              :title="riskTodoAll.checkRiskCtrlPlan.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;margin-top:6px"
                            >保单号：{{riskTodoAll.checkRiskCtrlPlan.insContractNo}}</div>
                            <div v-else style="margin-top:6px">保单号：未填写</div>
                            <div
                              style="margin-top:6px"
                            >住宅性质：{{riskTodoAll.checkRiskCtrlPlan.dictValue}}</div>
                            <div
                              style="margin-top:6px"
                            >阶段：{{riskTodoAll.checkRiskCtrlPlan.projectChnStatus}}</div>
                          </el-col>
                        </div>
                        <div
                          v-if="!riskTodoAll.checkRiskCtrlPlan.projectId"
                          class="none_list1 none_listbase"
                        >
                          <div style="padding-top: 121px;font-size: 13px;font-weight: 600;">暂无信息</div>
                        </div>
                      </el-row>
                    </div>
                  </el-col>

                  <el-col :span="12">
                    <div
                      class="content case_green mouse-pointer"
                      style="margin-bottom: 7px;margin-left:7px"
                    >
                      <el-row>
                        <el-col :span="24" class="title" style="padding-right: 0">
                          <p>录入竣工项目保险信息</p>
                        </el-col>
                      </el-row>
                      <el-row>
                        <div
                          @click="selectCase('insertCompletedInfo')"
                          v-if="riskTodoAll.insertCompleted.projectId"
                        >
                          <el-col
                            :span="6"
                            :offset="1"
                            class="date date2 leftContent"
                            v-if="riskTodoAll.insertCompleted.mydate.case_month"
                          >
                            <span>{{riskTodoAll.insertCompleted.mydate.case_month}}</span>
                            <div
                              class="days"
                              style="color:#65D8C5;line-height: 40px"
                            >{{riskTodoAll.insertCompleted.mydate.case_day}}</div>
                            <div
                              class="year days"
                              style="color:#65D8C5;line-height: 14px"
                            >{{riskTodoAll.insertCompleted.mydate.case_year}}</div>
                          </el-col>
                          <el-col
                            :span="6"
                            :offset="1"
                            class="none_info2"
                            v-if="!riskTodoAll.insertCompleted.mydate.case_month"
                          ></el-col>
                          <el-col :span="16" :offset="1" class="rightContent">
                            <div
                              :title="riskTodoAll.insertCompleted.projectName"
                              style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                            >{{riskTodoAll.insertCompleted.projectName}}&nbsp;</div>
                            <div
                              v-if="riskTodoAll.insertCompleted.insContractNo!=null"
                              :title="riskTodoAll.insertCompleted.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;margin-top:6px"
                            >保单号：{{riskTodoAll.insertCompleted.insContractNo}}</div>
                            <div v-else style="margin-top:6px">保单号：未填写</div>
                            <div
                              style="margin-top:6px"
                            >住宅性质：{{riskTodoAll.insertCompleted.dictValue}}</div>
                            <div
                              style="margin-top:6px"
                            >阶段：{{riskTodoAll.insertCompleted.projectChnStatus}}</div>
                          </el-col>
                        </div>
                        <div
                          v-if="!riskTodoAll.insertCompleted.projectId"
                          class="none_list2 none_listbase"
                        >
                          <div style="padding-top: 121px;font-size: 13px;font-weight: 600;">暂无信息</div>
                        </div>
                        <div v-if="riskTodoAll.insertCompleted.status=='UNAPPROVED'" class="bohui"></div>
                      </el-row>
                    </div>
                  </el-col>

                  <el-col :span="12" style>
                    <div class="card_board">
                      <div class="card_num">{{cardNum}}</div>
                    </div>
                  </el-col>
                </el-row>
              </div>
            </el-col>
          </el-row>
        </div>
      </transition>
      <transition
        :duration="4000"
        :enter-active-class="showMyCase == 'mytodoList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
        :leave-active-class="showMyCase == 'mytodo' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div v-if="showMyCase==='mytodoList'" style="position: absolute; top: 0;width: 100%;">
          <mytodo-list
            @goForm="goForm"
            @backMytodo="backMytodo"
            :mytodoList="riskTodoAll.allTypeList[taskType]"
            :taskType="taskType"
          ></mytodo-list>
        </div>
      </transition>
      <!-- echart自定义 -->
      <transition
        :duration="4000"
        :enter-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
        :leave-active-class="showMyCase == 'mytodo' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div v-if="showMyCase==='mytodoEchartList'" style="position: absolute; top: 0;width: 100%;">
          <mytodo-echart-list
            @option="option"
            @backMytodo="backMytodo"
            :origEchartId="origEchartId"
            :interfaceName="interfaceName"
          ></mytodo-echart-list>
        </div>
      </transition>

      <transition
        :enter-active-class="showMyCase == 'mytodoList' ? 'animated zoomInLeft' : 'animated slideInLeft' "
        :leave-active-class="showMyCase == 'mytodoList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <!-- insertInsureInfo录入保险审核，checkRiskCtrlPlan审核风险管理，insertCompletedInfo，录入竣工 -->
        <div
          v-show="showMyCase ==='insertInsureInfo' || showMyCase ==='checkRiskCtrlPlan' || showMyCase ==='insertCompletedInfo'"
          style="position: absolute; top: 0;width: 100%;"
        >
          <div id="top">
            <flow-chart :current="current" @goBack="scc('close')" />
            <!-- 竣工审核驳回 -->
            <insurance-review
              title="驳回意见"
              taskType="insuranceReview"
              :disabled="true"
              v-show="showMyCase ==='insertCompletedInfo' && getInsuranceReview.insuranceReview.processIsEnd=='N'"
            />
            <insurance-coverage
              ref="insuranceCoverage"
              v-show="showMyCase ==='insertCompletedInfo'"
            />
            <insurance-review
              ref="insuranceReview"
              title="风险管理计划审核"
              taskType="newCheckRiskCtrlPlan"
              v-show="showMyCase ==='checkRiskCtrlPlan'"
            />
            <insurance-review
              title="历史风险管理计划审核"
              taskType="checkRiskCtrlPlan"
              :disabled="true"
              v-show="showMyCase ==='checkRiskCtrlPlan' && getInsuranceReview.checkRiskCtrlPlan.processIsEnd=='N'"
            />
            <!-- 保险审核驳回 -->
            <insurance-review
              title="驳回意见"
              taskType="underwrite"
              :disabled="true"
              v-show="showMyCase ==='insertInsureInfo' && getInsuranceReview.underwrite.processIsEnd=='N'"
            />
            <!-- <risk-plan :disabled="true" ref="riskPlan" v-show="showMyCase ==='checkRiskCtrlPlan'" /> -->
            <basic-information
              :disabled="showMyCase==='checkRiskCtrlPlan' || showMyCase ==='insertCompletedInfo'"
            />
            <bstablish-information
              :disabled="true"
            :showMyCase="taskType"
              v-if="showMyCase !=='insertInsureInfo'"
              ref="basicBstablish"
            />
            <bstablish-information
              v-if="showMyCase ==='insertInsureInfo'"
             :showMyCase="taskType"
              ref="basicBstablish"
            />
            <underwriting-information
              ref="underwriting"
              :error="error"
              :disabled="true"
              :showMyCase="taskType"
              v-if="showMyCase !=='insertInsureInfo'"
            />
            <underwriting-information
              ref="underwriting"
              :error="error"
              :showMyCase="taskType"
              v-if="showMyCase ==='insertInsureInfo'"
            />
            <insurance-review
              title="保险审核"
              taskType="underwrite"
              v-if="showMyCase ==='insertCompletedInfo' || showMyCase==='checkRiskCtrlPlan'"
              :disabled="showMyCase ==='insertCompletedInfo' || showMyCase==='checkRiskCtrlPlan'"
            />
            <risk-plan
              ref="riskPlan"
              v-show="showMyCase ==='insertCompletedInfo' || showMyCase ==='checkRiskCtrlPlan'"
              :disabled="true"
            />
            <insurance-review
              title="风险管理计划审核"
              taskType="checkRiskCtrlPlan"
              v-if="showMyCase ==='insertCompletedInfo'"
              :disabled="showMyCase ==='insertCompletedInfo'"
            />
            <risk-report-list
              v-show="showMyCase ==='insertCompletedInfo'"
              ref="riskReportList"
              :disabled="showMyCase ==='insertCompletedInfo'"
            />
            <risk-events-list
              ref="riskEventsList"
              v-show="showMyCase ==='insertCompletedInfo'"
              :disabled="showMyCase ==='insertCompletedInfo'"
            />
            <risk-final-report
              ref="riskFinalReport"
              v-show="showMyCase ==='insertCompletedInfo'"
              :disabled="true"
            />
            <div class="text-right" :class="{'mt10': showMyCase ==='checkRiskCtrlPlan'}">
              <el-button
                v-if="showMyCase != 'checkRiskCtrlPlan'"
                :disabled="isLocked"
                @click="scc('save', showMyCase)"
                type="primary"
                size="mini"
              >保存</el-button>
              <el-button
                @click="scc('commit', showMyCase)"
                type="primary"
                size="mini"
                :disabled="isLocked"
              >提交</el-button>
              <el-button @click="scc('close', showMyCase)" size="mini">关闭</el-button>
            </div>
            <el-button @click="goTop" id="go-top" circle :style="screen_width">
              <i class="el-icon-arrow-up"></i>
            </el-button>
          </div>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>
import ProjectSummary from "@/views/projectSummary/projectSummary";
import MytodoList from "@/views/myToDo/myToDoList";
import MytodoEchartList from "@/views/myToDo/myToDoEchartList";
import { mapGetters, mapActions } from "vuex";
import chart from "@/components/charts";
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //标的信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import http from "@/common/request";
export default {
  name: "MyToDo",
  components: {
    chart,
    ProjectSummary,
    RiskEventsList,
    MytodoList,
    MytodoEchartList,
    RiskPlan,
    RiskFinalReport,
    RiskReportList,
    InsuranceCoverage,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    UnderwritingInformation,
    InsuranceReview
  },
  computed: {
    ...mapGetters([
      "riskTodoAll",
      "userInfo",
      "getBasicBstablish",
      "getUnderwritingInformation",
      "getCopyUnderwriting",
      "getInsuranceCoverage",
      "getInsuranceReview",
      "copyProjectSummary",
      'fuzzyQuery',
      'screen'
    ]),
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  watch: {
    $route: {
      handler: (val, oldVal) => {},
      deep: true
    },
    showMyCase(newVal, oldVal) {
      this.showFilter(newVal);
      if (
        newVal != "insertInsureInfo" ||
        (newVal != "insertCompletedInfo" && !this.isLocked)
      ) {
        clearInterval(this.myLock);
      }
    }
  },
  beforeRouteLeave(to, from, next) {
    if (from.path == "/myToDo" && this.showMyCase == "insertInsureInfo") {
      if (
        JSON.stringify(this.copyProjectSummary.prjBasicInfoDO) !==
          JSON.stringify(this.getBasicBstablish.prjBasicInfoDO) ||
        JSON.stringify(this.copyProjectSummary.prjConstructionInfoDO) !==
          JSON.stringify(this.getBasicBstablish.prjConstructionInfoDO) ||
        JSON.stringify(this.copyProjectSummary.prjSingleUnitsDOList.rowList) !==
          JSON.stringify(this.getBasicBstablish.prjSingleUnitsDOList.rowList) ||
        JSON.stringify(this.copyProjectSummary.getUnderwritingInformation) !==
          JSON.stringify(this.getUnderwritingInformation)
      ) {
        this.$confirm("表单未保存，是否继续退出？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(async () => {
            next(vm => {
              // vm.$router.push(to.path)
            });
          })
          .catch(() => {});
      } else {
        next(vm => {
          // vm.$router.push(to.path)
        });
      }
    } else {
      next(vm => {
        // vm.$router.push(to.path)
      });
    }
  },
  data() {
    return {
      charts: {
        maanshan: maanshan,
        beijing: beijing,
        shanghai: shanghai,
        yangquan: yangquan
      },
      dataShow: [],
      error: false,
      showMyCase: "mytodo", //mytodo  mytodoList  mytodoDetail
      ids: "",
      idstwo: "",
      origEchartId: "",
      interfaceName: "TODO",
      current: {
        finished: [],
        current: []
      },
      taskType: "insertInsureInfo",
      cardNum: 0,
      variable: false,
      echartTitle: "",
      variabletwo: false,
      echartTitletwo: "",
      isLocked: false,
      myLock: null,
      ismyLockProjectId: "", //判断数据锁是否本人锁的,如果是，传入锁定的项目id
      lockFlag: ""
    };
  },
  created() {
    this.hasNews(false);
    this.getCaseNum();
    this.setFuzzyQuery("");
    this.getScreen({})
    this.showFilter("mytodo");
    this.getmytodo(1);
  },
  mounted() {
    window.addEventListener("beforeunload", e => this.beforeunloadHandler(e));
    window.addEventListener("scroll", this.showGoTop, true);
    this.Echarts(); //echarts接口调用
    this.$EventBus.$on("LOCK_EVENT", () => {
      clearInterval(this.myLock);
      if (this.ismyLockProjectId) {
        http
          .get(
            "/datalock/unlock/" + this.lockFlag + "/" + this.ismyLockProjectId
          )
          .then(res => {
            this.ismyLock = true;
          });
      }
    });
  },

  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  },
  destroyed() {
    window.removeEventListener("beforeunload", e =>
      this.beforeunloadHandler(e)
    );
  },
  methods: {
    ...mapActions(["hasNews", "riskTodo", "setFuzzyQuery", "showFilter",'getScreen']),
    //回到顶部按钮
    beforeunloadHandler(e) {
      if (this.ismyLockProjectId) {
        clearInterval(this.myLock);
        http
          .get(
            "/datalock/unlock/" + this.lockFlag + "/" + this.ismyLockProjectId
          )
          .then(res => {
            this.ismyLock = true;
          });
      }
      return "关闭提示";
    },
    showGoTop() {
      if (this.showMyCase !== "mytodoList" && this.showMyCase !== "mytodo") {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },

    selectCase(flag) {
      this.showMyCase = "mytodoList";
      this.taskType = flag;
    },
    // echart自定义
    selectEchart(flag) {
      if (flag == 0) {
        this.origEchartId = this.ids;
      } else if (flag == 1) {
        this.origEchartId = this.idstwo;
      }
      this.showMyCase = "mytodoEchartList";
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    //保存、提交、关闭
    scc(flag, showMyCase) {
      if (flag === "close") {
        if (
          JSON.stringify(this.copyProjectSummary.prjBasicInfoDO) !==
            JSON.stringify(this.getBasicBstablish.prjBasicInfoDO) ||
          JSON.stringify(this.copyProjectSummary.prjConstructionInfoDO) !==
            JSON.stringify(this.getBasicBstablish.prjConstructionInfoDO) ||
          JSON.stringify(
            this.copyProjectSummary.prjSingleUnitsDOList.rowList
          ) !==
            JSON.stringify(
              this.getBasicBstablish.prjSingleUnitsDOList.rowList
            ) ||
          JSON.stringify(this.copyProjectSummary.getUnderwritingInformation) !==
            JSON.stringify(this.getUnderwritingInformation)
        ) {
          this.$confirm("表单未保存，是否继续退出？", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(async () => {
              this.getInsuranceReview.newCheckRiskCtrlPlan.status = "";
              this.getInsuranceReview.newCheckRiskCtrlPlan.comment = "";
              this.showMyCase = "mytodoList";
              if (this.ismyLockProjectId) {
                clearInterval(this.myLock);
                http
                  .get(
                    "/datalock/unlock/" +
                      this.lockFlag +
                      "/" +
                      this.ismyLockProjectId
                  )
                  .then(res => {
                    this.ismyLock = true;
                  });
              }
              console.log("解锁了！");
            })
            .catch(() => {});
        } else {
          this.showMyCase = "mytodoList";
          this.getInsuranceReview.newCheckRiskCtrlPlan.status = "";
          this.getInsuranceReview.newCheckRiskCtrlPlan.comment = "";

          if (this.ismyLockProjectId) {
            clearInterval(this.myLock);
            http
              .get(
                "/datalock/unlock/" +
                  this.lockFlag +
                  "/" +
                  this.ismyLockProjectId
              )
              .then(res => {
                this.ismyLock = true;
              });
          }
          console.log("解锁了！");
        }
      } else {
        if (showMyCase === "insertInsureInfo") {
          //提交有校验
          if (flag === "commit") {
            let unValid = true;
            this.$refs.basicBstablish.$refs.validForm.validate(valid => {
              if (!valid) {
                this.$messageError({
                  message: "请完善内容"
                });
                unValid = valid;
                return unValid;
              }
            });

            this.$refs.underwriting.$refs.valid.validate(v => {
              if (!v) {
                // 校验提示
                if (unValid)
                  this.$messageError({
                    message: "请完善内容"
                  });
                unValid = v;
                return unValid;
              }
            });
            this.error = true;
            let valids = [
              this.getUnderwritingInformation.insBasicInfoDO.totalPremium,
              this.getUnderwritingInformation.insBasicInfoDO.totalCoverage,
              this.getUnderwritingInformation.insBasicInfoDO.deductibleAmount
            ];
            for (let v of valids) {
              if (!v && v != 0) {
                return false;
              }
            }
            if (!unValid) {
              return unValid;
            }
            // 承保比例之和
            const arry = this.getUnderwritingInformation.insCoinsuranceDOList;
            const strarr = [];
            for (let i in arry) {
              strarr.push(arry[i]["coinsPercent"]);
              if (!arry[i].insOrgId || !arry[i].coinsPercent) {
                this.$messageError({
                  message: "请将共保信息补充完整"
                });
                return;
              }
            }
            const numb = eval(strarr.join("+"));
            if (numb != 100) {
              this.$messageError({
                message: "共保承保比例之和必须为100"
              });
              return false;
            } else if (
              this.getUnderwritingInformation.insBasicInfoDO.totalFloorage <= 0
            ) {
              this.$messageError({
                message: "承保面积必须大于0"
              });
              return false;
            } else if (
              this.getUnderwritingInformation.insBasicInfoDO.totalCoverage <= 0
            ) {
              this.$messageError({
                message: "保险金额必须大于0"
              });
              return false;
            } else if (
              this.getUnderwritingInformation.insBasicInfoDO.totalPremium <= 0
            ) {
              this.$messageError({
                message: "总保险费必须大于0"
              });
              return false;
            } else if (
              this.getUnderwritingInformation.mainInsLiabilitiesDOList.length <=
              0
            ) {
              this.$messageError({
                message: "请选择主险责任范围"
              });
              return false;
            }
          }
          let url =
            flag == "commit"
              ? "/insurance/compose/commitUnderWriting"
              : "/insurance/compose/underWriting";
          this.getUnderwritingInformation.insBasicInfoDO.projectName = this.getBasicBstablish.prjBasicInfoDO.projectName;
          //如果主线附加险全选，完全覆盖（C01），非完全覆盖（C02）
          if (
            this.getCopyUnderwriting.otherInsLiabilitiesDOList.length +
              this.getCopyUnderwriting.mainInsLiabilitiesDOList.length ===
            this.getUnderwritingInformation.otherInsLiabilitiesDOList.length +
              this.getUnderwritingInformation.mainInsLiabilitiesDOList.length
          ) {
            this.getUnderwritingInformation.insBasicInfoDO.coverageType = "C01";
          } else {
            this.getUnderwritingInformation.insBasicInfoDO.coverageType = "C02";
          }
          if (flag == "commit") {
            this.$store.dispatch("loading", true);
            http
              .post(url, {
                flag: "First",
                insUnderWritingDTO: this.getUnderwritingInformation,
                prjBaseAndConstructionDTO: this.getBasicBstablish
              })
              .then(res => {
                this.$store.dispatch("loading", false);
                if (res.code == 1) {
                  let insMseeage = "";
                  for (var i in res.errMsg) {
                    insMseeage = insMseeage + res.errMsg[i] + ",";
                  }
                  insMseeage = insMseeage.substring(0, insMseeage.length - 1);
                  const h = this.$createElement;
                  this.$msgbox({
                    title: "消息",
                    message: h("p", null, [
                      h("span", { style: "color: red" }, insMseeage),
                      h("br", {}, ""),
                      h(
                        "span",
                        { style: "color: green" },
                        "---仍要提交，请录入备注信息！"
                      )
                    ]),
                    showCancelButton: true,
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    inputType: "textarea",
                    inputValue: this.getUnderwritingInformation.insBasicInfoDO
                      .description,
                    showInput: true,
                    beforeClose: (action, instance, done) => {
                      if (action === "confirm") {
                        if (!instance.inputValue) {
                          this.$messageError({
                            message: "请填写备注信息"
                          });
                        } else {
                          done();
                        }
                      } else {
                        done();
                      }
                    }
                  })
                    .then(({ value }) => {
                      this.getUnderwritingInformation.insBasicInfoDO.description = value;
                      this.$store.dispatch("loading", true);
                      http
                        .post(url, {
                          flag: "Second",
                          insUnderWritingDTO: this.getUnderwritingInformation,
                          prjBaseAndConstructionDTO: this.getBasicBstablish
                        })
                        .then(res => {
                          this.$store.dispatch("loading", false);
                          if (res.code == 0) {
                            this.$messageSuccess({
                              message: res.msg
                            });
                            if (flag == "commit") {
                              this.getmytodo(1);
                              this.showMyCase = "mytodoList";
                            }
                          } else {
                            this.$messageError({
                              message: res.msg
                            });
                          }
                        })
                        .catch(() => {
                          this.$store.dispatch("loading", false);
                        });
                    })
                    .catch(() => {
                      this.$message({
                        type: "info",
                        message: "已取消"
                      });
                      this.$store.dispatch("loading", true);
                      this.$refs.basicBstablish.init(
                        this.getBasicBstablish.prjBasicInfoDO.projectId
                      );
                      this.$refs.underwriting.init(
                        this.getBasicBstablish.prjBasicInfoDO.projectId
                      );
                      setTimeout(() => {
                        this.$store.dispatch("loading", false);
                      }, 1500);
                    });
                } else if (res.code == 500) {
                  this.$messageError({
                    message: res.msg
                  });
                  return false;
                } else {
                  this.$messageSuccess({
                    message: res.msg
                  });
                  if (flag == "commit") {
                    this.getmytodo(1);
                    this.showMyCase = "mytodoList";
                  }
                }
              })
              .catch(() => {
                this.$store.dispatch("loading", false);
              });
          } else {
            this.$store.dispatch("loading", true);
            this.getUnderwritingInformation.mainInsLiabilitiesDOList.map(
              (item, index) => {
                if (item.policyStartDate == null) {
                  item.policyStartDate = "";
                }
                if (item.policyEndDate == null) item.policyEndDate = "";
              }
            );
            this.getUnderwritingInformation.otherInsLiabilitiesDOList.map(
              (item, index) => {
                if (item.policyEndDate == null) {
                  item.policyEndDate = "";
                }
                if (item.policyStartDate == null) item.policyStartDate = "";
              }
            );
            http
              .post(url, {
                insUnderWritingDTO: this.getUnderwritingInformation,
                prjBaseAndConstructionDTO: this.getBasicBstablish
              })
              .then(res => {
                this.$store.dispatch("loading", false);
                if (res.code == 0) {
                  this.$messageSuccess({
                    message: res.msg
                  });
                  // if (flag == "commit") {
                  //   this.getmytodo(1);
                  //   this.showMyCase = "mytodoList";
                  // }
                  if (flag === "save") {
                    this.$refs.basicBstablish.init(
                      this.getBasicBstablish.prjBasicInfoDO.projectId
                    );
                    this.$refs.underwriting.init(
                      this.getBasicBstablish.prjBasicInfoDO.projectId
                    );
                  }
                } else {
                  this.$messageError({
                    message: res.msg
                  });
                }
              })
              .catch(() => {
                this.$store.dispatch("loading", false);
              });
          }
        } else if (showMyCase === "insertCompletedInfo") {
          //提交有校验
          if (flag === "commit") {
            let unValid = true;
            this.$refs.insuranceCoverage.$refs.validForm.validate(valid => {
              if (!valid) {
                unValid = valid;
                // 校验提示
                this.$messageError({
                  message: "请完善内容"
                });
                return unValid;
              }
            });
            if (!unValid) {
              return unValid;
            }
            // 承保比例之和
            const arry = this.getInsuranceCoverage
              .insCoinsuranceCompletedDOList;
            const strarr = [];
            for (let i in arry) {
              strarr.push(arry[i]["coinsPercent"]);
              if (!arry[i].insOrgId || !arry[i].coinsPercent) {
                this.$messageError({
                  message: "请将共保信息补充完整"
                });
                return;
              }
            }
            const numb = eval(strarr.join("+"));
            if (numb != 100) {
              this.$messageError({
                message: "共保承保比例之和必须为100"
              });
              return false;
            } else if (
              this.getInsuranceCoverage.insBasicInfoCompletedDO.totalFloorage <=
              0
            ) {
              this.$messageError({
                message: "承保面积必须大于0"
              });
              return false;
            } else if (
              this.getInsuranceCoverage.insBasicInfoCompletedDO.totalCoverage <=
              0
            ) {
              this.$messageError({
                message: "保险金额必须大于0"
              });
              return false;
            } else if (
              this.getInsuranceCoverage.insBasicInfoCompletedDO.totalPremium <=
              0
            ) {
              this.$messageError({
                message: "总保险费必须大于0"
              });
              return false;
            } else if (
              this.getInsuranceCoverage.mainInsLiabilitiesDOList.length <= 0
            ) {
              this.$messageError({
                message: "请选择主险责任范围"
              });
              return false;
            }
          }
          this.getInsuranceCoverage.mainInsLiabilitiesDOList1.map(
            (item, index) => {
              if (item.policyStartDate == null) {
                item.policyStartDate = "";
              }
              if (item.policyEndDate == null) item.policyEndDate = "";
            }
          );
          this.getInsuranceCoverage.mainInsLiabilitiesDOList.map(
            (item, index) => {
              if (item.policyStartDate == null) {
                item.policyStartDate = "";
              }
              if (item.policyEndDate == null) item.policyEndDate = "";
            }
          );
          this.getInsuranceCoverage.addInsLiabilitiesDOList1.map(
            (item, index) => {
              if (item.policyStartDate == null) {
                item.policyStartDate = "";
              }
              if (item.policyEndDate == null) item.policyEndDate = "";
            }
          );
          this.getInsuranceCoverage.addInsLiabilitiesDOList.map(
            (item, index) => {
              if (item.policyStartDate == null) {
                item.policyStartDate = "";
              }
              if (item.policyEndDate == null) item.policyEndDate = "";
            }
          );
          const commitFlag =
            flag == "save"
              ? "saveCompletedUnderWriting"
              : "commitCompletedUnderWriting";
          this.$store.dispatch("loading", true);
          http
            .post("/completed/" + commitFlag, this.getInsuranceCoverage)
            .then(res => {
              this.$store.dispatch("loading", false);
              if (flag == "save") {
                this.$refs.insuranceCoverage.insuranceCoverage(
                  this.getInsuranceCoverage.insBasicInfoCompletedDO.projectId
                );
                this.$refs.insuranceCoverage.init(
                  this.getInsuranceCoverage.insBasicInfoCompletedDO.projectId
                );
                if (res.code == 0) {
                  this.$messageSuccess({
                    message: res.msg
                  });
                }
              }
              if (flag == "commit") {
                this.getmytodo(1);
                this.showMyCase = "mytodoList";
              }
            });
        } else if (showMyCase === "checkRiskCtrlPlan") {
          //提交有校验
          if (flag === "commit") {
            let unValid = true;
            this.$refs.insuranceReview.$refs.validInsurance.validate(valid => {
              if (!valid) {
                unValid = valid;
                // 校验提示
                this.$messageError({
                  message: "请完善内容"
                });
                return unValid;
              }
            });
            if (!unValid) {
              return unValid;
            }
          }
          this.getInsuranceReview.newCheckRiskCtrlPlan.projectId = this.getInsuranceReview.projectId;
          const url =
            this.getInsuranceReview.newCheckRiskCtrlPlan.status == "APPROVED"
              ? "/sysconfig/check/success"
              : "/sysconfig/check/falied";
          this.$store.dispatch("loading", true);
          http
            .post(url, this.getInsuranceReview.newCheckRiskCtrlPlan)
            .then(res => {
              this.$store.dispatch("loading", false);
              if (res.code == 0) {
                this.getInsuranceReview.newCheckRiskCtrlPlan.status = "";
                this.getInsuranceReview.newCheckRiskCtrlPlan.comment = "";
                this.showMyCase = "mytodoList";
                this.$messageSuccess({
                  message: res.msg
                });
                this.getmytodo(1); // 重新查代办
              } else {
                this.$messageError({
                  message: res.msg
                });
              }
            });
        }
      }
    },
    //展示大表单
    goForm(flag, item) {
      this.showMyCase = flag;
      switch (flag) {
        case "insertInsureInfo":
          this.current = {
            finished: ["newProject"],
            current: ["enteringIns"],
            projectId: item.projectId
          };
          this.$refs.underwriting.init(item.projectId);
          this.$refs.insuranceReview.insuranceReview({
            projectId: item.projectId
          });
          http
            .get("/datalock/islocked/insertInsureInfo/" + item.projectId)
            .then(res => {
              if (res.data.locked) {
                this.isLocked = true;
                this.lockFlag = "";
                this.ismyLockProjectId = "";
                this.$message({
                  message:
                    "该项目正在被用户<" +
                    res.data.userDo.username +
                    "-" +
                    res.data.userDo.mobile +
                    ">操作，已锁定！",
                  type: "warning",
                  showClose: true,
                  duration: 4000
                });
              } else {
                this.isLocked = false;
                http
                  .get("/datalock/lock/insertInsureInfo/" + item.projectId)
                  .then(res => {
                    this.lockFlag = "insertInsureInfo";
                    this.ismyLockProjectId = item.projectId;
                  });
                this.myLock = setInterval(() => {
                  http
                    .get("/datalock/lock/insertInsureInfo/" + item.projectId)
                    .then(res => {});
                }, 20000);
              }
            });
          break;
        case "checkRiskCtrlPlan":
          this.current = {
            finished: [
              "enteringIns",
              "newProject",
              "insuranceAudit",
              "launchRisk",
              "enteringRisk"
            ],
            current: ["checkRisk"],
            projectId: item.projectId
          };
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.underwriting.init(item.projectId);
          this.$refs.insuranceReview.insuranceReview({
            projectId: item.projectId,
            taskName: item.taskName
          });
          break;
        case "insertCompletedInfo":
          this.current = {
            finished: [
              "enteringIns",
              "newProject",
              "checkRisk",
              "insuranceAudit",
              "launchRisk",
              "enteringRisk",
              "riskManage"
            ],
            current: ["entreingCompleted"],
            projectId: item.projectId
          };
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.underwriting.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          this.$refs.insuranceReview.insuranceReview({
            projectId: item.projectId,
            taskName: item.taskName //不能删除taskname
          });
          http
            .get("/datalock/islocked/insertCompletedInfo/" + item.projectId)
            .then(res => {
              if (res.data.locked) {
                this.isLocked = true;
                this.lockFlag = "";
                this.ismyLockProjectId = "";
                this.$message({
                  message:
                    "该项目正在被用户<" +
                    res.data.userDo.roleName +
                    ">操作，已锁定！",
                  type: "warning",
                  showClose: true,
                  duration: 0
                });
              } else {
                this.isLocked = false;
                http
                  .get("/datalock/lock/insertCompletedInfo/" + item.projectId)
                  .then(res => {
                    this.lockFlag = "insertCompletedInfo";
                    this.ismyLockProjectId = item.projectId;
                  });
                this.myLock = setInterval(() => {
                  http
                    .get("/datalock/lock/insertCompletedInfo/" + item.projectId)
                    .then(res => {});
                }, 20000);
              }
            });
          break;
      }
      this.$refs.basicBstablish.init(item.projectId);
    },
    getmytodo(val) {
      if (!this.screen.buildingType) {
        if (
          typeof this.screen.buildingType != "string" ||
          typeof this.screen.buildingType != "object"
        ) {
          this.screen.buildingType = undefined;
        }
      } else {
        if (this.screen.buildingType.size == 0) {
          this.screen.buildingType = undefined;
        }
      }
      const keywords = {
        isMainIns: "Y",
        province: this.screen.province,
        district: this.screen.district,
        city: this.screen.city,
        taskName: "", //录入保险审核信息  审核风控管理计划  录入竣工信息
        minCostPerMeter: this.screen.minCostPerMeter,
        maxCostPerMeter: this.screen.maxCostPerMeter,
        beginSignDate: this.screen.beginSignDate,
        endSignDate: this.screen.endSignDate,
        buildingType: this.screen.buildingType,
        projectName:this.screen.projectName,
        insContractNo: this.screen.insContractNo,
        fuzzyQuery: this.fuzzyQuery.value,
        offset: val,
        limit: 8
      };
      this.$store.dispatch("loading", true);
      this.riskTodo(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    },
    // 自定义echart
    option() {
      this.$refs.chart.destroy(); //销毁
      this.$refs.chartLine.destroy(); //销毁
      this.Echarts();
    },
    // echarts
    async Echarts() {
      const keywords = {
        userId: this.userInfo.userId,
        orgId: this.userInfo.insOrgId,
        // userId: 'shpingan',
        // orgId: '1100030003',
        city: this.$getversionData.city,
        province: this.$getversionData.province
      };
      const { data } = await this.$api.echarts(keywords);
      this.dataShow = data;
      if (data[0]) {
        this.ids = data[0].echartId;
        this.echartTitle = data[0].title;
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(category_option);
          }, 10);
        } else if (data[0].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["25%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "17",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[0].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value.toFixed(2)
            });
          }
          setTimeout(() => {
            this.$refs.chart.initChart(pie_option);
            this.$refs.chart.editEcahrt(pie_option, this.$refs.chart.id);
          }, 10);
        } else if (data[0].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(axas_option);
          }, 10);
        } else if (data[0].echartType === "boxplot") {
          // 盒须图
          let boxplot_option = {
            title: {
              text: data[0].title,
              left: "center"
            },
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "shadow"
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: data.axisDatas,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              // axisLabel: {
              //   formatter: 'expr {value}'
              // },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              splitArea: {
                show: true
              }
            },
            series: [
              {
                type: "boxplot",
                data: data.boxData
              },
              {
                type: "scatter",
                data: data.outliers
              }
            ]
          };
          for (let n of data[0].data) {
            boxplot_option.xAxis.data = [
              // ...boxplot_option.axisData.data,
              n.name
            ];
            boxplot_option.series[0].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
            boxplot_option.series[1].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(boxplot_option);
          }, 10);
        } else if (data[0].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[0].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  //  areaColor: ["red","green"],
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[0].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chart.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[0].echartType === "lines") {
          // 多折线图
          let categorys_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
            },
            legend: {},
            xAxis: {
              axisLabel: {
                interval: 0,
                rotate: 30,
                fontSize: 12
              },
              type: "category",
              data: [
                "一月",
                "二月",
                "三月",
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
              ]
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[0].data.map((item, num) => {
            (item.type = "line"),
              (item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.chart.initChart(categorys_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chart.initChart(Yaxas_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            legend: {
              top: "12",
              right: "13",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: data[0].data[0].name
            },
            series: item.data
          };
          data[0].data.map((item, num) => {
            item.type = "bar";
            item.stack = "df";
            for (let n of item.result) {
              item.data = [n.value];
            }
          });
          setTimeout(() => {
            this.$refs.chart.initChart(Yaxass_option);
          }, 10);
        } else if (data[0].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[0];
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["50%", "50%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              left: "45%",
              top: "16%",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.chart.initChart(spie_option);
          }, 10);
        }
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].data.length != 0) {
          this.variable = false;
        }
      }
      if (data[1]) {
        this.idstwo = data[1].echartId;
        this.echartTitletwo = data[1].title;
        if (data[1].data.length == 0) {
          this.variabletwo = true;
        } else if (data[1].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(category_option);
          }, 10);
        } else if (data[1].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["25%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "20",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ],
            type: "pic"
          };
          for (let item of data[1].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value.toFixed(2)
            });
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(pie_option);
            this.$refs.chartLine.editEcahrt(
              pie_option,
              this.$refs.chartLine.id
            );
          }, 10);
        } else if (data[1].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(axas_option);
          }, 10);
        } else if (data[1].echartType === "boxplot") {
          // 盒须图
          let boxplot_option = {
            title: {
              text: data[1].title,
              left: "center"
            },
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "shadow"
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: data.axisDatas,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              // axisLabel: {
              //   formatter: 'expr {value}'
              // },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              splitArea: {
                show: true
              }
            },
            series: [
              {
                type: "boxplot",
                data: data.boxData
              },
              {
                type: "scatter",
                data: data.outliers
              }
            ]
          };
          for (let n of data[1].data) {
            boxplot_option.xAxis.data = [
              // ...boxplot_option.axisData.data,
              n.name
            ];
            boxplot_option.series[0].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
            boxplot_option.series[1].data = [
              // ...boxplot_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(boxplot_option);
          }, 10);
        } else if (data[1].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[1].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[1].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[1].echartType === "lines") {
          // 多折线图
          let categorys_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
            },
            legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: [
                "一月",
                "二月",
                "三月",
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
              ]
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[1].data.map((item, num) => {
            item.type = "line";
            item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.chartLine.initChart(categorys_option);
          }, 10);
        } else if (data[1].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(Yaxas_option);
          }, 10);
        } else if (data[1].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            legend: {
              top: "12",
              right: "13",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: data[1].data[0].name
            },
            series: item.data
          };
          data[1].data.map((item, num) => {
            item.type = "bar";
            item.stack = "df";
            for (let n of item.result) {
              item.data = [n.value];
            }
          });
          setTimeout(() => {
            this.$refs.chartLine.initChart(Yaxass_option);
          }, 10);
        } else if (data[1].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[1];
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["50%", "50%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              left: "45%",
              top: "16%",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.chartLine.initChart(spie_option);
          }, 10);
        }
        if (data[1].data.length == 0) {
          this.variabletwo = true;
        } else if (data[1].data.length != 0) {
          this.variabletwo = false;
        }
      }
    },
    backMytodo() {
      this.showMyCase = "mytodo";
      this.getmytodo(1);
    },
    async getCaseNum() {
      const res = await this.$api.getCaseNumber();
      this.cardNum = res.data;
    }
  }
};
</script>

<style scoped lang="scss" rel="stylesheet/scss">
.newclass {
  background: url(../../assets/imgs/noData.png);
  background-size: 160px 160px;
  background-repeat: no-repeat;
  background-position: 107px 30px;
}
.newclass /deep/ span {
  font-size: 17px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 15px;
  left: 21px;
}
.echart {
  position: relative;
  height: 240px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 6px;
  padding: 0 10px;
}
.content {
  height: 240px;
}
.title {
  color: #fff;
}

.leftContent span {
  color: #fff;
  margin-left: -8px;
  line-height: 26px;
}
.date {
  height: 130px;
  margin-top: 35px;
  background-image: url(../../assets/imgs/todo/todo1.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
}
.date1 {
  background-image: url(../../assets/imgs/todo/todo2.png);
}
.date2 {
  background-image: url(../../assets/imgs/todo/todo3.png);
}
.days {
  color: #7eafed;
  font-size: 35px;
  font-weight: bold;
  margin-left: -10px;
}
.year {
  font-size: 12px;
}
.rightContent {
  text-align: left;
  font-size: 13px;
  font-weight: bold;
}
.rightContent p {
  font-weight: bold;
  font-size: 16px;
}
.content1 {
  height: 240px;
}
.case_yellow {
  background-image: url(../../assets/imgs/case_yellow.png);
  background-size: 100%;
  background-repeat: no-repeat;
}
.case_green {
  background-image: url(../../assets/imgs/case_green.png);
  background-size: 100%;
  background-repeat: no-repeat;
}
.case_blue {
  background-image: url(../../assets/imgs/case_blue.png);
  background-size: 100%;
  background-repeat: no-repeat;
}
.card_board {
  background-image: url(../../assets/imgs/ziban.png);
  background-repeat: no-repeat;
  background-position: center;
  background-size: 100%;
  height: 220px;
  width: 252px;
  margin-top: 7px;
  margin-left: 70px;
}
.card_num {
  text-align: center;
  font-size: 100px;
  font-weight: bold;
  padding-top: 70px;
}
.none_info {
  background-image: url(../../assets/imgs/none_info.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
  height: 120px;
  margin-top: 35px;
}
.none_info1 {
  background-image: url(../../assets/imgs/none_info1.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
  height: 120px;
  margin-top: 35px;
}
.none_info2 {
  background-image: url(../../assets/imgs/none_info2.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
  height: 120px;
  margin-top: 35px;
}
.none_list {
  background-image: url(../../assets/imgs/none_list.png);
}
.none_list1 {
  background-image: url(../../assets/imgs/none_list1.png);
}
.none_list2 {
  background-image: url(../../assets/imgs/none_list2.png);
}
.none_listbase {
  background-repeat: no-repeat;
  background-size: 100px;
  height: 176px;
  background-position: 115px;
}
.bohui {
  background-image: url(../../assets/imgs/bohui.png);
  background-repeat: no-repeat;
  background-size: 100px;
  height: 176px;
  background-position: center;
}
</style>
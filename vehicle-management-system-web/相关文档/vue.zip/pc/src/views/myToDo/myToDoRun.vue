<template>
  <div>
    <div style="position: relative">
      <transition
        :duration="4000"
        :enter-active-class="showMyCase == 'mytodo' ? 'animated zoomInLeft' : 'animated slideInLeft'"
        :leave-active-class="showMyCase == 'mytodoList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div v-show="showMyCase==='mytodo'">
          <el-row>
            <el-col :span="8">
              <div
                class="content"
                style="border-radius:6px;padding:0 10px;background-color: rgba(255, 255, 255, 0.9);"
              >
                <span
                  class="el-icon-edit-outline mouse-pointer"
                  @click="selectEchart(0)"
                  style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
                >自定义</span>
                <div v-show="this.variable" class="newclass" style="height:240px">
                  <span>{{this.echartTitle}}</span>
                </div>
                <chart ref="chartLine"></chart>
              </div>
              <!-- 无数据时 -->
              <div
                v-show="this.dataShow.length===0"
                style="position: absolute;left: 15%;top: 150px;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
              <div
                v-show="control.includes('myToDoRunMap')"
                class="content"
                style="border-radius:6px;padding:0 10px;background-color: rgba(255, 255, 255, 0.9)"
              >
                <span
                  class="el-icon-edit-outline mouse-pointer"
                  @click="selectEchart(1)"
                  style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
                >自定义</span>
                <div v-show="this.variabletwo" class="newclass" style="height:240px">
                  <span>{{this.echartTitletwo}}</span>
                </div>
                <chart ref="beijingMap" style="width: 380px;height: 240px"></chart>
              </div>
              <!-- 无数据时 -->
              <div
                v-show="this.dataShow.length===0"
                style="position: absolute;left: 15%;top: 400px;transform: translate(-50%,-67%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
            </el-col>
            <el-col :span="1">
              <div class="content1"></div>
              <div class="content1"></div>
            </el-col>
            <el-col :span="15">
              <div>
                <el-row>
                  <el-col :span="12">
                    <div
                      v-if="control.includes('myToDoRunInsuranceAudit')"
                      class="content case_blue mouse-pointer"
                      style="margin-left:7px"
                    >
                      <el-row>
                        <el-col :span="24" class="title">
                          <p>保险审核</p>
                        </el-col>
                      </el-row>
                      <el-row>
                        <div
                          @click="selectCase('underWrite')"
                          v-if="riskTodoRunAll.underWrite.projectId"
                        >
                          <el-col
                            :span="6"
                            :offset="1"
                            class="date leftContent"
                            v-if="riskTodoRunAll.underWrite.mydate.case_month"
                          >
                            <span>{{riskTodoRunAll.underWrite.mydate.case_month}}</span>
                            <div
                              class="days"
                              style="line-height: 40px"
                            >{{riskTodoRunAll.underWrite.mydate.case_day}}</div>
                            <div
                              class="year days"
                              style="line-height: 14px"
                            >{{riskTodoRunAll.underWrite.mydate.case_year}}</div>
                          </el-col>
                          <el-col
                            :span="6"
                            :offset="1"
                            class="none_info"
                            v-if="!riskTodoRunAll.underWrite.mydate.case_month"
                          ></el-col>
                          <el-col :span="16" :offset="1" class="rightContent">
                            <div
                              :title="riskTodoRunAll.underWrite.projectName"
                              style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                            >{{riskTodoRunAll.underWrite.projectName}}&nbsp;</div>
                            <div
                              v-if="riskTodoRunAll.underWrite.insContractNo!=null"
                              :title="riskTodoRunAll.underWrite.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                            >保单号：{{riskTodoRunAll.underWrite.insContractNo}}</div>
                            <div v-else>保单号：未填写</div>
                            <div style="margin-top:6px">住宅性质：{{riskTodoRunAll.underWrite.dictValue}}</div>
                            <div
                              style="margin-top:6px"
                            >阶段：{{riskTodoRunAll.underWrite.projectChnStatus}}</div>
                          </el-col>
                        </div>
                        <div
                          v-if="!riskTodoRunAll.underWrite.projectId"
                          class="none_list none_listbase"
                        >
                          <div style="padding-top: 121px;font-size: 13px;font-weight: 600;">暂无信息</div>
                        </div>
                      </el-row>
                    </div>
                  </el-col>

                  <el-col :span="12">
                    <div
                      v-if="control.includes('myToDoRunStartControl')"
                      class="content case_yellow mouse-pointer"
                      style="margin-left:7px"
                    >
                      <el-row>
                        <el-col :span="24" class="title">
                          <p>启动风控</p>
                        </el-col>
                      </el-row>
                      <el-row>
                        <div
                          @click="selectCase('startRiskPlan')"
                          v-if="riskTodoRunAll.startRiskPlan.projectId"
                        >
                          <el-col
                            :span="6"
                            :offset="1"
                            class="date date1 leftContent"
                            v-if="riskTodoRunAll.startRiskPlan.mydate.case_month"
                          >
                            <span>{{riskTodoRunAll.startRiskPlan.mydate.case_month}}</span>
                            <div
                              class="days"
                              style="color:#F8C184;line-height: 40px"
                            >{{riskTodoRunAll.startRiskPlan.mydate.case_day}}</div>
                            <div
                              class="year days"
                              style="color:#F8C184;line-height: 14px"
                            >{{riskTodoRunAll.startRiskPlan.mydate.case_year}}</div>
                          </el-col>
                          <el-col
                            :span="6"
                            :offset="1"
                            class="none_info1"
                            v-if="!riskTodoRunAll.startRiskPlan.mydate.case_month"
                          ></el-col>
                          <el-col :span="16" :offset="1" class="rightContent">
                            <div
                              :title="riskTodoRunAll.startRiskPlan.projectName"
                              style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                            >{{riskTodoRunAll.startRiskPlan.projectName}}&nbsp;</div>
                            <div
                              v-if="riskTodoRunAll.startRiskPlan.insContractNo!=null"
                              :title="riskTodoRunAll.startRiskPlan.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                            >保单号：{{riskTodoRunAll.startRiskPlan.insContractNo}}</div>
                            <div v-else>保单号：未填写</div>
                            <div
                              style="margin-top:6px"
                            >住宅性质：{{riskTodoRunAll.startRiskPlan.dictValue}}</div>
                            <div
                              style="margin-top:6px"
                            >阶段：{{riskTodoRunAll.startRiskPlan.projectChnStatus}}</div>
                          </el-col>
                        </div>
                        <div
                          v-if="!riskTodoRunAll.startRiskPlan.projectId"
                          class="none_list1 none_listbase"
                        >
                          <div style="padding-top: 121px;font-size: 13px;font-weight: 600;">暂无信息</div>
                        </div>
                      </el-row>
                    </div>
                  </el-col>

                  <el-col :span="12">
                    <div
                      v-if="control.includes('myToDoRunCompletedData')"
                      class="content case_green mouse-pointer"
                      style="margin-left:7px"
                    >
                      <el-row>
                        <el-col :span="24" class="title" style="padding-right: 0">
                          <p>竣工保险审核</p>
                        </el-col>
                      </el-row>
                      <el-row>
                        <div
                          @click="selectCase('insuranceReview')"
                          v-if="riskTodoRunAll.insuranceReview.projectId"
                        >
                          <el-col
                            :span="6"
                            :offset="1"
                            class="date date2 leftContent"
                            v-if="riskTodoRunAll.insuranceReview.mydate.case_month"
                          >
                            <span>{{riskTodoRunAll.insuranceReview.mydate.case_month}}</span>
                            <div
                              class="days"
                              style="color:#65D8C5;line-height: 40px"
                            >{{riskTodoRunAll.insuranceReview.mydate.case_day}}</div>
                            <div
                              class="year days"
                              style="color:#65D8C5;line-height: 14px"
                            >{{riskTodoRunAll.insuranceReview.mydate.case_year}}</div>
                          </el-col>
                          <el-col
                            :span="6"
                            :offset="1"
                            class="none_info2"
                            v-if="!riskTodoRunAll.insuranceReview.mydate.case_month"
                          ></el-col>
                          <el-col :span="16" :offset="1" class="rightContent">
                            <div
                              :title="riskTodoRunAll.insuranceReview.projectName"
                              style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                            >{{riskTodoRunAll.insuranceReview.projectName}}&nbsp;</div>
                            <div
                              v-if="riskTodoRunAll.insuranceReview.insContractNo!=null"
                              :title="riskTodoRunAll.insuranceReview.insContractNo"
                              style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                            >保单号：{{riskTodoRunAll.insuranceReview.insContractNo}}</div>
                            <div v-else>保单号：未填写</div>
                            <div
                              style="margin-top:6px"
                            >住宅性质：{{riskTodoRunAll.insuranceReview.dictValue}}</div>
                            <div
                              style="margin-top:6px"
                            >阶段：{{riskTodoRunAll.insuranceReview.projectChnStatus}}</div>
                          </el-col>
                        </div>
                        <div
                          v-if="!riskTodoRunAll.insuranceReview.projectId"
                          class="none_list2 none_listbase"
                        >
                          <div style="padding-top: 121px;font-size: 13px;font-weight: 600;">暂无信息</div>
                        </div>
                      </el-row>
                    </div>
                  </el-col>
                  <el-col :span="12" style="padding-right: 0">
                    <div class="card_board">
                      <div class="card_num">{{cardNum}}</div>
                    </div>
                  </el-col>
                </el-row>
              </div>
            </el-col>
          </el-row>
        </div>
      </transition>
      <transition
        :duration="1000"
        :enter-active-class="showMyCase == 'mytodoList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
        :leave-active-class="showMyCase == 'mytodo' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div v-if="showMyCase==='mytodoList'" style="position: absolute; top: 0;width: 100%;">
          <mytodorun-list
            @goForm="goForm"
            @backMytodo="backMytodo"
            :mytodoList="riskTodoRunAll.allTypeRunList[taskType]"
            :taskType="taskType"
          ></mytodorun-list>
        </div>
      </transition>
      <!-- echart自定义 -->
      <transition
        :duration="4000"
        :enter-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
        :leave-active-class="showMyCase == 'mytodo' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div v-if="showMyCase==='mytodoEchartList'" style="position: absolute; top: 0;width: 100%;">
          <mytodo-echart-list
            @option="option"
            @backMytodo="backMytodo"
            :origEchartId="origEchartId"
            :interfaceName="interfaceName"
          ></mytodo-echart-list>
        </div>
      </transition>
      <transition
        :duration="1000"
        :enter-active-class="showMyCase == 'mytodoList' ? 'animated zoomInLeft' : 'animated slideInLeft' "
        :leave-active-class="showMyCase == 'mytodoList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
      >
        <div
          v-show="showMyCase ==='underWrite' || showMyCase ==='startRiskPlan' || showMyCase ==='insuranceReview'"
          style="position: absolute; top: 0;width: 100%;"
        >
          <div id="top">
            <flow-chart :current="current" @goBack="scc('close')" />
            <insurance-review
              ref="insuranceReview"
              v-show="showMyCase ==='underWrite'"
              title="保险审核"
              taskType="newUnderwrite"
            />
            <insurance-review
              v-show="showMyCase ==='underWrite' && getInsuranceReview.underwrite.processIsEnd=='N'"
              title="历史保险审核"
              taskType="underwrite"
              :disabled="true"
            />
            <div v-show="showMyCase ==='insuranceReview'">
              <insurance-review
                ref="insuranceReviewThree"
                title="竣工保险审核"
                taskType="newInsuranceReview"
              />
              <insurance-review
                title="历史竣工保险审核"
                taskType="insuranceReview"
                v-show="getInsuranceReview.insuranceReview.processIsEnd=='N'"
                :disabled="true"
              />
              <insurance-coverage :disabled="true" ref="insuranceCoverage" />
            </div>
            <basic-information :disabled="true" />
            <bstablish-information
              :disabled="true"
              ref="basicBstablish"
              :showMyCase="taskType"
              v-if="hackReset"
            />
            <underwriting-information ref="underwriting" :disabled="true" :showMyCase="taskType" />
            <insurance-review
              ref="insuranceReviewTwo"
              v-show="showMyCase !=='underWrite'"
              :disabled="true"
              title="保险审核"
              taskType="underwrite"
            />
            <div v-show="showMyCase ==='insuranceReview'">
              <risk-plan :disabled="true" ref="riskPlan" />
              <insurance-review title="风险管理计划审核" taskType="checkRiskCtrlPlan" :disabled="true" />
              <risk-report-list ref="riskReportList" />
              <risk-events-list ref="riskEventsList" />
              <risk-final-report :disabled="true" ref="riskFinalReport" />
            </div>
            <div class="text-right">
              <!-- <el-button v-if="showMyCase !=='underWrite'" @click="scc('save', showMyCase)" type="primary" size="mini">保存</el-button> -->
              <el-button @click="scc('commit', showMyCase)" type="primary" size="mini">提交</el-button>
              <el-button @click="scc('close', showMyCase)" size="mini">关闭</el-button>
            </div>
            <el-button @click="goTop" id="go-top" circle :style="screen_width">
              <i class="el-icon-arrow-up"></i>
            </el-button>
          </div>
        </div>
      </transition>
    </div>
  </div>
</template>
<script>
import chart from "@/components/charts/index";
import { mapGetters, mapActions } from "vuex";
import MytodorunList from "@/views/myToDo/myToDoRunList";
import MytodoEchartList from "@/views/myToDo/myToDoEchartList";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import http from "@/common/request";
export default {
  components: {
    chart,
    InsuranceReview,
    MytodorunList,
    MytodoEchartList,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    UnderwritingInformation,
    RiskPlan,
    RiskReportList,
    RiskEventsList,
    RiskFinalReport,
    InsuranceCoverage
  },
  computed: {
    ...mapGetters([
      "riskTodoRunAll",
      "control",
      "userInfo",
      "getInsuranceReview",
      "getUnderwritingInformation",
      "getBasicBstablish",
      'fuzzyQuery',
      'screen'
    ]),
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  watch: {
    // 当小区详情发生改变则重新进行更改承保公司图片
    showMyCase(newVal, oldVal) {
      this.showFilter(newVal);
    }
  },
  data() {
    return {
      hackReset: false,
      charts: {
        maanshan: maanshan,
        beijing: beijing,
        shanghai: shanghai,
        yangquan: yangquan
      },
      showMyCase: "mytodo", //mytodo  mytodoList  mytodoDetail
      taskType: "insertInsureInfo",
      cardNum: 0,
      mytodos: {
        list: [{}, {}, {}, {}]
      },
      current: {
        finished: [],
        current: []
      },
      dataShow: [],
      ids: "",
      idstwo: "",
      origEchartId: "",
      interfaceName: "TODO",
      projectId: "",
      variable: false,
      echartTitle: "",
      variabletwo: false,
      echartTitletwo: ""
    };
  },
  created() {
    this.getmytodoRun(1);
    this.getCaseNum();
    this.setFuzzyQuery("");
    // this.Echarts()
    this.getScreen({})
    this.showFilter("mytodo");
    this.hackReset = false;
    this.$nextTick(() => {
      this.hackReset = true;
    });
  },
  mounted() {
    window.addEventListener("scroll", this.showGoTop, true);
    this.Echarts();
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  },
  methods: {
    ...mapActions([
      "hasNews",
      "riskTodoRun",
      "setFuzzyQuery",
      "checkRuleGetMsg",
      "showFilter",
      'getScreen'
    ]),
    selectCase(flag) {
      this.showMyCase = "mytodoList";
      this.taskType = flag;
    },
    // echart自定义
    selectEchart(flag) {
      if (flag == 0) {
        this.origEchartId = this.ids;
      } else if (flag == 1) {
        this.origEchartId = this.idstwo;
      }
      this.showMyCase = "mytodoEchartList";
    },
    showGoTop() {
      if (this.showMyCase !== "mytodoList" && this.showMyCase !== "mytodo") {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    //展示大表单
    goForm(flag, item) {
      this.projectId = item.projectId;
      this.showMyCase = flag;
      if (flag === "underWrite") {
        this.current = {
          finished: ["newProject", "enteringIns"],
          current: ["insuranceAudit"],
          projectId: item.projectId
        };
      } else if (flag === "startRiskPlan") {
        this.current = {
          finished: ["newProject", "enteringIns", "insuranceAudit"],
          current: ["launchRisk"],
          projectId: item.projectId
        };
      } else if (flag === "insuranceReview") {
        this.current = {
          finished: [
            "enteringIns",
            "newProject",
            "checkRisk",
            "insuranceAudit",
            "launchRisk",
            "enteringRisk",
            "riskManage",
            "entreingCompleted"
          ],
          current: ["insuranceCheck"],
          projectId: item.projectId
        };
      }
      if (flag === "underWrite" || flag === "startRiskPlan") {
        this.$refs.basicBstablish.init(item.projectId);
        this.$refs.underwriting.init(item.projectId);
        this.$refs[
          flag === "underWrite" ? "insuranceReview" : "insuranceReviewTwo"
        ].insuranceReview({
          projectId: item.projectId,
          taskName: item.taskName
        });
        setTimeout(() => {
          if (flag === "underWrite") {
            this.$refs["insuranceReview"].insuranceReviewTips(item.projectId);
            http
              .post("/sysconfig/BussinessRule/checkRule", {
                projectId: item.projectId,
                sendFlag: false
              })
              .then(res => {
                this.checkRuleGetMsg(res);
              });
          }
        }, 1000);
      } else if (flag === "insuranceReview") {
        this.$refs.basicBstablish.init(item.projectId);
        this.$refs.underwriting.init(item.projectId);
        this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
        this.$refs.insuranceCoverage.init(item.projectId);
        this.$refs.riskPlan.init(item.projectId);
        this.$refs.riskReportList.getPagination(1, item.projectId, "hasPrama");
        this.$refs.riskEventsList.getPagination(1, item.projectId, "hasPrama");
        this.$refs.riskFinalReport.riskFinalReport(item.projectId);
        this.$refs.insuranceReviewThree.insuranceReview({
          projectId: item.projectId
        });
      }
    },
    //关闭、保存、提交
    scc(flag, showMyCase) {
      if (flag === "close") {
        this.showMyCase = "mytodoList";
        this.getInsuranceReview.newUnderwrite.comment = "";
        this.getInsuranceReview.newUnderwrite.ruleTypes = [];
        this.getInsuranceReview.newUnderwrite.status = "";
        this.getInsuranceReview.newInsuranceReview.status = "";
        this.getInsuranceReview.newInsuranceReview.comment = "";
      } else {
        if (flag === "commit") {
          if (showMyCase === "underWrite") {
            let unValid = true;
            this.$refs.insuranceReview.$refs.validInsurance.validate(valid => {
              if (!valid) {
                unValid = valid;
                return unValid;
              }
            });
            if (!unValid) {
              // 校验提示
              this.$messageError({
                message: "请完善内容"
              });
              return unValid;
            }
            this.getInsuranceReview.newUnderwrite.projectId = this.projectId;
            this.getInsuranceReview.newUnderwrite.taskName = "underwrite";
            this.getInsuranceReview.newUnderwrite.blockchain = true;
            const url =
              this.getInsuranceReview.newUnderwrite.status == "APPROVED"
                ? "/sysconfig/check/success"
                : "/sysconfig/check/falied";
            this.$store.dispatch("loading", true);
            http.post(url, this.getInsuranceReview.newUnderwrite).then(res => {
              this.$store.dispatch("loading", false);
              if (res.code == 0) {
                this.getInsuranceReview.newUnderwrite.status = "";
                this.getInsuranceReview.newUnderwrite.comment = "";
                this.getInsuranceReview.newUnderwrite.ruleTypes = [];
                this.showMyCase = "mytodoList";
                this.$messageSuccess({
                  message: res.msg
                });
                this.getmytodoRun(1); // 重新查代办
                this.getCaseNum(); // 重新获取代办数量
              } else {
                this.$messageError({
                  message: res.msg
                });
              }
            });
          } else if (showMyCase === "startRiskPlan") {
            if (!this.getUnderwritingInformation.insBasicInfoDO.tisOrgId) {
              this.$messageError({
                message: "请选择风险管理机构"
              });
              return false;
            }
            if (this.getUnderwritingInformation.insBasicInfoDO.tisOrgId=='未指定') {
              this.$messageError({
                message: "请选择风险管理机构"
              });
              return false;
            }
            if (this.getUnderwritingInformation.insBasicInfoDO.tisOrgId!='未指定'&&!this.getUnderwritingInformation.insBasicInfoDO.tisOrgCode) {
              this.$messageError({
                message: "请选择重新风险管理机构"
              });
              return false;
            }
            this.getUnderwritingInformation.insBasicInfoDO.tisOrgId = this.getUnderwritingInformation.insBasicInfoDO.tisOrgId;
            http.post("/insurance/compose/underWriting", {
              insUnderWritingDTO: this.getUnderwritingInformation,
              prjBaseAndConstructionDTO: this.getBasicBstablish
            });
            this.$store.dispatch("loading", true);
            http
              .get(
                `/risk/RiskManagementPlan/startRiskManagementPlan/${this.getInsuranceReview.underwrite.projectId}`
              )
              .then(res => {
                this.$store.dispatch("loading", false);
                if (res.code == 0) {
                  this.showMyCase = "mytodoList";
                  this.$messageSuccess({
                    message: res.msg
                  });
                  this.getmytodoRun(1); // 重新查代办
                  this.getCaseNum(); // 重新获取代办数量
                } else {
                  this.$messageError({
                    message: res.msg
                  });
                }
              });
          } else if (showMyCase === "insuranceReview") {
            let unValid = true;
            this.$refs.insuranceReviewThree.$refs.validInsurance.validate(
              valid => {
                if (!valid) {
                  unValid = valid;
                  // 校验提示
                  this.$messageError({
                    message: "请完善内容"
                  });
                  return unValid;
                }
              }
            );
            if (!unValid) {
              return unValid;
            }
            this.getInsuranceReview.newInsuranceReview.projectId = this.projectId;
            this.getInsuranceReview.newInsuranceReview.taskName =
              "insuranceReview";
            this.getInsuranceReview.newInsuranceReview.blockchain = true;
            const url =
              this.getInsuranceReview.newInsuranceReview.status == "APPROVED"
                ? "/sysconfig/check/success"
                : "/sysconfig/check/falied";
            this.$store.dispatch("loading", true);
            http
              .post(url, this.getInsuranceReview.newInsuranceReview)
              .then(res => {
                this.$store.dispatch("loading", false);
                if (res.code == 0) {
                  this.getInsuranceReview.newInsuranceReview.status = "";
                  this.getInsuranceReview.newInsuranceReview.comment = "";
                  this.showMyCase = "mytodoList";
                  this.$messageSuccess({
                    message: res.msg
                  });
                  this.getmytodoRun(1); // 重新查代办
                  this.getCaseNum(); // 重新获取代办数量
                } else {
                  this.$messageError({
                    message: res.msg
                  });
                }
              });
          }
        }
      }
    },
    // 自定义echart
    option() {
      this.$refs.chartLine.destroy(); //销毁
      this.$refs.beijingMap.destroy(); //销毁
      this.Echarts();
    },
    // echarts
    async Echarts() {
      const keywords = {
        userId: this.userInfo.userId,
        orgId: this.userInfo.insOrgId,
        province: this.$getversionData.province,
        city: this.$getversionData.city
      };
      const { data } = await this.$api.echarts(keywords);
      this.dataShow = data;
      if (data[0]) {
        this.ids = data[0].echartId;
        this.echartTitle = data[0].title;
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(category_option);
          }, 10);
        } else if (data[0].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["25%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "17",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[0].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(pie_option);
            this.$refs.chartLine.editEcahrt(
              pie_option,
              this.$refs.chartLine.id
            );
          }, 10);
        } else if (data[0].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(axas_option);
          }, 10);
        } else if (data[0].echartType === "boxplot") {
          // 盒须图
         let boxDataList = [];
          let boxDataName = [];
          for (let n of data[0].data) {
            boxDataList.push(n.value);
            boxDataName.push(n.name);
          }
          let datass = echarts.dataTool.prepareBoxplotData(boxDataList);
          let boxplot_option = {
            title: [
              {
                text: data[0].title,
                left: "10",
                top: "15",
                textStyle: {
                  fontSize: "17",
                  fontWeight: "bold",
                  fontFamily: "Source Han Sans CN"
                }
              }
            ],
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "cross"
              },
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "10%"
            },
            xAxis: {
              type: "category",
              data: boxDataName,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              axisLabel: {
                formatter: "{value}"
              },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              name: "",
              splitArea: {
                show: true
              },
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: datass.boxData,
                tooltip: {
                  formatter: function(param) {
                    return [
                      "Experiment " + param.name + ": ",
                      "upper: " + param.data[5],
                      "Q3: " + param.data[4],
                      "median: " + param.data[3],
                      "Q1: " + param.data[2],
                      "lower: " + param.data[1]
                    ].join("<br/>");
                  }
                }
              },
              {
                name: "outlier",
                type: "scatter",
                data: datass.outliers
              }
            ]
          };
          setTimeout(() => {
            this.$refs.chartLine.initChart(boxplot_option);
          }, 10);
        } else if (data[0].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[0].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[0].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[0].echartType === "lines") {
          // 多折线图
          let dateArr = [];
          let dateYM = new Date();
          let currentYear = dateYM.getFullYear();
          dateYM.setMonth(dateYM.getMonth() + 1, 1);
          for (let i = 0; i < 12; i++) {
            dateYM.setMonth(dateYM.getMonth() - 1);
            let dateM = dateYM.getMonth() + 1;
            dateM = dateM < 10 ? "0" + dateM : dateM;
            let dateArrItem = {
              name: dateYM.getFullYear() + "-" + dateM,
              value: 0
            };
            dateArr.unshift(dateArrItem);
          }
          let x_data = [];
          dateArr.map(arrItem => {
            x_data.push(arrItem.name);
          });
          let categorys_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            // legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 15
              },
              type: "category",
              data: x_data
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: data[0].data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[0].data.map(itemChild => {
            itemChild.name = itemChild.name;
            itemChild.type = "line";
            itemChild.stack = "df";
            itemChild.data = [0,0,0,0,0,0,0,0,0,0,0,0];
            itemChild.result.map(resultChild => {
              dateArr.map((arrItem,num) => {
                if (arrItem.name == resultChild.name) {
                  arrItem.value = resultChild.value;
                  itemChild.data.map((list,i)=>{
                    if(num==i){itemChild.data.splice(i,1,arrItem.value)}
                  })
                } 
              });
            });
          });
          setTimeout(() => {
            this.$refs.chartLine.initChart(categorys_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            yAxis: {
              type: "category",
              axisLabel: {
                interval: 0
                // rotate: 25
              },
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideLeft"
                  }
                },
                data: [],
                itemStyle: {
                    normal:{
                        color: function (params){
                            var colorList=[];
                            for(var aa=0;aa<data[0].data.length;aa++){
                              colorList.push(`#${Math.floor(Math.random()*0xffffff).toString(16)}`); 
                            }
                          return colorList[params.dataIndex];
                        }
                    },
                    //鼠标悬停时：
                    emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.chartLine.initChart(Yaxas_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {
            //   top: "12",
            //   right: "13",
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: "bold"
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: data[0].yList
            },
            series: data[0].data
          };
          data[0].data.map((itemChild, num) => {
            itemChild.type = "bar";
            itemChild.stack = "df";
            itemChild.data = [];
            data[0].yList.map(itemYear => {
              if (itemChild.value[itemYear]) {
                itemChild.data.push(itemChild.value[itemYear]);
              } else {
                itemChild.data.push(0);
              }
          });
        });
          setTimeout(() => {
            this.$refs.chartLine.initChart(Yaxass_option);
          }, 10);
        } else if (data[0].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[0].data;
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["25%", "58%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              right: "5",
              top: "40",
              align:"left",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                fontWeight:"bold"
                // font: "Noto Sans SC"
              },
              data: data[0].data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.chartLine.initChart(spie_option);
          }, 10);
        }
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].data.length != 0) {
          this.variable = false;
        }
      }
      if (data[1]) {
        this.idstwo = data[1].echartId;
        this.echartTitletwo = data[1].title;
        if (data[1].data.length == 0) {
          this.variabletwo = true;
        } else if (data[1].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(category_option);
          }, 10);
        } else if (data[1].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["25%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "17",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[1].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(pie_option);
              this.$refs.beijingMap.editEcahrt(
              pie_option,
              this.$refs.beijingMap.id
            );
          }, 10);
        } else if (data[1].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(axas_option);
          }, 10);
        } else if (data[1].echartType === "boxplot") {
          // 盒须图
          let boxDataList = [];
          let boxDataName = [];
          for (let n of data[1].data) {
            boxDataList.push(n.value);
            boxDataName.push(n.name);
          }
          let datass = echarts.dataTool.prepareBoxplotData(boxDataList);
          let boxplot_option = {
            title: [
              {
                text: data[1].title,
                left: "10",
                top: "15",
                textStyle: {
                  fontSize: "17",
                  fontWeight: "bold",
                  fontFamily: "Source Han Sans CN"
                }
              }
            ],
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "cross"
              },
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "10%"
            },
            xAxis: {
              type: "category",
              data: boxDataName,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              axisLabel: {
                formatter: "{value}"
              },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              name: "",
              splitArea: {
                show: true
              },
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: datass.boxData,
                tooltip: {
                  formatter: function(param) {
                    return [
                      "Experiment " + param.name + ": ",
                      "upper: " + param.data[5],
                      "Q3: " + param.data[4],
                      "median: " + param.data[3],
                      "Q1: " + param.data[2],
                      "lower: " + param.data[1]
                    ].join("<br/>");
                  }
                }
              },
              {
                name: "outlier",
                type: "scatter",
                data: datass.outliers
              }
            ]
          };
          setTimeout(() => {
            this.$refs.beijingMap.initChart(boxplot_option);
          }, 10);
        } else if (data[1].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[1].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.5, //长宽比例
                width: "60%",
                height: "90%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[1].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[1].echartType === "lines") {
          // 多折线图
          let dateArr = [];
          let dateYM = new Date();
          let currentYear = dateYM.getFullYear();
          dateYM.setMonth(dateYM.getMonth() + 1, 1);
          for (let i = 0; i < 12; i++) {
            dateYM.setMonth(dateYM.getMonth() - 1);
            let dateM = dateYM.getMonth() + 1;
            dateM = dateM < 10 ? "0" + dateM : dateM;
            let dateArrItem = {
              name: dateYM.getFullYear() + "-" + dateM,
              value: 0
            };
            dateArr.unshift(dateArrItem);
          }
          let x_data = [];
          dateArr.map(arrItem => {
            x_data.push(arrItem.name);
          });
          let categorys_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              position: function(pos, params, dom, rect, size) {
                var obj = { top: 60 };
                obj[["left", "right"][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                return obj;
              }
            },
            // legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 15
              },
              type: "category",
              data: x_data
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: data[1].data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[1].data.map(itemChild => {
            itemChild.name = itemChild.name;
            itemChild.type = "line";
            itemChild.stack = "df";
            itemChild.data = [0,0,0,0,0,0,0,0,0,0,0,0];
            itemChild.result.map(resultChild => {
              dateArr.map((arrItem,num) => {
                if (arrItem.name == resultChild.name) {
                  arrItem.value = resultChild.value;
                  itemChild.data.map((list,i)=>{
                    if(num==i){itemChild.data.splice(i,1,arrItem.value)}
                  })
                } 
              });
            });
          });
          setTimeout(() => {
            this.$refs.beijingMap.initChart(categorys_option);
          }, 10);
        } else if (data[1].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            yAxis: {
              type: "category",
              axisLabel: {
                interval: 0
                // rotate: 25
              },
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideLeft"
                  }
                },
                data: [],
                itemStyle: {
                    normal:{//每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                        color: function (params){
                            var colorList=[];
                            for(var aa=0;aa<data[1].data.length;aa++){
                              colorList.push(`#${Math.floor(Math.random()*0xffffff).toString(16)}`); 
                            }
                          return colorList[params.dataIndex];
                        }
                    },
                    //鼠标悬停时：
                    emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
              }
            ]
          };
          for (let n of data[1].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(Yaxas_option);
          }, 10);
        } else if (data[1].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {
            //   top: "12",
            //   right: "13",
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: "bold"
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: data[1].yList
            },
            series: data[1].data
          };
          data[1].data.map((itemChild, num) => {
            itemChild.type = "bar";
            itemChild.stack = "df";
            itemChild.data = [];
            data[1].yList.map(itemYear => {
              if (itemChild.value[itemYear]) {
                itemChild.data.push(itemChild.value[itemYear]);
              } else {
                itemChild.data.push(0);
              }
          });
        });
          setTimeout(() => {
            this.$refs.beijingMap.initChart(Yaxass_option);
          }, 10);
        } else if (data[1].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[1].data;
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["25%", "58%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[1].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              right: "5",
              top: "40",
              align:"left",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                fontWeight:"bold"
                // font: "Noto Sans SC"
              },
              data: data[1].data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.beijingMap.initChart(spie_option);
          }, 10);
        }
        if (data[1].data.length == 0) {
          this.variabletwo = true;
        } else if (data[1].data.length != 0) {
          this.variabletwo = false;
        }
      }
    },
    //运营待办，初始化项目信息
    getmytodoRun(val) {
       if (!this.screen.buildingType) {
        if (
          typeof this.screen.buildingType != "string" ||
          typeof this.screen.buildingType != "object"
        ) {
          this.screen.buildingType = undefined;
        }
      } else {
        if (this.screen.buildingType.size == 0) {
          this.screen.buildingType = undefined;
        }
      }
      const keywords = {
        isMainIns: "Y",
        province: this.screen.province,
        district: this.screen.district,
        city: this.screen.city,
        taskName: "", //保单审核  启动风控  竣工保险审核
        minCostPerMeter: this.screen.minCostPerMeter,
        maxCostPerMeter: this.screen.maxCostPerMeter,
        beginSignDate: this.screen.beginSignDate,
        endSignDate: this.screen.endSignDate,
        buildingType: this.screen.buildingType,
        projectName:this.screen.projectName,
        insContractNo: this.screen.insContractNo,
        fuzzyQuery: this.fuzzyQuery.value,
        offset: val,
        limit: 8
      };
      this.$store.dispatch("loading", true);
      this.riskTodoRun(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    },
    //返回待办首页
    backMytodo() {
      this.showMyCase = "mytodo";
      this.getmytodoRun(1);
    },
    //获取案件数
    async getCaseNum() {
      const res = await this.$api.getCaseNumber();
      this.cardNum = res.data;
    }
  }
};
</script>
<style lang="scss" scoped>
.newclass {
  background: url(../../assets/imgs/noData.png);
  background-size: 160px 160px;
  background-repeat: no-repeat;
  background-position: 107px 30px;
}
.newclass /deep/ span {
  font-size: 17px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 15px;
  left: 21px;
}
.news {
  height: 45px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  span {
    margin-left: 16px;
  }
}
.content {
  height: 240px;
  position: relative;
  background-color: rgba(255, 255, 255, 0.9);
  margin-bottom: 7px;
}
.content1 {
  height: 240px;
}
.upTitle {
  font-size: 15px;
  color: #000000;
  font-weight: 900;
  padding-top: 15px;
  padding-right: 30px;
}
.risk_btn {
  position: absolute;
  bottom: 0px;
  width: 100%;
  .el-button {
    width: 100%;
    background-color: rgba(41, 122, 227, 0.56);
    border: 0px;
    border-radius: 0 0 5px 5px;
    font-family: Source Han Sans CN;
    font-weight: 500;
    font-size: 16px;
    color: #fff;
  }
}
.my_progress /deep/ {
  .el-progress-circle {
    height: 100px !important;
    width: 100px !important;
  }
  .el-progress__text {
    color: #333333;
    font-size: 22px !important;
    top: 40%;
    font-weight: bolder;
  }
}
.el-pagination {
  padding: 2px 0px;
  /deep/ button {
    padding: 0;
  }
}
.leftContent span {
  color: #fff;
  line-height: 26px;
}
.title {
  color: #fff;
}
.date {
  height: 130px;
  margin-top: 35px;
  background-image: url(../../assets/imgs/todo/todo1.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
}
.date1 {
  background-image: url(../../assets/imgs/todo/todo2.png);
}
.date2 {
  background-image: url(../../assets/imgs/todo/todo3.png);
}
.days {
  color: #7eafed;
  font-size: 35px;
  font-weight: bold;
  margin-left: -10px;
}
.year {
  font-size: 12px;
}
.rightContent {
  text-align: left;
  font-size: 13px;
  font-weight: bold;
}
.rightContent p {
  font-weight: bold;
  font-size: 16px;
}
.case_yellow {
  background-image: url(../../assets/imgs/case_yellow.png);
  background-size: 100%;
  background-repeat: no-repeat;
}
.case_green {
  background-image: url(../../assets/imgs/case_green.png);
  background-size: 100%;
  background-repeat: no-repeat;
}
.case_blue {
  background-image: url(../../assets/imgs/case_blue.png);
  background-size: 100%;
  background-repeat: no-repeat;
}
.card_board {
  background-image: url(../../assets/imgs/ziban.png);
  background-repeat: no-repeat;
  background-position: center;
  background-size: 100%;
  height: 220px;
  width: 252px;
  margin-top: 7px;
  margin-left: 70px;
}
.card_num {
  text-align: center;
  font-size: 100px;
  font-weight: bold;
  padding-top: 70px;
}
.none_info {
  background-image: url(../../assets/imgs/none_info.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
  height: 120px;
  margin-top: 35px;
}
.none_info1 {
  background-image: url(../../assets/imgs/none_info1.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
  height: 120px;
  margin-top: 35px;
}
.none_info2 {
  background-image: url(../../assets/imgs/none_info2.png);
  background-repeat: no-repeat;
  background-size: 90% 70%;
  height: 120px;
  margin-top: 35px;
}
.none_list {
  background-image: url(../../assets/imgs/none_list.png);
}
.none_list1 {
  background-image: url(../../assets/imgs/none_list1.png);
}
.none_list2 {
  background-image: url(../../assets/imgs/none_list2.png);
}
.none_listbase {
  background-repeat: no-repeat;
  background-size: 100px;
  height: 176px;
  background-position: 115px;
}
</style>

<template>
  <div style="position: relative">
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'MyToDoRisk' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-show="!showForm && showMyCase==='MyToDoRisk'">
        <el-row>
          <el-col :span="9">
            <div class="content-left">
              <span
                class="el-icon-edit-outline mouse-pointer"
                @click="selectEchart()"
                style="position: absolute;left:350px;top: 20px;color:#297AE3;z-index:999"
              >自定义</span>
              <div v-show="this.variable" class="newclass" style="height:488px">
                <span>{{this.echartTitle}}</span>
              </div>
              <chart ref="beijingMap" style="width:100%;height:100%"></chart>
            </div>
            <!-- 无数据时 -->
            <div
              v-show="this.dataShow.length===0"
              style="position: absolute;left: 15%;top: 50%;transform: translate(-50%,-67%);"
            >
              <img src="@/assets/imgs/noData.png" width="220" height="171" />
            </div>
          </el-col>
          <!-- <el-col :span="1">
            <div style="height: 240px;"></div>
            <div style="height: 240px;"></div>
          </el-col>-->
          <el-col :span="15">
            <el-row>
              <el-col
                :span="12"
                class="content-right"
                v-for="(item,index) in riskList.insertRiskCtrlPlan.rows"
                :key="index"
              >
                <div class="risk-card" style="margin-left: 7px;" @click="goForm(item)">
                  <el-row>
                    <div class="mouse-pointer">
                      <el-col :span="24" class="title" style="background:rgba(41,122,227,0.56)">
                        <div style="height:37px;line-height: 37px;">待上传风险管理工作计划</div>
                      </el-col>
                    </div>
                  </el-row>
                  <el-row class="case">
                    <div class="mouse-pointer">
                      <el-col :span="6" :offset="1" class="date leftContent">
                        <span>{{item.mydate.case_month}}</span>
                        <div
                          class="days"
                          style="color: #7eafed; line-height: 40px"
                        >{{item.mydate.case_day}}</div>
                        <div class="year days" style="line-height: 14px">{{item.mydate.case_year}}</div>
                      </el-col>
                      <el-col :span="16" class="rightContent">
                        <div
                          :title="item.projectName"
                          style="font-weight: bold;font-size: 16px;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;margin:16px 0"
                        >{{item.projectName}}&nbsp;</div>
                        <div
                          style="margin-top:17.5px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                          :title="item.insContractNo!=null"
                          v-if="item.insContractNo"
                        >保单号：{{item.insContractNo}}</div>
                        <div
                          v-else
                          style="margin-top:17.5px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                        >保单号：未填写</div>
                        <div style="margin-top:5px">住宅性质：{{item.dictValue}}</div>
                        <div style="margin-top:5px">阶段：{{item.projectChnStatus}}</div>
                      </el-col>
                    </div>
                    <div v-if="item.status=='UNAPPROVED'" class="bohui"></div>
                  </el-row>
                </div>
              </el-col>
            </el-row>
            <div
              v-show="riskList.insertRiskCtrlPlan.rows.length===0"
              style="position: absolute;left: 65%;top: 50%;transform: translate(-50%,-67%);"
            >
              <img src="@/assets/imgs/noData.png" width="220" height="171" />
            </div>
          </el-col>
        </el-row>
        <el-row style="text-align: right">
          <el-col v-show="riskList.insertRiskCtrlPlan.total!=0">
            <el-pagination
              small
              class="mt10 page-lucency"
              layout="prev, pager, next"
              @current-change="handleRiskChange"
              :page-size="4"
              :total="riskList.insertRiskCtrlPlan.total"
              :current-page.sync="currentPage"
            ></el-pagination>
          </el-col>
        </el-row>
      </div>
    </transition>
    <!-- echart自定义 -->
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'MyToDoRisk' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-if="showMyCase==='mytodoEchartList'" style="position: absolute; top: 0;width: 100%;">
        <mytodo-echart-list
          @option="option"
          @backMytodo="backMytodo"
          :origEchartId="origEchartId"
          :interfaceName="interfaceName"
        ></mytodo-echart-list>
      </div>
    </transition>
    <div v-show="showForm" style="position: absolute; top: 0; width: 100%">
      <div id="top">
        <flow-chart :current="current" @goBack="scc('close')" />
        <insurance-review
          ref="checkRiskCtrlPlan"
          title="驳回意见"
          taskType="checkRiskCtrlPlan"
          :disabled="true"
          v-show="getInsuranceReview.checkRiskCtrlPlan.processIsEnd=='N'"
        />
        <risk-plan ref="riskPlan" />
        <basic-information :disabled="true" />
        <bstablish-information ref="basicBstablish" :disabled="true" showMyCase="basicBstablish" />
        <div class="text-right mt10">
          <el-button @click="scc('save')" type="primary" size="mini">保存</el-button>
          <el-button @click="scc('commit')" type="primary" size="mini">提交</el-button>
          <el-button @click="scc('close')" size="mini">关闭</el-button>
        </div>
        <el-button @click="goTop" id="go-top" circle :style="screen_width">
          <i class="el-icon-arrow-up"></i>
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import chart from "@/components/charts/index";
import beijing from "@/components/charts/map/beijing.json";
import yangquan from "@/components/charts/map/yangquan.json";
import maanshan from "@/components/charts/map/maanshan.json";
import shanghai from "@/components/charts/map/shanghai.json";
import MytodoEchartList from "@/views/myToDo/myToDoEchartList";
import http from "@/common/request";
export default {
  name: "MyToDoRisk",
  components: {
    chart,
    FlowChart,
    MytodoEchartList,
    BasicInformation,
    BstablishInformation,
    RiskPlan,
    InsuranceReview
  },
  computed: {
    ...mapGetters([
      "userInfo",
      "riskList",
      "getRiskPlan",
      "getInsuranceReview",
      "fuzzyQuery",
      "screen",
      "offsetLists"
    ]),
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  data() {
    return {
      charts: {
        maanshan: maanshan,
        beijing: beijing,
        shanghai: shanghai,
        yangquan: yangquan
      },
      showMyCase: "MyToDoRisk",
      current: {
        finished: ["newProject", "enteringIns", "insuranceAudit", "launchRisk"],
        current: ["enteringRisk"]
      },
      dataShow: [],
      showForm: false,
      pagerCount: 5,
      pageSize: 10,
      total: 60,
      mytodos: {},
      ids: "",
      idstwo: "",
      origEchartId: "",
      interfaceName: "TODO",
      variable: false,
      echartTitle: "",
      currentPage:1
    };
  },
  created() {
    this.getmytodorisk(1);
  },
  mounted() {
    this.Echart();
    window.addEventListener("scroll", this.showGoTop, true);
     this.$EventBus.$on("QUERY_EVENT", () => {
      this.riskList.insertRiskCtrlPlan.total = 0;
      this.currentPage = 1
    });
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  },
  methods: {
    ...mapActions(["hasNews", "todorisk", "setFuzzyQuery", "riskScreen"]),
    showGoTop() {
      if (this.showForm) {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },
    // echart自定义
    selectEchart() {
      this.origEchartId = this.ids;
      this.showMyCase = "mytodoEchartList";
    },
    // 返回首页
    backMytodo() {
      this.showMyCase = "MyToDoRisk";
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    goForm(item) {
      this.riskScreen(true);
      this.showForm = true;
      this.$refs.basicBstablish.init(item.projectId);
      this.$refs.riskPlan.init(item.projectId);
      this.$refs.checkRiskCtrlPlan.insuranceReview({
        projectId: item.projectId
      });
      this.current.projectId = item.projectId;
    },
    handleRiskChange(val) {
      this.currentPage = val
      this.getmytodorisk(val, this.fuzzyQuery.value);
    },
    //保存、提交、关闭
    scc(flag) {
      let _this = this;
      if (flag === "close") {
        this.getmytodorisk(1);
        this.showForm = false;
      } else {
        if (flag === "commit") {
          let valid = true;
          this.$refs.riskPlan.$refs.validRiskPlan.validate(v => {
            if (!v) {
              valid = v;
              // 校验提示
              this.$messageError({
                message: "请完善内容"
              });
              return v;
            }
          });
          if (!valid) {
            return valid;
          }
        }
        this.getRiskPlan.riskManagementPlanBigDO.sqlStatus =
          flag == "save" ? 0 : 1;
        let riskManagePtcps = [];
        for (let item of this.getRiskPlan.userDO) {
          if (item.username) {
            riskManagePtcps.push(item.userId);
          }
        }
        this.getRiskPlan.riskManagementPlanBigDO.riskManagePtcp = riskManagePtcps.join();
        this.$store.dispatch("loading", true);
        http.post("/risk/RiskManagementPlan", this.getRiskPlan).then(res => {
          this.$store.dispatch("loading", false);
          if (res.code == 0) {
            if (flag === "save") {
              _this.$refs.basicBstablish.init(
                _this.getRiskPlan.riskManagementPlanBigDO.projectId
              );
              _this.$refs.riskPlan.init(
                _this.getRiskPlan.riskManagementPlanBigDO.projectId
              );
            }
            this.$messageSuccess({
              message: res.msg
            });
            if (flag !== "save") {
              this.getmytodorisk(1);
              this.showForm = false;
            }
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        });
      }
    },
    getmytodorisk(val, fuzzyQuery) {
      if (!this.screen.buildingType) {
        if (
          typeof this.screen.buildingType != "string" ||
          typeof this.screen.buildingType != "object"
        ) {
          this.screen.buildingType = undefined;
        }
      } else {
        if (this.screen.buildingType.size == 0) {
          this.screen.buildingType = undefined;
        }
      }
      const keywords = {
        fuzzyQuery: fuzzyQuery,
        offset: val,
        limit: 4,
        beginSignDate: this.screen.beginSignDate,
        buildingType: this.screen.buildingType,
        city: this.screen.city,
        district: this.screen.district,
        endSignDate: this.screen.endSignDate,
        insContractNo: this.screen.insContractNo,
        isMainIns: this.screen.isMainIns,
        maxCostPerMeter: this.screen.maxCostPerMeter,
        minCostPerMeter: this.screen.minCostPerMeter,
        orgId: this.screen.orgId,
        projectName: this.screen.projectName,
        province: this.screen.province
      };
      this.$store.dispatch("loading", true);
      this.todorisk(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    },
    // 自定义echart
    option() {
      this.$refs.beijingMap.destroy(); //销毁
      this.Echart();
    },
    async Echart() {
      // 调用接口
      const keywords = {
        userId: this.userInfo.userId,
        orgId: this.userInfo.insOrgId,
        province: this.$getversionData.province,
        city: this.$getversionData.city
      };
      const { data } = await this.$api.echarts(keywords);
      this.dataShow = data;
      if (data.length != 0) {
        this.ids = data[0].echartId;
        this.echartTitle = data[0].title;
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].echartType === "line") {
          // 折线图
          let category_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: "{c}" //鼠标滑过时候的显示
            },
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: []
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000) {
                    value = value / 10000000 + "千万";
                  }
                  return value;
                }
              }
            },
            series: [
              {
                data: [],
                type: "line"
              }
            ],
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            category_option.xAxis.data = [
              ...category_option.xAxis.data,
              n.name
            ];
            category_option.series[0].data = [
              ...category_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(category_option);
          }, 10);
        } else if (data[0].echartType === "sector") {
          // 圆形扇形图
          let pie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              triggrer: "item",
              formatter: "{b}:{c} ({d}%)"
            },
            legend: {
              selectedMode: false,
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              icon: "circle",
              top: "40",
              right: "5",
              align: "left",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            color: [
              "#C81812",
              "#EFB70C",
              "#9F77FA",
              "#FB5277",
              "#297AE3",
              "#3CD323",
              "#E5E5E5",
              "#8C8C8C",
              "#FF33FF",
              "#CAFF70",
              "#3399FF",
              "#3366FF",
              "#CCCCFF",
              "#99FFCC",
              "#663333",
              "#00FFFF"
            ],
            series: [
              {
                name: "",
                type: "pie",
                radius: ["55%", "65%"],
                center: ["38%", "58%"],
                // hoverAnimation: false, //高亮不可用
                // hoverOffset: 5, // 高亮的大小
                label: {
                  normal: {
                    show: false,
                    position: "center"
                  },
                  emphasis: {
                    show: true,
                    textStyle: {
                      fontSize: "17",
                      align: "center"
                    },
                    formatter: ["{a| {d}%}", "{b| {b}}"].join("\n"),
                    rich: {
                      a: {
                        fontSize: "23",
                        align: "center",
                        fontWeight: "400"
                      },
                      b: {
                        fontSize: "12",
                        align: "center",
                        fontWeight: "400",
                        color: "#68615f"
                      }
                    }
                  }
                },
                labelLine: {
                  normal: {
                    show: false
                  }
                },
                labelLine: {
                  normal: {
                    lineStyle: {
                      color: "rgba(255, 255, 255, 0.3)"
                    },
                    smooth: 0.2,
                    length: 10,
                    length2: 20
                  }
                },
                data: []
              }
            ]
          };
          for (let item of data[0].data) {
            if (typeof item.value !== "number") {
              continue;
            }
            pie_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(pie_option);
            this.$refs.beijingMap.editEcahrt(
              pie_option,
              this.$refs.beijingMap.id
            );
          }, 10);
        } else if (data[0].echartType === "columnar") {
          // 柱状图
          let axas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "category",
              data: [],
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "value"
            },
            series: [
              {
                type: "bar",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            axas_option.xAxis.data = [...axas_option.xAxis.data, n.name];
            axas_option.series[0].data = [
              ...axas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(axas_option);
          }, 10);
        } else if (data[0].echartType === "boxplot") {
          // 盒须图
          let boxplot_option = {
            title: {
              text: data[0].title,
              left: "center"
            },
            tooltip: {
              trigger: "item",
              axisPointer: {
                type: "shadow"
              }
            },
            grid: {
              left: "10%",
              right: "10%",
              bottom: "15%"
            },
            xAxis: {
              type: "category",
              data: data.axisDatas,
              boundaryGap: true,
              nameGap: 30,
              splitArea: {
                show: false
              },
              // axisLabel: {
              //   formatter: 'expr {value}'
              // },
              splitLine: {
                show: false
              }
            },
            yAxis: {
              type: "value",
              splitArea: {
                show: true
              }
            },
            series: [
              {
                name: "boxplot",
                type: "boxplot",
                data: data.boxData
              },
              {
                name: "outlier",
                type: "scatter",
                data: data.outliers
              }
            ]
          };
          for (let n of data[0].data) {
            boxplot_option.xAxis.data = [
              // ...boxplot_option.axisData.data,
              n.name
            ];
            boxplot_option.series[0].data = [
              // ...boxplot_option.series[0].data,
              n.name
            ];
            boxplot_option.series[1].data = [
              // ...boxplot_option.series[0].data,
              n.name
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(boxplot_option);
          }, 10);
        } else if (data[0].echartType === "map") {
          // 地图
          let map_option = {
            title: {
              // 设置标题
              text: data[0].title,
              x: "left",
              top: "3%",
              left: "3%",
              textStyle: {
                fontSize: "17",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            visualMap: {
              min: 0,
              max: 50,
              text: ["High", "Low"],
              inRange: {
                color: ["lightskyblue", "yellow", "orangered"]
              }
            },
            tooltip: {
              formatter: function(params, ticket, callback) {
                if (isNaN(params.value)) {
                  params.value = "-";
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                } else {
                  return (
                    params.seriesName +
                    "<br />" +
                    params.name +
                    "：" +
                    params.value
                  );
                }
              }
            }, // 鼠标移到图里面的浮动提示框
            series: [
              {
                name: this.$getversionData.city,
                type: "map",
                mapType: this.$getversionData.city,
                aspectScale: 0.4, //长宽比例
                width: "60%",
                height: "60%",
                data: [], // 存入 let data数据value值
                itemStyle: {
                  borderColor: "#fff", //省份边框线颜色
                  borderWidth: 1 //省份边框线宽度
                },
                label: {
                  normal: {
                    show: true //显示省份标签
                  },
                  emphasis: {
                    show: true, //对应的鼠标悬浮效果
                    borderColor: "#01aef0"
                  }
                },
                roam: true, //鼠标滚轮放大缩小
                scaleLimit: {
                  //滚轮缩放的极限控制
                  min: 0.4,
                  max: 2.5
                }
              }
            ]
          };
          for (let item of data[0].data) {
            map_option.series[0].data.push({
              name: item.name,
              value: item.value
            });
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(map_option, {
              name: this.$getversionData.city,
              map: this.charts[this.$getversionData.control]
            });
          }, 10);
        } else if (data[0].echartType === "lines") {
          // 多折线图
          let categorys_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis"
              // formatter: '{c}' //鼠标滑过时候的显示
            },
            legend: {},
            xAxis: {
              axisLabel: {
                fontSize: 12,
                interval: 0,
                rotate: 30
              },
              type: "category",
              data: [
                "一月",
                "二月",
                "三月",
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
              ]
            },
            yAxis: {
              type: "value",
              splitNumber: "4",
              scale: true,
              axisLabel: {
                fontSize: 11,
                formatter: function(value, index) {
                  if (value >= 10000 && value < 1000000) {
                    value = value / 10000 + "万";
                  } else if (value >= 1000000 && value < 10000000) {
                    value = value / 1000000 + "百万";
                  } else if (value >= 10000000 && value < 100000000) {
                    value = value / 10000000 + "千万";
                  } else if (value >= 100000000) {
                    value = value / 100000000 + "亿";
                  }
                  return value;
                }
              }
            },
            series: item.data,
            grid: {
              //Y轴显示不全
              left: 54
            }
          };
          data[0].data.map((item, num) => {
            item.type = "line";
            item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.beijingMap.initChart(categorys_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnar") {
          // 横向柱状图
          let Yaxas_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            // legend: {

            //   top: '12',
            //   right: '13',
            //   textStyle: {
            //     fontSize: 10,
            //     fontWeight: 'bold'
            //   },
            //   itemWidth: 10, //图标宽
            //   itemHeight: 10, //图标高
            //   itemGap: 10 //间距
            // },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: []
            },
            series: [
              {
                type: "bar",
                color: "#0000CD",
                label: {
                  normal: {
                    show: true,
                    position: "insideRight"
                  }
                },
                data: []
              }
            ]
          };
          for (let n of data[0].data) {
            if (typeof n.value !== "number") {
              continue;
            }
            Yaxas_option.yAxis.data = [...Yaxas_option.yAxis.data, n.name];
            Yaxas_option.series[0].data = [
              ...Yaxas_option.series[0].data,
              n.value
            ];
          }
          setTimeout(() => {
            this.$refs.beijingMap.initChart(Yaxas_option);
          }, 10);
        } else if (data[0].echartType === "acrossColumnars") {
          // 多项横向柱状图
          let Yaxass_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                // 坐标轴指示器，坐标轴触发有效
                type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            legend: {
              top: "12",
              right: "13",
              textStyle: {
                fontSize: 10,
                fontWeight: "bold"
              },
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            grid: {
              left: "1%",
              right: "1%",
              bottom: "1%",
              containLabel: true
            },
            xAxis: {
              type: "value",
              axisLabel: {
                interval: 0,
                rotate: 30
              }
            },
            yAxis: {
              type: "category",
              data: ["1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4"]
            },
            series: item.data
          };
          data[0].data.map((item, num) => {
            (item.type = "bar"),
              (itemstack = ""),
              (item.data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
            item.result.map(itemChild => {
              item.data.map((list, index) => {
                if (itemChild.name == index + 1) {
                  item.data.splice(index, 1, itemChild.value);
                }
              });
            });
          });
          setTimeout(() => {
            this.$refs.beijingMap.initChart(Yaxass_option);
          }, 10);
        } else if (data[0].echartType === "specialSector") {
          // 特殊扇形
          const datas = data[0];
          const arrName = getArrayValue(datas, "name");
          const arrValue = getArrayValue(datas, "value");
          const sumValue = eval(arrValue.join("+"));
          const objData = array2obj(datas, "name");
          const optionData = getData(datas);
          function getArrayValue(array, key) {
            var key = key || "value";
            var res = [];
            if (array) {
              array.forEach(function(t) {
                res.push(t[key]);
              });
            }
            return res;
          }
          function array2obj(array, key) {
            var resObj = {};
            for (var i = 0; i < array.length; i++) {
              resObj[array[i][key]] = array[i];
            }
            return resObj;
          }
          function getData(data) {
            var res = {
              series: [],
              yAxis: []
            };
            for (let i = 0; i < data.length; i++) {
              res.series.push({
                type: "pie",
                clockWise: false, //顺时加载
                hoverAnimation: false, //鼠标移入变大
                radius: [66 - i * 8 + "%", 61 - i * 8 + "%"],
                center: ["50%", "50%"],
                label: {
                  show: false
                },
                itemStyle: {
                  label: {
                    show: false
                  },
                  labelLine: {
                    show: false
                  },
                  borderWidth: 5
                },
                data: [
                  {
                    value: data[i].value,
                    name: data[i].name
                  },
                  {
                    value: sumValue - data[i].value,
                    name: "",
                    itemStyle: {
                      color: "rgba(0,0,0,0)",
                      borderWidth: 0
                    },
                    tooltip: {
                      show: false
                    },
                    hoverAnimation: false
                  }
                ]
              });
            }
            return res;
          }
          let spie_option = {
            title: {
              text: data[0].title,
              x: "10",
              y: "15",
              textStyle: {
                fontSize: "13",
                fontWeight: "bold",
                fontFamily: "Source Han Sans CN"
              }
            },
            tooltip: {
              trigger: "item",
              formatter: "{b}: {c} ({d}%)"
            },
            legend: {
              backgroundColor: "rgba(245,245,245,1)", // 设置整个图例区域背景颜色
              borderRadius: 10,
              orient: "vertical",
              left: "45%",
              top: "16%",
              textStyle: {
                // color: '#FFFFFF',
                fontSize: 10,
                font: "Noto Sans SC"
              },
              data: item.data,
              itemWidth: 10, //图标宽
              itemHeight: 10, //图标高
              itemGap: 10 //间距
            },
            series: optionData.series
          };
          setTimeout(() => {
            this.$refs.beijingMap.initChart(spie_option);
          }, 10);
        }
        if (data[0].data.length == 0) {
          this.variable = true;
        } else if (data[0].data.length != 0) {
          this.variable = false;
        }
      }
    }
  }
};
</script>
<style scoped lang="scss">
.newclass {
  background: url(../../assets/imgs/noData.png);
  background-size: 220px 220px;
  background-repeat: no-repeat;
  background-position: 90px 100px;
}
.newclass /deep/ span {
  font-size: 17px;
  font-weight: bold;
  font-family: Source Han Sans CN;
  position: absolute;
  top: 15px;
  left: 21px;
}
.news {
  height: 45px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  span {
    margin-left: 16px;
  }
}
.content-left {
  height: 488px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 5px;
}
.content-right {
  margin-bottom: 7px;
}
.risk-card {
  position: relative;
  height: 240px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 0 0 5px 5px;
  box-shadow: 0px 5px 4px 0px rgba(0, 0, 0, 0.28);
}
.days {
  color: #7eafed;
  font-size: 35px;
  font-weight: bold;
  margin-left: -10px;
}
.year {
  font-size: 12px;
}
.leftContent span {
  color: #fff;
  line-height: 26px;
  margin-left: -8px;
  font-weight: bold;
}
.rightContent {
  text-align: left;
  font-size: 13px;
  font-weight: bold;
}
.rightContent p {
  font-weight: bold;
  font-size: 16px;
  margin-top: 35px;
}
.clearfix {
  padding: 20px 0;
  span {
    display: block;
    font-family: Source Han Sans CN;
    font-size: 16px;
    font-weight: bold;
  }
}
.my_progress /deep/ {
  .el-progress-circle {
    height: 100px !important;
    width: 100px !important;
  }
  .el-progress__text {
    color: #333333;
    font-size: 22px !important;
    top: 40%;
    font-weight: bold !important;
  }
  // .el-progress-circle__path {
  //   stroke: rgb(119, 165, 224);
  // }
}
.risk_btn {
  position: absolute;
  bottom: 0px;
  width: 100%;
  .el-button {
    width: 100%;
    background-color: rgba(41, 122, 227, 0.56);
    border: 0px;
    border-radius: 0 0 5px 5px;
    font-family: Source Han Sans CN;
    font-weight: 500;
    font-size: 16px;
    color: #fff;
  }
}

.date {
  height: 130px;
  margin-top: 35px;
  background-repeat: no-repeat;
  background-size: 90% 70%;
  background-image: url(../../assets/imgs/todo/todo1.png);
}
.title {
  color: #fff;
}
.bohui {
  background-image: url(../../assets/imgs/bohui.png);
  background-repeat: no-repeat;
  background-size: 100px;
  height: 176px;
  background-position: center;
}
</style>
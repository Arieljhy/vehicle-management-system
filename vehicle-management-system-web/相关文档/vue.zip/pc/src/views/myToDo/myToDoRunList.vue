<template>
  <div class="content_list">
    <el-row>
      <div @click="backMytodo" class="case_title mouse-pointer">
        <i class="el-icon-arrow-left"></i>
        <span>项目展开</span>
      </div>
    </el-row>
    <el-row :gutter="8" style="margin-top:2px">
      <el-col :span="6" v-for="item in mytodoList.rows" :key="item.id" style="margin-top:18px">
        <el-row>
          <div class="mouse-pointer" @click="goForm(taskType, item)">
            <el-col
              :span="24"
              class="title"
              style="background:rgba(41,122,227,0.56)"
              v-if="taskType==='underWrite'"
            >
              <div style="height:37px;line-height: 37px;">保险审核</div>
            </el-col>
            <el-col
              :span="24"
              class="title"
              style="background:rgba(255,154,42,0.56)"
              v-if="taskType==='startRiskPlan'"
            >
              <div style="height:37px;line-height: 37px;">启动风控</div>
            </el-col>
            <el-col
              :span="24"
              class="title"
              style="background:rgba(5,207,173,0.56)"
              v-if="taskType==='insuranceReview'"
            >
              <div style="height:37px;line-height: 37px;">竣工保险审核</div>
            </el-col>
          </div>
        </el-row>
        <el-row class="case">
          <div class="mouse-pointer" @click="goForm(taskType, item)">
            <el-col :span="6" :offset="1" class="date leftContent" :class="[mc_data]">
              <span>{{item.mydate.case_month}}</span>
              <div class="days" :style="mc_data_color">{{item.mydate.case_day}}</div>
              <div class="year days" :style="mc_date_color">{{item.mydate.case_year}}</div>
            </el-col>
            <el-col :span="16" class="rightContent">
              <div
                style="margin-top:12px"
                :title="item.projectName"
                class="edit_text"
              >{{item.projectName}}&nbsp;</div>
              <div
                v-if="item.insContractNo!=null"
                style="margin-top:17.5px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                :title="item.insContractNo"
              >保单号：{{item.insContractNo}}</div>
              <div
                v-else
                style="margin-top:17.5px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
              >保单号：未填写</div>
              <div style="margin-top:5px">住宅性质：{{item.dictValue}}</div>
              <div style="margin-top:5px">阶段：{{item.projectChnStatus}}</div>
            </el-col>
          </div>
        </el-row>
      </el-col>
      <div
        v-show="mytodoList.rows.length===0"
        style="position: absolute;left: 50%;top: 50%;transform: translate(-50%,67%);"
      >
        <img src="@/assets/imgs/noData.png" width="220" height="171" />
      </div>
    </el-row>
    <el-pagination
      small
      class="page-lucency text-right mt10 control"
      layout="prev, pager, next"
      :page-size="8"
      @current-change="handleCurrentChange"
      :total="mytodoList.total"
      v-show="mytodoList.total!=0"
    ></el-pagination>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "MytodorunList",
  data() {
    return {
      listTotal: 0
    };
  },
  props: {
    mytodoList: {
      type: Object
    },
    taskType: {
      type: String
    }
  },
  mounted() {
    this.$EventBus.$on("QUERY_EVENT", () => {
      this.mytodoList.total = 0;
    });
  },

  computed: {
    ...mapGetters(["fuzzyQuery", "screen"]),
    mc_data() {
      switch (this.taskType) {
        case "underWrite":
          return "date1";
        case "startRiskPlan":
          return "date2";
        case "insuranceReview":
          return "date3";
      }
    },
    mc_data_color() {
      switch (this.taskType) {
        case "underWrite":
          return { color: "#7eafed", lineHeight: "20px" };
        case "startRiskPlan":
          return { color: "#F8C184", lineHeight: "20px" };
        case "insuranceReview":
          return { color: "#65D8C5", lineHeight: "20px" };
      }
    },
    mc_date_color() {
      switch (this.taskType) {
        case "underWrite":
          return { color: "#7eafed", lineHeight: "14px" };
        case "startRiskPlan":
          return { color: "#F8C184", lineHeight: "14px" };
        case "insuranceReview":
          return { color: "#65D8C5", lineHeight: "14px" };
      }
    }
  },

  methods: {
    ...mapActions(["riskTodoRun"]),
    handleCurrentChange(val) {
      this.getmytodo(val, this.fuzzyQuery.value);
    },
    //返回待办首页
    backMytodo() {
      this.$emit("backMytodo", "2222");
    },
    //展示大表单
    goForm(flag, item) {
      this.$emit("goForm", flag, item);
    },
    async getmytodo(val, fuzzyQuery) {
      const keywords = {
        taskName: this.taskType,
        offset: val,
        limit: 8,
        fuzzyQuery: fuzzyQuery,
        beginSignDate: this.screen.beginSignDate,
        buildingType: this.screen.buildingType,
        city: this.screen.city,
        district: this.screen.district,
        endSignDate: this.screen.endSignDate,
        insContractNo: this.screen.insContractNo,
        isMainIns: this.screen.isMainIns,
        maxCostPerMeter: this.screen.maxCostPerMeter,
        minCostPerMeter: this.screen.minCostPerMeter,
        orgId: this.screen.orgId,
        projectName: this.screen.projectName,
        province: this.screen.province
      };
      this.$store.dispatch("loading", true);
      this.riskTodoRun(keywords).then(() => {
        this.$store.dispatch("loading", false);
      });
    }
  }
};
</script>
<style scoped lang="scss">
.content_list {
  padding: 31.5px 43.5px;
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  height: 430px;
}
.case {
  background: rgba(255, 255, 255, 0.6);
  box-shadow: 0px 5px 4px 0px rgba(0, 0, 0, 0.28);
}
.days {
  color: #7eafed;
  font-size: 29px;
  font-weight: bold;
  margin-left: -10px;
  line-height: 24px;
}
.year {
  font-size: 9px;
  line-height: 16px;
}
.title {
  color: #fff;
}

.leftContent span {
  color: #fff;
  line-height: 22px;
  font-weight: bold;
}
.date {
  height: 102px;
  margin-top: 25px;
  background-repeat: no-repeat;
  background-size: 90% 62%;
}
.date1 {
  background-image: url(../../assets/imgs/todo/todo1.png);
}
.date2 {
  background-image: url(../../assets/imgs/todo/todo2.png);
}
.date3 {
  background-image: url(../../assets/imgs/todo/todo3.png);
}
.rightContent {
  text-align: left;
  font-size: 9px;
  font-weight: bold;
}
.rightContent p {
  font-weight: bold;
  font-size: 11px;
  margin-top: 18px;
}
.control {
  position: absolute;
  bottom: 30px;
  right: 30px;
  left: 0;
}
.case_title {
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
.edit_text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
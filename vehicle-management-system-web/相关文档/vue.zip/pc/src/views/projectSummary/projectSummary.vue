<template>
  <div>
    <img :src="birdsNes[$getversionData.control]" class="bg-img" />
    <div class="content" style="padding: 31.5px 43.5px">
      <el-row class="logo-header">
        <span class="float-left">
          <img src="../../assets/imgs/logo.png" class="logo" />
          <span class="company-name">{{$getversionData.city+"IDI 平台"}}</span>
        </span>
      </el-row>
      <component
        :is="item.key"
        v-for="item in allComponents"
        :key="item.key"
        :disabled="true"
        :title="item.title"
        :ref="item.ref"
        :showMyCase="item.showMyCase"
        :taskType="item.taskType"
      ></component>
    </div>
  </div>
</template>

<script>
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //标的信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核--风险管理计划审核--竣工保险审核
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
import ProjectClaims from "@/components/ProjectSummary/ProjectClaims"; //理赔列表
import ProjectReturns from "@/components/ProjectSummary/ProjectReturns"; //项目回访
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import MASbirdsNes from "@/assets/imgs/MASbirdsNest.jpg";
import BJbirdsNes from "@/assets/imgs/birdsNest.jpg";
import SHbirdsNes from "@/assets/imgs/SHbirdsNes.jpg";
import YQbirdsNes from "@/assets/imgs/YQbirdsNest-new.jpg";
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "projectSummary",
  components: {
    BasicInformation: BasicInformation,
    BstablishInformation: BstablishInformation,
    UnderwritingInformation: UnderwritingInformation,
    InsuranceReview: InsuranceReview,
    InsuranceReview1: InsuranceReview,
    RiskPlan: RiskPlan,
    RiskReportList: RiskReportList,
    RiskEventsList: RiskEventsList,
    RiskFinalReport: RiskFinalReport,
    InsuranceCoverage: InsuranceCoverage,
    ProjectReturns: ProjectReturns,
    ProjectClaims: ProjectClaims
    // FlowChart
  },
  data() {
    return {
      allComponents: [
        { key: "BasicInformation", title: "基础信息" },
        {
          key: "BstablishInformation",
          title: "标的信息",
          ref: "basicBstablish",
          showMyCase: "qweqwe"
        },
        {
          key: "UnderwritingInformation",
          title: "承保信息",
          ref: "underwriting",
          showMyCase: "qweqwe"
        },
        {
          key: "InsuranceReview",
          title: "保险审核",
          ref: "insuranceReview",
          taskType: "underwrite"
        },
        { key: "riskPlan", title: "风险检查工作计划", ref: "riskPlan" },
        {
          key: "InsuranceReview1",
          title: "风险管理计划审核",
          taskType: "checkRiskCtrlPlan"
        },
        {
          key: "RiskReportList",
          title: "风险评估报告列表",
          ref: "riskReportList"
        },
        { key: "RiskEventsList", title: "风险事件列表", ref: "riskEventsList" },
        {
          key: "RiskFinalReport",
          title: "风险最终检查报告",
          ref: "riskFinalReport"
        },
        {
          key: "InsuranceCoverage",
          title: "保险责任范围说明书",
          ref: "insuranceCoverage"
        },
        { key: "ProjectReturns", title: "项目回访", ref: "projectReturns" },
        { key: "ProjectClaims", title: "理赔列表", ref: "ProjectClaims" }
      ],
      birdsNes: {
        beijing: BJbirdsNes,
        maanshan: MASbirdsNes,
        shanghai: SHbirdsNes,
        yangquan: YQbirdsNes
      },
      projectId: ""
    };
  },
  mounted() {
    this.hash = this.$route.query.hash;
    http
      .get("/common/HomePage/InsInfoPage", {
        hash: this.hash,
        tenantId: this.$getversionData.lesseeId
      })
      .then(res => {
        console.log(res);
        this.projectId = res.data.projectId;
        const loginForm = {
          userId: res.data.DEFAULT_ACCOUNT_USERNAME,
          password: res.data.DEFAULT_ACCOUNT_PASSWORD,
          tenantId: this.$getversionData.lesseeId,
          loginType: "password",
          loginBase: "API",
          loginCode: "1"
        };
        this.login(loginForm).then(res => {
          if (res && res.code == 0) {
            this.selects();
            this.getOrgId();
            this.getInsOrg(res.data.insOrgId);
            this.$refs.basicBstablish[0].init(this.projectId);
            this.$refs.riskPlan[0].init(this.projectId);
            this.$refs.underwriting[0].init(this.projectId);
            this.$refs.riskReportList[0].getPagination(
              1,
              this.projectId,
              "hasPrama"
            );
            this.$refs.riskEventsList[0].getPagination(
              1,
              this.projectId,
              "hasPrama"
            );
            this.$refs.riskEventsList[0].thisAFlag();//标识组件为外网访问，非本系统内部访问
            this.$refs.riskFinalReport[0].riskFinalReport(this.projectId);
            this.$refs.insuranceCoverage[0].insuranceCoverage(this.projectId);
            this.$refs.insuranceCoverage[0].init(this.projectId);
            this.$refs.insuranceReview[0].insuranceReview({
              projectId: this.projectId,
              taskName: "insertCompleteInfo"
            });
            this.$refs.ProjectClaims[0].projectClaim(this.projectId);
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        });
      });
  },
  methods: {
    ...mapActions(["login", "getInsOrg", "selects", "getOrgId"])
  }
};
</script>
<style scoped lang="scss">
.content {
  font-family: Source Han Sans CN;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #221815;
  width: 1189px;
  margin: 0 auto;
  padding-top: 42px;
  background: rgba(255, 255, 255, 0.9);
}
.bg-img {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.logo-header {
  position: relative;
  top: 0;
  margin-bottom: 40px;
  .company-name {
    color: rgba(0, 0, 0, 1);
    margin-left: 59px;
    font-size: 25px;
    font-weight: bold;
  }
  .logo {
    width: 50px;
    height: 45px;
    position: absolute;
    bottom: -5px;
  }
  .info {
    position: absolute;
    right: 0;
    bottom: 0;
  }
}
</style>

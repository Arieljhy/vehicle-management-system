<template>
  <div>
    <img :src="birdsNes[$getversionData.control]" class="bg-img" />

    <div class="content" style="padding: 31.5px 43.5px">
      <el-row class="logo-header">
        <span class="float-left">
          <img src="../../assets/imgs/logo.png" class="logo" />
          <span class="company-name">{{$getversionData.city+"IDI 平台"}}</span>
        </span>
      </el-row>
      <el-divider class="mc-divider"></el-divider>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">单体信息</span>
      </el-col>
      <el-form
        class="mc-form"
        label-width="137px"
        size="mini"
        label-position="right"
        align="left"
        disabled
      >
        <el-row>
          <el-col :span="8">
            <el-form-item label="单体编号：" prop="unitId">
              <el-input v-model="newMonomer.unitId" text-align="left"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="单体名称：" prop="unitName">
              <el-input v-model="newMonomer.unitName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="总层数：">
              <format-input v-model="newMonomer.totalStories" text-align="left"></format-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="地下层数：">
              <format-input v-model="newMonomer.basementStories" text-align="left"></format-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="竣工后楼栋门牌号：" class="mc-multi-row">
              <el-input v-model="newMonomer.buildingName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="楼栋类别：">
              <el-select v-model="newMonomer.buildingType" clearable style="width: 100%">
                <el-option
                  v-for="item in listBaseData.IDI_BUILDING_TYPES"
                  :key="item.ddId"
                  :label="item.dictValue"
                  :value="item.dictValue"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="土地性质：">
              <el-select v-model="newMonomer.landType" clearable style="width: 100%">
                <el-option
                  v-for="item in listBaseData.IDI_BUILDING_NATURE"
                  :key="item.ddId"
                  :label="item.dictValue"
                  :value="item.dictValue"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="结构类型：">
              <el-select v-model="newMonomer.structureType" clearable style="width: 100%">
                <el-option
                  v-for="item in listBaseData.IDI_BUILDING_FWORK"
                  :key="item.ddId"
                  :label="item.dictValue"
                  :value="item.dictValue"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="开工日期：">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                @change="validData(newMonomer.conStartDate, newMonomer.conCompleteDate)"
                v-model="newMonomer.conStartDate"
                value-format="yyyy-MM-dd HH:mm:ss"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="竣工日期：">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                @change="validData(newMonomer.conStartDate, newMonomer.conCompleteDate)"
                v-model="newMonomer.conCompleteDate"
                value-format="yyyy-MM-dd HH:mm:ss"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="总户数：">
              <format-input v-model="newMonomer.totalUnits" text-align="left"></format-input>
            </el-form-item>
          </el-col>
          <el-col :span="22">
            <el-form-item label="商业用房、车棚 层、住宅层分布：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                maxlength="512"
                show-word-limit
                v-model="newMonomer.floorDistribution"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="22">
            <el-form-item label="基础信息：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                maxlength="512"
                show-word-limit
                v-model="newMonomer.basicDesc"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="22">
            <el-form-item label="其他情况：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                maxlength="512"
                show-word-limit
                v-model="newMonomer.otherDesc"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <component
        :is="item.key"
        v-for="item in allComponents"
        :key="item.key"
        :disabled="true"
        :title="item.title"
        :ref="item.ref"
        :showMyCase="item.showMyCase"
        :taskType="item.taskType"
      ></component>
    </div>
  </div>
</template>

<script>
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import ProjectClaims from "@/components/ProjectSummary/ProjectClaims"; //理赔列表
import MASbirdsNes from "@/assets/imgs/MASbirdsNest.jpg";
import BJbirdsNes from "@/assets/imgs/birdsNest.jpg";
import SHbirdsNes from "@/assets/imgs/SHbirdsNes.jpg";
import YQbirdsNes from "@/assets/imgs/YQbirdsNest-new.jpg";
import http from "@/common/request";
import formatInput from "@/components/formatInput";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "projectSummary",
  components: {
    RiskEventsList: RiskEventsList,
    ProjectClaims: ProjectClaims,
    formatInput
  },
  data() {
    return {
      allComponents: [
        { key: "RiskEventsList", title: "风险事件列表", ref: "riskEventsList" },
        { key: "ProjectClaims", title: "理赔列表", ref: "ProjectClaims" }
      ],
      birdsNes: {
        beijing: BJbirdsNes,
        maanshan: MASbirdsNes,
        shanghai: SHbirdsNes,
        yangquan: YQbirdsNes
      },
      projectId: "",
      newMonomer: {},
      listBaseData: []
    };
  },
  mounted() {
    console.log(this.$route.query.projectId);
    this.hash = this.$route.query.hash;
    this.dtbh = this.$route.query.singloNum;
    http
      .get("/common/HomePage/InsInfoPage", {
        hash: this.hash,
        tenantId: this.$getversionData.lesseeId
      })
      .then(res => {
        console.log(res);
        this.projectId = res.data.projectId;

        const loginForm = {
          userId: res.data.DEFAULT_ACCOUNT_USERNAME,
          password: res.data.DEFAULT_ACCOUNT_PASSWORD,
          tenantId: this.$getversionData.lesseeId,
          loginType: "password",
          loginBase: "API",
          loginCode: "1"
        };
        this.login(loginForm).then(res => {
          if (res && res.code == 0) {
            this.selects()
            this.getOrgId();
            this.getInsOrg(res.data.insOrgId);
            http
              .get("/project/PrjSingleUnits/getDtxx", {
                dtbh: this.dtbh,
                projectId: this.projectId
              })
              .then(res => {
                this.newMonomer = res.data;
              });
            this.$refs.riskEventsList[0].getPagination(
              1,
              this.projectId,
              "hasPrama",
              this.dtbh
            );
            this.$refs.riskEventsList[0].thisAFlag();//标识组件为外网访问，非本系统内部访问
            this.$refs.ProjectClaims[0].projectClaim(this.projectId,1,this.dtbh);
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        });
      });
  },
  methods: {
    ...mapActions(["login", "getInsOrg","selects",'getOrgId'])
  }
};
</script>
<style scoped lang="scss">
.content {
  font-family: Source Han Sans CN;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #221815;
  width: 1189px;
  margin: 0 auto;
  padding-top: 42px;
  background: rgba(255, 255, 255, 0.9);
}
.bg-img {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}
.logo-header {
  position: relative;
  top: 0;
  margin-bottom: 40px;
  .company-name {
    color: #fff;
    margin-left: 59px;
    font-size: 25px;
    font-weight: bold;
  }
  .logo {
    width: 50px;
    height: 45px;
    position: absolute;
    bottom: -5px;
  }
  .info {
    position: absolute;
    right: 0;
    bottom: 0;
  }
}
</style>

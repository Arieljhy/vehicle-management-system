<template>
<div>
  <el-row class="content-wrapper">
    <el-col :span="4">
      <el-table
        class="mc-table"
        @current-change="handleCurrentChange"
        highlight-current-row
        height="495px"
        tooltip-effect="light"
        :data="orgList"
        row-key="id"
        :tree-props="{children: 'childrens', hasChildren: 'hasChildren'}"
      >
        <el-table-column label="名称" prop="orgName" />
        <el-table-column width="56" align="center">
          <!-- <template slot="header">
            <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
              <i
                class="el-icon-circle-plus-outline"
                style="color:#fff;"
                @click="$router.push({name:'userManageInfo'})"
              ></i>
            </span>
          </template>-->
          <!-- <template slot-scope="scope">
            <el-dropdown @command="()=>{handleCommand(command,scope.row)}" placement="bottom">
              <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
                <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="add">
                  <i class="el-icon-circle-plus-outline iconBlue"></i>新增
                </el-dropdown-item>
                <el-dropdown-item command="delete">
                  <i class="el-icon-remove-outline iconBlue"></i>删除
                </el-dropdown-item>
                <el-dropdown-item command="update">
                  <i class="el-icon-edit-outline iconBlue"></i>修改
                </el-dropdown-item>
                <el-dropdown-item command="show">
                  <i class="el-icon-view iconBlue"></i>详情
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>-->
        </el-table-column>
      </el-table>
    </el-col>
    <el-col :span="12" class="user-left">
      <el-table highlight-current-row @row-click="editClick" :data="userList" class="mc-table" height="495">
        <el-table-column label="序号" align="center" :show-overflow-tooltip="true">
          <template slot-scope="scope">{{scope.$index}}</template>
        </el-table-column>
        <!-- <el-table-column label="租户ID" prop="tenantId" align="center" :show-overflow-tooltip="true" /> -->
        <el-table-column label="角色名称" prop="roleName" align="center" :show-overflow-tooltip="true" />
        <!-- <el-table-column label="备注" prop="remark" align="center" :show-overflow-tooltip="true" /> -->
        <el-table-column width="80">
          <!-- <template slot-scope="scope" width="80">报错信息为scope没有使用所以注掉了 -->
              <!-- <el-button @click="editClick(scope.row)" type="text" size="small">编辑</el-button> -->



            <!-- <el-dropdown
              @command="(command)=>{handleCommand(command,scope.row)}"
              placement="bottom"
            >
              <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
                <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="delete">
                  <i class="el-icon-remove-outline iconBlue"></i>删除
                </el-dropdown-item>
                <el-dropdown-item command="update">
                  <i class="el-icon-edit-outline iconBlue"></i>修改
                </el-dropdown-item>
                <el-dropdown-item command="show">
                  <i class="el-icon-view iconBlue"></i>详情
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown> -->
          <!-- </template> -->
        </el-table-column>
      </el-table>
      <el-pagination
        small
        class="page-lucency page-right"
        layout="prev,pager,next"
        :total="pagination.total"
        :currentPage="pagination.currentPage"
        @current-change="handlePageChange"
        :page-size="pagination.pageSize"
      ></el-pagination>
      <img
        v-if="currentRow.orgId&&(currentRow.orgPid!=='root'||currentRow.orgName === '业主'||currentRow.orgName==='运营方')"
        class="project-collection mouse-pointer"
        id="addAccount"
        draggable="true"
        src="@/assets/imgs/addForm.png"
        width="64"
        height="64"
        @click="$router.push({ name: 'userManageInfo',query:{tenantId:currentRow.tenantId,orgType:currentRow.orgType,insOrgId:currentRow.orgId} });"
      />
    </el-col>
    <el-col :span="8">
      <div class="menu-permissions">菜单权限 
        <el-button style="margin-left: 192px;" v-if="menuCurrent=='1'" type="primary" size="mini" @click="edit">编辑</el-button> 
        <el-button style="margin-left: 192px;" v-else type="primary" size="mini" @click="saveClick">保存</el-button>
      </div>
      <!-- <el-button type="primary" size="mini" @click="editClick">编辑</el-button>
      <el-button type="primary" size="mini" @click="saveClick">保存</el-button> -->
      <el-form ref="withdrawForm" label-width="90px" class="remark-margin">
        <el-form-item label="" prop="remark">
           <el-tree
           class="tree-border"
           style="background-color: rgba(255, 255, 255, 0.5);overflow-y: auto;scroll-behavior: smooth;height: 390px;"
            :data="treeData"
            show-checkbox
            node-key="id"
            ref="tree"
            :disabled="flag"
            :props="defaultProps"
            >
            </el-tree>
        </el-form-item>
    </el-form>     
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="treeSave">确定</el-button>
        <el-button size="small" @click="treeDialog = false">关闭</el-button>
      </span>
    </el-col>
  </el-row>
    <!-- 树形结构框 -->
    <!-- <el-dialog
      title="角色修改"
      :visible.sync="treeDialog"
      width="30%"
      class="dialog"
      :close-on-click-modal="false"
    >
    <el-form ref="withdrawForm" label-width="90px">
        <el-form-item label="菜单权限：" prop="remark">
           <el-tree
            :data="treeData"
            show-checkbox
            node-key="id"
            ref="tree"
            :props="defaultProps"
            >
            </el-tree>
        </el-form-item>
    </el-form>     
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="treeSave">确定</el-button>
        <el-button size="small" @click="treeDialog = false">关闭</el-button>
      </span>
    </el-dialog> -->
  </div>
</template>
<script>
export default {
  data() {
    return {
      menuCurrent:'1',//编辑按钮与保存按钮切换
      flag:true,
      treeData:[{
          id:1,
          label:'一级1',
          children:[{
              id:4,
              label:'二级1-1',
              children:[{
                  id:9,
                  label:'三级1-1-1'
              },{
                  id:10,
                  label:'三级1-1-2'
              }]
          }]
      },{
          id:2,
          label:'一级2',
          children:[{
              id:5,
              label:'二级2-1'
          },{
              id:6,
              label:'二级2-2'
          }]
      },{
          id:3,
          label:'一级3',
          children:[{
              id:7,
              label:'二级3-1'
          },{
              id:8,
              label:'二级3-2'
          }]
      }],
      defaultProps:{
        //   children:'children',
          label:'text'
      },
      orgList: [],
      userList: [],
      newRoleId:'',
      treeDialog:false,
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      },
      currentRow: {}
    };
  },
  created() {
    this.handleQuery();
  },
  mounted() {
    this.$doScrollStyle();
  },
  methods: {
    edit(){
      this.menuCurrent = '2'
      this.getDisabledList(this.treeData)
      var treeList = JSON.parse(JSON.stringify(this.treeData))
      this.treeData = []
      this.treeData = treeList
    },
    saveClick(){
      this.menuCurrent = '1'
      this.getDisabledList(this.treeData)
      this.treeSave()
    },
      getCheckList(arr,result) {
          arr.forEach(item=>{
              if(item.checked){
                  result.push(item.id)
              }
              if(item.children instanceof Array){
                  this.getCheckList(item.children,result)
              }
          })
          return result
      },
      //获取disabled的方法
      getDisabledList(arr) {
          arr.forEach(item=>{ 
            if(this.menuCurrent == 2){
              item.disabled = false
            }else{
              item.disabled = true
            }
              if(item.children instanceof Array){
                  this.getDisabledList(item.children)
              }
          })
          
      },
    //   编辑isTenantId:'',isRoleId:'',
   async editClick(row){
      this.treeDialog = true;
      this.newRoleId = row.roleId
     await this.$api.getRoleTree2({
        tenantId:row.tenantId,
        roleId:row.roleId
      }).then(res=>{
          this.treeData = res.children;
          this.getDisabledList(this.treeData)
          this.checkedList = this.getCheckList(res.children,[])
          this.$refs.tree && this.$refs.tree.setCheckedKeys(this.checkedList,false)
      });
    //   if (code === 0) {
    //     this.generateId(data, tenantId);
    //     this.$set(this.orgList[index], "childrens", data);
    //   } else {
    //     this.$messageError({ message });
    //   }
    },
    // 树形结构确定
   async treeSave(){
      this.treeDialog = false;
      // var menuIdsArr=this.$refs.tree.getCheckedNodes(false,true).map(item=>item.id)
      var menuId=this.$refs.tree.getCheckedNodes()
      var treeId=this.$refs.tree.getHalfCheckedKeys()
      var menuIdsArr = []
      menuId.map(item=>{
        menuIdsArr.push(item.id)
      })
      treeId.map(item=>{
        menuIdsArr.push(item)
      })
      const { code, msg } = await this.$api.addRoleMenu({
        roleId:this.newRoleId,
        menuIds:menuIdsArr
      });
      if (code === 0) {
        this.$messageSuccess({message:msg});
        this.handleQuery()
      } else {
        this.$messageError({ message:msg });
      }
    },
    // async handleCommand(command, row) {
    //   const { userId,tenantId} = row;
    //   switch (command) {
    //     case "delete": {
    //       this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
    //         confirmButtonText: "确定",
    //         cancelButtonText: "取消",
    //         type: "warning"
    //       })
    //         .then(async () => {
    //           const { code, msg: message } = await this.$api.manageRemoveUser({
    //             userId,
    //             tenantId
    //           });
    //           if (code === 0) {
    //             this.$messageSuccess({ message });
    //             this.handleUserQuery();
    //           } else {
    //             this.$messageError({ message });
    //           }
    //         })
    //         .catch(() => {
    //           this.$message({
    //             type: "info",
    //             message: "已取消删除"
    //           });
    //         });
    //       break;
    //     }
    //     case "update": {
    //       const { tenantId, orgType, orgId } = this.currentRow;
    //       this.$router.push({
    //         name: "userManageInfo",
    //         query: {
    //           tenantId,
    //           orgType,
    //           insOrgId: orgId,
    //           userId
    //         }
    //       });
    //       break;
    //     }
    //     case "show": {
    //       const { tenantId, orgType, orgId } = this.currentRow;
    //       this.$router.push({
    //         name: "userManageInfo",
    //         query: {
    //           tenantId,
    //           orgType,
    //           insOrgId: orgId,
    //           userId,
    //           read: true
    //         }
    //       });
    //       break;
    //     }
    //   }
    // },
    async handleQuery() {
      this.$store.dispatch("loading", true);
      //查询全部租户，带分页
      const {
        code,
        data: { rows, total },
        msg
      } = await this.$api.rolePermissionList({ offset: 1, limit: 100 });
      if (code === 0) {
        rows.forEach((item, index) => {
          item.orgName = item.appChnName;
        //   this.queryOrgList(item.tenantId, index);
        });
        this.orgList = rows;
        if (total > 0) {
          // alert('jinlaile')
          this.currentRow = rows[0];
          this.handleUserQuery();
        }
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    //遍历生成主键
    generateId(data, tenantId) {
      data.forEach(item => {
        item.tenantId = tenantId;
        item.id = `${tenantId}-${item.orgId}`;
        if (item.childrens) {
          this.generateId(item.childrens, tenantId);
        }
      });
    },
    //根据租户查询机构列表
    async queryOrgList(tenantId, index) {
      const { code, data, msg: message } = await this.$api.listOrg({
        tenantId
      });
      if (code === 0) {
        this.generateId(data, tenantId);
        this.$set(this.orgList[index], "childrens", data);
      } else {
        this.$messageError({ message });
      }
    },
    //根据机构id查询用户列表
    async handleUserQuery() {
      const { pageSize, currentPage } = this.pagination;
      const { tenantId } = this.currentRow;
      //limit,每页有多少条，offset,第几页
      const {
        code,
        msg,
        data: { rows, total }
      } = await this.$api.roleList({ 
        limit: pageSize,
        offset: currentPage,
        tenantId,  
      });
      // var row = {};
      // rows.map((rowsChild)=>{
      //   row = rowsChild;
      // });
      // console.log('这是row',row);
      if (code === 0) {
        this.userList = rows;
        this.editClick(rows[0])
        // this.editClick(row);
        this.pagination.total = total;
      } else {
        this.$messageError({ message: msg });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleUserQuery();
    },
    handleCurrentChange(currentRow) {
      this.currentRow = currentRow;
      this.handleUserQuery();
    }
  }
};
</script>
<style lang="scss" scoped>
.project-collection {
  position: absolute;
  right: 22px;
  bottom: 28px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
.menu-permissions{
  background-color: rgba(16, 143, 235, 0.6);
  height: 39px;
  line-height: 38px;
  font-size: 14px;
  color: #fff;
  // padding-right: 264px;
  // height: 400px;
  // overflow-y: scroll;
}
.tree-border::-webkit-scrollbar{
  width: 10px;
}
.tree-border::-webkit-scrollbar-thumb{
  border-radius: 10px;
  box-shadow:inset 0 0 6px rgba(255, 255, 255, 0.6);//加这行代码的用途是考虑兼容性，否则会有警告提示
  -webkit-box-shadow:inset 0 0 6px rgba(255, 255, 255, 0.6);
  background:rgba(255, 255, 255, 0.8);
}
.tree-border::-webkit-scrollbar-track{
  border-radius: 0;
  box-shadow:inset 0 0 6px rgba(255, 255, 255, 0.6);//加这行代码的用途是考虑兼容性，否则会有警告提示
  -webkit-box-shadow:inset 0 0 6px rgba(255, 255, 255, 0.6);
  background:rgba(0,0,0,0.1);
}
.user-left{
  // border-right: 1px solid rgba(4, 0, 0, 0.61);
  box-shadow: 0px 5px 13px 0px rgba(4, 0, 0, 0.61);
  border-radius: 0px 0px 0px 6px;
}
</style>
<template>
  <div class="content">
    <el-row>
      <el-col :span="2" class="goback">
        <div
          @click="$router.replace({name:'tenantManageSetting',query:{tenantId:params.tenantId}})"
        >
          <i class="el-icon-arrow-left"></i>
          <span>租户设置</span>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
      </el-col>
    </el-row>
    <el-row>
      <el-form
        ref="baseData"
        :model="baseData"
        :rules="rules"
        class="mc-form"
        size="mini"
        label-width="148px"
        label-position="left"
        align="left"
      >
        <el-col :span="8">
          <el-form-item label="主键" prop="ddId">
            <el-input size="mini" :disabled="!!params.ddId" v-model="baseData.ddId" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="dict_key">
            <el-input size="mini" :disabled="params.read" v-model="baseData.dictKey" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="dict_value">
            <el-input size="mini" :disabled="params.read" v-model="baseData.dictValue" />
          </el-form-item>
        </el-col>
      </el-form>
    </el-row>
    <!-- style="position:absolute;bottom:63.5px;right:205px" -->
    <div style="position:absolute;bottom:63.5px;right:34.5px;width:100%;padding-right: 60px;">
      <el-row>
        <el-col :offset="16" :span="8" class="text-right">
          <el-button
            v-if="!params.read"
            size="mini"
            type="primary"
            style="background-color: #108FEB"
            @click="handleSave"
          >确定</el-button>
          <el-button
            size="mini"
            @click="$router.replace({name:'tenantManageSetting',query:{tenantId:params.tenantId}})"
          >关闭</el-button>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data: () => {
    return {
      baseData: {
        dictKey: "",
        dictValue: ""
      },
      rules: {
        ddId: [{ required: true, message: "请输入主键" }]
      }
    };
  },
  created() {
    this.handleQuery();
  },
  computed: {
    params() {
      const { tenantId, dictId, ddId, read } = this.$route.query;
      return { tenantId, dictId, ddId, read: read === "true" };
    }
  },
  methods: {
    async handleQuery() {
      if (this.params.ddId) {
        const { code, msg, data } = await this.$api.baseSubDataInfo({
          tenantId: this.params.tenantId,
          ddId: this.params.ddId
        });
        if (code === 0) {
          this.baseData = data;
        } else {
          this.$messageError({ message });
        }
      }
    },
    handleSave() {
      this.$refs.baseData.validate(valid => {
        if (valid) {
          this.doSave();
        }
      });
    },
    async doSave() {
      const { tenantId, ddId, dictId } = this.params;
      if (ddId) {
        const { code, msg: message } = await this.$api.updateBaseSubData({
          ...this.baseData,
          tenantId,
          dictId
        });
        if (code === 0) {
          this.$messageSuccess({ message });
          this.$router.replace({
            name: "tenantManageSetting",
            query: { tenantId }
          });
        } else {
          this.$messageError({ message });
        }
      } else {
        const { code, msg: message } = await this.$api.saveBaseSubData({
          ...this.baseData,
          tenantId,
          dictId
        });
        if (code === 0) {
          this.$messageSuccess({ message });
          this.$router.replace({
            name: "tenantManageSetting",
            query: { tenantId }
          });
        } else {
          this.$messageError({ message });
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.content {
  position: relative;
  padding: 0 34.5px;
  min-height: 495px;
  background-color: rgba(255, 255, 255, 0.5);
}
/deep/ .el-form-item__label {
  font-weight: 500;
}
/deep/ .el-form-item__content {
  .el-icon-view {
    display: none;
  }
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>
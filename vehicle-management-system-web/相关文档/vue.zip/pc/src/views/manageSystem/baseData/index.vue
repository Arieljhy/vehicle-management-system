<template>
  <el-row class="content-wrapper">
    <el-col :span="8" class="content-wrapper-left">
      <el-table
        highlight-current-row
        @current-change="handleCurrentChange"
        :data="parentTableData"
        class="mc-table"
        height="495px"
        max-height="495px"
      >
        <el-table-column prop="dictName" label="名称" width="120" :show-overflow-tooltip="true" />
        <el-table-column prop="dictDesc" label="描述" :show-overflow-tooltip="true" />
        <el-table-column width="56" align="center">
          <template slot="header">
            <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
              <i
                class="el-icon-circle-plus-outline"
                style="color:#fff;"
                @click="$router.push({name:'baseParentDataInfo',query:{tenantId}})"
              ></i>
            </span>
          </template>
          <template slot-scope="scope">
            <el-dropdown
              @command="(command)=>handleParentCommand(command,scope.row)"
              placement="bottom"
            >
              <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
                <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="delete">
                  <i class="el-icon-remove-outline iconBlue"></i>删除
                </el-dropdown-item>

                <el-dropdown-item command="update">
                  <i class="el-icon-edit-outline iconBlue"></i>修改
                </el-dropdown-item>
                <el-dropdown-item command="show">
                  <i class="el-icon-view iconBlue"></i>详情
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
    </el-col>
    <el-col :span="16">
      <el-table :data="subTableData" class="mc-table" height="495px" max-height="495px">
        <el-table-column label="序号" width="80">
          <template slot-scope="scope">{{scope.$index+1}}</template>
        </el-table-column>
        <el-table-column label="dict_key" prop="dictKey" />
        <el-table-column label="dict_value" prop="dictValue" />
        <el-table-column label="更新日期" prop="updateDate" width="150" />
        <el-table-column width="100">
          <template slot-scope="scope">
            <el-dropdown
              @command="(command)=>handleSubCommand(command,scope.row)"
              placement="bottom"
            >
              <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
                <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="delete">
                  <i class="el-icon-remove-outline iconBlue"></i>删除
                </el-dropdown-item>
                <el-dropdown-item command="update">
                  <i class="el-icon-edit-outline iconBlue"></i>修改
                </el-dropdown-item>
                <el-dropdown-item command="show">
                  <i class="el-icon-view iconBlue"></i>详情
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
    </el-col>
    <el-pagination
      small
      class="page-lucency page-right"
      layout="prev,pager,next"
      :total="pagination.total"
      :currentPage="pagination.currentPage"
      :page-size="pagination.pageSize"
    ></el-pagination>
    <img
      class="project-collection mouse-pointer"
      id="addAccount"
      draggable="true"
      src="@/assets/imgs/addForm.png"
      width="64"
      height="64"
      @click="$router.push({ name: 'baseDataInfo',query:{tenantId,dictId:currentRow.dictId} });"
    />
  </el-row>
</template>
<script>
export default {
  props: {
    tenantId: {
      type: String
    }
  },
  data() {
    return {
      parentTableData: [],
      subTableData: [],
      currentRow: null,
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      }
    };
  },
  methods: {
    async handleQuery() {
      const {
        code,
        data: { rows, total },
        msg
      } = await this.$api.baseParentData({
        offset: 1,
        limit: 50,
        tenantId: this.tenantId
      });
      if (code === 0) {
        this.parentTableData = rows;
        if (rows && rows.length > 0) {
          this.currentRow = rows[0];
          this.handleSubQuery();
        }
      } else {
        this.$messageError({ message: msg });
      }
    },
    async handleSubQuery() {
      const {
        code,
        data: { rows: subData, total: subTotal },
        msg
      } = await this.$api.baseSubData({
        tenantId: this.tenantId,
        dictId: this.currentRow.dictId
      });
      if (code === 0) {
        this.subTableData = subData;
      } else {
        this.$messageError({ message: msg });
      }
    },
    async handleParentCommand(command, row) {
      switch (command) {
        case "delete": {
          const { code, msg: message } = await this.$api.removeBaseParentData({
            tenantId: this.tenantId,
            dictId: row.dictId
          });
          if (code === 0) {
            this.$messageSuccess({ message });
            this.handleQuery();
          } else {
            this.$messageError({ message });
          }
          break;
        }
        case "update": {
          this.$router.push({
            name: "baseParentDataInfo",
            query: { tenantId: this.tenantId, dictId: row.dictId }
          });
          break;
        }
        case "show": {
          this.$router.push({
            name: "baseParentDataInfo",
            query: { tenantId: this.tenantId, dictId: row.dictId, read: true }
          });
          break;
        }
      }
    },
    async handleSubCommand(command, row) {
      switch (command) {
        case "delete": {
          const { code, msg: message } = await this.$api.removeSubDataInfo({
            tenantId: this.tenantId,
            ddId: row.ddId
          });
          if (code === 0) {
            this.$messageSuccess({ message });
            this.handleQuery();
          } else {
            this.$messageError({ message });
          }
          break;
        }
        case "update": {
          this.$router.push({
            name: "baseDataInfo",
            query: {
              tenantId: this.tenantId,
              dictId: this.currentRow.dictId,
              ddId: row.ddId
            }
          });
          break;
        }
        case "show": {
          this.$router.push({
            name: "baseDataInfo",
            query: {
              tenantId: this.tenantId,
              dictId: this.currentRow.dictId,
              ddId: row.ddId,
              read: true
            }
          });
          break;
        }
      }
    },
    handleCurrentChange(currentRow) {
      this.currentRow = currentRow;
      this.handleSubQuery();
    }
  },
  created() {
    this.handleQuery();
  },
  mounted() {
    this.$doScrollStyle();
  }
};
</script>
<style lang="scss" scoped>
.project-collection {
  position: absolute;
  right: 22px;
  bottom: 28px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
</style>
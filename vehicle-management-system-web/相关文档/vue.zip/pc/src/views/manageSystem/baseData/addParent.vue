<template>
  <div class="content">
    <el-row>
      <el-col :span="2" class="goback">
        <div
          @click="$router.replace({name:'tenantManageSetting',query:{tenantId:params.tenantId}})"
        >
          <i class="el-icon-arrow-left"></i>
          <span>租户设置</span>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
      </el-col>
    </el-row>
    {{params.read}}
    <el-form
      ref="baseData"
      :model="baseData"
      class="mc-form"
      label-width="120px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="主键">
            <el-input size="mini" :disabled="!!params.dictId" v-model="baseData.dictId" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="名称">
            <el-input size="mini" :disabled="params.read" v-model="baseData.dictName" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-form-item label="描述">
          <el-input
            type="textarea"
            :autosize="{minRows: 2.5}"
            :disabled="params.read"
            placeholder="请输入内容"
            v-model="baseData.dictDesc"
          ></el-input>
        </el-form-item>
      </el-row>
    </el-form>
    <!-- style="position:absolute;bottom:63.5px;right:205px" -->
    <div style="position:absolute;bottom:63.5px;right:34.5px;width:100%;padding-right: 60px;">
      <el-row>
        <el-col :offset="16" :span="8" class="text-right">
          <el-button
            v-if="!params.read"
            size="mini"
            type="primary"
            style="background-color: #108FEB"
            @click="handleSave"
          >确定</el-button>
          <el-button
            size="mini"
            @click="$router.replace({name:'tenantManageSetting',query:{tenantId:params.tenantId}});"
          >关闭</el-button>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data: () => {
    return {
      baseData: {}
    };
  },
  created() {
    this.handleQuery();
  },
  computed: {
    params() {
      const { read, tenantId, dictId } = this.$route.query;
      return { read, tenantId, dictId };
    }
  },
  methods: {
    async handleQuery() {
      const { tenantId, dictId } = this.params;
      if (dictId) {
        const { code, msg, data } = await this.$api.baseParentDataInfo({
          tenantId,
          dictId
        });
        if (code === 0) {
          this.baseData = data;
        } else {
          this.$messageError({ message });
        }
      }
    },
    handleSave() {
      this.$refs.baseData.validate(valid => {
        if (valid) {
          this.doSave();
        }
      });
    },
    async doSave() {
      const { tenantId, dictId } = this.params;
      if (dictId) {
        const { code, msg: message } = await this.$api.updateBaseParentData({
          ...this.baseData,
          tenantId
        });
        if (code === 0) {
          this.$messageSuccess({ message });
          this.$router.replace({
            name: "tenantManageSetting",
            query: { tenantId }
          });
        } else {
          this.$messageError({ message });
        }
      } else {
        const { code, msg: message } = await this.$api.saveBaseParentData({
          ...this.baseData,
          tenantId
        });
        if (code === 0) {
          this.$messageSuccess({ message });
          this.$router.replace({
            name: "tenantManageSetting",
            query: { tenantId }
          });
        } else {
          this.$messageError({ message });
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.content {
  position: relative;
  padding: 0 34.5px;
  min-height: 495px;
  background-color: rgba(255, 255, 255, 0.5);
}
/deep/ .el-form-item__label {
  font-weight: 500;
}
/deep/ .el-form-item__content {
  .el-icon-view {
    display: none;
  }
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>
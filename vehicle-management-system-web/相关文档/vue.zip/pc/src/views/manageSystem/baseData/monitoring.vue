<template>
  <div style="position: relative">
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'monitoring' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
    <el-row v-show="showMyCase==='monitoring'">
      <el-col :span="8">
        <div class="content">
          <span
            class="el-icon-edit-outline mouse-pointer"
            @click="selectEchart1()"
            style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
          >自定义</span>
          <chart ref="chart"></chart>
        </div>
        <div class="content">
          <span
            class="el-icon-edit-outline mouse-pointer"
            @click="selectEchart2()"
            style="position: absolute;right: 32px;top: 20px;color:#297AE3;z-index:999"
          >自定义</span>
          <chart ref="chartLine"></chart>
        </div>
      </el-col>
      <el-col :span="5" style="width:275px;margin:0 7px">
        <div class="content">
          <el-row class="centTop">
            <el-col
              :span="12"
              :offset="12"
              style="margin-top:15px;border-left:1px rgba(255, 255, 255, 0.22) solid"
            >
              <div style="margin:0 10px">
                <span style="color:rgba(236,238,242,1);font-size:13px">保费总收益</span>
                <br />
                <span style="color:RGBA(33, 176, 243, 1);font-size:17px">1,543.03元</span>
              </div>
            </el-col>
            <el-col
              :span="12"
              :offset="12"
              style="margin-top:15px;border-left:1px rgba(255, 255, 255, 0.22) solid"
            >
              <div style="margin:0 10px">
                <span style="color:rgba(236,238,242,1);font-size:13px">总销量</span>
                <br />
                <span style="color:rgba(119, 202, 97, 1);font-size:17px">1,543.03元</span>
              </div>
            </el-col>
          </el-row>
        </div>
        <div class="content">
           <chart ref="chartZZZ"></chart>
        </div>
      </el-col>
      <el-col :span="10">
        <el-row :gutter="7">
          <el-col :span="6">
            <div class="content1">
              <el-col :span="10">
                <img class="picture" src="../../../assets/imgs/zuhu-1.png" alt="人物" />
              </el-col>
              <el-col :span="14">
                <span class="title">用户数</span>
                <span class="Ntitle">520</span>
              </el-col>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="content1">
              <el-col :span="10">
                <img class="picture" src="../../../assets/imgs/zuhu-2.png" alt="人物" />
              </el-col>
              <el-col :span="14">
                <span class="title">访问数</span>
                <span class="Ntitle">1310</span>
              </el-col>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="content1">
              <el-col :span="10">
                <img class="picture" src="../../../assets/imgs/zuhu-3.png" alt="人物" />
              </el-col>
              <el-col :span="14">
                <span class="title">资源占比</span>
                <span class="Ntitle">25.3%</span>
              </el-col>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="content1">
              <el-col :span="10">
                <img class="picture" src="../../../assets/imgs/zuhu-4.png" alt="人物" />
              </el-col>
              <el-col :span="14">
                <span class="title">当前在线</span>
                <span class="Ntitle">25000</span>
              </el-col>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="7">
          <el-col :span="12">
            <div class="content2">
              <el-col>
                <p style="text-align:left;font-weight: bold;margin-left: 15px;">展现方式</p>
              </el-col>
              <el-row style="padding:45px 0">
                <el-col :span="8">
                  <el-progress
                    type="circle"
                    :stroke-width="6"
                    color="#9D60FF"
                    :percentage="65"
                    :width="65"
                  ></el-progress>
                  <div style="font-size:14px;color:#5e5e62">广告</div>
                </el-col>
                <el-col :span="8">
                  <el-progress
                    type="circle"
                    :stroke-width="6"
                    color="#FF960F"
                    :percentage="25"
                    :width="65"
                  ></el-progress>
                  <div style="font-size:14px;color:#5e5e62">资讯</div>
                </el-col>
                <el-col :span="8">
                  <el-progress type="circle" :stroke-width="6" :percentage="40" :width="65"></el-progress>
                  <div style="font-size:14px;color:#5e5e62">视频</div>
                </el-col>
              </el-row>
            </div>
          </el-col>
          <el-col :span="12">
            <div class="content2">111</div>
          </el-col>
        </el-row>
        <el-row>
          <div class="content">sdfsdfsd</div>
        </el-row>
      </el-col>
    </el-row>
     </transition>
    <!-- echart自定义 -->
    <transition
      :duration="4000"
      :enter-active-class="showMyCase == 'mytodoEchartList' ? 'animated zoomInLeft' : 'animated slideInLeft'"
      :leave-active-class="showMyCase == 'monitoring' ? 'animated zoomOutLeft' :'animated slideOutRight'"
    >
      <div v-if="showMyCase==='mytodoEchartList'" style="position: absolute; top: 0;width: 100%;">
        <MytodoEchartList @goForm="goForm" @backMytodo="backMytodo"></MytodoEchartList>
      </div>
    </transition>
  </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex'
import chart from '@/components/charts'
import MytodoEchartList from '@/views/myToDo/myToDoEchartList'
export default {
  name: 'monitoring',
  components: {
    chart,
    MytodoEchartList
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  data() {
    return {
      showMyCase: 'monitoring',
      pie_option: {
        title: {
          text: '',
          x: '10',
          y: '18',
          textStyle: {
            fontSize: '17',
            fontWeight: 'bold',
            fontFamily: 'Source Han Sans CN'
          }
        },
        legend: {
          orient: 'vertical',
          icon: 'circle',
          bottom: '20',
          right: '13',
          align: 'left',
          textStyle: {
            fontSize: 10,
            fontWeight: 'bold'
          },
          itemWidth: 10, //图标宽
          itemHeight: 10, //图标高
          itemGap: 10 //间距
        },
        color: [
          '#C81812',
          '#EFB70C',
          '#9F77FA',
          '#FB5277',
          '#297AE3',
          '#3CD323'
        ],
        series: [
          {
            name: '',
            type: 'pie',
            radius: ['55%', '65%'],
            center: ['35%', '58%'],
            label: {
              normal: {
                show: false,
                position: 'center'
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '20',
                  align: 'center'
                },
                formatter: ['{a| {d}%}', '{b| {b}}'].join('\n'),
                rich: {
                  a: {
                    fontSize: '30',
                    align: 'center',
                    fontWeight: '400'
                  },
                  b: {
                    fontSize: '11',
                    align: 'center',
                    fontWeight: '400',
                    color: '#fff'
                  }
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            labelLine: {
              normal: {
                lineStyle: {
                  color: 'rgba(255, 255, 255, 0.3)'
                },
                smooth: 0.2,
                length: 10,
                length2: 20
              }
            },
            data: []
          }
        ]
      },
      category_option: {
        title: {
          text: '',
          x: '10',
          y: '15',
          textStyle: {
            fontSize: '17',
            fontWeight: 'bold',
            fontFamily: 'Source Han Sans CN'
          }
        },
        tooltip: {
          trigger: 'item',
          formatter: '{c}' //鼠标滑过时候的显示
        },
        xAxis: {
          axisLabel: {
            interval: 0,
            rotate: 30
          },
          type: 'category',
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: [],
            type: 'line'
          }
        ]
      }
    }
  },

  created() {
    this.Echarts()
  },
  methods: {
    ...mapActions([
      'riskManagement',
      'reportManagement',
      'changeRiskPage',
      'setFuzzyQuery'
    ]),
    // echart自定义
    selectEchart1() {
      this.showMyCase = 'mytodoEchartList'
    },
    // echart自定义
    selectEchart2() {
      this.showMyCase = 'mytodoEchartList'
    },
    //返回待办首页
    backMytodo() {
      this.showMyCase = 'monitoring'
    },
    // charts
    async Echarts() {
      const keywords = {
        userId: this.userInfo.userId,
        insOrgId: this.userInfo.insOrgId,
        city:this.$getversionData.city,
        province: this.$getversionData.city
      }
      const { data } = await this.$api.riskecharts(keywords)
      if (data.length) {
        //圆形图
        this.pie_option.title.text = data[1].title
        for (let item of data[1].data) {
          this.pie_option.series[0].data.push({
            name: item.riskLevel,
            value: item.notClolseRiskSeverity
          })
        }
        this.$refs.chart.initChart(this.pie_option)

        // 折线图
        this.category_option.title.text = data[0].title
        for (let i of data[0].data) {
          this.category_option.xAxis.data = [
            ...this.category_option.xAxis.data,
            i.rectifyMounth
          ]
          this.category_option.series[0].data = [
            ...this.category_option.series[0].data,
            i.notClolseRectifyRate
          ]
        }
        this.$refs.chartLine.initChart(this.category_option)
      }
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
.content {
  position: relative;
  height: 240px;
  background: rgba(255, 255, 255, 0.5);
  margin-bottom: 7px;
  border-radius: 5px;
  /deep/ .centTop {
    height: 240px;
    border-radius: 5px;
    text-align: left;
    background: rgba(57, 59, 72, 0.57);
  }
}
.content1 {
  position: relative;
  height: 50px;
  padding: 0 5px;
  background: rgba(255, 255, 255, 0.5);
  margin-bottom: 7px;
  border-radius: 5px;
  .picture {
    width: 30px;
    height: 30px;
    margin: 10px;
  }
  .title {
    font-size: 12px;
    color: #5e5e62;
  }
  .Ntitle {
    font-size: 19px;
    color: #5e5e62;
  }
}
// 进度条的文字
.el-progress /deep/.el-progress__text {
  font-size: 18px !important;
}
.content2 {
  position: relative;
  height: 183px;
  background: rgba(255, 255, 255, 0.5);
  margin-bottom: 7px;
  border-radius: 5px;
}
</style>

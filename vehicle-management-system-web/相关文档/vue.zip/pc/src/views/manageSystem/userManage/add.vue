<template>
  <div class="content">
    <el-row>
      <el-col :span="2" class="goback">
        <div @click="$router.replace({name:'userManageList'})">
          <i class="el-icon-arrow-left"></i>
          <span>用户管理</span>
        </div>
      </el-col>
    </el-row>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-form
      class="mc-form"
      :model="caseDetails"
      ref="userForm"
      :rules="rules"
      label-width="148px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="账号：" prop="userId">
            <el-input
              autocomplete="new-password"
              :disabled="!!params.userId || readThreeFlag"
              v-model="caseDetails.userId"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="密码：" prop="password">
            <input type="password" style="position: absolute;z-index: -999" />
            <el-input
              autocomplete="new-password"
              :disabled="params.read || readThreeFlag"
              @focus="params.userId?caseDetails.password='':()=>{}"
              @blur="handlePassword"
              type="password"
              v-model="caseDetails.password"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="名称：" prop="username">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.username"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="性别：">
            <el-radio-group v-model="caseDetails.sex" :disabled="params.read || readThreeFlag">
              <el-radio :label="1">男</el-radio>
              <el-radio :label="0">女</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="证件号码：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.idCard"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="出生日期：">
            <el-date-picker
              class="date"
              type="date"
              :disabled="params.read || readThreeFlag"
              value-format="yyyy-MM-dd"
              v-model="caseDetails.birth"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="手机号：" prop="mobile">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.mobile" @blur="checkMobile()"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="办公电话：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.telephone"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="邮箱：" prop="email">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.email"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="专业领域：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.professional"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="最高学历：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.educationLevel"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="所学专业：">
            <el-input :disabled="params.read || readThreeFlag" v-model="caseDetails.major"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="角色：" prop="roleId">
            <el-select :disabled="params.read" v-model="caseDetails.roleId">
              <el-option
                v-for="item in roleList"
                :key="item.roleId"
                :label="item.roleName"
                :value="`${item.roleId}`"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="16">
          <el-form-item label="状态：" prop="status">
            <el-radio-group :disabled="params.read" v-model="caseDetails.status">
              <el-radio :label="1">有效</el-radio>
              <el-radio :label="0">无效</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="住宅性质：" prop="listTransHouseProperty">
            <el-checkbox-group :disabled="params.read" v-model="caseDetails.listTransHouseProperty">
              <el-checkbox
                v-for="item in listBaseData"
                :key="item.dictKey"
                :label="item.dictKey"
              >{{item.dictValue}}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="可查看项目区域：">
            <el-table
              class="mc-table district-table"
              tooltip-effect="light"
              :data="caseDetails.listTransArea"
              style="width: 100%;border-radius:2px;"
            >
              <el-table-column prop="province" align="center" label="省">
                <template slot-scope="scope">
                  <span v-if="params.read">{{scope.row.province}}</span>
                  <el-select
                    v-else
                    v-model="scope.row.provinceId"
                    @change="queryCity(scope.row.provinceId,scope.$index)"
                  >
                    <el-option
                      v-for="(item,index) in provinceList"
                      :key="index"
                      :value="item.provinceId"
                      :label="item.province"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="city" align="center" label="市">
                <template slot-scope="scope">
                  <span v-if="params.read">{{scope.row.city}}</span>
                  <el-select
                    v-else
                    v-model="scope.row.cityId"
                    @change="queryDistrict(scope.row.cityId,scope.$index)"
                  >
                    <el-option
                      v-for="(item,index) in scope.row.cityList"
                      :key="index"
                      :value="item.cityId"
                      :label="item.city"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="district" align="center" label="区/县">
                <template slot-scope="scope">
                  <span v-if="params.read">{{scope.row.district}}</span>
                  <el-select v-else v-model="scope.row.districtId">
                    <el-option
                      v-for="row in scope.row.districtList"
                      :key="row.id"
                      :label="row.district"
                      :value="row.originalId"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column v-if="!params.read" prop="district" align="center">
                <template slot="header" solt-scope="scope">
                  <i @click="doRowAdd" class="el-icon-circle-plus-outline"></i>
                </template>
                <template slot-scope="scope">
                  <i @click="doRowDel(scope.$index)" class="el-icon-remove-outline"></i>
                </template>
              </el-table-column>
            </el-table>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="备注：">
            <el-input
              type="textarea"
              :autosize="{minRows: 2.5}"
              :disabled="params.read"
              placeholder="请输入内容"
              v-model="caseDetails.remark"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23" class="text-right" style="padding: 55px 0 22.5px 0">
          <el-button
            v-if="!params.read"
            type="primary"
            style="background-color: #108FEB"
            size="mini"
            @click="handleSave"
          >确定</el-button>
          <el-button size="mini" @click="$router.push({name:'userManageList'})">关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import md5 from "js-md5";
import http from "@/common/request";
export default {
  name: "userManage",
  data() {
    return {
      listBaseData:[],
      caseDetails: {
        listTransHouseProperty: [],
        listTransArea: [],
        userId:'',
        password:'',
        username:'',
        read:'',
        idCard:'',
        birth:'',
        telephone:'',
        email:'',
        professional:'',
        educationLevel:'',
        major:"",
        mobile:''
      },
      readThreeFlag:false,
      roleList: [],
      provinceList: [],
      rules: {
        userId: [{ required: true, message: "请输入账号" }],
        password: [
          {
            required: true,
            message: "请输入至少八位的密码",
            min: 8,
            trigger: "blur"
          }
        ],
        username: [{ required: true, message: "请输入名称" }],
        mobile: [{ required: true, message: "请输入手机号" }],
        email: [{ required: true, message: "请输入邮箱" }],
        status: [{ required: true, message: "请选择状态" }],
        roleId: [{ required: true, message: "请选择角色" }],
        listTransHouseProperty: [{ required: true, message: "请添加可查看项目区域" }]
      }
    };
  },
  props: {
    routePath: {
      type: String,
      required: false,
      default: ""
    }
  },
  computed: {
    params() {
      const { read, tenantId, userId, insOrgId, orgType } = this.$route.query;
      return { read, tenantId, userId, insOrgId, orgType };
    },
  },
  methods: {
    //检测手机号码是否注册过
    checkMobile() {
      if (/^[1]([3-9])[0-9]{9}$/.test(this.caseDetails.mobile)) {
        http
          .get("/sys/user/getUserByMobileGenerator", {
            mobile: this.caseDetails.mobile,
            tenantId:this.$route.query.tenantId
          })
          .then(res => {
            //code=0,号码没有注册过；code=1，号码在本平台已经注册；code=2，号码在其他平台注册过
            if (res.code == 1 && this.$route.query.insOrgId && !this.$route.query.userId) {
              this.caseDetails.mobile = "";
              this.$messageError({ message: res.msg });
            }else if (res.code == 2 && this.$route.query.insOrgId && !this.$route.query.userId) {
              this.$confirm('此手机号已在其他平台注册，是否在本平台创建账号？','提示',{
                confirmButtonText:'',
                cancelButtonText:'',
                type:'warning'
              }).then(()=>{
                this.readThreeFlag = true
                this.caseDetails.userId = res.data.userId
                this.caseDetails.password = res.data.password
                this.caseDetails.username = res.data.username
                this.caseDetails.read = res.data.read
                this.caseDetails.idCard = res.data.idCard
                this.caseDetails.birth = res.data.birth
                this.caseDetails.telephone = res.data.telephone
                this.caseDetails.email = res.data.email
                this.caseDetails.professional = res.data.professional
                this.caseDetails.educationLevel = res.data.educationLevel
                this.caseDetails.major = res.data.major
                this.caseDetails.tenantId = this.$route.query.tenantId
                this.caseDetails.insOrgId = this.$route.query.insOrgId
                this.caseDetails.addFlag = '1'
                 this.$refs.userForm.clearValidate();
              }).catch(()=> {
                this.caseDetails.mobile = "";
                this.caseDetails.addFlag = ''
              })
            }
          });
      }
    },
    handlePassword(val) {
      if (!/^[A-Za-z0-9_]{8,}$/.test(this.caseDetails.password)) {
        this.caseDetails.password = this.oldPassword;
      }
    },
    async handleQuery() {
      const { tenantId, userId } = this.params;
      if (userId) {
        const { code, msg, data } = await this.$api.manageUserInfo({
          tenantId,
          userId
        });
        if (code === 0) {
          this.oldPassword = data.password;
          this.caseDetails = {
            ...data,
            listTransArea: [],
            listTransHouseProperty: []
          };
        } else {
          this.$messageError({ message: msg });
        }
        const {
          code: res,
          msg: message,
          data: { listTransArea, listTransHouseProperty }
        } = await this.$api.findUserTransCode({ tenantId, userId });
        if (res === 0) {
          listTransArea.forEach((item, index) => {
            item.districtId = item.originalId;
            this.queryCity(item.provinceId, index);
            this.queryDistrict(item.cityId, index);
          });
          this.caseDetails.listTransArea = listTransArea;
          this.caseDetails.listTransHouseProperty = listTransHouseProperty.map(
            item => item.transId
          );
        } else {
          this.$messageError({ message });
        }
      }
    },
    async handleSave() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          this.doSaveOrUpdate();
        } else {
          this.$messageError({ message: "请完善信息！" });
        }
      });
    },
    async doSaveOrUpdate() {
      this.$store.dispatch("loading", true);
      const { insOrgId, userId, tenantId } = this.params;
      this.caseDetails.listTransArea = this.caseDetails.listTransArea.map(
        item => {
          let districtObj,
            cityObj,
            provinceObj = null;
          const {
            districtId,
            cityId,
            provinceId,
            cityList,
            districtList
          } = item;
          if (districtId) {
            districtObj = districtList.filter(
              item => item.originalId === districtId
            )[0];
          } else if (cityId) {
            cityObj = cityList.filter(item => item.cityId === cityId)[0];
          } else if (provinceId) {
            provinceObj = this.provinceList.filter(
              item => item.provinceId === provinceId
            )[0];
          }
          return districtId
            ? districtObj
            : cityId
            ? {
                ...cityObj,
                flagId: cityObj.cityId
              }
            : {
                ...provinceObj,
                flagId: provinceObj.provinceId
              };
        }
      );
      if (userId) {
        const { code, msg } = await this.$api.manageUpdateUser({
          ...this.caseDetails,
          listTransHouseProperty: this.caseDetails.listTransHouseProperty.map(
            item => ({ transId: item })
          ),
          ...(this.caseDetails.password !== this.oldPassword && {
            password: md5(this.caseDetails.password)
          })
        });
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.$router.push({ name: "userManageList" });
        } else {
          this.$messageError({ message: msg });
        }
      } else {
        //新增
        const { code, msg } = await this.$api.manageAddUser({
          ...this.caseDetails,
          listTransHouseProperty: this.caseDetails.listTransHouseProperty.map(
            item => ({ transId: item })
          ),
          password: md5(this.caseDetails.password),
          tenantId,
          insOrgId
        });
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          this.$router.push({ name: "userManageList" });
        } else {
          this.$messageError({ message: msg });
        }
      }
      this.$store.dispatch("loading", false);
    },
    async queryRoleList() {
      const data = await this.$api.eidiGetRoleListByTenant({
        tenantId: this.params.tenantId,
        orgType: this.params.orgType
      });
      this.roleList = data;
    },
    async queryProvnice() {
      //查询省
      let { code, msg: message, data } = await this.$api.findTenantAreaProvince(
        {
          tenantId: this.params.tenantId
        }
      );
      if (code === 0) {
        this.provinceList = data;
      } else {
        this.$messageError({ message });
      }
    },
    //查询市
    async queryCity(provinceId, index) {
      let { code, msg: message, data } = await this.$api.findTenantAreaCity({
        provinceId,
        tenantId: this.params.tenantId
      });
      if (code === 0) {
        let temp = {};
        this.$set(
          this.caseDetails.listTransArea[index],
          "cityList",
          data.filter(item => {
            if (!temp[item.cityId]) {
              temp[item.cityId] = item.cityId;
              return true;
            }
          })
        );
      } else {
        this.$messageError({ message });
      }
    },
    //查询区域
    async queryDistrict(cityId, index) {
      let { code, msg: message, data } = await this.$api.findTenantAreaDistrict(
        {
          cityId,
          tenantId: this.params.tenantId
        }
      );
      if (code === 0) {
        this.$set(this.caseDetails.listTransArea[index], "districtList", data);
      } else {
        this.$messageError({ message });
      }
    },
    doRowAdd(scope) {
      this.caseDetails.listTransArea.push({});
    },
    doRowDel(curIndex) {
      const ind = this.caseDetails.listTransArea.findIndex(
        (item, index) => index === curIndex
      );
      this.caseDetails.listTransArea.splice(ind, 1);
    },
   //字典  
   async baseSubData(){
     const res=await this.$api.baseSubData({
        tenantId: this.params.tenantId,
        dictId: 'IDI_PROJECT_TYPES'
      })
     this.listBaseData=res.data.rows
   }
  },
  async created() {
    this.handleQuery();
    this.queryProvnice();
    this.queryRoleList();
    this.baseSubData()
  }
};
</script>
<style scoped lang="scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.5);
  .district-table {
    font-size: 12.5px;
  }
}
/deep/ .el-form-item__label {
  font-weight: 500;
}
/deep/ .el-form-item__content {
  .el-icon-view {
    display: none;
  }
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>
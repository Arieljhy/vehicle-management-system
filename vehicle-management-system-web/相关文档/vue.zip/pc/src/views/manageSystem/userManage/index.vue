<template>
  <el-row class="content-wrapper">
    <el-col :span="8" class="content-wrapper-left">
      <el-table
        class="mc-table"
        @current-change="handleCurrentChange"
        highlight-current-row
        height="495px"
        tooltip-effect="light"
        :data="orgList"
        row-key="id"
        :tree-props="{children: 'childrens', hasChildren: 'hasChildren'}"
      >
        <el-table-column label="名称" prop="orgName" />
        <el-table-column width="56" align="center">
          <!-- <template slot="header">
            <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
              <i
                class="el-icon-circle-plus-outline"
                style="color:#fff;"
                @click="$router.push({name:'userManageInfo'})"
              ></i>
            </span>
          </template>-->
          <!-- <template slot-scope="scope">
            <el-dropdown @command="()=>{handleCommand(command,scope.row)}" placement="bottom">
              <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
                <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="add">
                  <i class="el-icon-circle-plus-outline iconBlue"></i>新增
                </el-dropdown-item>
                <el-dropdown-item command="delete">
                  <i class="el-icon-remove-outline iconBlue"></i>删除
                </el-dropdown-item>
                <el-dropdown-item command="update">
                  <i class="el-icon-edit-outline iconBlue"></i>修改
                </el-dropdown-item>
                <el-dropdown-item command="show">
                  <i class="el-icon-view iconBlue"></i>详情
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>-->
        </el-table-column>
      </el-table>
    </el-col>
    <el-col :span="16">
      <el-table :data="userList" class="mc-table" height="495">
        <el-table-column label="序号" align="center" :show-overflow-tooltip="true">
          <template slot-scope="scope">{{scope.$index}}</template>
        </el-table-column>
        <el-table-column label="用户ID" prop="userId" align="center" :show-overflow-tooltip="true" />
        <el-table-column label="手机号" prop="mobile" align="center" :show-overflow-tooltip="true" />
        <el-table-column
          label="邮箱"
          prop="email"
          align="center"
          width="200px"
          :show-overflow-tooltip="true"
        />
        <el-table-column label="创建时间" prop="createAt" align="center" :show-overflow-tooltip="true" />
        <el-table-column label="状态" prop="status" align="center" :show-overflow-tooltip="true" />
        <el-table-column width="80px">
          <template slot-scope="scope">
            <el-dropdown
              @command="(command)=>{handleCommand(command,scope.row)}"
              placement="bottom"
            >
              <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
                <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="delete">
                  <i class="el-icon-remove-outline iconBlue"></i>删除
                </el-dropdown-item>
                <el-dropdown-item command="update">
                  <i class="el-icon-edit-outline iconBlue"></i>修改
                </el-dropdown-item>
                <el-dropdown-item command="show">
                  <i class="el-icon-view iconBlue"></i>详情
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        small
        class="page-lucency page-right"
        layout="prev,pager,next"
        :total="pagination.total"
        :currentPage="pagination.currentPage"
        @current-change="handlePageChange"
        :page-size="pagination.pageSize"
      ></el-pagination>
      <img
        v-if="currentRow.orgId&&(currentRow.orgPid!=='root'||currentRow.orgName === '业主'||currentRow.orgName==='运营方')"
        class="project-collection mouse-pointer"
        id="addAccount"
        draggable="true"
        src="@/assets/imgs/addForm.png"
        width="64"
        height="64"
        @click="$router.push({ name: 'userManageInfo',query:{tenantId:currentRow.tenantId,orgType:currentRow.orgType,insOrgId:currentRow.orgId} });"
      />
    </el-col>
  </el-row>
</template>
<script>
export default {
  data() {
    return {
      orgList: [],
      userList: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      },
      currentRow: {}
    };
  },
  created() {
    this.handleQuery();
  },
  mounted() {
    this.$doScrollStyle();
  },
  methods: {
    async handleCommand(command, row) {
      const { userId,tenantId } = row;
      switch (command) {
        case "delete": {
          this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(async () => {
              const { code, msg: message } = await this.$api.manageRemoveUser({
                userId,
                tenantId:tenantId
              });
              if (code === 0) {
                this.$messageSuccess({ message });
                this.handleUserQuery();
              } else {
                this.$messageError({ message });
              }
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消删除"
              });
            });
          break;
        }
        case "update": {
          const { tenantId, orgType, orgId } = this.currentRow;
          this.$router.push({
            name: "userManageInfo",
            query: {
              tenantId,
              orgType,
              insOrgId: orgId,
              userId
            }
          });
          break;
        }
        case "show": {
          const { tenantId, orgType, orgId } = this.currentRow;
          this.$router.push({
            name: "userManageInfo",
            query: {
              tenantId,
              orgType,
              insOrgId: orgId,
              userId,
              read: true
            }
          });
          break;
        }
      }
    },
    async handleQuery() {
      this.$store.dispatch("loading", true);
      //查询全部租户，带分页
      const {
        code,
        data: { rows, total },
        msg
      } = await this.$api.tenantData({ offset: 1, limit: 100 });
      if (code === 0) {
        rows.forEach((item, index) => {
          item.orgName = item.appChnName;
          this.queryOrgList(item.tenantId, index);
        });
        this.orgList = rows;
        if (total > 0) {
          this.currentRow = rows[0];
          this.handleUserQuery();
        }
      } else {
        this.$messageError({ message: msg });
      }
      this.$store.dispatch("loading", false);
    },
    //遍历生成主键
    generateId(data, tenantId) {
      data.forEach(item => {
        item.tenantId = tenantId;
        item.id = `${tenantId}-${item.orgId}`;
        if (item.childrens) {
          this.generateId(item.childrens, tenantId);
        }
      });
    },
    //根据租户查询机构列表
    async queryOrgList(tenantId, index) {
      const { code, data, msg: message } = await this.$api.listOrg({
        tenantId
      });
      if (code === 0) {
        this.generateId(data, tenantId);
        this.$set(this.orgList[index], "childrens", data);
      } else {
        this.$messageError({ message });
      }
    },
    //根据机构id查询用户列表
    async handleUserQuery() {
      const { pageSize, currentPage } = this.pagination;
      const { tenantId, orgId: InsOrgId } = this.currentRow;
      //limit,每页有多少条，offset,第几页
      const {
        code,
        msg,
        data: { rows, total }
      } = await this.$api.generatorSelectUserByOrgId({
        InsOrgId: this.currentRow.orgId,
        limit: pageSize,
        offset: currentPage,
        tenantId,
        InsOrgId
      });
      if (code === 0) {
        this.userList = rows;
        this.pagination.total = total;
      } else {
        this.$messageError({ message: msg });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleUserQuery();
    },
    handleCurrentChange(currentRow) {
      this.currentRow = currentRow;
      this.handleUserQuery();
    }
  }
};
</script>
<style lang="scss" scoped>
.project-collection {
  position: absolute;
  right: 22px;
  bottom: 28px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
</style>
<template>
  <el-form class="content-wrapper">
    <el-row>
      <el-col :span="3" class="goback">
        <div @click="$router.replace({name:'tenantManageList'})">
          <i class="el-icon-arrow-left"></i>
          <span>租户数据创建</span>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">租户字典</span>
      </el-col>
    </el-row>
    <el-row style="margin-bottom:39px;">
      <el-col :span="24">
        <baseDataList :tenantId="params.tenantId" />
      </el-col>
    </el-row>
    <el-row>
      <el-form-item label="可查看项目区域">
        <el-table
          class="mc-table district-table"
          tooltip-effect="light"
          :data="listTransArea"
          style="width: 100%;border-radius:2px;"
        >
          <el-table-column prop="province" align="center" label="省">
            <template slot-scope="scope">
              <span v-if="params.read">{{scope.row.province}}</span>
              <el-select
                size="mini"
                v-else
                v-model="scope.row.provinceId"
                @change="handleProvinceChange(scope.row,scope.$index)"
              >
                <el-option
                  v-for="(item,index) in provinceList"
                  :value="item.provinceId"
                  :label="item.province"
                  :key="index"
                ></el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column prop="city" align="center" label="市">
            <template slot-scope="scope">
              <span v-if="params.read">{{scope.row.city}}</span>
              <el-select
                v-else
                :disabled="!scope.row.provinceId"
                clearable
                size="mini"
                v-model="scope.row.cityId"
                @change="handleCityChange(scope.row,scope.$index)"
              >
                <el-option
                  v-for="(item,index) in scope.row.cityList"
                  :value="item.cityId"
                  :label="item.city"
                  :key="index"
                ></el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column prop="district" align="center" label="区/县">
            <template slot-scope="scope">
              <span v-if="params.read">{{scope.row.district}}</span>
              <el-select :disabled="!scope.row.cityId" clearable v-else size="mini" v-model="scope.row.districtId">
                <el-option
                  v-for="row in scope.row.districtList"
                  :key="row.id"
                  :label="row.district"
                  :value="row.originalId"
                ></el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column v-if="!params.read" prop="district" align="center">
            <template slot="header" solt-scope="scope">
              <i @click="doRowAdd" class="el-icon-circle-plus-outline"></i>
            </template>
            <template slot-scope="scope">
              <i @click="doRowDel(scope.$index)" class="el-icon-remove-outline"></i>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
    </el-row>
    <!-- ----------------------------------------------------------------------------------- -->
    <el-row>
      <el-form-item label="app版本发布">
        <el-table
          class="mc-table district-table"
          tooltip-effect="light"
          :data="listTransAreaApp"
          style="width: 100%;border-radius:2px;"
        >
          <el-table-column prop="appVersion" align="center" label="版本号">
            <template slot-scope="scope">
              <span v-if="params.read">{{scope.row.appVersion}}</span>
              <el-input
              v-else
              size="mini"
              clearable
              class="input-box"
              v-model="scope.row.appVersion"
            ></el-input>
              <!-- <el-select
                size="mini"
                v-else
                v-model="scope.row.provinceId"
                @change="handleProvinceChange(scope.row,scope.$index)"
              >
                <el-option
                  v-for="(item,index) in provinceList"
                  :value="item.provinceId"
                  :label="item.province"
                  :key="index"
                ></el-option>
              </el-select> -->
            </template>
          </el-table-column>
          <el-table-column prop="appUri" align="center" label="下载链接">
            <template slot-scope="scope">
              <span v-if="params.read">{{scope.row.appUri}}</span>
              <el-input
              v-else
              size="mini"
              clearable
              class="input-box"
              v-model="scope.row.appUri"
            ></el-input>
              <!-- <el-select
                v-else
                :disabled="!scope.row.provinceId"
                clearable
                size="mini"
                v-model="scope.row.cityId"
                @change="handleCityChange(scope.row,scope.$index)"
              >
                <el-option
                  v-for="(item,index) in scope.row.cityList"
                  :value="item.cityId"
                  :label="item.city"
                  :key="index"
                ></el-option>
              </el-select> -->
            </template>
          </el-table-column>
          <el-table-column prop="updateAt" align="center" label="创建时间">
            <template slot-scope="scope">
              <span>{{scope.row.updateAt}}</span>
              <!-- <span v-if="params.read">{{scope.row.updateAt}}</span>
              <el-input
              v-else
              size="mini"
              clearable
              class="input-box"
              v-model="scope.row.updateAt"
            ></el-input> -->
              <!-- <el-select :disabled="!scope.row.cityId" clearable v-else size="mini" v-model="scope.row.districtId">
                <el-option
                  v-for="row in scope.row.districtList"
                  :key="row.id"
                  :label="row.district"
                  :value="row.originalId"
                ></el-option>
              </el-select> -->
            </template>
          </el-table-column>
          <el-table-column v-if="!params.read" prop="district" align="center">
            <template slot="header" solt-scope="scope">
              <i @click="doAppRowAdd" class="el-icon-circle-plus-outline"></i>
            </template>
            <template slot-scope="scope">
              <!-- <i @click="doRowDel(scope.$index)" class="el-icon-remove-outline"></i> -->
              <el-button @click="doAppRowPre(scope.row)" type="text" size="mini">保存</el-button>
              <el-button @click="doAppRowDel(scope.row)" type="text" size="mini">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
    </el-row>
    <!-- ----------------------------------------------------------------------------------- -->
    <el-row>
      <el-col :span="23" class="text-right" style="padding: 55px 0 22.5px 0">
        <el-button
          type="primary"
          style="background-color: #108FEB"
          size="mini"
          @click="handleSave"
        >确定</el-button>
        <el-button size="mini" @click="$router.push({name:'tenantManageList'})">关闭</el-button>
      </el-col>
    </el-row>
  </el-form>
</template>
<script>
import baseDataList from "@/views/manageSystem/baseData/index.vue";
export default {
  name: "tenantManageSetting",
  components: {
    baseDataList
  },
  data() {
    return {
      listTransArea: [],
      listTransAreaApp:[],
      provinceList: [],
      cityList: [],
      districtList: []
    };
  },
  async created() {
    this.appList();
    const { tenantId } = this.params;
    //查询省
    let { code, msg: message, data } = await this.$api.findAreaProvince({
      tenantId
    });
    if (code === 0) {
      this.provinceList = data;
    } else {
      this.$messageError({ message });
    }
    if (tenantId) {
      const { code, msg: message, data } = await this.$api.queryTenantArea({
        tenantId
      });
      if (code === 0) {
        this.listTransArea = [];
        data.forEach((item, index) => {
          const { provinceId, cityId, originalId } = item;
          this.listTransArea.push({
            provinceId,
            cityId,
            districtId: originalId
          });
          this.queryCity(provinceId, index);
          this.queryDistrict(cityId, index);
        });
      } else {
        this.$messageError({ message });
      }
    }
  },
  computed: {
    params() {
      const { tenantId } = this.$route.query;
      return { tenantId };
    }
  },
  methods: {
   async appList() {
    const { tenantId } = this.params;
    let { rows,total } = await this.$api.appEditionList({
      tenantId
    });
    this.listTransAreaApp = rows
    },
    // 新增
    doAppRowAdd(scope) {
      this.listTransAreaApp.push({});
    },
    //删除
    async doAppRowDel(row) {
      let { code, msg } = await this.$api.appEditionRemove(
          row.id
        );
        if(code===0) {
          this.$messageSuccess({message:msg});
          this.appList();
        }else{
          this.$messageSuccess({message:msg});
        }
    },
    //保存
    async doAppRowPre(row) {
      if(row.id){
        const { tenantId } = this.params;
        let { code, msg, data } = await this.$api.appEditionUpdate({
          tenantId,
          id:row.id,
          appVersion: row.appVersion,
          appUri: row.appUri
        });
        if(code===0){
          this.$messageSuccess({message:msg});
          this.appList();
        }else{
          this.$messageError({message:msg});
        }
      }else{
        const { tenantId } = this.params;
        let { code, msg } = await this.$api.appEditionSave({
          tenantId,
          id:row.id,
          appVersion: row.appVersion,
          appUri: row.appUri
        });
        if(code===0){
          this.$messageSuccess({message:msg});
          this.appList();
        }else{
          this.$messageError({message:msg});
        }
        
      }
    },
    doRowAdd(scope) {
      this.listTransArea.push({});
    },
    doRowDel(curIndex) {
      const ind = this.listTransArea.findIndex(
        (item, index) => index === curIndex
      );
      this.listTransArea.splice(ind, 1);
    },
    async handleSave() {
      this.listTransArea = this.listTransArea.map(item => {
        let districtObj,
          cityObj,
          provinceObj = null;
        const { districtId, cityId, provinceId, cityList, districtList } = item;
        if (districtId) {
          districtObj = districtList.filter(
            item => item.originalId === districtId
          )[0];
        } else if (cityId) {
          cityObj = cityList.filter(item => item.cityId === cityId)[0];
        } else if (provinceId) {
          provinceObj = this.provinceList.filter(
            item => item.provinceId === provinceId
          )[0];
        }
        return districtId
          ? districtObj
          : cityId
          ? {
              ...cityObj,
              flagId: cityObj.cityId
            }
          : {
              ...provinceObj,
              flagId: provinceObj.provinceId
            };
      });
      const { code, msg: message } = await this.$api.tenantArea({
        listcfgAreaInfoDO: this.listTransArea,
        tenantId: this.params.tenantId
      });
      if (code === 0) {
        this.$router.push({ name: "tenantManageList" });
      } else {
        this.$messageError({ message });
      }
    },
    handleProvinceChange(row, index) {
      this.listTransArea[index].cityId = "";
      this.listTransArea[index].districtId = "";
      if (row.provinceId) {
        this.queryCity(row.provinceId, index);
      }
    },
    handleCityChange(row, index) {
      this.listTransArea[index].districtId = "";
      if (row.cityId) {
        this.queryDistrict(row.cityId, index);
      }
    },

    //查询市
    async queryCity(provinceId, index) {
      let { code, msg: message, data } = await this.$api.findAreaCity({
        provinceId,
        tenantId: this.params.tenantId
      });
      if (code === 0) {
        let temp = {};
        this.$set(
          this.listTransArea[index],
          "cityList",
          data.filter(item => {
            if (!temp[item.cityId]) {
              temp[item.cityId] = item.cityId;
              return true;
            }
          })
        );
      } else {
        this.$messageError({ message });
      }
    },
    //查询区域
    async queryDistrict(cityId, index) {
      let { code, msg: message, data } = await this.$api.findAreaDistrict({
        cityId,
        tenantId: this.params.tenantId
      });
      if (code === 0) {
        this.$set(this.listTransArea[index], "districtList", data);
      } else {
        this.$messageError({ message });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.content-wrapper {
  position: relative;
  padding: 0 34.5px;
  min-height: 495px;
  background-color: rgba(255, 255, 255, 0.5);
  .content-wrapper {
    background-color: transparent;
  }
}
</style>



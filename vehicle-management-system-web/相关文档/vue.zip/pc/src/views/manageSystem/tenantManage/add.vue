<template>
  <div class="content-wrapper">
    <el-row>
      <el-col :span="3" class="goback">
        <div @click="$router.replace({name:'tenantManageList'})">
          <i class="el-icon-arrow-left"></i>
          <span>租户数据创建</span>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
      </el-col>
    </el-row>
    <el-form
      ref="tenantData"
      :model="tenantData"
      class="mc-form"
      label-width="120px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="租户ID">
            <el-input size="mini" :disabled="!!params.tenantId" v-model="tenantData.tenantId" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="租户名称">
            <el-input size="mini" :disabled="params.read" v-model="tenantData.appChnName" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="PC域名">
            <el-input size="mini" :disabled="params.read" v-model="tenantData.domain" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="6.5">
          <el-form-item label="租户类别" prop="tenantType" :rules="[{required: true, message: '请选择租户类别', trigger: 'change'}]">
            <el-radio-group :disabled="!!params.tenantId" v-model="tenantData.tenantType">
              <el-radio label="eidi">IDI平台</el-radio>
              <el-radio label="espi">安泽险平台</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="9.5" style="margin-left:17px">
          <el-form-item label="状态">
            <el-radio-group v-model="tenantData.status" :disabled="params.read">
              <el-radio label="0">未开通</el-radio>
              <el-radio label="1">开通</el-radio>
              <el-radio label="2">可用</el-radio>
              <el-radio label="3">禁用</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="mobile域名">
            <el-input size="mini" :disabled="params.read" v-model="tenantData.domainMobile" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold" id="message">租户数据</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="数据库名称">
            <el-input size="mini" :disabled="!!params.tenantId" v-model="tenantData.tenantDatabase" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="数据库IP">
            <el-input size="mini" :disabled="!!params.tenantId" v-model="tenantData.tenantIp" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="端口">
            <el-input size="mini" :disabled="!!params.tenantId" v-model="tenantData.tenantPort" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="连接用户">
            <el-input size="mini" :disabled="!!params.tenantId" v-model="tenantData.username" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="连接密码">
            <el-input size="mini" :disabled="!!params.tenantId" v-model="tenantData.password" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-form-item label="备注：">
          <el-input
            type="textarea"
            :autosize="{minRows: 2.5}"
            :disabled="params.read"
            placeholder="请输入内容"
            v-model="tenantData.remark"
          ></el-input>
        </el-form-item>
      </el-row>
    </el-form>
    <el-row>
      <el-col :span="23" class="text-right" style="padding: 55px 0 22.5px 0">
        <el-button
          v-if="!params.read"
          type="primary"
          style="background-color: #108FEB"
          size="mini"
          @click="handleSave"
        >确定</el-button>
        <el-button size="mini" @click="$router.replace({name:'tenantManageList'})">关闭</el-button>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  name: "tenantManageAdd",
  data() {
    return {
      tenantData: {}
    };
  },
  created() {
    this.handleQuery();
  },
  computed: {
    params() {
      const { tenantId, read } = this.$route.query;
      return { tenantId, read: read === "true" };
    }
  },
  methods: {
    handleSave() {
      this.$refs.tenantData.validate(valid => {
        if (valid) {
          this.save();
        }else {
          this.$messageError({
            message: '请完善信息'
         })
          return false
        }
      });
    },
    async handleQuery() {
      let { tenantId } = this.params;
      if (tenantId) {
        const { code, msg: message, data } = await this.$api.tenantDataInfo({
          tenantId
        });
        if (code === 0) {
          this.tenantData = data;
        } else {
          this.$messageError({ message });
        }
      }
    },
    async save() {
      if (this.params.tenantId) {
        const { code, msg: message } = await this.$api.updateTenant(
          this.tenantData
        );
        if (code === 0) {
          this.$messageSuccess({ message });
          this.$router.replace({ name: "tenantManageList" });
        } else {
          this.$messageError({ message });
        }
      } else {
        const { code, msg: message } = await this.$api.saveTenant(
          this.tenantData
        );
        if (code === 0) {
          this.$messageSuccess({ message });
          this.$router.replace({ name: "tenantManageList" });
        } else {
          this.$messageError({ message });
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.content-wrapper {
  position: relative;
  padding: 0 34.5px;
  min-height: 495px;
  background-color: rgba(255, 255, 255, 0.5);
}
/deep/ .el-form-item__label {
  font-weight: 500;
}
/deep/ .el-form-item__content {
  .el-icon-view {
    display: none;
  }
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>
<template>
  <div class="content-wrapper" style="padding-bottom: 22px">
    <el-table :data="tenantData" class="mc-table" max-height="495" height="495">
      <el-table-column label="租户ID" prop="tenantId" align="center" width="80" />
      <el-table-column label="租户名称" prop="appChnName" align="center" width="200" />
      <el-table-column label="数据库" prop="tenantDatabase" align="center" />
      <el-table-column label="域名" prop="domain" align="center" />
      <el-table-column label="服务状态" prop="status" align="center">
        <template slot-scope="scope">{{$getValueByCode('status',scope.row.status)}}</template>
      </el-table-column>
      <el-table-column width="80">
        <template slot-scope="scope">
          <el-dropdown @command="(command)=>handleCommand(command,scope.row)" placement="bottom">
            <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
              <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="delete">
                <i class="el-icon-remove-outline iconBlue"></i>删除
              </el-dropdown-item>
              <el-dropdown-item command="setting">
                <i class="el-icon-view iconBlue"></i>设置
              </el-dropdown-item>
              <el-dropdown-item command="update">
                <i class="el-icon-edit-outline iconBlue"></i>修改
              </el-dropdown-item>
              <el-dropdown-item command="show">
                <i class="el-icon-view iconBlue"></i>详情
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      small
      class="page-lucency page-right"
      layout="prev,pager,next"
      :total="pagination.total"
      :currentPage="pagination.currentPage"
      @current-change="handlePageChange"
      :page-size="pagination.pageSize"
    ></el-pagination>
    <img
      class="project-collection mouse-pointer"
      id="addAccount"
      draggable="true"
      src="@/assets/imgs/addForm.png"
      width="64"
      height="64"
      @click="$router.push({ name: 'tenantManageInfo',query:{} });"
    />
  </div>
</template>
<script>
export default {
  data() {
    return {
      tenantData: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      }
    };
  },
  created() {
    this.handleQuery();
  },
  methods: {
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleQuery();
    },
    async handleQuery() {
      const { pageSize, currentPage } = this.pagination;
      const {
        code,
        msg: message,
        data: { rows, total }
      } = await this.$api.tenantData({ limit: pageSize, offset: currentPage });
      if (code === 0) {
        this.pagination.total = total;
        this.tenantData = rows;
      } else {
        this.$messageError({ message });
      }
    },
    async handleCommand(command, row) {
      switch (command) {
        case "delete": {
          this.$confirm('此操作将删除该信息, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async() => {
          const { code, msg:message } = await this.$api.removeTenant({
            tenantId: row.tenantId
          });
          if (code === 0) {
            this.$messageSuccess({message});
            this.handleQuery();
          }else{
            this.$messageError({message});
          }
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
          break;
        }
        case "update": {
          this.$router.push({
            name: "tenantManageInfo",
            query: { tenantId: row.tenantId }
          });
          break;
        }
        case "setting": {
          this.$router.push({
            name: "tenantManageSetting",
            query: { tenantId: row.tenantId }
          });
          break;
        }

        case "show": {
          this.$router.push({
            name: "tenantManageInfo",
            query: { tenantId: row.tenantId,read: true }
          });
          break;
        }
      }
    },
  }
};
</script>
<style lang="scss" scoped>
.project-collection {
  position: absolute;
  right: 22px;
  bottom: 28px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
</style>
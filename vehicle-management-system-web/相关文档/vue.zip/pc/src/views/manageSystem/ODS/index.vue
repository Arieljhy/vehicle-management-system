<template>
  <div class="content-wrapper">
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">ODS保单</span>
      </el-col>
    </el-row>
    <el-row>
      <el-form class="mc-form">
        <el-col :span="8">
          <el-form-item label="租户">
            <el-input size="mini" v-model="searchForm.province" @keyup.native.enter="handleQuery" />
          </el-form-item>
        </el-col>
      </el-form>
    </el-row>
    <el-table class="mc-table" :data="odsList">
      <el-table-column label="租户">
        <template slot-scope="scope">{{scope.row.tenantId}}</template>
      </el-table-column>
      <el-table-column prop label="状态" width="70">
        <template slot-scope="scope">{{scope.row.projectId?"正常":"失败"}}</template>
      </el-table-column>
      <el-table-column prop="projectName" label="项目名称" width="110" :show-overflow-tooltip="true" />
      <el-table-column prop="insContractNo" label="保险单号" width="110" :show-overflow-tooltip="true" />
      <el-table-column prop="insOrgId" label="保险公司" width="110" :show-overflow-tooltip="true" />
      <!-- <el-table-column prop="tisOrgId" label="保险管理公司" width="110" :show-overflow-tooltip="true" />
      <el-table-column prop="insuredOrgId" label="被保机构" width="110" :show-overflow-tooltip="true" /> -->
      <el-table-column
        prop="policyStartDate"
        label="保险开始日期"
        width="120"
        :show-overflow-tooltip="true"
      >
        <template slot-scope="scope">{{scope.row.policyStartDate|filterDate}}</template>
      </el-table-column>
      <el-table-column
        prop="policyEndDate"
        label="保险终止日期"
        width="120"
        :show-overflow-tooltip="true"
      >
        <template slot-scope="scope">{{scope.row.policyEndDate|filterDate}}</template>
      </el-table-column>
      <el-table-column prop="totalPremium" label="总保险费" width="80" :show-overflow-tooltip="true" />
      <el-table-column prop="totalCoverage" label="保险金额" width="80" :show-overflow-tooltip="true" />
      <el-table-column
        prop="deductibleAmount"
        label="免赔额"
        width="80"
        :show-overflow-tooltip="true"
      />
      <!-- <el-table-column prop="createdDate" label="创建时间" width="120" :show-overflow-tooltip="true" /> -->
      <el-table-column>
        <template slot-scope="scope">
          <el-dropdown @command="(command)=>handleCommand(command,scope.row)" placement="bottom">
            <span style="font-size: 13.5px; color: #fff" class="mouse-pointer el-dropdown-link">
              <i style="font-size: 20px;" class="iconBlue mouse-pointer el-icon-more"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-if="!scope.row.projectId" command="update">
                <i class="el-icon-edit-outline iconBlue"></i>修改
              </el-dropdown-item>
              <el-dropdown-item command="show">
                <i class="el-icon-remove-outline iconBlue"></i>详情
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      small
      class="page-lucency page-right"
      layout="prev,pager,next"
      :total="pagination.total"
      :currentPage="pagination.currentPage"
      :page-size="pagination.pageSize"
      @current-change="handlePageChange"
    ></el-pagination>
  </div>
</template>
<script>
export default {
  name: "ODSList",
  data() {
    return {
      odsList: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      },
      searchForm: {
        province: ""
      }
    };
  },
  created() {
    this.handleQuery();
  },
  methods: {
    handleCommand(command, row) {
      switch (command) {
        case "show": {
          this.$router.push({
            name: "manageSystemODSInfo",
            query: { read: true, id: row.id, tenantId: row.tenantId }
          });
          break;
        }
        case "update": {
          this.$router.push({
            name: "manageSystemODSInfo",
            query: { id: row.id, tenantId: row.tenantId }
          });
          break;
        }
      }
    },
    async handleQuery() {
      const {
        code,
        msg: message,
        data: { rows, total }
      } = await this.$api.ODSList({
        ...this.searchForm.province&&{province: this.searchForm.province},
        offset: this.pagination.currentPage,
        limit: this.pagination.pageSize
      });
      if (code === 0) {
        this.odsList = rows;
        this.pagination.total = total;
      } else {
        this.$messageError({ message });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleQuery();
    }
  }
};
</script>
<style lang="scss" scoped>
.content-wrapper {
  padding: 22.5px 34.5px 0 34.5px;
  .dialog {
    min-height: 495px;
  }
  .dialog /deep/.el-dialog__header {
    padding: 10px;
    background: #297ae3;
  }
  .dialog /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  .dialog /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  .dialog /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
  .dialog /deep/.el-dialog__body {
    padding: 30px 10px;
  }
}
</style>
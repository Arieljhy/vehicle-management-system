<template>
  <div class="content">
    <el-row>
      <el-col :span="2" class="goback">
        <div @click="$router.replace({name:'manageSystemODS'})">
          <i class="el-icon-arrow-left"></i>
          <span>基本信息</span>
        </div>
      </el-col>
    </el-row>
    <el-form
      class="mc-form"
      :model="odsInfo"
      ref="userForm"
      :rules="rules"
      label-width="148px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="项目名称">
            <el-input v-model="odsInfo.projectName" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="状态">
            <el-radio-group v-model="odsInfo.projectId">
              <el-radio :label="1">成功</el-radio>
              <el-radio :label="0">失败</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="保险单号">
            <el-input v-model="odsInfo.insContractNo" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="保险公司">
            <el-input v-model="odsInfo.insOrgId" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="风险管理公司">
            <el-input v-model="odsInfo.tisOrgId" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="被保机构">
            <el-input v-model="odsInfo.insuredOrgId" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="保险开始日期">
            <el-date-picker
              class="date"
              type="date"
              value-format="yyyy-MM-dd"
              v-model="odsInfo.policyStartDate"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="保险终止日期">
            <el-date-picker
              class="date"
              type="date"
              value-format="yyyy-MM-dd"
              v-model="odsInfo.policyEndDate"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="总保险费">
            <el-input v-model="odsInfo.totalPremium" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="保险金额">
            <el-input v-model="odsInfo.totalCoverage" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="免赔额">
            <el-input v-model="odsInfo.deductibleAmount" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="创建时间">
            <el-date-picker
              class="date"
              type="date"
              value-format="yyyy-MM-dd"
              v-model="odsInfo.createdDate"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23" class="text-right" style="padding: 55px 0 22.5px 0">
          <el-button
            type="primary"
            style="background-color: #108FEB"
            size="mini"
            @click="handleSave"
          >确定</el-button>
          <el-button size="mini" @click="$router.push({name:'manageSystemODS'})">关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
export default {
  name: "ODSForm",
  data() {
    return {
      odsInfo: {},
      rules: {}
    };
  },
  created() {
    this.handleQuery();
  },
  computed: {
    params() {
      const { id, tenantId, read } = this.$route.query;
      return { id, tenantId, read };
    }
  },
  methods: {
    async handleQuery() {
      const { code, msg: message, data } = await this.$api.ODSInfo({
        id: this.params.id,
        tenantId: this.params.tenantId
      });
      if (code === 0) {
        this.odsInfo = data;
      } else {
        this.$messageError({ message });
      }
    },
    async handleSave() {
      const { code, msg: message } = await this.$api.ODSUpdate(this.odsInfo);
      if (code === 0) {
        this.$messageSuccess({ message });
        this.$router.replace({name:'manageSystemODS'});
      } else {
        this.$messageError({ message });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.5);
  .district-table {
    font-size: 12.5px;
  }
}
/deep/ .el-form-item__label {
  font-weight: 500;
}
/deep/ .el-form-item__content {
  .el-icon-view {
    display: none;
  }
}
.el-form-item--mini {
  margin-bottom: 12px;
}
</style>



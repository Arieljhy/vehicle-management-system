<template>
  <article class="bg">
    <section class="logo">
      <img src="@/assets/imgs/cr_logo.png" height="50" />
      <p class="divider"></p>
      <img src="@/assets/imgs/IDILogo.png" height="50" />
    </section>
    <section class="user-form">
      <h2>欢迎使用IDI管理系统</h2>
      <el-form :model="user" ref="manageSystemLoginForm" :rules="rules">
        <el-form-item prop="userId">
          <el-input v-model="user.userId" placeholder="请输入账号" @keyup.enter.native="loginOn"/>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" v-model="user.password" placeholder="请输入密码" @keyup.enter.native="loginOn" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" style="width:100%;" @click="loginOn">登录</el-button>
        </el-form-item>
      </el-form>
    </section>
  </article>
</template>
<script>
import md5 from "js-md5";
import { mapActions } from "vuex";
export default {
  name: "manageSystemLogin",
  data() {
    return {
      user: {
        userId: "",
        password: ""
      },
      rules: {
        userId: [{ required: true, message: "请输入账号" }],
        password: [{ required: true, message: "请输入密码" }]
      }
    };
  },
  methods: {
    ...mapActions(["manageLoginCas"]),
    loginOn() {
      this.$refs.manageSystemLoginForm.validate(valid => {
        if (valid) {
          this.manageLoginCas({ ...this.user, password: md5(this.user.password),tenantId:"eidi-generator",loginType:'password' }).then(
            res => {
              const { code, msg } = res;
              if (code === 0) {
                this.$router.push({ name: "Monitoring" });
              } else {
                this.$messageError({ message: msg });
              }
            }
          );
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.bg {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background: url("../../../assets/imgs/headerBg.jpg") no-repeat;
  background-size: cover;
  .logo {
    position: absolute;
    top: 50px;
    left: 50px;
    .divider {
      margin: 0;
      padding: 0;
      display: inline-block;
      height: 50px;
      width: 2px;
      margin: 0 10px 0 20px;
      background: #838a8b;
    }
    img:last-child {
      margin-bottom: 3px;
    }
  }
  .user-form {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    padding: 10px 50px;
    background: rgba(255, 255, 255, 0.3);
    h2 {
      font-weight: 500;
      color: #fff;
    }
  }
}
</style>
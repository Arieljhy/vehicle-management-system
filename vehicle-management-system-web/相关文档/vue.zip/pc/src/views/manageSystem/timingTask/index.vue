<template>
  <div class="content-wrapper">
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">定时任务</span>
      </el-col>
    </el-row>
    <el-row>
      <el-form :model="searchForm" ref="searchForm" class="mc-form">
        <el-col :span="6">
          <el-form-item label="任务名称">
            <el-input
              size="mini"
              v-model="searchForm.jobName"
              @keyup.native.enter="tenantProcessList"
            />
          </el-form-item>
        </el-col>
        <!-- <el-col :span="6">
          <el-form-item label="任务分组">
            <el-select
            size="mini"
            clearable
            v-model="searchForm.jobGroup"
            >
            <el-option
                v-for="(item,
                index) in jobGroupList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
            </el-select>
          </el-form-item>
        </el-col> -->
        <el-col :span="6">
          <el-form-item label="任务状态">
            <el-select
            size="mini"
            clearable
            v-model="searchForm.status"
            >
            <el-option
                v-for="(item,
                index) in statusList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6" style="line-height: 40px;">
          <el-button type="primary" size="small" style="cursor:pointer;margin-left: 10px;" @click="searchFN()">搜索</el-button>
          <el-button type="primary" size="small" style="cursor:pointer;" @click="doDownload()">重置</el-button>
        </el-col>
      </el-form>
    </el-row>
    <el-row>
        <el-col class="timing-task">
          <el-button type="primary" size="mini" @click="newlyAddedClick('new')">新增</el-button>
          <el-button type="primary" size="mini" :disabled="modifyBtn" @click="newlyAddedClick('modify')">修改</el-button>
          <el-button type="primary" size="mini" :disabled="deleteBtn" @click="deleteClick">删除</el-button>
          <el-button type="primary" size="mini" @click="journalClick">日志</el-button>
        </el-col>
    </el-row>
    <el-table class="mc-table" :data="processList" @selection-change="handelSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column label="任务编号" prop="jobId" />
      <el-table-column label="任务名称" prop="jobName" :show-overflow-tooltip="flag" />
      <el-table-column label="任务分组" prop="jobGroup" :show-overflow-tooltip="flag">
          <template slot-scope="scope">
              <span v-if="scope.row.jobGroup == 'DEFAULT'">默认</span>
          </template>
      </el-table-column>
      <el-table-column label="调用目标字符串" prop="invokeTarget" :show-overflow-tooltip="flag" />
      <el-table-column label="执行表达式" prop="cronExpression" :show-overflow-tooltip="flag" />
      <el-table-column label="任务状态"  >
          <template slot-scope="scope">
              <el-switch 
                v-model="scope.row.flag"
                @click.native="taskStatusChange(scope.$index,scope.row)"
               ></el-switch>
          </template> 
      </el-table-column>
      <el-table-column label="创建时间" prop="createTime" :show-overflow-tooltip="flag" />
      <el-table-column>
        <template slot-scope="scope">
            <el-button @click="executeOnce(scope.row)" type="text" size="mini">执行一次</el-button>
            <el-button @click="newlyAddedClick('detailed',scope.row)" type="text" size="mini">详细</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      small
      class="page-lucency page-right total-page"
      layout="total,prev,pager,next"
      :total="pagination.total"
      @current-change="handlePageChange"
      :currentPage="pagination.currentPage"
      :page-size="pagination.pageSize"
    ></el-pagination>
    <!-- 删除提示框 -->
    <el-dialog
      title="删除"
      :visible.sync="deleteDialog"
      width="30%"
      class="dialog"
      :close-on-click-modal="false"
    >
      <p>确定要删除所有吗</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="deleteSave">确定</el-button>
        <el-button size="small" @click="deleteDialog = false">关闭</el-button>
      </span>
    </el-dialog>
     <!-- 开启提示框 -->
    <el-dialog
      title="系统提示"
      :visible.sync="systemOpenDialog"
      width="30%"
      class="dialog"
      :close-on-click-modal="false"
    >
      <p>确人要请用任务吗</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="deleteSave">确定</el-button>
        <el-button size="small" @click="systemOpenDialog = false">关闭</el-button>
      </span>
    </el-dialog>
    <!-- 开启审批提示框 -->
    <el-dialog
      title="提示"
      :visible.sync="openDialog"
      width="30%"
      class="dialog"
      :close-on-click-modal="false"
    >
      <p>确定要立即执行一次任务吗</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="openSave">确定</el-button>
        <el-button size="small" @click="openDialog = false">关闭</el-button>
      </span>
    </el-dialog>
    <el-dialog
      :title="nAndMType == 'new' ? '添加任务' : (nAndMType =='modify' ? '修改任务' : '任务详细')"
      :visible.sync="visibleDialog"
      width="607.5px"
      class="dialog"
      :close-on-click-modal="false"
      :before-close="beforeDailog"
    >
      <el-form :model="processForm" :rules="rules" class="mc-form" label-width="137px" ref="processForm">
        <el-row v-if="nAndMType=='detailed'">
          <el-col :span="24">
            <el-form-item label="任务序号">
              <el-input :disabled ="nAndMType=='detailed'" size="mini" v-model="processForm.jobId" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="任务名称" prop="jobName">
              <el-input :disabled ="nAndMType=='detailed'" size="mini" v-model="processForm.jobName" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="任务分组" >
              <el-select size="mini" v-model="processForm.jobGroup" disabled >
                <el-option
                  v-for="(item,index) in jobGroupList"
                  :key="index"
                  :value="item.value"
                  :label="item.label"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="调用目标字符串" prop="invokeTarget">
              <el-input :disabled ="nAndMType=='detailed'" size="mini" v-model="processForm.invokeTarget" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="cron表达式" prop="cronExpression">
              <el-input :disabled ="nAndMType=='detailed'" size="mini" v-model="processForm.cronExpression" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="nAndMType=='detailed'">
          <el-col :span="22">
            <el-form-item label="下次执行时间">
              <el-input :disabled ="nAndMType=='detailed'" size="mini" v-model="processForm.nextValidTime" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col  :span="22">
            <el-form-item label="执行策略" prop="misfirePolicy">
              <div v-if="nAndMType=='detailed'" class="el-input el-input--mini is-disabled">
                <span class=" el-input el-input__inner">{{getMisFriePolicy(this.processForm.misfirePolicy,this.misfirePolicyList)}}</span>
              </div>
                <el-radio-group v-else v-model="processForm.misfirePolicy">
                    <el-radio
                    v-for="(item,index) in misfirePolicyList"
                    :key="index"
                    :label="item.value" 
                    >{{item.label}}</el-radio>
                </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col v-if="nAndMType=='detailed'" :span="22">
            <el-form-item label="并发执行">
              <div class="el-input el-input--mini is-disabled">
                <span class=" el-input el-input__inner">{{getMisFriePolicy(this.processForm.concurrent,this.concurrentList)}}</span>
              </div>
            </el-form-item>
          </el-col>
          <el-col v-else :span="22">
            <el-form-item label="并发执行" prop="concurrent">
              <el-radio-group v-model="processForm.concurrent">
                <el-radio
                  v-for="(item,index) in concurrentList"
                  :key="index"
                  :label="item.value" 
                >{{item.label}}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col v-if="nAndMType=='detailed'" :span="22">
            <el-form-item label="执行状态">
              <div class="el-input el-input--mini is-disabled">
                <span class=" el-input el-input__inner">{{getMisFriePolicy(this.processForm.status,this.statusList)}}</span>
              </div>
            </el-form-item>
          </el-col>
          <el-col v-else :span="22">
            <el-form-item label="状态" prop="status">
              <el-radio-group v-model="processForm.status">
                <el-radio
                  v-for="(item,index) in statusList"
                  :key="index"
                  :label="item.value" 
                >{{item.label}}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="nAndMType=='new'">
          <el-col :span="22">
            <el-form-item label="备注">
              <el-input size="mini" v-model="processForm.remark" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-row style="text-align: right; margin-top: 30px;margin-right: 45px" class="btns">
        <el-button v-if="nAndMType=='new' || nAndMType=='modify'" type="primary" size="mini" @click="save">确定</el-button>
        <el-button size="small" @click="closeFN">关闭</el-button>
      </el-row>
    </el-dialog>
 
  </div>
</template>
<script>
import imgUpload from "@/assets/imgs/put.png";

const [inputValid, selectValid] = [
  { required: true, message: "请输入", trigger: "blur" },
  { required: true, message: "请选择", trigger: "change" }
  // { required: true, message: "请选择", trigger: "change" }
];

export default {
  name: "TimingTask",
  data() {
    return {
        systemOpenDialog:false,
        deleteDialog:false,
        jobGroupList:[{
            value:'0',
            label:'所有'
        },{
            value:'DEFAULT',
            label:'默认'
        },{
            value:'2',
            label:'系统'
        }],

        misfirePolicyList:[{
            value:'1',
            label:'立即执行'
        },{
            value:'2',
            label:'执行一次'
        },{
            value:'3',
            label:'放弃执行'
        }],
        concurrentList:[{
            value:'0',
            label:'允许'
        },{
            value:'1',
            label:'禁止'
        }],
        statusList:[{
            value:'0',
            label:'正常'
        },{
            value:'1',
            label:'暂停'
        }],
        processForm: {
            jobId:'',
            jobName:'',
            invokeTarget: '',
            invokeTarget: '',
            cronExpression: '',
            jobGroup: 'DEFAULT',
            misfirePolicy: '1',
            concurrent: '1',
            status: '1'
        },
        visibleDialog:false,
        openDialog:false,
        nAndMType: '', // 用来判断新增 修改
        deleteBtn: true,
        modifyBtn: true,
        taskStatus:true,
        status:false,
        flag: true, //超出部分省略号显示
        jobId:'',
        jobGroup:'',
        rules: {
            // jobName: [{required: true, message: '请输入', trigger: 'blur'}],
            // jobGroup: [{required: true, message: '请输入', trigger: 'blur'}],
            // invokeTarget: [{required: true, message: '请输入', trigger: 'blur'}],
            // cronExpression:[{required: true, message: '请输入', trigger: 'blur'}]
            jobName: [inputValid],
            jobGroup: [inputValid],
            invokeTarget: [inputValid],
            cronExpression:[inputValid],
            misfirePolicy:[selectValid],
            concurrent:[selectValid],
            status:[selectValid]
        },
        selectionData: {},
         searchForm: {
                jobName: "",
                status: '',
                // jobGroup:''
            },
      imgUpload,  
      menuList: [],
      visible: false,
      settingVisible: false,
      processList: [],
      tenantList: [],
      tableSettingData: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      }
    };
  },
  async created() {
    this.timingTaskList();
    const {
      code,
      msg: message,
      data: { rows, total }
    } = await this.$api.tenantData({ offset: 1, limit: 10 });
    if (code === 0) {
      this.tenantList = rows;
    } else {
      this.$messageError({ message });
    }
  },
  methods: {
    //   转码
      getMisFriePolicy(num,arr){
          for(var i=0;i<arr.length;i++) {
            if(arr[i].value == num) {
                return arr[i].label
            }   
          }
          return ''
      },
      // 弹框关闭
      beforeDailog(done){
          this.processForm = {}
        done()
      },
      closeFN(){
          this.visibleDialog = false
          this.processForm = {}
      },
      taskStatusChange(index,row){
          if(row.flag){
              row.status = '0'
          }else{
              row.status = '1'
          }
        let text = row.status=='1'?'关闭':'启用';
        // let status = row.status?0:1;
        this.$confirm(`你确定${text}此备用服务器吗?`,'系统提示',{
            confirmButtonText:'确定',
            cancelButtonText:'取消',
            callback: async taskStatusOpen =>{
                if(taskStatusOpen=='confirm'){
                    let { code, msg } = await this.$api.changeStatusOpen({
                        jobId:row.jobId,
                        jobGroup: 'DEFAULT',
                        status:row.status
                    });
                    if(code===0){
                    this.$messageSuccess({message:msg});
                    this.timingTaskList();
                    }else{
                    this.$messageError({message:msg});
                    }
                }
            }
        })

      },
      searchFN(){
           this.timingTaskList();
      },
    //   执行一次
      executeOnce(row) {
          this.openDialog = true
          this.jobId = row.jobId
          this.jobGroup = row.jobGroup
      },
      //   执行一次的确定
     async openSave() {
        let { code, msg } = await this.$api.openSave({
          jobId:this.jobId,
          jobGroup: this.jobGroup
        });
        if(code===0){
          this.openDialog = false
          this.timingTaskList();
          this.$messageSuccess({message:msg});
        }else{
          this.$messageError({message:msg});
        }
      },
    //   详细
      detailed() {},
    //   新增 修改
    newlyAddedClick(type,row) {
        this.nAndMType = type
        
        if(type == 'new'){
            this.processForm = {}
            this.processForm.jobGroup ='DEFAULT'
            // this.processForm.misfirePolicy ='3'
            // this.processForm.concurrent ='1'
            // this.processForm.status ='1'
        }else if(type == 'modify'){
            this.processForm = this.selectionData[0]
        }else if(type=="detailed"){
            this.processForm = row
        }
        this.visibleDialog = true
    },
    // 删除
    deleteClick() {
        this.deleteDialog = true
    },
    // 删除确定
    async deleteSave(){
       let ids = this.selectionData.map(item => {
            return item.jobId;
         }).join(',')
        let { code, msg } = await this.$api.setTimeDelete({
          ids:ids
        });
        if(code===0) {
          this.deleteDialog = false
          this.$messageSuccess({message:msg});
          this.timingTaskList();
        }else{
          this.$messageSuccess({message:msg});
        }
      },
    // 日志
    journalClick() {
        this.$router.push('/manageSystem/timingTask/journal')
    },
    //重置
    doDownload(){
        this.searchForm.jobName = ''
        this.searchForm.status = ''
    },
    handelSelectionChange(val){
        this.selectionData = val
        if(val.length != 0){
            this.deleteBtn = false
            if(val.length <2) {
            this.modifyBtn = false;
            }else{
                this.modifyBtn = true
            }
        }else{
            this.deleteBtn = true
        }
    },

    async timingTaskList() {
      const { pageSize, currentPage } = this.pagination;
      const {
        msg,
        code,
        data
      } = await this.$api.timingTaskList({
        limit: pageSize,
        offset: currentPage,
        ...this.searchForm
      });
      if(code==0){
        this.processList =data.rows;
        this.pagination.total = data.total
        }else{
            this.$messageError({ message: msg });
        }
      this.processList && this.processList.map(item=>{
        if(item.status=="0"){
          item.flag = true
        }else {
          item.flag = false
        }
      })
    },
    async save() {
         //表单校验
        let returnFlag = false;
        this.$refs["processForm"].validate(valid => {
            returnFlag = valid;
        });
        if (!returnFlag) {
            return;
        }
                if(this.nAndMType =='new'){
                    // 表达式
                await this.$api.checkCron({cronExpression:this.processForm.cronExpression?this.processForm.cronExpression:''}).then(res=> {
                    if(res){
                        //  新增
                        this.$api.setTimeNewSave(this.processForm).then(res=>{
                            if(res.code===0){
                            this.visibleDialog = false
                            this.$messageSuccess({message:res.msg});
                            this.timingTaskList()
                            }else{
                            this.$messageError({message:res.msg});
                            }
                        });
                        
                    }else{
                        this.$messageError({message:'请填写正确的表达式!'})
                    }
                    })
                }else {
                    //修改
                    // 表达式
                await this.$api.checkCron({cronExpression:this.processForm.cronExpression?this.processForm.cronExpression:''}).then(res=> {
                    if(res){
                        //    修改
                        this.$api.setTimeModifySve(this.processForm).then(res=>{

                        if(res.code===0){
                                this.visibleDialog = false
                                this.$messageSuccess({message:res.msg});
                                this.processForm = {}
                                this.timingTaskList()
                            }else{
                                this.$messageError({message:res.msg});
                            }
                        })
                    }else{
                        this.$messageError({message:'请填写正确的表达式!'})
                    }
                })
            }
    },
    async saveSetting() {
      const { code, msg } = await this.$api.setProcess(this.tableSettingData);
      if (code === 0) {
        this.$messageSuccess({ message: msg });
        this.handleVisivle("settingVisible", false);
        this.tenantProcessList();
      } else {
        this.$messageError({ message: msg });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.timingTaskList();
    }

  }
};
</script>
<style lang="scss" scoped>
.timing-task{
    margin-bottom: 10px;
    .el-button{
        float: left;
    }
}
.el-input{
    width: 179px !important;
}
.content-wrapper {
  padding: 22.5px 34.5px 0 34.5px;
  .dialog {
    min-height: 495px;
  }
  .dialog /deep/.el-dialog__header {
    padding: 10px;
    background: #297ae3;
  }
  .dialog /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  .dialog /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  .dialog /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
  .dialog /deep/.el-dialog__body {
    padding: 30px 10px;
  }
  .project-collection {
  position: absolute;
  right: 22px;
  bottom: 28px;
  height: 64px;
  width: 64px;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
}
</style>
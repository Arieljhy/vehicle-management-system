<template>
  <div class="content-wrapper">
    <el-row>
      <el-col :span="2" class="goback">
        <div @click="returnClick">
          <i class="el-icon-arrow-left"></i>
          <span>定时任务</span>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">调度日志</span>
      </el-col>
    </el-row>
    <el-row>
       
      <el-form class="mc-form formStyle">
        <!-- <el-col :span="6">
          <el-form-item label="任务名称">
            <el-input
              size="mini"
              v-model="searchForm.tenantId"
              @keyup.native.enter="tenantProcessList"
            />
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="任务分组">
            <el-select
            size="mini"
            clearable
            v-model="searchForm.businessType"
            >
            <el-option
                v-for="(item,
                index) in typeOfBusinessList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="执行状态">
            <el-select
            size="mini"
            clearable
            v-model="searchForm.businessType"
            >
            <el-option
                v-for="(item,
                index) in typeOfBusinessList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
            </el-select>
          </el-form-item>

        </el-col> -->
        <el-col :span="6">
          <el-form-item label="任务名称">
            <el-input
            style="width: 179px!important;"
              size="mini"
              v-model="searchForm.jobName"
              @keyup.native.enter="tenantProcessList"
            />
          </el-form-item>
        </el-col>
        <!-- <el-col :span="6">
          <el-form-item label="任务分组">
            <el-select
            size="mini"
            clearable
            v-model="searchForm.jobGroup"
            >
            <el-option
                v-for="(item,
                index) in jobGroupList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
            </el-select>
          </el-form-item>
        </el-col> -->
        <el-col :span="6">
          <el-form-item label="任务状态">
            <el-select
            size="mini"
            clearable
            v-model="searchForm.status"
            >
            <el-option
                v-for="(item,
                index) in statusList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="执行时间" prop="uploadDate">
            <el-date-picker
            style="width: 100%;"
            size="mini"
            v-model="searchForm.uploadDate"
            type="daterange"
            value-format="yyyy-MM-dd HH:mm:ss"
            unlink-panels
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期" 
            ></el-date-picker>
          </el-form-item>
        </el-col>
       
            <el-col :span="4" class="btnStyle">
          <el-button type="primary" size="small" style="cursor:pointer;margin-left: 10px;" @click="searchFN()">搜索</el-button>
          <el-button type="primary" size="small" style="cursor:pointer;" @click="doDownload">重置</el-button>
        </el-col>
      
       
      </el-form>
    </el-row>
    <el-row style="marginTop:30px">
        <el-col class="timing-task">
         
          <el-button type="primary" size="mini" :disabled="deleteBtn" @click="deleteClick">删除</el-button>
           <el-button type="primary" size="mini"  @click="clearFN()">清空</el-button>
        </el-col>
    </el-row>
    <el-table class="mc-table" :data="processList" @selection-change="handelSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column label="日志编号" prop="jobLogId" />
      <el-table-column label="任务名称" prop="jobName" :show-overflow-tooltip="flag" />
      <el-table-column label="任务分组" prop="jobGroup" :show-overflow-tooltip="flag">
          <template slot-scope="scope">
              <span v-if="scope.row.jobGroup == 'DEFAULT'">默认</span>
          </template>
      </el-table-column>
      <el-table-column label="调用目标字符串" prop="invokeTarget" :show-overflow-tooltip="flag" />
       <el-table-column label="日志信息" prop="jobMessage" :show-overflow-tooltip="flag" />
      <el-table-column label="状态"  prop="status" :show-overflow-tooltip="flag">
          <template slot-scope="scope">
              <span v-if="scope.row.status == '0'">成功</span>
              <span v-if="scope.row.status == '1'">失败</span>
          </template>
      </el-table-column>
      <el-table-column label="创建时间" prop="createTime" :show-overflow-tooltip="flag" />
      <el-table-column label="操作">
        <template slot-scope="scope">
            <el-button @click="newlyAddedClick(scope.row)" type="text" size="mini">详细</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- <img
      class="project-collection mouse-pointer"
      id="addAccount"
      draggable="true"
      src="@/assets/imgs/addForm.png"
      width="64"
      height="64"
      @click="()=>handleVisivle('visible',true)"
    /> -->
    <el-pagination
      small
      class="page-lucency page-right"
      layout="total,prev,pager,next"
      :total="pagination.total"
      @current-change="handlePageChange"
      :currentPage="pagination.currentPage"
      :page-size="pagination.pageSize"
    ></el-pagination>
    <!-- 删除提示框 -->
    <el-dialog
      title="删除"
      :visible.sync="deleteDialog"
      width="30%"
      class="dialog"
      :close-on-click-modal="false"
    >
      <p>确定要删除所有吗</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="deleteSave">确定</el-button>
        <el-button size="small" @click="deleteDialog = false">关闭</el-button>
      </span>
    </el-dialog>
    <!-- 清空提示框 -->
    <el-dialog
      title="清空"
      :visible.sync="openDialog"
      width="30%"
      class="dialog"
      :close-on-click-modal="false"
    >
      <p>确定要清空所有吗</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="openSave">确定</el-button>
        <el-button size="small" @click="openDialog = false">关闭</el-button>
      </span>
    </el-dialog>
    <!-- 详情 -->
    <el-dialog
      title="调度日志详细"
      :visible.sync="visibleDialog"
      width="607.5px"
      class="dialog"
      :close-on-click-modal="false"
      :before-close="beforeClose"
    >
      <el-form :model="processForm" :rules="rules" class="mc-form" label-width="120px">
        <el-row>
          <el-col :span="22">
            <el-form-item label="日志序号">
              <!-- <pre>{{processForm.jobLogId}}</pre> -->
              <el-input disabled size="mini" v-model="processForm.jobLogId" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="任务名称">
              <el-input disabled size="mini" v-model="processForm.jobName" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="调用目标字符串">
              <el-input type="textarea" autosize disabled size="mini" v-model="processForm.invokeTarget" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="日志信息">
              <el-input disabled size="mini" v-model="processForm.jobMessage" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row >
          <el-col :span="22">
            <el-form-item label="执行状态">
              <div class="el-input el-input--mini is-disabled">
                <span class=" el-input el-input__inner">{{getMisFriePolicy(this.processForm.status,this.statusList)}}</span>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row >
          <el-col :span="22">
            <el-form-item label="错误信息"  v-if="processForm.status=='1'">
              <el-input type="textarea" :rows="6" disabled size="mini" v-model="processForm.exceptionInfo" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>
 
  </div>
</template>
<script>
import imgUpload from "@/assets/imgs/put.png";
export default {
  name: "Journal",
  data() {
    return {
        flag:true,
        typeOfBusinessList:[{
            value:'选项1',
            label:'所有'
        },{
            value:'选项2',
            label:'默认'
        },{
            value:'选项3',
            label:'系统'
        }],
        statusList:[{
            value:'0',
            label:'正常'
        },{
            value:'1',
            label:'失败'
        }],
        visibleDialog:false,
        openDialog:false,
        deleteDialog:false,
        nAndMType: '', // 用来判断新增 修改
        deleteBtn: true,
        taskStatus:true,
        processForm: {
            jobLogId:'',
            jobName:'',
            invokeTarget:'',
            jobMessage:'',
            status:''
        },
        processList: [],
        selectionData: {},
        searchForm: {
        jobName: "",
        status: '',
        uploadDate:[]
      },
      imgUpload, 
      menuList: [],
      rules: {
        tenantId: "",
        name: "",
        number: "",
        desc: ""
      },
      visible: false,
      settingVisible: false, 
      tenantList: [],
      tableSettingData: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      }
    };
  },
  async created() {
    this.journalList();
    const {
      code,
      msg: message,
      data: { rows, total }
    } = await this.$api.tenantData({ offset: 1, limit: 10 });
    if (code === 0) {
      this.tenantList = rows;
    } else {
      this.$messageError({ message });
    }
  },
  methods: {
      //   转码
      getMisFriePolicy(num,arr){
          for(var i=0;i<arr.length;i++) {
            if(arr[i].value == num) {
                return arr[i].label
            }   
          }
          return ''
      },
      returnClick(){
          this.$router.push('/manageSystem/timingTask')
      },
      searchFN(){
        this.journalList();
      },
      //关闭弹框
      beforeClose(done){
        done()
      },
      //删除
      deleteClick(){
          this.deleteDialog = true
      },
      //删除确定
     async deleteSave(){
       let ids = this.selectionData.map(item => {
            return item.jobLogId;
         }).join(',')
        let { code, msg } = await this.$api.journalRemove({
          ids:ids
        });
        if(code===0) {
          this.deleteDialog = false
          this.$messageSuccess({message:msg});
          this.journalList();
        }else{
          this.$messageSuccess({message:msg});
        }
      },
      //清空
      clearFN(){
          this.openDialog = true
      },
      //   清空确定
      async openSave() {
          
        let { code, msg } = await this.$api.journalClean();
        if(code===0) {
          this.openDialog = false
          this.$messageSuccess({message:msg});
          this.journalList();
        }else{
          this.$messageSuccess({message:msg});
        }
      },
    //   详细
    newlyAddedClick(row) {
        this.processForm = row
        this.visibleDialog = true
    },
    // 重置
    doDownload(){
        this.searchForm.jobName = ''
        this.searchForm.status = ''
        this.searchForm.uploadDate = ''
    },
handelSelectionChange(val){
    this.selectionData = val
    if(val.length != 0){
        this.deleteBtn = false
    }else{
        this.deleteBtn = true
    }
},
    async journalList() {
      const { pageSize, currentPage } = this.pagination;
      const {
        msg,
        code,
        data
      } = await this.$api.journalList({
        limit: pageSize,
        offset: currentPage,
        ...this.searchForm,
        startTime:this.searchForm.uploadDate && this.searchForm.uploadDate.length>1 ?this.searchForm.uploadDate[0] : '',
        endTime:this.searchForm.uploadDate && this.searchForm.uploadDate.length>1 ?this.searchForm.uploadDate[1]: ''
      });
    if(code==0){
        this.processList =data.rows;
        this.pagination.total = data.total
    }else{
        this.$messageError({ message: msg });
    }
      
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.journalList();
    }

  }
};
</script>
<style lang="scss" scoped>
.el-textarea{
  width: 107% !important;
}
.mc-form /deep/ .el-input__inner, .mc-form /deep/ .el-textarea__inner{
    width: 79% !important;
}
.formStyle{
    position: relative;
}
.timing-task{
    margin-bottom: 10px;
    .el-button{
        float: left;
    }
}
.btnStyle{
    position: absolute;
    top: 50px;
    right: -23px;
}
.el-input{
    width: 448px !important;
}
.content-wrapper {
  padding: 22.5px 34.5px 0 34.5px;
  .dialog {
    min-height: 495px;
  }
  .dialog /deep/.el-dialog__header {
    padding: 10px;
    background: #297ae3;
  }
  .dialog /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  .dialog /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  .dialog /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
  .dialog /deep/.el-dialog__body {
    padding: 30px 10px;
  }
  .project-collection {
  position: absolute;
  right: 22px;
  bottom: 28px;
  height: 64px;
  width: 64px;
  // background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
}
</style>
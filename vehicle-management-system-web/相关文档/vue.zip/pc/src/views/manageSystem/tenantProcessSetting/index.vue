<template>
  <div class="content-wrapper">
    <el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">应用系统流程管理</span>
      </el-col>
    </el-row>
    <el-row>
      <el-form class="mc-form">
        <el-col :span="8">
          <el-form-item label="租户ID">
            <el-input
              size="mini"
              v-model="searchForm.tenantId"
              @keyup.native.enter="tenantProcessList"
            />
          </el-form-item>
        </el-col>
        <el-col :offset="8" :span="8">
          <el-button type="primary" style="cursor:pointer;float:right;" @click="doDownload">下载流程定义模板</el-button>
        </el-col>
      </el-form>
    </el-row>
    <el-table class="mc-table" :data="processList">
      <el-table-column label="序号" prop="id" />
      <el-table-column label="租户ID" prop="tenantId" />
      <el-table-column label="流程名称" prop="processDefName" />
      <el-table-column label="流程定义标识" prop="processBussinessKey" />
      <el-table-column label="流程部署编号" prop="processDeploymentId" />
      <el-table-column label="流程定义描述" prop="processDefDescription" />
      <el-table-column width="200">
        <template slot-scope="scope">
          <img
            @click="handleUpdate(scope.row)"
            src="@/assets/imgs/update.png"
            alt="修改"
            width="25"
            style="margin-right: 7.5px;cursor:pointer;"
            title="修改"
          />
          <!-- v-if="scope.row.status==='DEFINED'" -->
          <el-upload
            class="inline-block"
            action
            :http-request="({file})=>{uploadFile(file,scope.row.id)}"
            :show-file-list="false"
          >
            <img
              src="@/assets/imgs/upload.png"
              alt="上传"
              width="25"
              style="margin-right: 7.5px;cursor:pointer;"
              title="上传"
            />
          </el-upload>
          <img
            v-if="scope.row.status==='STOPED'"
            @click="handleAction(scope.row)"
            src="@/assets/imgs/active.png"
            width="25"
            style="margin-right: 7.5px;cursor:pointer;"
            title="激活"
          />
          <img
            v-if="scope.row.status==='STARTED'"
            @click="handleAction(scope.row)"
            src="@/assets/imgs/pause.png"
            width="25"
            style="margin-right: 7.5px;cursor:pointer;"
            title="挂起"
          />
          <img
            @click="()=>handleVisivle('settingVisible',true,scope.row)"
            src="@/assets/imgs/setting.png"
            width="25"
            style="margin-right: 7.5px;cursor:pointer;"
            title="设置"
          />
          <img
            @click="handleRemove(scope.row.id)"
            src="@/assets/imgs/delete.png"
            width="25"
            style="margin-right: 7.5px;cursor:pointer;"
            title="删除"
          />
        </template>
      </el-table-column>
    </el-table>
    <img
      class="project-collection mouse-pointer"
      id="addAccount"
      draggable="true"
      src="@/assets/imgs/addForm.png"
      width="64"
      height="64"
      @click="()=>handleVisivle('visible',true)"
    />
    <el-pagination
      small
      class="page-lucency page-right"
      layout="prev,pager,next"
      :total="pagination.total"
      @current-change="handlePageChange"
      :currentPage="pagination.currentPage"
      :page-size="pagination.pageSize"
    ></el-pagination>
    <el-dialog
      title="新增流程定义"
      :visible="visible"
      width="607.5px"
      class="dialog"
      :before-close="()=>handleVisivle('visible',false)"
      :close-on-click-modal="false"
    >
      <el-form :model="processForm" :rules="rules" class="mc-form" label-width="120px">
        <el-row>
          <el-col :span="22">
            <el-form-item label="租户ID">
              <el-select size="mini" v-model="processForm.tenantId">
                <el-option
                  v-for="(item,index) in tenantList"
                  :key="index"
                  :value="item.tenantId"
                  :label="item.name"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="流程名称">
              <el-input size="mini" v-model="processForm.processDefName" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="流程定义标识">
              <el-input size="mini" v-model="processForm.processBussinessKey" />
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <el-row>
          <el-col :span="22">
            <el-form-item label="流程部署编号">
              <el-input size="mini" v-model="processForm.processDeploymentId" />
            </el-form-item>
          </el-col>
        </el-row>-->
        <el-row>
          <el-col :span="22">
            <el-form-item label="流程定义描述">
              <el-input size="mini" v-model="processForm.processDefDescription" />
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <el-row>
          <el-col :span="15">
            <el-form-item label="上传文件">
              <el-input disabled size="mini" />
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <img :src="imgUpload" class="img-upload" />
            <el-upload
              class="inline-block mlr97"
              action
              :http-request="uploadFile"
              :show-file-list="false"
              :on-change="handleChange"
            >
              <el-button size="mini" type="primary">上传</el-button>
            </el-upload>
          </el-col>
        </el-row>-->
      </el-form>
      <el-row style="text-align: right; margin-top: 30px;margin-right: 45px" class="btns">
        <el-button type="primary" size="mini" @click="save">保存</el-button>
      </el-row>
    </el-dialog>
    <el-dialog
      title="任务节点配置"
      :visible="settingVisible"
      width="607.5px"
      class="dialog"
      :before-close="()=>handleVisivle('settingVisible',false)"
      :close-on-click-modal="false"
    >
      <el-table class="mc-table" :data="tableSettingData">
        <el-table-column label="英文名称" prop="userTaskId" />
        <el-table-column label="中文名称" prop="name" />
        <el-table-column label="选择系统菜单">
          <template slot-scope="scope">
            <el-select size="mini" v-model="scope.row.menuId">
              <el-option
                v-for="(item,index) in menuList"
                :key="index"
                :value="`${item.menuId}`"
                :label="item.nameChn"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>
      </el-table>
      <el-row style="text-align: right; margin-top: 30px;margin-right: 45px" class="btns">
        <el-button type="primary" size="mini" @click="saveSetting()">保存</el-button>
      </el-row>
    </el-dialog>
  </div>
</template>
<script>
import imgUpload from "@/assets/imgs/put.png";
export default {
  name: "TenantProcessSetting",
  data() {
    return {
      imgUpload,
      searchForm: {
        tenantId: ""
      },
      processForm: {},
      menuList: [],
      rules: {
        tenantId: "",
        name: "",
        number: "",
        desc: ""
      },
      visible: false,
      settingVisible: false,
      processList: [],
      tenantList: [],
      tableSettingData: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      }
    };
  },
  async created() {
    this.tenantProcessList();
    const {
      code,
      msg: message,
      data: { rows, total }
    } = await this.$api.tenantData({ offset: 1, limit: 100 });
    if (code === 0) {
      this.tenantList = rows;
    } else {
      this.$messageError({ message });
    }
  },
  methods: {
    async doDownload() {
      //返回的数据，需要进行处理
      const { headers, status, data } = await this.$api.processDownload();
      if (status === 200) {
        const aElement = document.createElement("a");
        aElement.style.display = "none";
        aElement.href = window.URL.createObjectURL(
          new Blob([data], { type: "application/zip" })
        );
        aElement.setAttribute(
          "download",
          headers["content-disposition"].split("filename=")[1]
        );
        aElement.click();
        URL.revokeObjectURL(aElement.href);
      }
    },
    async tenantProcessList() {
      const { pageSize, currentPage } = this.pagination;
      const {
        msg,
        code,
        data: { rows, total }
      } = await this.$api.tenantProcessList({
        limit: pageSize,
        offset: currentPage,
        tenantId: this.searchForm.tenantId
      });
      this.processList = rows;
    },
    async handleUpdate(row) {
      this.handleVisivle("visible", true);
      this.processForm = row;
    },
    uploadFile(file, id) {
      const formData = new FormData();
      formData.set("file", file);
      formData.set("id", id);
      this.$api.uploadAndDeploy(formData).then(res => {
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      });
    },
    async handleSetting(id) {
      const {
        code,
        msg,
        data: { rows, total }
      } = await this.$api.listUserTaskByProcessMgrId({
        id,
        offset: 1,
        limit: 50
      });
      if (code === 0) {
        this.tableSettingData = rows;
      } else {
        this.$messageError({ message: msg });
      }
    },
    async queryMenuList(tenantId) {
      const { code, msg: nessage, data } = await this.$api.getGenMenu({
        tenantId
      });
      if (code === 0) {
        this.menuList = data;
      } else {
        this.$messageError({ message });
      }
    },
    async handleAction(row) {
      if (row.status === "STOPED") {
        const { code, msg } = await this.$api.startProcess({ id: row.id });
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          row.status = "STARTED";
        } else {
          this.$messageError({ message: msg });
        }
      } else {
        const { code, msg } = await this.$api.pauseProcess({ id: row.id });
        if (code === 0) {
          this.$messageSuccess({ message: msg });
          row.status = "STOPED";
        } else {
          this.$messageError({ message: msg });
        }
      }
    },
    async handleRemove(id) {
      const { code, msg } = await this.$api.removeProcess({ id });
      if (code === 0) {
        this.$messageSuccess({ message: msg });
        this.tenantProcessList();
      } else {
        this.$messageError({ message: msg });
      }
    },
    async save() {
      const { code, msg } = await this.$api.addTenantProcess(this.processForm);
      if (code === 0) {
        this.$messageSuccess({ message: msg });
        this.handleVisivle("visible", false);
        this.tenantProcessList();
      } else {
        this.$messageError({ message: msg });
      }
    },
    async saveSetting() {
      const { code, msg } = await this.$api.setProcess(this.tableSettingData);
      if (code === 0) {
        this.$messageSuccess({ message: msg });
        this.handleVisivle("settingVisible", false);
        this.tenantProcessList();
      } else {
        this.$messageError({ message: msg });
      }
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.tenantProcessList();
    },
    handleVisivle(type, visible, data) {
      switch (type) {
        case "visible": {
          this.visible = visible;
          break;
        }
        case "settingVisible": {
          this.settingVisible = visible;
          if (visible) {
            this.handleSetting(data.id);
            this.queryMenuList(data.tenantId);
          }
          break;
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.content-wrapper {
  padding: 22.5px 34.5px 0 34.5px;
  .dialog {
    min-height: 495px;
  }
  .dialog /deep/.el-dialog__header {
    padding: 10px;
    background: #297ae3;
  }
  .dialog /deep/ .el-dialog__title {
    color: #fff;
    font-size: 15px;
    font-weight: bold;
  }
  .dialog /deep/ .el-dialog__headerbtn {
    position: absolute;
    top: 12px;
    right: 20px;
    padding: 0;
  }
  .dialog /deep/.el-dialog__headerbtn .el-dialog__close {
    color: #fff;
  }
  .dialog /deep/.el-dialog__body {
    padding: 30px 10px;
  }
  .project-collection {
    position: absolute;
    right: 22px;
    bottom: 28px;
    height: 64px;
    width: 64px;
    // background-color: #4781ca;
    border-radius: 8px;
    color: #e2e2e2;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    div {
      font-weight: bold;
      font-size: 12px;
    }
    i {
      padding: 6px 0;
      font-size: 26px;
      font-weight: bold;
    }
  }
}
</style>
<template>
  <div class="content">
    <el-row class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-row>
    <el-form
      :disabled="$route.query.type=='view'"
      class="mc-form"
      label-width="140px"
      size="mini"
      label-position="left"
      align="left"
      :rules="rules"
      ref="caseDetails"
      :model="caseDetails"
    >
      <el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="理赔进度："  prop="claimHandleProgress">
              <el-select v-model="caseDetails.claimHandleProgress" clearable style="width: 100%">
                <el-option
                  v-for="item in listBaseData.IDI_CLAIM_HANDLE_PROGRESS"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="赔偿金额：" prop="claimAmount">
              <format-input
                empty-value="0"
                text-align="left"
                :precision="2"
                :error="error"
                v-model="caseDetails.claimAmount"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="阶段日期：" prop="progressDate">
              <!-- <el-input v-model="caseDetails.Data"></el-input> -->
              <el-date-picker
                type="date"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="选择日期"
                v-model="caseDetails.progressDate"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-form-item label="赔偿项目名称：">
              <el-input v-model="caseDetails.claimItemName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-form-item label="赔偿条款名称：">
              <el-input v-model="caseDetails.claimTermName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-row>
    </el-form>
    <!-- 提交 -->
    <el-row>
      <el-col :span="22" class="text-right" style="padding: 63px 0 63.5px 0">
        <el-button
          type="primary"
          size="mini"
          @click="saveClaims('caseDetails')"
          v-if="$route.query.type!=='view'"
        >保存</el-button>
        <el-button
          type="primary"
          size="mini"
          @click="submit('caseDetails')"
          v-if="$route.query.type!=='view'"
        >提交</el-button>
        <el-button size="mini" @click="close()">关闭</el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import formatInput from '@/components/formatInput'
export default {
  name: 'ClaimsServiceDetailingAdd',
  components: {
    formatInput
  },
  props: {
    error: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data() {
    return {
      // 表单校验 claimHandleProgress,claimAmount
      rules: {
        progressDate: [{ required: true, message: '请选择日期', trigger: 'change' }],
        claimHandleProgress: [{ required: true, message: '请选择理赔进度', trigger: 'change' }],
        claimAmount: [{ required: true, message: '请输入赔偿金额', trigger: 'blur' }],
      },
      row: '',
      preservationState: 0, // 保存状态
      submissionState: 1, // 提交状态
      caseDetails: {
        sqlStatus: null, //传个状态
        projectId: '',
        claimId: '', // 生成的id
        progressDate: '', // 阶段日期
        claimHandleProgress:'',
        claimItemName: '', // 项目名称
        claimTermName: '', // 条款名称
        claimAmount: '0' // 理赔金额
      }
    }
  },
  computed: {
    ...mapGetters(['listBaseData'])
  },
  methods: {
    // 提交
    submit(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.caseDetails.sqlStatus = this.submissionState // 状态1
          this.caseDetails.projectId = this.$route.query.projectId // 页面id
          this.caseDetails.claimId = this.$route.query.claimId // 页面id
          this.saveRequest()
        } else {
          this.$messageError({
            message: '请完善信息'
          })
        }
      })
    },
    // 保存
    saveClaims(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.caseDetails.sqlStatus = this.preservationState // 状态0
          this.caseDetails.projectId = this.$route.query.projectId // 页面id
          this.caseDetails.claimId = this.$route.query.claimId // 页面id
          this.saveRequest()
        } else {
          this.$messageError({
            message: '请完善信息'
          })
        }
      })
    },
    //保存提交请求
    async saveRequest() {
      this.$store.dispatch('loading', true)
      if (this.$route.query.type == 'new') {
        const res = await this.$api.savePrjClaimDetail(this.caseDetails)
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          })
          this.$router.go(-1)
        } else {
          this.$messageError({
            message: res.msg
          })
        }
        this.$store.dispatch('loading', false)
      } else if (this.$route.query.type == 'edit') {
        const res = await this.$api.amendClaimDetail(this.caseDetails)
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          })
          this.$router.go(-1)
        } else {
          this.$messageError({
            message: res.msg
          })
        }
      }
      this.$store.dispatch('loading', false)
    },
    // 返回上一级
    close() {
      this.$router.go(-1)
    }
  },
  created() {
    this.caseDetails.claimItemName = this.$route.query.row.claimItemName
     this.caseDetails.claimTermName= this.$route.query.row.claimTermName
    if (this.$route.query.type == 'edit') {
      this.caseDetails = this.$route.query.item
    } else if (this.$route.query.type == 'view') {
      this.caseDetails = this.$route.query.item
    }
  }
}
</script>
<style scoped lang="scss" rel="stylesheet/scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
}
</style>
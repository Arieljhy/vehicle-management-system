<template>
  <div style="position: relative">
    <transition leave-active-class="animated rollOut" enter-active-class="animated rollIn">
      <div v-show="showForm" class="diaplay-flex">
        <div class="content">
          <div class="back-gauge">
            <span style="padding-right:37.5px;">
              <el-row class="con-head">
                <div style="width: 80px;height: 51.5px">
                  <img :src="logo_2" style="width: 80px;height: 51.5px" />
                </div>
                <el-input
                  v-model="queryData.fuzzyQuery"
                  @keyup.enter.native="()=>{isFuzzyQuery = false;handleQuery()}"
                  placeholder="请输入项目名称 / 保单号"
                >
                  <el-button
                    @click="()=>{isFuzzyQuery = false;handleQuery()}"
                    slot="append"
                    icon="el-icon-search"
                  ></el-button>
                </el-input>
              </el-row>
              <div
                v-show="projectList.length===0"
                style="position: absolute;left: 50%;top: 50%;transform: translate(-50%,-50%);"
              >
                <img src="@/assets/imgs/noData.png" width="220" height="171" />
              </div>
              <div v-if="projectList.length!==0" style="margin: 47px 0px 32px;">
                <div :key="index" v-for="(item,index) of projectList">
                  <el-row style="margin-left: 10px" :class="{'rowMt': item === 1}">
                    <el-col class="text-left" :span="24">
                      <span
                        @click="goForm(item)"
                        class="con-title mouse-pointer"
                      >{{item.projectName}}</span>
                    </el-col>
                    <el-form>
                      <el-col :span="19">
                        <el-row>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="保险单号：">
                              <div
                                class="policy"
                                :title="item.insContractNo"
                                style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                              >{{item.insContractNo}}</div>
                            </el-form-item>
                          </el-col>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="所在区域：">
                              <span>{{item.district}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="住宅性质：">
                              <span>{{item.dictValue}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="签单日期：">
                              <span>{{item.signDate | filterDate("yyyy-MM-dd")}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="业务状态：">
                              <span>{{item.taskChnName}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="当前处理人：">
                              <span>{{item.processRoleId}}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :span="12">
                            <el-form-item class="text-left" label="小区名称：">
                              <span>{{item.communityName}}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-col>
                      <el-col :span="5">
                        <div class="text-left mouse-pointer btn-bg">
                          <!-- <img
                            @click="jump(item)"
                            style="width: 19.5px; height: 20px;vertical-align:middle;margin-right:10px"
                            src="../../assets/imgs/pm.png"
                          />-->
                          <img src="../../assets/imgs/operationManagement/btn-bg.png" />
                          <span class="image el-icon-document-copy" @click="jump(item)">项目理赔管理</span>
                        </div>
                        <div class="text-left mouse-pointer btn-bg" @click="goToForum(item)">
                          <!-- <img
                            style="width: 19.5px; height: 20px;vertical-align:middle;margin-right:10px"
                            src="../../assets/imgs/liuyan.png"
                          />-->
                          <img src="../../assets/imgs/operationManagement/btn-bg.png" />
                          <span class="image el-icon-edit-outline">{{item.mainPostCount}}个讨论帖</span>
                        </div>
                      </el-col>
                    </el-form>
                  </el-row>
                  <el-divider v-if="item !== 3"></el-divider>
                </div>
                <el-pagination
                  small
                  style="position:absolute;bottom:18.5px;left:50%;transform: translateX(-50%);"
                  class="page-lucency"
                  layout="prev, pager, next"
                  @current-change="handlePageChange"
                  :total="pagination.total"
                  :page-size="pagination.pageSize"
                  :current-page="pagination.currentPage"
                ></el-pagination>
              </div>
            </span>
          </div>
        </div>
        <div class="display-flex text-left">
          <div class="contentTop">
            <div style="padding: 13px;">
              <div style="font-size: 14.5px;margin-top: 5.5px" class="blue font-bold">项目筛选条件</div>
              <div style="margin-top: 15px">
                <div style="font-size: 12.5px;margin:0 25.5px 12px 2px" class="blue font-bold">住宅区域</div>
                <el-row style="font-size: 12.5px">
                  <el-col :span="24">
                    <div
                      class="inline-block area mouse-pointer"
                      @click="handleQuery({item,type:'district'})"
                      :class="{'checked': item.check}"
                      v-for="item of district"
                      :key="item.code"
                    >{{item.value}}</div>
                  </el-col>
                </el-row>
                <!-- <div
                  v-for="(item,index) of district"
                  :key="index"
                  style="font-size: 12.5px;margin-right:19px; color:rgba(62,58,57,1);"
                >{{item.value}}</div>-->
              </div>
              <div style="margin: 5px 0;font-size: 12.5px;">
                <div style="margin:0 24.5px 12px 2px" class="blue font-bold">住宅性质</div>
                <el-row>
                  <el-col :span="24">
                    <div
                      class="inline-block area mouse-pointer"
                      @click="handleQuery({item,type:'buildingType'})"
                      :class="{'checked': item.check}"
                      v-for="item of buildingType"
                      :key="item.code"
                    >{{item.value}}</div>
                  </el-col>
                </el-row>
              </div>
              <!-- <div style="font-size: 12.5px;">
                <div
                  style="font-size: 12.5px;margin:0 25.5px 12px 2px"
                  class="blue text-left font-bold"
                >项目状态</div>
                <el-row>
                  <el-col :span="24">
                    <div
                      class="inline-block area mouse-pointer"
                      @click="handleQuery({item,type:'projectStatus'})"
                      :class="{'checked': item.check}"
                      v-for="item of projectStatus"
                      :key="item.code"
                    >{{item.value}}</div>
                  </el-col>
                </el-row>
              </div>-->
            </div>
          </div>
          <div class="contentCenter">
            <div style="padding: 13px;">
              <div style="margin-bottom: 16.5px" class="blue font-bold text-left">热门论坛</div>
              <el-row>
                <el-col
                  :span="12"
                  v-for="(item) in  hotNotesPlate"
                  :class="{'mt5': item > 2}"
                  class="text-left"
                  :key="item.index"
                >
                  <el-image
                    :src="house"
                    style="height: 50px;width: 50px;border-radius: 6px;cursor:pointer;"
                    @click="hotNotesPlateFun(item)"
                  ></el-image>
                  <div
                    class="inline-block text-left"
                    style="position: relative; top: -4.5px;cursor:pointer;"
                    @click="hotNotesPlateFun(item)"
                  >
                    <div
                      :title="item.projectName"
                      style="width: 120px;padding:0 0 13.5px 2.5px;
                      font-weight: 500;color: #000;font-size: 12px;
                      overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                    >{{item.projectName}}</div>
                    <div
                      style="margin-left: 2.5px;font-size: 11px;color: #3F3A39"
                    >{{item.postCount}}条评论</div>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
          <div class="contentBottom">
            <el-image style="height: 135.5px;width:211.5px;margin-top: 20.5px" :src="WechatIMG48"></el-image>
          </div>
        </div>
      </div>
    </transition>
    <transition enter-active-class="animated rollIn" leave-active-class="animated rollOut">
      <div v-show="!showForm" class="faster" style="position: absolute; top: 0;">
        <div id="top">
          <flow-chart :current="current" @goBack="showForm = true" />
          <basic-information :disabled="true" />
          <bstablish-information :disabled="true" ref="basicBstablish"  showMyCase="basicBstablish"/>
          <underwriting-information ref="underwriting" :disabled="true"  showMyCase='UnderwritingInformation'/>
          <insurance-review
            :disabled="true"
            ref="insuranceReview"
            taskType="underwrite"
            title="保险审核"
          />
          <risk-plan ref="riskPlan" :disabled="true" />
          <insurance-review :disabled="true" title="风险管理计划审核" taskType="checkRiskCtrlPlan" />
          <risk-report-list ref="riskReportList" :disabled="true" />
          <risk-events-list ref="riskEventsList" :disabled="true" />
          <risk-final-report ref="riskFinalReport" :disabled="true" />
          <insurance-coverage ref="insuranceCoverage" :disabled="true" />
          <insurance-review :disabled="true" title="竣工保险审核" taskType="insuranceReview" />
          <project-returns ref="ProjectReturns" />
          <project-claims ref="ProjectClaims" />
          <el-button @click="goTop" id="go-top" circle :style="screen_width">
            <i class="el-icon-arrow-up"></i>
          </el-button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getNode } from "@/assets/js/utils";
import http from "@/common/request";
import Query from "@/components/Query";
import house from "@/assets/imgs/house.png";
import logo_2 from "@/assets/imgs/projectInquiry/logo-2.png";
import WechatIMG48 from "@/assets/imgs/WechatIMG48.png";
import MessageEdit from "@/components/Message.vue";
import FlowChart from "@/components/ProjectSummary/FlowChart"; //流程图
import BasicInformation from "@/components/ProjectSummary/BasicInformation"; //基础信息
import BstablishInformation from "@/components/ProjectSummary/BstablishInformation"; //报建信息
import UnderwritingInformation from "@/components/ProjectSummary/UnderwritingInformation"; //承保信息
import RiskPlan from "@/components/ProjectSummary/RiskPlan"; //风险检查工作计划
import InsuranceReview from "@/components/ProjectSummary/InsuranceReview"; //保险审核
import InsuranceCoverage from "@/components/ProjectSummary/InsuranceCoverage"; //保险责任范围说明书
import RiskReportList from "@/components/ProjectSummary/RiskReportList"; //风险评估报告列表
import RiskEventsList from "@/components/ProjectSummary/RiskEventsList"; //风险事件列表
import RiskFinalReport from "@/components/ProjectSummary/RiskFinalReport"; //风险最终检查报告
import ProjectClaims from "@/components/ProjectSummary/ProjectClaims"; //理赔列表
import ProjectReturns from "@/components/ProjectSummary/ProjectReturns"; //项目回访
export default {
  name: "claimsService",
  components: {
    Query,
    MessageEdit,
    FlowChart,
    BasicInformation,
    BstablishInformation,
    UnderwritingInformation,
    RiskPlan,
    InsuranceReview,
    InsuranceCoverage,
    RiskReportList,
    RiskEventsList,
    RiskFinalReport,
    ProjectClaims,
    ProjectReturns
  },
  data() {
    return {
      types: "IDI_PROJECT_TYPES",
      hotNotesPlate: [],
      logo_2,
      house,
      current: {
        finished: [],
        current: []
      },
      showForm: true,
      WechatIMG48,
      district: [],
      buildingType: [],
      projectStatus: [
        { value: "项目已竣工", check: false, code: 1 },
        { value: "项目理赔中", check: false, code: 2 },
        { value: "项目施工中", check: false, code: 3 },
        { value: "项目理赔终止", check: false, code: 4 }
      ],
      projectList: [],
      pagination: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      },
      queryData: {
        province: "",
        city: "",
        district: new Set(),
        buildingType: new Set(),
        // projectStatus: new Set(),
        fuzzyQuery: "",
        projectStatus: "项目理赔中"
      }
    };
  },
  computed: {
    screen_width() {
      const mc_right = (document.body.clientWidth - 1189) / 2 + 30 + "px";
      return { right: mc_right };
    }
  },
  created() {
    this.handleQuery({});
    this.hotNotes();
    this.districts();
    this.listBaseData();
  },
  methods: {
    hotNotesPlateFun(item) {
      this.goToForum(item);
    },
    //获取字典
    listBaseData() {
      http.get("/sysconfig/DictionaryData/listBaseData").then(res => {
        if (res.code == 0) {
          this.buildingType = res.data[this.types];
          this.buildingType.map((item, index) => {
            (item.value = item.dictValue),
              (item.check = false),
              (item.code = index + 1);
          });
        }
      });
    },
    //获取省市县
    districts() {
      http.get("/sysconfig/DictionaryData/listAreaData").then(res => {
        if (res.code === 0) {
          this.district = res.data[0].city[0].area;
          this.district.map((item, index) => {
            (item.value = item.district),
              (item.check = false),
              (item.code = index + 1);
          });
        }
      });
    },
    //热帖
    async hotNotes() {
      let res = await this.$api.hotNotes();
      this.hotNotesPlate = res.data;
    },
    goToForum(item) {
      this.$router.push({
        path: "/forumDetails",
        query: {
          projectId: item.projectId //获取项目ID
        }
      });
    },
    //打开表单
    goForm(row) {
      let item = { ...row };
      item.taskName = getNode(item);
      this.showForm = false;
      switch (item.taskName) {
        case "newProject":
          this.current = {
            current: ["enteringIns"],
            finished: ["newProject"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "insertInsureInfo":
          this.current = {
            current: ["insuranceAudit"],
            finished: ["newProject", "enteringIns"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "underwrite":
          this.current = {
            current: ["launchRisk"],
            finished: ["newProject", "enteringIns", "insuranceAudit"],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "startRiskPlan":
          this.current = {
            current: ["enteringRisk"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          break;
        case "insertRiskCtrlPlan":
          this.current = {
            current: ["checkRisk"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          break;
        case "checkRiskCtrlPlan":
          this.current = {
            current: ["riskManage"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          break;
        case "riskCtrlMgr":
          this.current = {
            current: ["entreingCompleted"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          break;
        case "insertCompletedInfo":
          this.current = {
            current: ["insuranceCheck"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          break;
        case "insuranceReview":
          this.current = {
            current: ["riskReturn"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          break;
        case "riskReportMent":
          this.current = {
            current: ["claim"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck",
              "riskReturn"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          this.$refs.ProjectReturns.projectReturn(item.projectId);
          this.$refs.ProjectClaims.projectClaim(item.projectId);
          break;
        case "settleClaims":
          this.current = {
            current: ["projectCompletion"],
            finished: [
              "launchRisk",
              "newProject",
              "enteringIns",
              "insuranceAudit",
              "enteringRisk",
              "checkRisk",
              "riskManage",
              "entreingCompleted",
              "insuranceCheck",
              "riskReturn",
              "claim"
            ],
            projectId: item.projectId
          };
          this.$refs.basicBstablish.init(item.projectId);
          this.$refs.riskPlan.init(item.projectId);
          this.$refs.riskFinalReport.riskFinalReport(item.projectId);
          this.$refs.riskReportList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.riskEventsList.getPagination(
            1,
            item.projectId,
            "hasPrama"
          );
          this.$refs.insuranceCoverage.insuranceCoverage(item.projectId);
          this.$refs.insuranceCoverage.init(item.projectId);
          this.$refs.ProjectReturns.projectReturn(item.projectId);
          this.$refs.ProjectClaims.projectClaim(item.projectId);
          break;
      }
      if (item.taskName != "newProject") {
        this.$refs.underwriting.init(item.projectId);
      }
      if (
        item.taskName != "newProject" &&
        item.taskName != "insertInsureInfo"
      ) {
        this.$refs.insuranceReview.insuranceReview({
          projectId: item.projectId
        });
      }
    },
    //回到顶部
    goTop() {
      document.getElementById("top").scrollIntoView();
    },
    //回到顶部按钮
    showGoTop() {
      if (!this.showForm) {
        let scrollTop = document.getElementById("getHeight").scrollTop;
        if (scrollTop > 355) {
          document.getElementById("go-top").style.display = "block";
        } else {
          document.getElementById("go-top").style.display = "none";
        }
      }
    },
    jump(item) {
      this.$router.push({
        path: "/claimsServiceDetail",
        query: {
          id: item.projectId //获取项目ID
        }
      });
    },
    handlePageChange(currentPage) {
      this.pagination.currentPage = currentPage;
      this.handleQuery();
    },
    handleQuery(params) {
      const { item, type } = params || {};
      if (item) {
        item.check = !item.check;
        if (item.check) {
          this.queryData[type].add(item.value);
        } else {
          this.queryData[type].delete(item.value);
        }
      }
      if (this.queryData.fuzzyQuery !== "" && !this.isFuzzyQuery) {
        this.isFuzzyQuery = true;
        this.pagination.currentPage = 1;
      }
      const { district, buildingType, projectStatus } = this.queryData;
      const { currentPage, pageSize } = this.pagination;
      // this.$store.dispatch(`setClaimServiceQueryParams`, {
      //   ...this.queryData,
      //   district: Array.from(district),
      //   buildingType: Array.from(buildingType),
      //   projectStatus: Array.from(projectStatus)
      // });
      this.$store.dispatch("loading", true);
      this.$api
        .getProjectList({
          ...this.queryData,
          offset: currentPage,
          limit: pageSize,
          district: Array.from(district),
          buildingType: Array.from(buildingType),
          // projectStatus: Array.from(projectStatus)
          projectStatus: this.queryData.projectStatus
        })
        .then(res => {
          const {
            code,
            data: { rows, total },
            msg
          } = res;
          if (code === 0) {
            this.pagination.total = total;
            this.projectList = rows;
          } else {
            this.messageError(msg);
          }
          this.$store.dispatch("loading", false);
        });
    }
  },

  mounted() {
    window.addEventListener("scroll", this.showGoTop, true);
  },

  beforeDestroy() {
    window.removeEventListener("scroll", this.showGoTop, true);
  }
};
</script>
<style scoped lang="scss">
.diaplay-flex {
  display: flex;
}
$color: rgba(62, 58, 57, 1);
.area {
  color: $color;
  padding: 2px 10px;
  // margin: 0 12.5px 8.5px 0;
  margin: 0 2.5px 10px 0;
}
$blue: #297ae3;
.checked {
  background-color: $blue;
  color: #fff !important;
  border-radius: 15px;
}
.mt5 {
  margin-top: 5px;
}
.rowMt {
  margin-top: 33.5px;
}
.news {
  height: 45px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  span {
    margin-left: 16px;
  }
}
%content {
  // width: 447.5px;
  position: relative;
  border-radius: 6px;
  background-color: rgba(255, 255, 255, 0.9);
}
.contentTop {
  @extend %content;
  //height: 151.5px;
}
%mt8 {
  margin-top: 8px;
}
.contentCenter {
  @extend %content, %mt8;
  height: 174.5px;
}
.contentBottom {
  @extend %content, %mt8;
  height: 184px;
  text-align: center;
}
.content {
  width: 72%;
  position: relative;
  margin-right: 7.5px;
  min-height: 493px;
  // width: 736px;
  border-radius: 6px;
  background-color: rgba(255, 255, 255, 0.9);
  .con-head {
    $bule: #297ae3;
    display: flex;
    align-items: flex-end;
    .el-image {
      margin-left: 5px;
    }
    .el-input {
      width: 585px;
      $height: 39.5px;
      /deep/ .el-input__inner {
        background-color: rgba(255, 255, 255, 0);
        $color: #e7edf7;
        border-radius: 0;
        height: $height;
        line-height: $height;
        border: 1px solid $bule;
        &::-webkit-input-placeholder {
          color: $color;
        }
        &::-moz-placeholder {
          color: $color;
        }
        &:-ms-input-placeholder {
          color: $color;
        }
      }
    }
    /deep/ .el-input-group__append {
      background: $bule;
      border-radius: 0;
      border: 0;
      padding: 0;
      width: 49px;
      height: 39.5px;
    }
    /deep/ .el-button {
      margin: 0;
      padding: 0;
      color: #fff;
      font-size: 25px;
    }
  }
  .back-gauge {
    display: flex;
    padding: 27px 29px 18.5px 29px;
    .el-input {
      margin-left: 20px;
    }
  }
  $bule: #297ae3;
  .con-title {
    font-size: 14.5px;
    color: $bule;
    font-weight: bold;
    padding-bottom: 1.5px;
    border-bottom: 1.5px solid $bule;
  }
  .el-form {
    $height: 13.5px;
    $color: rgba(62, 58, 57, 1);
    $font: 12.5px;
    .el-form-item {
      margin: 8px 0 0 0;
      font-weight: bold;
      height: $height;
      /deep/ .el-form-item__label {
        font-size: $font;
        color: $color;
        line-height: $height !important;
        padding: 0 !important;
      }
      /deep/ .el-form-item__content {
        font-size: $font;
        color: $color;
        line-height: $height !important;
      }
      .policy {
        font-weight: normal;
      }
    }
  }
  .el-divider {
    margin: 16px 0 13px 0;
    background-color: $bule;
    width: 678px;
    height: 1.5px;
  }
}
.btn-bg {
  &:hover {
    opacity: 0.8;
  }
  position: relative;
  font-size: 14px;
  color: #fff;
  img {
    height: 28px;
    width: 125px;
  }
  span {
    position: absolute;
    top: 6px;
    left: 12px;
  }
}
</style>
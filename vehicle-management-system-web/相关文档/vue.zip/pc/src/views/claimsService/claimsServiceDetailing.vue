<template>
  <div class="content">
    <el-row class="contents">
      <el-row class="text-left mc-title">
        <div @click="backClaimdetail" class="mouse-pointer">
          <i class="el-icon-arrow-left blue font-bold"></i>
          <span style="font-size: 14.5px;" class="blue font-bold">理赔服务详情</span>
        </div>
      </el-row>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
      </el-col>
      <el-form class="mc-form" label-width="135px" size="mini" label-position="left" align="left">
        <el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="赔偿项目名称：">
                <el-input v-model="row.claimItemName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="赔偿条款名称：">
                <el-input v-model="row.claimTermName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="报案号：">
                <el-input v-model="row.insCaseReportId" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="报案受理公司：">
                <el-input v-model="row.claimHanleCompany" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="报案楼栋门牌号：">
                <el-input v-model="row.riskBldingsName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="详细地址：">
                <el-input v-model="row.address" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="备注：">
                <el-input
                  v-model="row.remark"
                  type="textarea"
                  :autosize=" {minRows: 4}"
                  placeholder="审核意见"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-row>
      </el-form>
    </el-row>
    <el-row style="min-height:220px;" v-if="JSON.parse(this.$route.query.row).sqlStatus==1">
      <el-table class="mc-table" tooltip-effect="light" :data="tableData" style="width: 100%">
        <!-- <el-table-column type="index" align="center" label="序号" width="100px"></el-table-column> -->
        <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
        <el-table-column  align="center" label="理赔进度">
          <template
            slot-scope="scope"
          >{{scope.row.claimHandleProgress | filterCode(listBaseData.IDI_CLAIM_HANDLE_PROGRESS,'dictValue','dictKey')}}</template>
        </el-table-column>
        <el-table-column prop="claimAmount" align="center" label="赔偿金额"></el-table-column>
        <el-table-column prop="progressDate" align="center" label="阶段日期">
          <template slot-scope="scope">{{ scope.row.progressDate | filterDate}}</template>
        </el-table-column>
        <el-table-column align="center">
          <template slot-scope="scope">
            <el-dropdown
              placement="bottom"
              size="small"
              trigger="click"
              @command="handleCommand(scope.row,$event)"
            >
              <i class="el-icon-more"></i>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item
                  icon="el-icon-remove-outline"
                  command="delete"
                  v-if="scope.row.sqlStatus==0"
                >删除</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-edit-outline"
                  command="edit"
                  v-if="scope.row.sqlStatus==0"
                >修改</el-dropdown-item>
                <el-dropdown-item icon="el-icon-view" command="view">详情</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <div
      class="project-collection"
      @click="goClaimsDetails('','new')"
      v-if="JSON.parse(this.$route.query.row).sqlStatus==1"
    >
      <i class="el-icon-plus"></i>
      <div>新增项目详情</div>
    </div>
    <el-pagination
      v-if="JSON.parse(this.$route.query.row).sqlStatus==1"
      small
      class="page-lucency"
      layout="prev, pager, next"
      :total="this.total"
      :current-page="this.offset"
      :page-size="this.limit"
      @current-change="handleCurrentChange"
    ></el-pagination>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
export default {
  name: "claimsServiceDetailing",
  components: {
    MessageEdit
  },
  computed: {
    ...mapGetters(["app",'listBaseData'])
  },
  data() {
    return {
      projectId: "",
      claimId: "",
      // 分页
      total: 0,
      limit: 3, //每页几条数据
      offset: 1, //第几页
      row: {},
      tableData: []
    };
  },
  methods: {
    backClaimdetail() {
      this.$router.go(-1);
    },
    // 详情数据请求
    async claimsDetail() {
      // this.projectId = this.$route.query.projectId
      this.claimId = this.$route.query.claimId;
      const keywords = {
        // projectId: this.projectId,
        claimId: this.claimId,
        offset: this.offset,
        limit: this.limit
      };
      const data = await this.$api.listPrjClaimDetail(keywords);
      this.tableData = data.data.rows;
      this.total = data.data.total;
    },
    // 分页
    handleCurrentChange(val) {
      this.offset = val;
      this.claimsDetail();
    },
    // table_index(index){ // 分页后序号
    //   return (this.offset-1) * this.limit + index + 1
    // },
    // 增删改查
    handleCommand(item, command) {
      command == "delete"
        ? this.delete(item.id)
        : this.goClaimsDetails(item, command);
    },
    // 删除数据
    async delete(id) {
      this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          const res = await this.$api.deleteClaimDetail(id);
          if (res.code == 0) {
            this.$messageSuccess({
              message: "删除成功"
            });
            this.claimsDetail();
          } else {
            this.$messageError({
              message: "删除失败 "
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    //新增new、查看view、修改edit
    goClaimsDetails(item, type) {
      this.$router.push({
        path: "/claimsServiceDetailingAdd",
        query: {
          row: this.row,
          item,
          projectId: this.$route.query.projectId,
          claimId: this.row.claimId,
          type
        }
      });
    }
  },
  created() {
    this.claimsDetail();
    this.row = JSON.parse(this.$route.query.row);
  }
};
</script>
<style lang="scss" scoped rel="stylesheet/scss">
.content {
  position: relative;
  min-height: 493px;
  background: rgba(255, 255, 255, 0.9);
}
.contents {
  padding: 23px 36.5px;
}
// 新增按钮位置
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 5px;
  height: 75px;
  width: 75px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
// table透明
.mc-table /deep/ .el-table__row {
  background-color: rgba(255, 255, 255, 0.1);
}
// 分页位置
.page-lucency {
  position: absolute;
  left: 45%;
  bottom: 15px;
}
</style>
<template>
  <div style="padding:11.5px;">
    <el-row>
      <el-col :span="18" style="text-align: left;">
        <div class="text_tag" style="background: #1271CE">本周热点</div>
        <span
          class="text_title"
          style="margin-left: 10px;"
          @click="goToForumOpen(forumBaseInfo.leaderboard[0])"
        >{{forumBaseInfo.leaderboard[0].mainTopic}}</span>
      </el-col>
      <el-col :span="6"></el-col>
      <el-col :span="24" class="text_main">
        {{forumBaseInfo.leaderboard[0].mainContents}}
        <div>
          <span
            v-for="item in forumBaseInfo.leaderboard[0].forumPicDOList"
            :key="item.id"
            style="margin-right:10px"
            @click="openPic(item.imgUrl)"
          >
            <img width="90" height="90" :src="item.imgUrl" alt />
          </span>
        </div>
      </el-col>
      <el-col
        :span="24"
        class="text_main hot_paste fileContent"
        v-if="mainPost.followPost.length>0"
      >
        <div v-for="item in mainPost.followPost" :key="item.id">
          <el-row class="hot_paste_follow">
            <el-col :span="1">
              <img
                class="manager mouse-pointer"
                style="margin-top: 6px;"
                :src="item.userImage ? item.userImage:imgs"
                width="30"
                height="30"
              />
            </el-col>
            <el-col :span="18" style="line-height: 41px;">
              <span
                style="font-size: 13.5px;font-weight: 500;color: rgba(18, 113, 206, 1);"
              >{{item.userName}}：</span>
              {{item.followContents}}
            </el-col>
            <el-col :span="5" style="text-align: right;line-height: 41px;">{{item.followTime}}</el-col>
          </el-row>
        </div>
      </el-col>
    </el-row>
    <el-divider class="mc-divider"></el-divider>
    <el-row>
      <el-col :span="18" style="text-align: left;">
        <div class="text_tag" style="background: #FDCD37">管理置顶</div>
        <span
          class="text_title"
          style="margin-left: 10px;"
          @click="goToForumOpen(alreadyTop)"
        >{{alreadyTop.mainTopic}}</span>
      </el-col>
      <el-col :span="6"></el-col>
      <el-col :span="24" class="text_main">
        {{alreadyTop.mainContents}}
        <div>
          <span
            v-for="item in alreadyTop.forumPicDOList"
            :key="item.id"
            style="margin-right:10px"
            @click="openPic(item.imgUrl)"
          >
            <img width="90" height="90" :src="item.imgUrl" alt />
          </span>
        </div>
      </el-col>
    </el-row>
    <el-divider class="mc-divider"></el-divider>
    <div v-for="item in mainPost.mainPostList" :key="item.id">
      <el-row>
        <el-col :span="18" style="text-align: left;">
          <span @click="goToForumOpen(item)" class="text_title">{{item.mainTopic}}</span>
        </el-col>
        <el-col :span="6" class="text_icon">
          <el-col :span="24">
            <div class="el-icon-user-solid">&nbsp;{{item.userName}}</div>
          </el-col>
          <!-- <el-col :span="12" style="text-align:right"></el-col> -->
        </el-col>
        <el-col :span="18" class="text_main">
          <div class="edit_text">{{item.mainContents}}</div>
          <div>
            <span
              v-for="childItem in item.forumPicDOList"
              :key="childItem.id"
              style="margin-right:10px"
              @click="openPic(childItem.imgUrl)"
            >
              <img width="90" height="90" :src="childItem.imgUrl" alt />
            </span>
          </div>
        </el-col>
        <el-col :span="6" class="text_icon">
          <el-col :span="12">
            <div
              class="el-icon-s-comment mouse-pointer"
              @click="goToForumOpen(item)"
              style="line-height: 24px;"
            >&nbsp;{{item.mainCommentCount}}</div>
          </el-col>
          <el-col :span="12" style="line-height: 24px;text-align:right" v-if="roleType=='INS'">
            <div v-if="item.isTop==='N'" @click="placeOnTop(item)" class="mouse-pointer">
              <el-tag type="success" size="small">置顶</el-tag>
            </div>
            <div v-if="item.isTop==='Y'">
              <el-tag type="info" size="small">已置顶</el-tag>
            </div>
          </el-col>
        </el-col>
        <el-col
          :span="24"
          class="text_main"
          style="line-height: 24px;text-align:right"
        >{{item.mainTime}}</el-col>
      </el-row>
      <el-divider class="mc-divider"></el-divider>
    </div>
    <el-pagination
      small
      class="text-center mt10 control block page-lucency"
      @current-change="handlePage"
      :page-size="5"
      layout="prev, pager, next"
      :total="mainPost.total"
    ></el-pagination>
    <div class="new_post">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span class="blue font-bold">发表新帖</span>
      <div class="post_title">
        <el-input placeholder="请输入标题" size="small" v-model="mainTopic"></el-input>
      </div>
      <div class="post_value">
        <el-input
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 4}"
          v-model="mainContents"
          placeholder="请输入正文"
        ></el-input>
      </div>
      <div style="margin-top:12px">
        <el-upload
          action
          :http-request="uploadFile"
          list-type="picture-card"
          :on-preview="handlePictureCardPreview"
          :on-remove="handleRemove"
          :file-list="fileList"
          :on-change="handleChange"
        >
          <i class="el-icon-plus"></i>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible" :close-on-click-modal="false">
          <img width="100%" :src="dialogImageUrl" alt />
        </el-dialog>
      </div>
      <div class="post_btn">
        <el-button type="primary" @click="saveMainPost" size="mini">发表</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
import config from "@/common/config";
export default {
  name: "ForumDetails",
  computed: {
    ...mapGetters(["forumBaseInfo", "mainPost"])
  },
  data() {
    return {
      imgs:require('../../../assets/imgs/user.png'),
      mainTopic: "",
      mainContents: "",
      dialogImageUrl: "",
      dialogVisible: false,
      limit: 5, //每页几条数据
      offset: 1, //第几页
      forumPicDOList: [],
      fileList: [],
      alreadyTop: {},
      roleType: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).roleType
    };
  },
  created() {
    this.getListMain();
    this.getAlreadyTop();
  },
  methods: {
    ...mapActions(["setForumLeaderboard", "setListMain", "setUserPost"]),
    //获取置顶主贴
    getAlreadyTop() {
      const keywords = {
        projectId: this.$route.query.projectId,
        isTop: "Y"
      };
      http.get("/forum/listMain", keywords).then(res => {
        if (res.code == 0) {
          if (res.data.rows.length > 0) {
            res.data.rows[0].forumPicDOList.map((item, index) => {
              item.imgUrl =
                `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
            });
            this.alreadyTop = res.data.rows[0];
          }
        }
      });
    },
    //主贴置顶
    placeOnTop(item) {
      this.$store.dispatch("loading", true);
      http.get("/forum/getTopById/", item.id).then(res => {
        this.$store.dispatch("loading", false);
        if (res.code == 0) {
          this.$messageSuccess({ message: "成功置顶" });
          this.getAlreadyTop();
          this.getListMain();
        }
      });
    },
    saveMainPost() {
      if (!this.mainTopic.replace(/\s*/g, "")) {
        this.$messageError({ message: "请录入帖子标题！" });
        return;
      }
      if (!this.mainContents.replace(/\s*/g, "")) {
        this.$messageError({ message: "请录入帖子正文！" });
        return;
      }
      const keywords = {
        userId: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).userId,
        userName: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).username,
        projectId: this.$route.query.projectId,
        mainTopic: this.mainTopic,
        mainContents: this.mainContents,
        forumPicDOList: this.forumPicDOList
      };
      this.$store.dispatch("loading", true);
      http.post("/forum/saveMain", keywords).then(res => {
        this.$store.dispatch("loading", false);
        if (res.code == 0) {
          this.mainTopic = "";
          this.mainContents = "";
          this.forumPicDOList = [];
          this.fileList = [];
          this.offset = 1;
          this.getListMain();
          this.getUserPost();
          this.setForumLeaderboard(this.$route.query.projectId);
          this.$messageSuccess({ message: "发表成功" });
        }
      });
    },
    getUserPost() {
      const keywords = {
        userId: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).userId
      };
      this.setUserPost(keywords);
    },
    //查询主贴
    getListMain() {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        projectId: this.$route.query.projectId
      };
      this.setListMain(keywords);
    },
    handleChange(file, fileList) {
      if (file.raw.type.indexOf("image") < 0) {
        this.fileList = fileList.slice(0, fileList.length - 1);
        return;
      }
    },

    uploadFile(param) {
      if (param.file.type.indexOf("image") < 0) {
        this.$messageError({ message: "只能上传图片模式" });
        return;
      }
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "forumPic");
      file.append("projectId", this.$route.query.projectId);
      let keepPic = {
        picType: "1",
        picName: "",
        picPath: "",
        picUidName: param.file.uid,
        projectId: this.$route.query.projectId
      };
      this.$store.dispatch("loading", true);
      this.$api.pictureProcessDoc(file).then(res => {
        this.$store.dispatch("loading", false);
        if (res.code == 0) {
          this.$messageSuccess({ message: "上传成功" });
          keepPic.picPath = res.data.cloudDocId;
          keepPic.picUidName = res.data.uidFileName;
          this.forumPicDOList.push(keepPic);
        } else {
          this.$messageError({ message: res.msg });
        }
      });
    },
    openPic(picUrl) {
      this.dialogImageUrl = picUrl;
      this.dialogVisible = true;
    },
    handleRemove(file, fileList) {
      this.forumPicDOList.map((item, index) => {
        if (file.uid == item.picUidName) {
          this.forumPicDOList.splice(index, 1);
        }
      });
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    //跳转到论坛展开页面
    goToForumOpen(item) {
      this.$router.push({
        path: "/forumOpen",
        query: {
          mainId: item.id, //获取项目ID
          projectId: this.$route.query.projectId
        }
      });
    },
    handlePage(val) {
      //分页
      this.offset = val;
      this.getListMain();
    },
    backMytodo() {
      this.$router.go(-1);
    }
  }
};
</script>
<style scoped lang="scss">
.text_tag {
  display: inline-block;
  background: blue;
  color: white;
  font-size: 11.3px;
  line-height: 18px;
  border-radius: 4px;
  width: 57px;
  text-align: center;
}
.text_title {
  font-size: 13.5px;
  font-weight: 500;
  color: rgba(18, 113, 206, 1);
  cursor: pointer;
}
.text_main {
  font-size: 13.5px;
  font-weight: 500;
  text-align: left;
  line-height: 25px;
}
.text_icon {
  font-size: 13.5px;
  text-align: left;
}
.new_post {
  font-size: 13.5px;
  text-align: left;
  .el-divider--vertical {
    margin: 0 4.5px 1px 0;
    width: 2px;
    background-color: #297ae3;
    height: 0.9em;
  }
}
.post_title {
  margin: 10px 0 10px 0;
}
.post_btn {
  margin: 10px 0 10px 0;
  text-align: right;
}
.edit_text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.mc-divider {
  background: #aaaaaa;
}
.hot_paste {
  border: 1.5px solid #aaaaaa;
  padding: 8px;
  max-height: 200px;
  overflow: auto;
  background: rgba(255, 255, 255, 0.5);
}
.hot_paste_follow {
  border-bottom: 1px dashed #aaaaaa;
}
.fileContent {
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 5px;
    box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    -webkit-box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    background-color: rgba(255, 255, 255, 1);
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    background-color: rgba(158, 159, 160, 0.1);
  }
}
</style>
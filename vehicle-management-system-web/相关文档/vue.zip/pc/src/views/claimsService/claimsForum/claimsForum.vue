<template>
  <div class="content">
    <el-row class="forum_head">
      <el-col :span="18"  style="margin-bottom: 15px;" class="forum_title">
        <span class="forum_title el-icon-arrow-left"
          @click="goToClaimService"
          v-if="this.$route.name=='ForumDetails' || this.$route.name=='ForumOpen'"
        >{{forumBaseInfo.forumInfo.communityName}}</span>
        <span v-else class="el-icon-arrow-left forum_title" @click="goToClaimService">理赔服务</span>
      </el-col>
      <el-col :span="6">
        <el-input
          placeholder="论坛搜索"
          v-if="this.$route.name=='ForumDetails'"
          class="float-right search"
          v-model="fuzzyQuery"
          @keyup.enter.native="forumSearch"
        >
          <el-button slot="append" icon="el-icon-search" @click="forumSearch"></el-button>
        </el-input>
      </el-col>
    </el-row>
    <el-row :gutter="15">
      <el-col :span="17">
        <div class="main_info">
          <router-view style="margin-bottom: 20px"></router-view>
        </div>
      </el-col>
      <el-col :span="7">
        <div class="personal_info">
          <div>
            <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
            <span class="blue font-bold">个人信息</span>
            <el-row style="margin-top:14px">
              <el-col :span="7">
                <img class="manager mouse-pointer" :src="profilePicture ? profilePicture:imgs" width="80" style="height: 80px" />
              </el-col>
              <el-col :span="17" class="form_title">
                <span>昵称：</span>
                {{username}}
                <br />
                <span>发帖数：</span>
                {{forumBaseInfo.userInfo.personalPostNum}}
                <br />
                <span @click="goToMyPost" style="cursor: pointer;">我的贴子</span>
                <br />
                <span @click="goToMessage" style="cursor: pointer;">我的消息</span>
                <br />
                <br />
              </el-col>
            </el-row>
          </div>
          <div>
            <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
            <span class="blue font-bold">论坛信息</span>
            <div class="form_title" style="margin-top:14px">
              <div>
                <span>项目名称：</span>
                {{forumBaseInfo.forumInfo.projectName}}
              </div>
              <div>
                <span>小区名称：</span>
                {{forumBaseInfo.forumInfo.communityName}}
              </div>
              <div>
                <span>承保公司：</span>
                {{forumBaseInfo.forumInfo.orgName}}
              </div>
              <div>
                <span>理赔案件数：</span>
                {{forumBaseInfo.forumInfo.claimCount}}
              </div>
              <div>
                <span>平台服务邮箱：</span>
                {{forumBaseInfo.forumInfo.idiMailValue }}
              </div>
              <div>
                <span>报案电话：</span>
                {{forumBaseInfo.forumInfo.reportTelephone}}
              </div>
              <br />
              <br />
            </div>
          </div>
          <div>
            <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
            <span class="blue font-bold">小区热议榜</span>
            <el-row
              v-for="(item,index) in forumBaseInfo.leaderboard"
              :key="item.id"
              style="line-height: 35px;"
            >
              <div @click="goToForumOpen(item)">
                <el-col :span="2" style="text-align: center;" v-if="item.mainTopic">
                  <span :class="{'leaderboard_red':index==0 || index==1 || index==2}">{{index+1}}</span>
                </el-col>
                <el-col :span="18">{{item.mainTopic}}</el-col>
                <el-col :span="4">{{item.mainCommentCount}}</el-col>
              </div>
            </el-row>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "ClaimsForum",
  computed: {
    ...mapGetters(["forumBaseInfo"])
  },
  data() {
    return {
      imgs:require('../../../assets/imgs/user.png'),
      username: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).username,
      limit: 5, //每页几条数据
      offset: 1, //第几页
      fuzzyQuery: "",
      profilePicture: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo))
        .userImage,
      personalPostNum: 0
    };
  },
  created() {
    this.getPostBaseInfo();
    this.getUserPost();
  },
  methods: {
    ...mapActions([
      "setForumBaseInfo",
      "setForumLeaderboard",
      "setListMain",
      "setUserPost",
      "setFollowPost"
    ]),
    //跳转到论坛展开页面
    goToForumOpen(item) {
      this.$router.push({
        path: "/forumOpen",
        query: {
          mainId: item.id, //获取项目ID
          projectId: this.$route.query.projectId
        }
      });
    },
    //获取论坛基本信息
    getPostBaseInfo() {
      this.setForumBaseInfo(this.$route.query.projectId); //获取小区论坛基本信息
      this.setForumLeaderboard(this.$route.query.projectId).then(res => {
        if (res.data.rows.length > 0) {
          const keywords = {
            offset: 1,
            limit: 10,
            mainId: res.data.rows[0].id
          };
          this.setFollowPost(keywords);
        }
      }); //获取论坛排行版
      this.getUserPost(); //获取个人贴子数
    },
    getUserPost() {
      const keywords = {
        userId: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).userId
      };
      this.setUserPost(keywords);
    },
    forumSearch() {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        projectId: this.$route.query.projectId,
        fuzzyQuery: this.fuzzyQuery
      };
      this.setListMain(keywords);
    },
    goToForumDetails() {
      this.$router.push({
        path: "/forumDetails",
        query: {
          projectId: this.$route.query.projectId
        }
      });
    },
    goToClaimService() {
      this.$router.push({
        path: "/claimsService"
      });
    },
    goToMessage() {
      this.$router.push({
        path: "/myForumMessage",
        query: {
          projectId: this.$route.query.projectId
        }
      });
    },
    goToMyPost() {
      this.$router.push({
        path: "/myForumPost",
        query: {
          projectId: this.$route.query.projectId
        }
      });
    },
    backMytodo() {
      this.$router.go(-1);
    }
  }
};
</script>
<style scoped lang="scss">
$bule: #297ae3 !important;
.search {
  width: 328px;
  margin-bottom: 8px;
  & /deep/ .el-input__inner {
    height: 28px;
    background-color: rgba(255, 255, 255, 0);
    border: 1px solid #a7adb5;
    line-height: 28px;
    border-radius: 0;
    $color: #a7aeb7;
    &::-webkit-input-placeholder {
      color: $color;
    }
    &::-moz-placeholder {
      color: $color;
    }
    &:-ms-input-placeholder {
      color: $color;
    }
  }
  & /deep/ .el-input-group__append {
    background: $bule;
    border-radius: 0;
    border: 0;
    padding: 0 7px;
  }
  & /deep/ .el-button {
    margin: 0;
    padding: 0;
    color: #fff;
    font-size: 19px;
  }
}
.content {
  padding: 11.5px;
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  min-height: 430px;
}
.forum_head {
  border-bottom: 1.5px solid rgba(18, 113, 206, 1);
}
.forum_title {
  font-weight: bold;
  font-size: 16px;
  color: #1271ce;
  text-align: left;
  cursor: pointer;
}
.personal_info {
  background: rgba(255, 255, 255, 0.9);
  margin-top: 12px;
  border-radius: 4px;
  padding: 11.5px;
  text-align: left;
  font-size: 13.5px;
}
.main_info {
  background: rgba(255, 255, 255, 0.9);
  min-height: 300px;
  margin-top: 12px;
  border-radius: 4px;
}
.personal_info .el-divider--vertical {
  margin: 0 4.5px 1px 0;
  width: 2px;
  background-color: #297ae3;
  height: 0.9em;
}
.form_title span {
  color: #1271ce;
  font-weight: 500;
  line-height: 20px;
}
.form_title div {
  margin-top: 12px;
}
.leaderboard_red {
  padding: 0px 5px;
  background-color: #e60012;
  border-radius: 4px;
}
</style>
<template>
  <div style="padding:11.5px 34px 11.5px 34px;text-align: left;">
    <el-row>
      <el-row style="margin-top: 10px;margin-bottom: 15px;">
        <el-col :span="1">
          <span
            @click="backMytodo"
            class="case_title mouse-pointer post_title"
            style="color:#221815"
          >
            <i class="el-icon-arrow-left"></i>
          </span>
        </el-col>
        <el-col :span="21" class="post_title">{{mainPost.mainTopic}}</el-col>
      </el-row>
      <el-col
        :span="24"
        class="post_frequency"
        v-if="mainPost.mainTopic"
      >浏览{{mainPost.mainPointCount}} · 讨论{{mainPost.mainCommentCount}}</el-col>
    </el-row>
    <el-row style="margin-top:25px">
      <el-col :span="3">
        <div class="post_head">
          <img
            class="manager mouse-pointer"
            :src="mainPost.userImage?mainPost.userImage:imgs"
            width="100%"
            height="100%"
          />
        </div>
      </el-col>
      <el-col :span="21">
        <el-col :span="24" class="user_name">{{mainPost.userName}}</el-col>
        <el-col :span="24" class="release_time" v-if="mainPost.mainTime">发布于{{mainPost.mainTime}}</el-col>
        <el-col :span="24" class="text_main">{{mainPost.mainContents}}</el-col>
        <el-col :span="24">
          <div>
            <span
              v-for="childItem in mainPost.forumPicDOList"
              :key="childItem.id"
              style="margin-right:10px"
              @click="openPic(childItem.imgUrl)"
            >
              <img width="90" height="90" :src="childItem.imgUrl" alt />
            </span>
          </div>
        </el-col>
        <el-col :span="22">&nbsp;</el-col>
        <el-col :span="2" class="post_floor">主贴</el-col>
      </el-col>
    </el-row>
    <el-divider class="mc-divider"></el-divider>
    <el-row style="margin-top:25px" v-for="item in followPostList" :key="item.id">
      <el-col :span="3">
        <div class="post_head">
          <img
            class="manager mouse-pointer"
            :src=" item.userImage ? item.userImage :imgs"
            width="100%"
            height="100%"
          />
        </div>
      </el-col>
      <el-col :span="21">
        <el-col :span="24" class="user_name">{{item.userName}}</el-col>
        <el-col :span="24" class="release_time">发布于{{item.followTime}}</el-col>
        <el-col :span="24" class="text_main">{{item.followContents}}</el-col>
        <el-col :span="24">
          <div>
            <span
              v-for="childItem in item.forumPicDOList"
              :key="childItem.id"
              style="margin-right:10px"
              @click="openPic(childItem.imgUrl)"
            >
              <img width="90" height="90" :src="childItem.imgUrl" alt />
            </span>
          </div>
        </el-col>
        <el-col :span="22">
          <el-button
            type="primary"
            size="mini"
            v-if="!item.flag"
            @click="openComment(item,'open')"
          >展开评论</el-button>
          <el-button
            type="primary"
            size="mini"
            v-if="item.flag"
            @click="openComment(item,'close')"
          >收起评论</el-button>
        </el-col>
        <!-- <el-col :span="2" class="post_floor">{{index+2+(offset-1)*limit}}楼</el-col> -->
        <el-col :span="24" v-if="item.flag">
          <div class="post_comment">
            <el-row
              v-for="reItem in item.forumReplyDOList"
              :key="reItem.id"
              style="margin-bottom:12px"
            >
              <el-col :span="2">
                <img
                  class="manager mouse-pointer"
                  :src="reItem.userImage?reItem.userImage:imgs"
                  width="36"
                  height="36"
                />
              </el-col>
              <el-col :span="22" class="post_review">
                <span>{{reItem.userName}}：</span>
                {{reItem.replyContents}}
              </el-col>
              <el-col :offset="16" :span="2" class="post_reply">
                <div @click="replyOther(reItem,item)">&nbsp;回复</div>
              </el-col>
              <el-col :span="6" style="text-align: right;">{{reItem.replyTime}}</el-col>
            </el-row>
            <el-input
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4}"
              v-model="item.replyContents"
              placeholder="请输入正文"
            ></el-input>
            <div class="post_btn">
              <el-button type="primary" size="mini" @click="saveReply(item)">发表</el-button>
            </div>
          </div>
        </el-col>
      </el-col>
      <el-col>
        <el-divider class="mc-divider"></el-divider>
      </el-col>
    </el-row>
    <el-pagination
      small
      class="text-center mt10 control block page-lucency"
      @current-change="handlePage"
      :page-size="limit"
      layout="prev, pager, next"
      :total="total"
    ></el-pagination>
    <div class="new_post">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span class="blue font-bold">发表评论</span>
      <!-- <div class="post_title">
        <el-input placeholder="请输入标题" size="small" v-model="followTopic"></el-input>
      </div>-->
      <div class="post_value">
        <el-input
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 4}"
          v-model="followContents"
          placeholder="请输入正文"
        ></el-input>
      </div>
      <div style="margin-top:12px">
        <el-upload
          action
          :http-request="uploadFile"
          list-type="picture-card"
          :on-preview="handlePictureCardPreview"
          :on-remove="handleRemove"
          :file-list="fileList"
          :on-change="handleChange"
        >
          <i class="el-icon-plus"></i>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible" :close-on-click-modal="false">
          <img width="100%" :src="dialogImageUrl" alt />
        </el-dialog>
      </div>
      <div class="post_btn">
        <el-button type="primary" size="mini" @click="saveFollowReply">发表</el-button>
      </div>
      <el-dialog :visible.sync="dialogVisible" :close-on-click-modal="false">
        <img width="100%" :src="dialogImageUrl" alt />
      </el-dialog>
    </div>
  </div>
</template>
<script>
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
import config from "@/common/config";
export default {
  name: "ForumOpen",
  data() {
    return {
      imgs: require("../../../assets/imgs/user.png"),
      value: "",
      limit: 5, //每页几条数据
      offset: 1, //第几页
      followTopic: "",
      followContents: "",
      mainPost: {},
      followPostList: [],
      total: 0,
      dialogVisible: false,
      dialogImageUrl: "",
      forumPicDOList: [],
      fileList: [],
      replyToReplyId: null,
      replyType: "1"
    };
  },
  watch: {
    $route() {
      this.getMainPost();
      this.getListFollowReply();
    }
  },
  created() {
    this.getMainPost();
    this.getListFollowReply();
  },
  methods: {
    backMytodo() {
      this.$router.go(-1);
    },
    ...mapActions(["setForumLeaderboard", "setFollowPost"]),
    //获取贴子详情
    getListFollowReply() {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        mainId: this.$route.query.mainId
      };

      http.get("/forum/listFollowReply", keywords).then(res => {
        res.data.rows.map((item, index) => {
          if (item.forumReplyDOList.length > 0) {
            item.flag = true;
          } else {
            item.flag = false;
          }

          item.forumPicDOList.map((childItem, index1) => {
            childItem.imgUrl =
              `/api/processDoc/downloadProcessDoc?cloudDocId=${childItem.picPath}&view=1`;
          });
        });
        this.followPostList = res.data.rows;
        this.total = res.data.total;
      });
    },
    //获取主贴
    getMainPost() {
      http
        .get("/forum/getMainPointCount/", this.$route.query.mainId)
        .then(res => {
          if (res.data.forumPicDOList) {
            res.data.forumPicDOList.map((item, index) => {
              item.imgUrl =
                `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
            });
          }
          this.mainPost = res.data;
        });
    },
    //跟帖
    saveFollowReply() {
      if (!this.followContents.replace(/\s*/g, "")) {
        this.$messageError({ message: "请录入跟帖信息！" });
        return;
      }
      const keywords = {
        userId: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo))
          .userId,
        userName: JSON.parse(
          sessionStorage.getItem(this.$getversionData.userInfo)
        ).username,
        projectId: this.$route.query.projectId,
        mainId: this.$route.query.mainId,
        followTopic: this.followTopic,
        followContents: this.followContents,
        forumPicDOList: this.forumPicDOList
      };
      this.$store.dispatch("loading", true);
      http.post("/forum/saveFollow", keywords).then(res => {
        this.$store.dispatch("loading", false);
        if (res.code == 0) {
          this.offset = 1;
          this.getListFollowReply();
          this.setForumLeaderboard(this.$route.query.projectId).then(res => {
            const obj = {
              offset: 1,
              limit: 10,
              mainId: res.data.rows[0].id
            };
            this.setFollowPost(obj);
          });
          this.followContents = "";
          this.fileList = [];
        }
      });
    },
    //对回复的回复
    replyOther(reItem, item) {
      this.replyToReplyId = reItem.id;
      this.replyType = "2";
      this.$set(item, "replyContents", "回复 " + reItem.userName + ":");
      item.replyContents = "回复 " + reItem.userName + "：";
    },
    //对跟帖的回复
    saveReply(reItem) {
      const keywords = {
        replyToReplyId: this.replyToReplyId,
        followId: reItem.id,
        mainId: this.$route.query.mainId,
        userId: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo))
          .userId,
        userName: JSON.parse(
          sessionStorage.getItem(this.$getversionData.userInfo)
        ).username,
        projectId: this.$route.query.projectId,
        replyType: this.replyType,
        replyTopic: "",
        replyContents: reItem.replyContents
      };
      const index=reItem.replyContents.lastIndexOf("：")
      if (keywords.replyContents == ""||keywords.replyContents.slice(index+1)=='') {
        this.$messageError({ message: "请输入内容" });
      } else {
        http.post("/forum/saveReply", keywords).then(res => {
          if (res.code == 0) {
            this.offset = 1;
            this.getListFollowReply();
            this.followContents = "";
          }
        });
      }
    },
    openPic(picUrl) {
      this.dialogImageUrl = picUrl;
      this.dialogVisible = true;
    },
    openComment(item, flag) {
      if (flag == "open") {
        item.flag = true;
      } else if (flag == "close") {
        item.flag = false;
      }
    },
    handlePage(val) {
      //分页
      this.offset = val;
      this.getListFollowReply();
    },
    backMytodo() {
      this.$router.go(-1);
    },
    handleChange(file, fileList) {
      if (file.raw.type.indexOf("image") < 0) {
        this.fileList = fileList.slice(0, fileList.length - 1);
        return;
      }
    },
    uploadFile(param) {
      if (param.file.type.indexOf("image") < 0) {
        this.$messageError({ message: "只能上传图片模式" });
        return;
      }
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "forumPic");
      file.append("projectId", this.$route.query.projectId);
      let keepPic = {
        picType: "2",
        picName: "",
        picPath: "",
        picUidName: param.file.uid,
        projectId: this.$route.query.projectId,
        mainId: this.$route.query.mainId
      };
      this.$store.dispatch("loading", true);
      this.$api.pictureProcessDoc(file).then(res => {
        this.$store.dispatch("loading", false);
        if (res.code == 0) {
          this.$messageSuccess({ message: "上传成功" });
          keepPic.picPath = res.data.cloudDocId;
          this.forumPicDOList.push(keepPic);
        } else {
          this.$messageError({ message: res.msg });
        }
      });
    },
    handleRemove(file, fileList) {
      this.forumPicDOList.map((item, index) => {
        if (file.uid == item.picUidName) {
          this.forumPicDOList.splice(index, 1);
        }
      });
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    }
  }
};
</script>
<style scoped lang="scss">
.post_title {
  font-size: 21px;
  line-height: 40px;
}
.post_frequency {
  font-size: 12.5px;
  font-weight: 400;
  color: rgba(170, 170, 170, 1);
}
.post_head {
  width: 65px;
  height: 65px;
  border-radius: 50%;
  text-align: center;
  overflow: hidden;
}
.user_name {
  font-size: 13.5px;
  font-weight: bold;
  margin-bottom: 16.5px;
}
.release_time {
  font-size: 13.5px;
  margin-bottom: 18px;
}
.text_main {
  font-size: 13.5px;
  margin-bottom: 22px;
  line-height: 25px;
}
.post_comment {
  border: 1px solid #aaaaaa;
  border-radius: 4px;
  padding: 25px 20px 10px 20px;
  font-size: 13.5px;
  margin-top: 15px;
  background: rgba(255, 255, 255, 0.5);
}
.mc-divider {
  background: #aaaaaa;
}
.post_review {
  line-height: 25px;
  min-height: 40px;
  span {
    color: #1271ce;
    font-weight: 500;
  }
}
.post_btn {
  margin: 10px 0 10px 0;
  text-align: right;
}
.post_reply {
  text-align: right;
  color: #1271ce;
  cursor: pointer;
}
.new_post {
  font-size: 13.5px;
  text-align: left;
  .el-divider--vertical {
    margin: 0 4.5px 1px 0;
    width: 2px;
    background-color: #297ae3;
    height: 0.9em;
  }
}
.post_floor {
  font-size: 12.5px;
  text-align: right;
}
.post_value {
  margin-top: 15px;
}
</style>
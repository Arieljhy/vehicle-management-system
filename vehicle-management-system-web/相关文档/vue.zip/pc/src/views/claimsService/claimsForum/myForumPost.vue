<template>
  <div style="padding:11.5px;">
    <div class="my_title">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span class="blue font-bold">我的帖子</span>
    </div>
    <div v-for="item in myPostList" :key="item.id">
      <el-row>
        <el-col :span="18" style="text-align: left;">
          <span @click="goToForumOpen(item)" class="text_title">{{item.mainTopic}}</span>
        </el-col>
        <el-col :span="6" class="text_icon">
          <el-col :span="24">
            <div class="el-icon-user-solid">&nbsp;{{item.userName}}</div>
          </el-col>
          <!-- <el-col :span="12" style="text-align:right"></el-col> -->
        </el-col>
        <el-col :span="18" class="text_main">
          <div class="edit_text">{{item.mainContents}}</div>
        </el-col>
        <el-col :span="6" class="text_icon">
          <el-col :span="12">
            <div
              class="el-icon-s-comment"
              style="line-height: 24px;"
            >&nbsp;{{item.mainCommentCount}}</div>
          </el-col>
          <el-col :span="12" style="line-height: 24px;text-align:right">{{item.mainTime}}</el-col>
        </el-col>
      </el-row>
      <el-divider class="mc-divider"></el-divider>
    </div>
    <el-pagination
      small
      class="text-center mt10 control block page-lucency"
      @current-change="handlePage"
      :page-size="8"
      layout="prev, pager, next"
      :total="total"
    ></el-pagination>
  </div>
</template>
<script>
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
import config from '@/common/config';
export default {
  name: "MyForumPost",
  data() {
    return {
      offset: 1,
      limit: 8,
      myPostList: [],
      total: 0
    };
  },
  created() {
    this.getMyListMain();
  },
  methods: {
    ...mapActions(["setForumBaseInfo", "setForumLeaderboard"]),
    getMyListMain() {
      const keywords = {
        offset: this.offset,
        limit: this.limit,
        userId: JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo)).userId
      };
      http.get("/forum/listMain", keywords).then(res => {
        
        this.myPostList = res.data.rows;
        this.total = res.data.total;
      });
    },
    //跳转到论坛展开页面
    goToForumOpen(item) {
      this.setForumBaseInfo(item.projectId); //获取小区论坛基本信息
      this.setForumLeaderboard(item.projectId); //获取论坛排行版
      this.$router.push({
        path: "/forumOpen",
        query: {
          mainId: item.id, //获取项目ID
          projectId: item.projectId
        }
      });
    },
    handlePage(val) {
      //分页
      this.offset = val;
      this.getMyListMain();
    },
    backMytodo() {
      this.$router.go(-1);
    }
  }
};
</script>
<style scoped lang="scss">
.text_title {
  font-size: 13.5px;
  font-weight: 500;
  color: rgba(18, 113, 206, 1);
  cursor: pointer;
}
.text_icon {
  font-size: 13.5px;
  text-align: left;
}
.text_main {
  font-size: 13.5px;
  font-weight: 500;
  text-align: left;
  line-height: 25px;
}
.mc-divider {
  background: #aaaaaa;
}
.edit_text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.my_title {
  font-size: 13.5px;
  text-align: left;
  margin-bottom: 12px;
  .el-divider--vertical {
    margin: 0 4.5px 1px 0;
    width: 2px;
    background-color: #297ae3;
    height: 0.9em;
  }
}
</style>
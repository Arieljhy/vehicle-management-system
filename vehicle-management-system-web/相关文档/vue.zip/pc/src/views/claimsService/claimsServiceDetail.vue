<template>
  <div style="position: relative">
    <div class="content">
      <el-row>
        <div @click="backClaims" class="case_title mouse-pointer">
          <i class="el-icon-arrow-left"></i>
          <span>理赔服务</span>
        </div>
      </el-row>
      <el-table class="mc-table" tooltip-effect="light" :data="tableData" style="width: 100%">
        <!-- <el-table-column type="index" align="center" label="序号" width="100px"></el-table-column> -->
        <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
        <el-table-column prop="claimItemName" align="center" label="赔偿项目名称"></el-table-column>
        <el-table-column prop="claimTermName" align="center" label="赔偿条款名称"></el-table-column>
        <el-table-column prop="insCaseReportId" align="center" label="报案号"></el-table-column>
        <el-table-column prop="riskBldingsName" align="center" label="报案楼栋门牌号"></el-table-column>
        <el-table-column align="center">
          <template slot-scope="scope">
            <el-dropdown placement="bottom" size="small" trigger="click">
              <i class="el-icon-more"></i>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item
                  icon="el-icon-edit-outline"
                  @click.native="handleClick(scope.row)"
                >详情</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-view"
                  @click.native="goClaims('change', scope.row)"
                  v-if="scope.row.sqlStatus==0"
                >修改</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-remove-outline"
                  v-if="scope.row.sqlStatus==0"
                  @click.native="removeClaimsServiceHandle(scope.row)"
                >删除</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
      <div class="project-collection" @click="goClaims('new')">
        <i class="el-icon-plus"></i>
        <div>新增项目理赔</div>
      </div>
      <el-pagination
        small
        class="page-lucency"
        layout="prev, pager, next"
        :total="this.total"
        :current-page="this.offset"
        :page-size="this.limit"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
export default {
  name: "ClaimsServiceDetail",
  data() {
    return {
      projectId: "",
      val: "",
      // 分页
      total: 0,
      limit: 10, //每页几条数据
      offset: 1, //第几页
      tableData: []
    };
  },
  methods: {
    async claimsDetail() {
      this.projectId = this.$route.query.id;
      const keywords = {
        projectId: this.projectId,
        offset: this.offset,
        limit: this.limit
      };
      const data = await this.$api.projectClaimsDetail(keywords);
      this.tableData = data.data.rows;
      this.total = data.data.total;
    },
    // 返回上一级
    backClaims() {
      this.$router.go(-1);
    },
    // 项目详情
    handleClick(row) {
      this.$router.push({
        path: "/claimsServiceDetailing",
        query: {
          projectId: this.projectId, //项目ID
          id: row.id, //当前数据的ID
          row: JSON.stringify(row),
          claimId: row.claimId
        }
      });
    },
    //删除项目
    async removeClaimsServiceHandle(row) {
      this.$confirm("此操作将删除该信息, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          const res = await this.$api.removeClaimsServiceHandle(
            row.caseReportId
          );
          if (res.code == 0) {
            this.$messageSuccess({
              message: "删除成功"
            });
            this.offset = 1;
            this.claimsDetail();
          } else {
            this.$messageError({
              message: "删除失败 "
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // 新增项目
    goClaims(flag, row) {
      this.$router.push({
        path: "/claimsServiceDetailAdd",
        query: {
          projectId: this.projectId, //项目ID,
          flag:flag,
          row: JSON.stringify(row),
        }
      });
    },
    // 分页
    handleCurrentChange(val) {
      this.offset = val;
      this.claimsDetail();
    }
  },
  created() {
    this.claimsDetail();
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 21.5px;
  bottom: 60px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
// table透明
// .mc-table /deep/ .el-table__row {
//   background-color: rgba(255, 255, 255, 0.1);
// }
// 分页位置
.page-lucency {
  position: absolute;
  right: 40%;
  bottom: 20px;
}
.content {
  background: rgba(255, 255, 255, 0.9);
  min-height: 490px;
  padding: 30px 40px;
}
.case_title {
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #297ae3;
  padding-bottom: 20px;
  .el-icon-arrow-left {
    font-size: 18px;
    font-weight: bold;
    color: #297ae3;
  }
}
</style>
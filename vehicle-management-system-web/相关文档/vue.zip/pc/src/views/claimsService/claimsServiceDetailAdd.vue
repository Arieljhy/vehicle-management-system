<template>
  <div class="content">
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
    </el-col>
    <el-form
      class="mc-form"
      label-width="135px"
      size="mini"
      label-position="left"
      align="left"
      :rules="rules"
      ref="ClaimsData.insClaimDO"
      :model="ClaimsData.insClaimDO"
    >
      <el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="赔偿项目名称：" prop="claimItemName">
              <el-input v-model="ClaimsData.insClaimDO.claimItemName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-form-item label="赔偿条款名称：" prop="claimTermName">
              <el-input v-model="ClaimsData.insClaimDO.claimTermName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="报案号：">
              <el-input v-model="ClaimsData.insCaseReportDO.insCaseReportId"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="报案受理公司：">
              <el-input v-model="ClaimsData.insCaseReportDO.claimHanleCompany"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="报案楼栋门牌号：">
              <span @click="storiedBuilding" @mouseover="mouseover" @mouseleave="mouseleave">
                <el-input v-model="ClaimsData.insCaseReportDO.riskBldingsName" readonly></el-input>
              </span>
                <el-popover
              placement="top"
              width="200"
              trigger="manual"
              :content="ClaimsData.insCaseReportDO.riskBldingsName"
              v-model="visible"
            ></el-popover>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="详细地址：">
              <el-input v-model="ClaimsData.insCaseReportDO.address"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-form-item label="备注：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 4}"
                placeholder="请输入内容"
                v-model="ClaimsData.insClaimDO.remark"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 提交 -->
        <el-col :span="22" class="text-right" style="padding: 63px 0 63.5px 0">
          <el-button size="mini" type="primary" @click="save('ClaimsData.insClaimDO')">保存</el-button>
          <el-button type="primary" @click="submit('ClaimsData.insClaimDO')" size="mini">提交</el-button>
          <el-button size="mini" @click="clock()">关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
    <el-dialog
      title="住宅楼信息"
      :visible.sync="buildingWindows"
      width="900px"
      class="dialog"
      :close-on-click-modal="false"
    >
      <el-row style="border:1px #ccc solid">
        <el-row>
          <el-table
            class="mc-table residence-table"
            :data="residentialBuildingInformation"
            @select="checkedList"
            @select-all="checkedLists"
            ref="multipleTable"
          >
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="buildingName" align="center" label="竣工后楼栋门牌号"></el-table-column>
            <el-table-column prop="unitId" align="center" label="单体编号"></el-table-column>
            <el-table-column prop="unitName" align="center" label="单体名称"></el-table-column>
            <el-table-column prop="buildingType" align="center" label="类别"></el-table-column>
            <el-table-column prop="totalStories" align="center" label="总层数"></el-table-column>
            <el-table-column prop="totalUnits" align="center" label="总户数"></el-table-column>
          </el-table>
        </el-row>
      </el-row>
      <el-pagination
        small
        class="text-center mt10 control block page-lucency"
        @current-change="handleCurrentChangePaging"
        :current-page.sync="offset"
        :page-size="this.limit"
        layout="prev, pager, next"
        :total="this.total"
      ></el-pagination>
      <el-row style="text-align: right; margin-top: 30px" class="btns">
        <el-button size="mini" @click="confirmationBtn()">确定</el-button>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import MessageEdit from "@/components/Message.vue";
import formatInput from "@/components/formatInput";
import { log } from "util";
export default {
  name: "InsuranceTreatyt",
  components: {
    MessageEdit,
    formatInput
  },
  computed: {
    ...mapGetters(["app", "district", "listBaseData", "getBasicBstablish"])
  },
  data() {
    return {
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      endDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      // 校验
      rules: {
        claimItemName: [
          { required: true, message: "请输入项目名称", trigger: "blur" }
        ],
        claimTermName: [
          { required: true, message: "请输入条款名称", trigger: "blur" }
        ]
      },
      // 状态
      preservationState: 0, // 保存状态
      submissionState: 1, // 提交状态
      buildingWindows: false, //单体列表
      newMonomer: {}, //新增单体信息
      residentialBuildingInformation: undefined, //报建信息住宅楼
      limit: 6, //每页几条数据
      offset: 1, //第几页
      total: undefined,
      ClaimsData: {
        insCaseReportDO: {
          sqlStatus: null,
          projectId: "",
          insCaseReportId: "", // 报案号,
          riskBldings: "", // 所属楼栋,
          address: "", // 详情地址
          claimHanleCompany: "" //报案受理公司
        },
        insClaimDO: {
          claimItemName: "", //赔偿项目名称,
          claimTermName: "", //赔偿条款名称,
          remark: "", //备注
          sqlStatus: null
        }
      },
      riskBlding: [],
      riskBldingName: [],
      unitId: [],
      uid: [],
      visible:false
    };
  },
  methods: {
     mouseover() {
      this.visible = true;
    },
    mouseleave() {
      this.visible = false;
    },
    // 保存提交
    //保存按钮
    save(formName) {
      this.ClaimsData.insCaseReportDO.sqlStatus = this.preservationState; //0
      this.ClaimsData.insClaimDO.sqlStatus = this.preservationState; //0
      this.ClaimsData.insCaseReportDO.projectId = this.$route.query.projectId; // 页面id
      this.saveRequest();
    },
    // 提交按钮
    submit(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.ClaimsData.insCaseReportDO.sqlStatus = this.submissionState; // 状态1
          this.ClaimsData.insClaimDO.sqlStatus = this.submissionState; //0
          this.ClaimsData.insCaseReportDO.projectId = this.$route.query.projectId; // 页面id
          this.saveRequest();
        } else {
          this.$messageError({
            message: "请完善信息"
          });
        }
      });
    },
    //保存提交请求
    async saveRequest() {
      this.$store.dispatch("loading", true);
      if (this.$route.query.flag == "new") {
        const res = await this.$api.savePrjClaim(this.ClaimsData);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      } else if (this.$route.query.flag == "change") {
        const res = await this.$api.amendPrjClaim(this.ClaimsData);
        if (res.code == 0) {
          this.$messageSuccess({
            message: res.msg
          });
          this.$router.go(-1);
        } else {
          this.$messageError({
            message: res.msg
          });
        }
      }
      this.$store.dispatch("loading", false);
    },
    // 关闭
    clock() {
      this.$router.go(-1);
    },
    //所属楼栋弹窗
    storiedBuilding() {
      this.buildingWindows = true;
      this.riskRequestForConstruction();
    },
    //确定按钮
    confirmationBtn() {
      this.buildingWindows = false;
      this.ClaimsData.insCaseReportDO.riskBldingsName = this.riskBldingName.join();
    },
    //单个数据添加和删除
    checkedList(rows, row) {
      let isCkeck = rows.findIndex(item => {
        return item.id == row.id;
      });
      if (isCkeck < 0) {
        for (let [index, item2] of this.riskBlding.entries()) {
          if (item2 == row.id) {
            this.$delete(this.riskBlding, index);
            this.$delete(this.riskBldingName, index);
          }
        }
        this.ClaimsData.insCaseReportDO.riskBldingsName = this.riskBldingName.join();
        this.ClaimsData.insClaimDO.riskBldings = this.riskBlding.join();
        this.ClaimsData.insCaseReportDO.riskBldings = this.riskBlding.join();
        this.ClaimsData.insClaimDO.riskBldingsName = this.riskBldingName.join();
      } else {
        if (row.buildingName) {
          this.riskBlding.push(row.id);
          let a = row.buildingName + "(" + row.unitId + ")";
          this.riskBldingName.push(a);
          this.ClaimsData.insCaseReportDO.riskBldings = this.riskBlding.join();
        } else {
          this.riskBlding.push(row.id);
          let a = "(" + row.unitId + ")";
          this.riskBldingName.push(a);
          this.ClaimsData.insCaseReportDO.riskBldings = this.riskBlding.join();
        }
      }
    },
    //多条数据删除和添加
    checkedLists(rows) {
      if (rows && rows.length) {
        for (let item of rows) {
          let flag = false;
          for (let item2 of this.riskBlding) {
            if (item2 == item.id) {
              flag = true;
            }
          }
          if (!flag) {
            if (item.buildingName) {
              this.riskBlding.push(item.id);
              let a = item.buildingName + "(" + item.unitId + ")";
              this.riskBldingName.push(a);
              this.ClaimsData.insCaseReportDO.riskBldings = this.riskBlding.join();
            } else {
              this.riskBlding.push(item.id);
              let a = "(" + item.unitId + ")";
              this.riskBldingName.push(a);
              this.ClaimsData.insCaseReportDO.riskBldings = this.riskBlding.join();
            }
          }
        }
      } else {
        let riskList = this.ClaimsData.insCaseReportDO.riskBldings.split(",");
        for (let item of this.residentialBuildingInformation) {
          for (let [index, item2] of this.riskBlding.entries()) {
            if (item.id == item2) {
              this.$delete(this.riskBlding, index);
              this.$delete(this.riskBldingName, index);
            }
          }
          for (let [index, item3] of riskList.entries()) {
            if (item.id == item3) {
              this.$delete(riskList, index);
            }
          }
        }
        this.ClaimsData.insCaseReportDO.riskBldings = riskList.join();
      }
       this.ClaimsData.insCaseReportDO.riskBldingsName = this.riskBldingName.join();
        this.ClaimsData.insClaimDO.riskBldings = this.riskBlding.join();
        this.ClaimsData.insCaseReportDO.riskBldings = this.riskBlding.join();
        this.ClaimsData.insClaimDO.riskBldingsName = this.riskBldingName.join();
    },
    handleCurrentChangePaging(val) {
      //分页
      this.offset = val;
      this.riskRequestForConstruction();
    },
    async riskRequestForConstruction() {
      const reportBuildingData = {
        projectId: this.$route.query.projectId,
        offset: this.offset,
        limit: this.limit
      };
      const res = await this.$api.buildingInformation(reportBuildingData);
      this.total = res.data.total;
      this.residentialBuildingInformation = res.data.rows;
      if (this.ClaimsData.insCaseReportDO.riskBldings) {
        this.riskBlding = this.ClaimsData.insCaseReportDO.riskBldings.split(
          ","
        );
        this.riskBldingName = this.ClaimsData.insCaseReportDO.riskBldingsName.split(
          ","
        );
        for (var i = 0; i < this.riskBlding.length; i++) {
          if (
            this.riskBlding[i] == "" ||
            this.riskBlding[i] == null ||
            typeof this.riskBlding[i] == undefined
          ) {
            this.riskBlding.splice(i, 1);
            i = i - 1;
          }
        }
        for (let item of this.riskBlding) {
          for (let item2 of this.residentialBuildingInformation) {
            if (item == item2.id) {
              setTimeout(() => {
                this.$refs.multipleTable.toggleRowSelection(item2);
              });
            }
          }
        }
      }
    }
  },
  created() {
    if (this.$route.query.flag && this.$route.query.flag == "change") {
      this.ClaimsData.insCaseReportDO = JSON.parse(this.$route.query.row);
      this.ClaimsData.insClaimDO = JSON.parse(this.$route.query.row);
    }
  }
};
</script>
<style scoped lang="scss" rel="stylesheet/scss">
.content {
  padding: 23px 36.5px;
  background-color: rgba(255, 255, 255, 0.9);
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
  background: rgba(214, 214, 214, 0.2);
}
</style>
<template>
  <div class="hello">
    <div id="w0_window" class="window">
      <h3 class="t">窗口一</h3>
      <div class="c">
        <input type="text" />
      </div>
    </div>
    <!-- <div id="w1_window" class="window">
      <h3 class="t">窗口二</h3>
      <div class="c">
        <button>确认</button>
      </div>
    </div>-->
    <footer>
      <span id="w0" class="dock" lock="false" @click="myclick()">窗口一</span>
      <!-- <span id="w1" class="dock" lock="false">窗口二</span> -->
    </footer>
    <canvas></canvas>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "HelloWorld",
  props: {
    msg: String
  },
  computed: {
    ...mapGetters(["app"])
  },
  data() {
    return {
      canvas: "",
      ctx: ""
    };
  },
  created() {},
  mounted() {
    this.drawer();
  },
  methods: {
    myclick() {
      var w0 = document.getElementById("w0");
      if (w0.getAttribute("lock") === "false") {
        var win = document.getElementById("w0_window");
        var that = this;
        w0.setAttribute("lock", "true");
        this.canvas.width = win.offsetWidth;
        this.canvas.height = w0.parentNode.offsetTop - win.offsetTop;
        this.canvas.style.top = 30 + "%";
        this.canvas.style.zIndex = 1;
        win.style.visibility = "hidden";
        var s1 = 0;
        var s2 = win.offsetLeft + win.offsetWidth;
        var p1 = w0.offsetLeft;
        var p2 = w0.offsetLeft + w0.offsetWidth;
        var cname = w0.className;
        if (cname.indexOf(" folded") === -1) {
          this.scale(s1, s2, p1, p2, "zoomout", function() {
            that.canvas.style.zIndex = -1;
            w0.setAttribute("lock", "false");
          });
          w0.className = cname + " folded";
        } else {
          that.scale(s1, s2, p1, p2, "zoomin", function() {
            that.canvas.style.zIndex = -1;
            win.style.visibility = "visible";
            w0.setAttribute("lock", "false");
          });
          w0.className = cname.replace(" folded", "");
        }
      }
    },
    //动画demo
    drawer() {
      this.canvas = document.querySelector("canvas");
      this.ctx = this.canvas.getContext("2d");
    },
    /**
     * 绘制形状
     * @param s1 {Number} 起点一
     * @param s2 {Number} 起点二
     * @param p1 {Number} 结束点一
     * @param p2 {Number} 结束点二
     */
    draw(s1, s2, p1, p2) {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      this.ctx.beginPath();
      this.ctx.moveTo(s1, 0);
      this.ctx.bezierCurveTo(
        s1,
        this.canvas.height * 0.2,
        p1,
        this.canvas.height * 0.6,
        p1,
        this.canvas.height
      );
      this.ctx.lineTo(p2, this.canvas.height);
      this.ctx.bezierCurveTo(
        p2,
        this.canvas.height * 0.6,
        s2,
        this.canvas.height * 0.2,
        s2,
        0
      );
      this.ctx.lineTo(s1, 0);
      this.ctx.fillStyle = "rgba(0, 0, 0, .2)";
      this.ctx.fill();
    },
    /**
     * 擦除方式
     * @param y {Number}
     * @param speed {Number}
     * @param type 类型，放大或缩小 zoomin、zoomout
     */
    clearRect(y, speed, type) {
      if (type === "zoomout") {
        this.ctx.clearRect(0, y, this.canvas.width, speed);
      } else if (type === "zoomin") {
        this.ctx.clearRect(0, 0, this.canvas.width, y);
      }
    },
    /**
     * 缩放效果
     * @param s1 {Number} 起点一
     * @param s2 {Number} 起点二
     * @param p1 {Number} 结束点一
     * @param p2 {Number} 结束点二
     * @param type {String} 类型，放大或缩小 zoomin、zoomout
     */
    scale(s1, s2, p1, p2, type, callback) {
      const that = this;
      var dist1 = Math.abs(p1 - s1);
      var dist2 = Math.abs(p2 - s2);
      var d1, d2, _p1, _p2, speed1, y, speed2;
      if (dist1 === 0 || dist2 === 0) {
        dist1 = 1;
        dist2 = 1;
      }
      speed1 = 30;
      speed2 = 30;
      if (type === "zoomout") {
        d1 = p1 >= s1 && p1 < speed1 ? 0 : p1 < s1 ? -speed1 : speed1;
        d2 = p2 < s2 ? (-speed1 * dist2) / dist1 : (speed1 * dist2) / dist1;
        _p1 = s1;
        _p2 = s2;
        y = 0;
        var t = setInterval(function() {
          if (_p2 - _p1 <= p2 - p1) {
            clearInterval(t);
            var timer = setInterval(function() {
              if (y > that.canvas.height) {
                clearInterval(timer);
                callback && callback();
              }
              that.clearRect(y, speed2, type);
              y += speed2;
              speed2 += 1;
            }, 17);
          }
          that.draw(s1, s2, _p1, _p2);
          _p1 += d1;
          _p2 += d2;
          if ((d1 < 0 && _p1 <= p1) || (d1 > 0 && _p1 >= p1)) {
            _p1 = p1;
          }
          if ((d2 < 0 && _p2 <= p2) || (d2 > 0 && _p2 >= p2)) {
            _p2 = p2;
          }
        }, 17);
      } else if (type === "zoomin") {
        d1 = p1 >= s1 && p1 < speed1 ? 0 : p1 < s1 ? speed1 : -speed1;
        d2 = p2 < s2 ? (speed1 * dist2) / dist1 : (-speed1 * dist2) / dist1;
        _p1 = p1;
        _p2 = p2;
        y = that.canvas.height;
        var timer = setInterval(function() {
          if (y <= 0) {
            clearInterval(timer);
            var t = setInterval(function() {
              if (_p2 - _p1 >= s2 - s1) {
                clearInterval(t);
                callback && callback();
              }
              that.draw(s1, s2, _p1, _p2);
              _p1 += d1;
              _p2 += d2;
            }, 17);
          }
          that.draw(s1, s2, _p1, _p2);
          that.clearRect(y, speed2, type);
          y -= speed2;
          speed2 += 1;
        }, 17);
      }
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
// html,body{margin:0;padding:0;height:100%;background:#69C;font:14px/1.5 sans-serif;}
.window {
  border: 1px solid #888;
  background: #fff;
  box-shadow: 0 0 2em rgba(0, 0, 0, 0.3);
}
.window > .t {
  margin: 0;
  padding: 0.3em;
  border-bottom: 1px solid #888;
  background: #ccc;
}
.window > .c {
  padding: 0.3em;
  min-height: 15em;
}
footer {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 3em;
  background: rgba(0, 0, 0, 0.2);
}
.dock {
  display: inline-block;
  margin: 0.3em;
  width: 5em;
  height: 2.4em;
  line-height: 2.4em;
  text-align: center;
  color: #fff;
  background: rgba(0, 0, 0, 0.6);
  cursor: pointer;
}
.dock:first-child {
  margin-right: 0;
}
.folded {
  background: rgba(0, 0, 0, 0.3);
}
footer > span:last-child {
  color: #69c;
}
#w0_window {
  position: absolute;
  // left: 5%;
  top: 30%;
  width: 100%;
  height: 70%;
}
// #w1_window {
//   position: absolute;
//   right: 8%;
//   top: 5%;
//   width: 60%;
//   height: 50%;
// }
canvas {
  position: absolute;
  z-index: -1;
}
</style>

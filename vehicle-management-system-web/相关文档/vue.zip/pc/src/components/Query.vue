<template>
  <div class="text-left">
    <div style="font-size: 14.5px; margin-top: 9px" class="blue font-bold">项目筛选条件（高级查询）</div>
    <div style="font-size: 12.5px;" class="blue font-bold mt10">项目区域</div>
    <el-row style="font-size: 12.5px">
      <el-col
        class="font-bold"
        style="margin: 13px 0 8.5px 0"
        :span="24"
      >{{$getversionData.province}}</el-col>
      <el-col :span="24">
        <div
          class="inline-block area mouse-pointer"
          @click="handleQuery({item,type:'district'})"
          :class="{'checked': item.check}"
          v-for="item of areas"
          :key="item.code"
        >{{item.value}}</div>
      </el-col>
      <!-- <el-col class="font-bold" style="margin-bottom: 13.5px" :span="24">北京市辖</el-col>
      <el-col :span="24">
        <div
          class="inline-block area mouse-pointer"
          @click="item.check = !item.check"
          :class="{'checked': item.check}"
          v-for="item of areas2"
          :key="item.code"
        >{{item.value}}</div>
      </el-col>-->
      <el-col
        class="blue font-bold"
        style="margin-bottom: 8px"
        :span="24"
        v-if="roleType!=='TIS'"
      >平米平均造价</el-col>
      <el-col :span="24" v-if="roleType!=='TIS'">
        <el-input
          size="mini"
          class="price"
          v-model="queryData.minCostPerMeter"
          placeholder="最低价"
          @blur="handleQuery"
        ></el-input>
        <span style="margin-left:7.75px">-</span>
        <el-input
          size="mini"
          class="price"
          @blur="handleQuery"
          v-model="queryData.maxCostPerMeter"
          style="margin: 0 0 16px 7.75px"
          placeholder="最高价"
        ></el-input>
      </el-col>
      <el-col
        class="blue font-bold"
        style="margin-bottom: 8px"
        :span="24"
        v-if="roleType!=='TIS'"
      >保费区间</el-col>
      <el-col :span="24" v-if="roleType!=='TIS'">
        <el-input
          size="mini"
          class="price"
          v-model="queryData.minTotalPremium"
          placeholder="最低价"
          @blur="handleQuery"
        ></el-input>
        <span style="margin-left:7.75px">-</span>
        <el-input
          size="mini"
          class="price"
          @blur="handleQuery"
          v-model="queryData.maxTotalPremium"
          style="margin: 0 0 16px 7.75px"
          placeholder="最高价"
        ></el-input>
      </el-col>
      <el-col
        class="blue font-bold"
        style="margin-bottom: 8px"
        :span="24"
        v-if="roleType!=='TIS'"
      >承保面积</el-col>
      <el-col :span="24" v-if="roleType!=='TIS'">
        <el-input
          size="mini"
          class="price"
          v-model="queryData.minTotalFloorage"
          placeholder="最小值"
          @blur="handleQuery"
        ></el-input>
        <span style="margin-left:7.75px">-</span>
        <el-input
          size="mini"
          class="price"
          @blur="handleQuery"
          v-model="queryData.maxTotalFloorage"
          style="margin: 0 0 16px 7.75px"
          placeholder="最大值"
        ></el-input>
      </el-col>
      <el-col class="blue font-bold" style="margin-bottom: 7px" :span="24">签单时间</el-col>
      <el-col :span="24">
        <el-date-picker
          class="date"
          type="date"
          @change="handleQuerys"
          :picker-options="pickerOptionsStart"
          value-format="yyyy-MM-dd HH:mm:ss"
          v-model="queryData.beginSignDate"
          placeholder="签单起期"
        ></el-date-picker>
        <span style="margin-left:7.75px">-</span>
        <el-date-picker
          class="date"
          style="margin: 0 0 16px 7.75px"
          type="date"
          @change="handleQuerys"
          :picker-options="pickerOptionsEnd"
          value-format="yyyy-MM-dd 23:59:59"
          v-model="queryData.endSignDate"
          placeholder="签单止期"
        ></el-date-picker>
      </el-col>
      <el-col
        class="blue font-bold"
        style="margin-bottom: 7px"
        :span="24"
        v-if="roleType!=='TIS'"
      >保单生效起期</el-col>
      <el-col :span="24" v-if="roleType!=='TIS'">
        <el-date-picker
          class="date"
          type="date"
          @change="handleQuerys"
          :picker-options="minBeginPolicyStart"
          value-format="yyyy-MM-dd HH:mm:ss"
          v-model="queryData.minBeginPolicyDate"
          placeholder="生效起期"
        ></el-date-picker>
        <span style="margin-left:7.75px">-</span>
        <el-date-picker
          class="date"
          style="margin: 0 0 16px 7.75px"
          type="date"
          @change="handleQuerys"
          :picker-options="maxBeginPolicyEnd"
          value-format="yyyy-MM-dd 23:59:59"
          v-model="queryData.maxBeginPolicyDate"
          placeholder="生效止期"
        ></el-date-picker>
      </el-col>
      <el-col
        class="blue font-bold"
        style="margin-bottom: 7px"
        :span="24"
        v-if="roleType!=='TIS'"
      >保单生效止期</el-col>
      <el-col :span="24" v-if="roleType!=='TIS'">
        <el-date-picker
          class="date"
          type="date"
          @change="handleQuerys"
          :picker-options="beginPolicyStart"
          value-format="yyyy-MM-dd HH:mm:ss"
          v-model="queryData.minEndPolicyDate"
          placeholder="生效起期"
        ></el-date-picker>
        <span style="margin-left:7.75px">-</span>
        <el-date-picker
          class="date"
          style="margin: 0 0 16px 7.75px"
          type="date"
          @change="handleQuerys"
          :picker-options="beginPolicyEnd"
          value-format="yyyy-MM-dd 23:59:59"
          v-model="queryData.maxEndPolicyDate"
          placeholder="生效止期"
        ></el-date-picker>
      </el-col>
      <el-col class="blue font-bold" style="margin-bottom: 14.5px" :span="24">项目进度</el-col>
      <el-col :span="24">
        <div
          class="inline-block area mouse-pointer"
          style="color: #000"
          @click="handleQuery({item,type:'projectStatus'})"
          :class="{'checked': item.check}"
          v-for="item of projectProgress"
          :key="item.code"
        >{{item.value}}</div>
      </el-col>
      <el-col
        class="blue font-bold"
        style="margin-bottom: 14px"
        :span="24"
        v-if="roleType!=='INS'"
      >承保公司</el-col>
      <el-col :span="24" v-if="roleType!=='INS'">
        <div
          class="inline-block area mouse-pointer"
          style="color: #000"
          @click="handleQuery({item,type:'orgIds'})"
          :class="{'checked': item.check}"
          v-for="item of insOrgList"
          :key="item.orgId"
        >{{item.orgName}}</div>
      </el-col>
    </el-row>
    <div
      v-if="add && control.includes('projectInquirySupplement')&&roleType=='INS'"
      class="project-collection mouse-pointer"
      @click="handleBtn"
    >
      <i class="el-icon-plus"></i>
      <div>项目补录</div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { projectProgress } from "@/assets/js/codes";
import http from "@/common/request";
export default {
  name: "Query",
  data() {
    return {
      insOrgList: [],
      roleType: "",
      pickerOptionsStart: {
        disabledDate: time => {
          if (this.queryData.endSignDate) {
            return (
              time.getTime() > new Date(this.queryData.endSignDate).getTime()
            );
          }
        }
      },
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.queryData.beginSignDate) {
            return (
              time.getTime() < new Date(this.queryData.beginSignDate).getTime()
            );
          }
        }
      },
      beginPolicyStart: {
        disabledDate: time => {
          if (this.queryData.maxEndPolicyDate) {
            return (
              time.getTime() > new Date(this.queryData.maxEndPolicyDate).getTime()
            );
          }
        }
      },
      beginPolicyEnd: {
        disabledDate: time => {
          if (this.queryData.minEndPolicyDate) {
            return (
              time.getTime() <
              new Date(this.queryData.minEndPolicyDate).getTime()
            );
          }
        }
      },
      minBeginPolicyStart: {
        disabledDate: time => {
          if (this.queryData.maxBeginPolicyDate) {
            return (
              time.getTime() > new Date(this.queryData.maxBeginPolicyDate).getTime()
            );
          }
        }
      },
      maxBeginPolicyEnd: {
        disabledDate: time => {
          if (this.queryData.minBeginPolicyDate) {
            return (
              time.getTime() <
              new Date(this.queryData.minBeginPolicyDate).getTime()
            );
          }
        }
      },
      projectProgress: projectProgress.map(item => ({ ...item })),
      queryData: {
        province: this.$getversionData.province,
        city: this.$getversionData.city,
        district: new Set(),
        minCostPerMeter: "",
        maxCostPerMeter: "",
        beginSignDate: "",
        endSignDate: "",
        minBeginPolicyDate: "",
        maxBeginPolicyDate: "",
        minEndPolicyDate: "",
        maxEndPolicyDate: "",
        minTotalPremium: "",
        maxTotalPremium: "",
        minTotalFloorage: "",
        maxTotalFloorage: "",
        orgIds: new Set(),
        projectStatus: new Set() //项目进度
      },
      areas: []
    };
  },
  props: {
    add: {
      type: Boolean,
      default: false,
      required: false
    },
    title: {
      type: String,
      required: true
    }
  },
  created() {
    this.roleType = JSON.parse(
      sessionStorage.getItem(this.$getversionData.userInfo)
    ).roleType;
    //查询保险公司二级机构作为筛选条件：承保公司
    const keywords = { orgLevel: "二级", orgType: "INS" };
    http.get("/sysconfig/Org/likelist", keywords).then(res => {
      if (res.code === 0) {
        this.insOrgList = res.data.rows;
      }
    });
    this.districts();
  },
  computed: {
    ...mapGetters(["control"])
  },
  methods: {
    //获取省市县
    districts() {
      http.get("/sysconfig/DictionaryData/listAreaData").then(res => {
        if (res.code === 0) {
          this.areas = res.data[0].city[0].area;
          this.areas.map((item, index) => {
            (item.value = item.district),
              (item.check = false),
              (item.code = index + 1);
          });
        }
      });
    },
    handleBtn() {
      this.$router.push("/addNewProject");
    },
    handleQuery({ item, type }) {
      if (item) {
        if (type === "orgIds") {
          this.$set(item, "check", !item.check);
        } else if (type === "district") {
          this.areas.map((item1, index) => {
            if (item == item1) {
              item1.check = !item.check;
              this.$set(this.areas, index, item1);
            }
          });
        } else {
          item.check = !item.check;
        }
        if (item.check) {
          this.queryData[type].add(type === "orgIds" ? item.orgId : item.value);
        } else {
          this.queryData[type].delete(
            type === "orgIds" ? item.orgId : item.value
          );
        }
      }
      const { district, orgIds, projectStatus } = this.queryData;
      // this.$store.dispatch(`set${this.title}QueryParams`, {
      //   ...this.queryData,
      //   district: Array.from(district),
      //   insOrgId: Array.from(insOrgId),
      //   projectStatus: Array.from(projectStatus)
      // });
      if (this.queryData.minCostPerMeter && this.queryData.maxCostPerMeter) {
        if (
          parseFloat(this.queryData.minCostPerMeter) >
          parseFloat(this.queryData.maxCostPerMeter)
        ) {
          this.queryData.minCostPerMeter = "";
          this.queryData.maxCostPerMeter = "";
          this.$messageError({
            message: "平米平均造价最低价不能高于最高价!"
          });
          return;
        }
      }
      if (this.queryData.minTotalPremium && this.queryData.maxTotalPremium) {
        if (
          parseFloat(this.queryData.minTotalPremium) >
          parseFloat(this.queryData.maxTotalPremium)
        ) {
          this.queryData.minTotalPremium = "";
          this.queryData.maxTotalPremium = "";
          this.$messageError({
            message: "保费区间最低价不能高于最高价!"
          });
          return;
        }
      }
      if (this.queryData.minTotalFloorage && this.queryData.maxTotalFloorage) {
        if (
          parseFloat(this.queryData.minTotalFloorage) >
          parseFloat(this.queryData.maxTotalFloorage)
        ) {
          this.queryData.minTotalFloorage = "";
          this.queryData.maxTotalFloorage = "";
          this.$messageError({
            message: "承保面积最小值不能高于最大值!"
          });
          return;
        }
      }
      this.$emit("doQuery", {
        isFresh: true,
        queryParams: {
          ...this.queryData,
          district: Array.from(district),
          orgIds: Array.from(orgIds),
          projectStatus: Array.from(projectStatus)
        }
      });
    },
    handleQuerys() {
      const { district, orgIds, projectStatus } = this.queryData;
      if (this.queryData.beginSignDate == null)
        this.queryData.beginSignDate = "";
      if (this.queryData.endSignDate == null) this.queryData.endSignDate = "";
      if (this.queryData.minBeginPolicyDate == null)
        this.queryData.minBeginPolicyDate = "";
      if (this.queryData.maxBeginPolicyDate == null)
        this.queryData.maxBeginPolicyDate = "";
        if (this.queryData.minEndPolicyDate == null)
        this.queryData.minEndPolicyDate = "";
      if (this.queryData.maxEndPolicyDate == null)
        this.queryData.maxEndPolicyDate = "";
      this.$emit("doQuery", {
        isFresh: true,
        queryParams: {
          ...this.queryData,
          district: Array.from(district),
          orgIds: Array.from(orgIds),
          projectStatus: Array.from(projectStatus)
        }
      });
    }
  }
};
</script>
<style scoped lang="scss">
.project-collection {
  position: absolute;
  right: 26.5px;
  // bottom: 28px;
  top: 460.5px;
  height: 76.5px;
  width: 76.5px;
  background-color: #4781ca;
  border-radius: 8px;
  color: #e2e2e2;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  div {
    font-weight: bold;
    font-size: 12px;
  }
  i {
    padding: 6px 0;
    font-size: 26px;
    font-weight: bold;
  }
}
$blue: #297ae3;
.checked {
  background-color: $blue;
  color: #fff !important;
  border-radius: 15px;
}
.ti-query {
  font-size: 14px;
  color: $blue;
  font-weight: bold;
}
.ti-area {
  font-weight: bold;
  font-size: 13px;
  margin-top: 10px;
}
.font-size13 {
  font-size: 13px;
}
$color: rgba(62, 58, 57, 1);
.area {
  color: $color;
  padding: 2px 6px;
  // margin: 0 12.5px 8.5px 0;
  margin: 0 2.5px 10px 0;
}
.price {
  /deep/ .el-input__inner {
    height: 22px !important;
    opacity: 0.68;
    border-radius: 1px;
    line-height: 22px !important;
  }
  //width: 76px;
  width: 140px;
}
.date {
  width: 140px;
  /deep/ .el-input__icon {
    color: #297ae3 !important;
  }
  /deep/ .el-input__inner {
    border-radius: 1px;
    opacity: 0.68;
    height: 22px !important;
    line-height: 22px !important;
  }
  /deep/ .el-input__prefix {
    top: -9px;
    left: 0;
  }
  /deep/ .el-input__suffix {
    right: 0;
    top: -9px;
  }
}
</style>
<template>
  <div>
    <el-row class="news">
      <el-col v-if="hasNews" :span="24">
        <el-col :span="18" style="text-align: left;white-space: nowrap">
          <el-carousel
            height="20px"
            indicator-position="none"
            :interval="5000"
            direction="vertical"
            :autoplay="true"
          >
            <img
              style="height: 18px;width: 20px;position: relative;top: 3px;"
              src="../assets/imgs/projectInquiry/tongzhi.png"
            />
            <el-carousel-item :key="item.id" v-for="item of tips">
              <div
                @click="query(item)"
                style="position: relative; left: 36px;font-size:14px;letter-spacing:1px;
              text-overflow:ellipsis;white-space:nowrap;overflow:hidden;width:800px;"
                class="white mouse-pointer"
              >{{item.message}}</div>
            </el-carousel-item>
          </el-carousel>
        </el-col>
        <el-col
          :span="6"
          v-if="$route.meta.upload && control.includes('myToDoInsuranceAudit')&&showRiskPage!='riskEvent'&&!filterCriteria"
          class="text-right mouse-pointer"
        >
          <div @click="showDialog">
            <img style="width: 18px;position: relative;top: 6px;" src="../assets/imgs/tianjia.png" />
            <span class="white">点击上传风险报告</span>
          </div>
        </el-col>
      </el-col>
      <el-col :span="22" v-if="!hasNews"></el-col>
      <el-col
        :span="2"
        v-if="($route.meta.screen && showFilter=='mytodo' ||showFilter=='mytodoList'||showRiskPage=='riskEvent')
        &&!filterCriteria&&($route.path=='/riskManagement'||$route.path=='/myToDo'||$route.path=='/myToDoRisk'
        ||$route.path=='/myToDoRun')"
        class="text-right middle"
      >
        <el-popover placement="bottom-end" trigger="manual" width="264" v-model="visible">
          <el-form ref="form" label-width="80px">
            <el-col class="filter_title" :span="24" v-if="$route.path=='/riskManagement'">发生日期:</el-col>
            <el-col :span="24" v-if="$route.path=='/riskManagement'">
              <el-col :span="11">
                <el-date-picker
                  type="date"
                  v-model="caseFilter.minRiskFoundTime"
                  placeholder="发生起期"
                  style="width: 100%;"
                  :picker-options="pickerOptionsStart"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  size="mini"
                ></el-date-picker>
              </el-col>
              <el-col class="line" :span="2">-</el-col>
              <el-col :span="11">
                <el-date-picker
                  type="date"
                  :picker-options="pickerOptionsEnd"
                  v-model="caseFilter.maxRiskFoundTime"
                  placeholder="发生止期"
                  style="width: 100%;"
                  value-format="yyyy-MM-dd 23:59:59"
                  size="mini"
                ></el-date-picker>
              </el-col>
            </el-col>
            <el-col :span="24" class="filter_title jg_line"  v-if="$route.path=='/riskManagement'">风险事件类型</el-col>
            <el-col :span="24"  v-if="$route.path=='/riskManagement'">
              <div
                class="inline-block area mouse-pointer"
                @click="riskEventType(item,index)"
                :class="item.check?'checked':''"
                v-for="(item,index) in riskEventTypeList"
                :key="index"
              >{{item.dictValue}}</div>
            </el-col>
            <el-col :span="24" class="filter_title jg_line"  v-if="$route.path=='/riskManagement'">风险等级</el-col>
            <el-col :span="24"  v-if="$route.path=='/riskManagement'">
              <div
                class="inline-block area mouse-pointer"
                @click="riskLevel(item,index)"
                :class="item.check?'checked':''"
                v-for="(item,index) in riskLevelList"
                :key="index"
              >{{item.dictValue}}</div>
            </el-col>
            <el-col :span="24" class="filter_title" v-if="$route.path!='/riskManagement'">项目区域</el-col>
            <el-col :span="24"  v-if="$route.path!='/riskManagement'">
              <el-select
                disabled
                placeholder="请选择"
                v-model="caseFilter.province"
                size="mini"
                @change="getCity(caseFilter.province,'city')"
                style="width:230px"
              >
                <el-option
                  v-for="item in district"
                  :key="item.province"
                  :label="item.province"
                  :value="item.province"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="24"  v-if="$route.path!='/riskManagement'">
              <el-select
                placeholder="请选择"
                v-model="caseFilter.city"
                size="mini"
                @change="getCity(caseFilter.city, 'county')"
                style="width:230px;margin-top:8px"
              >
                <el-option
                  v-for="item in getCitys"
                  :key="item.name"
                  :label="item.name"
                  :value="item.name"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="24"  v-if="$route.path!='/riskManagement'">
              <el-select
                placeholder="请选择"
                v-model="caseFilter.district"
                size="mini"
                style="width:230px;margin-top:8px"
              >
                <el-option
                  v-for="item in countys"
                  :key="item.district"
                  :label="item.district"
                  :value="item.district"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="24" class="filter_title jg_line"  v-if="$route.path!='/riskManagement'">平米平均造价</el-col>
            <el-col :span="24"  v-if="$route.path!='/riskManagement'">
              <el-col :span="11">
                <el-input v-model="caseFilter.minCostPerMeter" size="mini"></el-input>
              </el-col>
              <el-col class="line" :span="2">-</el-col>
              <el-col :span="11">
                <el-input size="mini" v-model="caseFilter.maxCostPerMeter"></el-input>
              </el-col>
            </el-col>
            <el-col :span="24" class="filter_title jg_line"  v-if="$route.path!='/riskManagement'">签单时间</el-col>
            <el-col :span="24"  v-if="$route.path!='/riskManagement'">
              <el-col :span="11">
                <el-date-picker
                  type="date"
                  :picker-options="beginSignDateStart"
                  placeholder="签单起期"
                  v-model="caseFilter.beginSignDate"
                  style="width: 100%;"
                  value-format="yyyy-MM-dd"
                  size="mini"
                ></el-date-picker>
              </el-col>
              <el-col class="line" :span="2">-</el-col>
              <el-col :span="11">
                <el-date-picker
                  type="date"
                   :picker-options="beginSignDateEnd"
                  placeholder="签单止期"
                  v-model="caseFilter.endSignDate"
                  style="width: 100%;"
                  value-format="yyyy-MM-dd"
                  size="mini"
                ></el-date-picker>
              </el-col>
            </el-col>
            <el-col
              v-if="this.$route.name != 'MyToDoRisk'&&$route.path!='/riskManagement'"
              :span="24"
              class="filter_title jg_line"
            >是否主承</el-col>
            <el-col v-if="this.$route.name != 'MyToDoRisk'&&$route.path!='/riskManagement'" :span="24">
              <el-form-item
                class="formItem"
                style="margin-bottom: 0;"
                label="非主承:"
                prop="isMainIns"
              >
                <el-checkbox v-model="isMainIns"></el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="24" class="filter_title jg_line"  v-if="$route.path!='/riskManagement'">住宅性质</el-col>
            <el-col :span="24"  v-if="$route.path!='/riskManagement'">
              <div
                class="inline-block area mouse-pointer"
                @click="residentClick(item,index)"
                :class="item.check?'checked':''"
                v-for="(item,index) in residentialNature"
                :key="index"
              >{{item.dictValue}}</div>
            </el-col>
            <el-col
              :span="24"
              class="filter_title jg_line"
              v-if="this.$route.name == 'MyToDoRun' || this.$route.name == 'MyToDoRisk'"
            >承保公司</el-col>
            <el-col
              :span="24"
              v-if="this.$route.name == 'MyToDoRun'  || this.$route.name == 'MyToDoRisk'"
            >
              <div
                class="inline-block area mouse-pointer"
                v-for="item1 of insOrgList"
                @click="item1.select = !item1.select"
                :class="{'checked': item1.select}"
                :key="item1.orgId"
              >{{item1.orgName}}</div>
            </el-col>
          </el-form>
          <div style="text-align: right; margin: 0">
            <el-button size="mini" type="info" @click="visibles" style="margin-top: 10px;">取消</el-button>
            <el-button size="mini" type="warning" @click="reset">重置</el-button>
            <el-button type="primary" size="mini" @click="filterMytodo()">确定</el-button>
          </div>
          <div
            slot="reference"
            @click="visible = !visible;openvisible()"
            class="mouse-pointer"
            style="margin-top: 15px;"
          >
            <img
              src="../assets/imgs/todo/filter.png"
              alt="screen"
              style="width:18px;position: relative;top: 3px;right: 8px;"
            />
            <span>筛选</span>
          </div>
        </el-popover>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import http from "@/common/request";
export default {
  name: "MessageEdit",
  computed: {
    ...mapGetters([
      "hasNews",
      "control",
      "district",
      "getCitys",
      "getOrgId",
      "tips",
      "showRiskPage",
      "insOrgList",
      "showFilter",
      "listBaseData",
      "fuzzyQuery",
      'filterCriteria'
    ]),
    listenshowpage1() {
      return this.$store.state.riskManagement.showRiskPage;
    }
  },
  data() {
    return {
      pickerOptionsStart: {
        disabledDate: time => {
          if (this.caseFilter.maxRiskFoundTime) {
            return time.getTime() > new Date(this.caseFilter.maxRiskFoundTime).getTime();
          }
        }
      },
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.caseFilter.minRiskFoundTime) {
            return time.getTime() < new Date(this.caseFilter.minRiskFoundTime).getTime();
          }
        }
      },
   beginSignDateStart: {
        disabledDate: time => {
          if (this.caseFilter.endSignDate) {
            return time.getTime() > new Date(this.caseFilter.endSignDate).getTime();
          }
        }
      },
      beginSignDateEnd: {
        disabledDate: time => {
          if (this.caseFilter.beginSignDate) {
            return time.getTime() < new Date(this.caseFilter.beginSignDate).getTime();
          }
        }
      },
      types: "IDI_PROJECT_TYPES",
      citys: [],
      countys: [],
      visible: false,
      isMainIns: false,
      caseFilter: {
        isMainIns: "",
        province: this.$getversionData.province,
        district: "",
        city: "",
        taskName: "", //录入保险审核信息  审核风控管理计划  录入竣工信息
        minCostPerMeter: "",
        maxCostPerMeter: "",
        beginSignDate: "",
        endSignDate: "",
        buildingType: new Set(),
        projectName: "",
        insContractNo: "",
        fuzzyQuery: "",
        offset: 1,
        limit: 8,
        orgId: "",
        riskEventType: new Set(),
        riskLevel: new Set(),
        minRiskFoundTime: "",
        maxRiskFoundTime: ""
      },
      residentialNature: [],
      riskEventTypeList: [],
      riskLevelList: [],
      //承保公司
      contractingCompany: [],
      myTips: null
    };
  },
  watch: {
    listenshowpage1() {
      if (this.$store.state.riskManagement.showRiskPage == "riskReport") {
        this.visible = false;
      }else{
        this.visible = false;
        this.reset();
      }
    },
    //监听路由变化，关闭筛选弹框
    $route(to, from) {
      if (from.path == "/myToDo" || from.path == "/myToDoRun") {
        this.visible = false;
      }
      if (from.path == "/myToDo") {
        this.$EventBus.$emit("LOCK_EVENT");
      }
      if (from.path == "/riskReportManagement"||from.path == "/riskManagement") {
        // this.changeRiskPage("riskReport");
        this.visible = false;
        // this.reset();
      }else{
        // this.changeRiskPage("riskReport");
        this.visible = false;
        this.reset();
      }
    },
    showFilter() {
      this.visible = false;
    }
  },
  mounted() {
    this.$EventBus.$on("TIPS_EVENT", () => {
      clearInterval(this.myTips);
      console.log("关闭语音！");
    });
  },
  created() {
    this.getTips({ read: 0 });
    //10分钟查询一下消息
    this.myTips = setInterval(() => {
      this.getTips({ read: 0 });
    }, 600000);
    // this.getOrgId.insOrgList.map((item, index) => {
    //   item.select = false;
    // });

    // http.get("/sysconfig/Org/listTree", { orgType: "INS" }).then(res => {
    //   if (res.data.length > 0)
    //     if (res.data[0].childrens) {
    //       this.getInsOrgList(res.data[0].childrens);
    //     }
    // });
    http
      .get("/sysconfig/Org/likelist", { orgLevel: "二级", orgType: "INS" })
      .then(res => {
        if (res.code === 0) {
          this.getInsOrgList(res.data.rows);
        }
      });
  },
  methods: {
    ...mapActions([
      "dialog",
      "riskTodo",
      "getTips",
      "riskTodoRun",
      "todorisk",
      "getInsOrgList",
      "getScreen",
      "changeRiskPage",
      "riskManagement",
    ]),
    visibles() {
      this.visible = false;
      // this.isMainIns = false;
    },
    residentClick(item, index) {
      item.check = !item.check;
      this.$set(this.residentialNature, index, item);
    },
    riskEventType(item, index) {
      item.check = !item.check;
      this.$set(this.riskEventTypeList, index, item);
    },
    riskLevel(item, index) {
      item.check = !item.check;
      this.$set(this.riskLevelList, index, item);
    },
    getCity(i, flag) {
      if (flag === "county") {
        this.caseFilter.district = "";
        let list = [];
        for (let item of this.district) {
          list = [...list, ...item.city];
        }
        for (let item of list) {
          if (i == item.name) {
            this.countys = item.area;
          }
        }
      } else if (flag === "city") {
        this.caseFilter.city = "";
        this.caseFilter.district = "";
        for (let city of this.district) {
          if (city.province == i) {
            this.citys = city.city;
          }
        }
      }
    },
    reset() {
      this.caseFilter = {
        province: this.$getversionData.province,
        district: "",
        city: "",
        taskName: "", //录入保险审核信息  审核风控管理计划  录入竣工信息
        minCostPerMeter: "",
        maxCostPerMeter: "",
        beginSignDate: "",
        endSignDate: "",
        buildingType: new Set(),
        projectName: "",
        insContractNo: "",
        fuzzyQuery: "",
        offset: 1,
        limit: 8,
        orgId: "",
        riskEventType: new Set(),
        riskLevel: new Set(),
        minRiskFoundTime: "",
        maxRiskFoundTime: ""
      };
      this.isMainIns = false;
      this.residentialNature.map((item, index) => {
        item.check = false;
      });
      this.riskEventTypeList.map((item, index) => {
        item.check = false;
        this.$set(this.riskEventTypeList, index, item);
      });
      this.riskLevelList.map((item, index) => {
        item.check = false;
        this.$set(this.riskLevelList, index, item);
      });
      this.insOrgList.map((item, index) => {
        item.select = false;
      });
      this.countys = [];
      this.getScreen(this.caseFilter);
    },
    showDialog() {
      this.dialog(true);
    },
    openvisible(item) {
      //获取住宅性质
      this.residentialNature = this.listBaseData[this.types];
      // if (!this.isMainIns) {
      //   this.residentialNature.map((item, index) => {
      //     item.check = false;
      //   });
      //   this.insOrgList.map((item, index) => {
      //     this.$set(item, "select", false);
      //     // item.select = false;
      //   });
      // }
      this.riskEventTypeList = this.listBaseData.IDI_RISK_EVENT_TYPE;
      // if (this.isMainIns) {
      //   this.riskEventTypeList.map((item, index) => {
      //     item.check = false;
      //   });
      // }
      this.riskLevelList = this.listBaseData.IDI_RISK_EVENT_LEVEL;
      // if (this.isMainIns) {
      //   this.riskLevelList.map((item, index) => {
      //     item.check = false;
      //   });
      // }
    },
    filterMytodo() {
      this.caseFilter.buildingType = new Set();
      this.residentialNature.map((item, index) => {
        if (item.check) {
          this.caseFilter.buildingType.add(item.dictKey);
        } else {
          this.caseFilter.buildingType.delete(item.dictKey);
        }
      });
      this.caseFilter.orgId = new Set();
      this.insOrgList.map((item, index) => {
        if (item.select) {
          this.caseFilter.orgId.add(item.orgId);
        } else {
          this.caseFilter.orgId.delete(item.orgId);
        }
      });
      this.caseFilter.riskEventType = new Set();
      this.riskEventTypeList.map((item, index) => {
        if (item.check) {
          this.caseFilter.riskEventType.add(item.dictKey);
        } else {
          this.caseFilter.riskEventType.delete(item.dictKey);
        }
      });
      this.caseFilter.riskLevel = new Set();
      this.riskLevelList.map((item, index) => {
        if (item.check) {
          this.caseFilter.riskLevel.add(item.dictKey);
        } else {
          this.caseFilter.riskLevel.delete(item.dictKey);
        }
      });
      //修改非主承字段值
      if (this.isMainIns == false) {
        this.caseFilter.isMainIns = "Y";
      } else {
        this.caseFilter.isMainIns = "N";
      }
      if (this.$route.name == "MyToDoRun") {
        const { buildingType, orgId } = this.caseFilter;
        this.caseFilter.buildingType = Array.from(buildingType);
        this.caseFilter.orgId = Array.from(orgId);
        if (this.caseFilter.beginSignDate == null) {
          this.caseFilter.beginSignDate = "";
        }
        if (this.caseFilter.endSignDate == null) {
          this.caseFilter.endSignDate = "";
        }
        this.riskTodoRun(this.caseFilter);
        this.getScreen(this.caseFilter);
        // this.reset();
      } else if (this.$route.name == "MyToDoRisk") {
        const { buildingType, orgId } = this.caseFilter;
        this.caseFilter.buildingType = Array.from(buildingType);
        this.caseFilter.orgId = Array.from(orgId);
        if (this.caseFilter.beginSignDate == null) {
          this.caseFilter.beginSignDate = "";
        }
        if (this.caseFilter.endSignDate == null) {
          this.caseFilter.endSignDate = "";
        }
        this.caseFilter.limit=4
        this.$EventBus.$emit("QUERY_EVENT");
        this.todorisk(this.caseFilter);
        this.getScreen(this.caseFilter);
      } else {
        const {
          buildingType,
          orgId,
          riskLevel,
          riskEventType
        } = this.caseFilter;
        this.caseFilter.buildingType = Array.from(buildingType);
        this.caseFilter.orgId = Array.from(orgId);
        this.caseFilter.riskLevel = Array.from(riskLevel);
        this.caseFilter.riskEventType = Array.from(riskEventType);
        this.riskTodo(this.caseFilter);
        this.getScreen(this.caseFilter);
        const keywords = {
          sqlStatus: "1",
          completeType: "0",
          offset: 1,
          limit: 4,
          fuzzyQuery: this.fuzzyQuery.value,
          insOrgId: JSON.parse(sessionStorage.getItem("eidi.ins")).orgId,
          riskLevel: this.caseFilter.riskLevel,
          riskEventType: this.caseFilter.riskEventType,
          minRiskFoundTime: this.caseFilter.minRiskFoundTime,
          maxRiskFoundTime: this.caseFilter.maxRiskFoundTime
        };
        this.$EventBus.$emit("QUERY_EVENT");
        this.$store.dispatch("loading", true);
        this.riskManagement(keywords).then(() => {
          this.$store.dispatch("loading", false);
        });
        // this.reset();
      }
      this.isMainIns == false;
      this.visible = false;
    },
    query(item) {
      this.$EventBus.$emit("nodeClick", {
        id: item.id
      });
    }
  }
};
</script>

<style scoped lang="scss">
.news {
  height: 45px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.middle {
  margin-top: 13px;
  margin-bottom: 13px;
}
.middle span {
  color: #fff;
  margin-right: 10px;
  line-height: 15px;
}
$blue: #297ae3;
.checked {
  background-color: $blue;
  color: #fff !important;
  border-radius: 8px;
}
$color: rgba(62, 58, 57, 1);
.area {
  color: $color;
  padding: 2px 6px;
  margin: 0 12.5px 8.5px 0;
}
.filter_title {
  font-weight: 600;
  padding-top: 8px;
  padding-bottom: 8px;
  font-size: 13px;
}
.el-date-editor /deep/ .el-input__inner {
  padding-right: 0;
}
.line {
  text-align: center;
}
.jg_line {
  border-top: 1px solid #d4d4d4;
  margin-top: 12px;
}
</style>

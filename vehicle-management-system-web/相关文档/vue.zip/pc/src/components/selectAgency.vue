<template>
  <div style="position: relative;">
    <!-- <el-dialog class="dialog" :title="title" :visible.sync="openVisible" width="615px"> -->
    <div v-if="!dialogAddUser">
      <!-- 表单 -->
      <el-row>
        <el-col :span="24">
          <el-input style="width: 50%" size="small" v-model="dialogUnit.searchOrg" placeholder="请输入姓名/手机号" >
            <el-button
              type="primary"
              @click="orgUser(1)"
              slot="append"
              icon="el-icon-search"
              v-if="num=='5'"
            ></el-button>
            <el-button
              type="primary"
              @click="reportPtcp(1)"
              slot="append"
              icon="el-icon-search"
              v-if="num=='2'"
            ></el-button>
          </el-input>
          <el-button
            style="position: relative;top:8px;left: 114px"
            size="mini"
            type="primary"
            @click="replace()"
          >创建</el-button>
        </el-col>
        <el-col :span="24">
          <el-table
            class="mc-table"
            :data="unitData.rows"
            style="width: 100%; margin-top: 20px;border:1px #ccc solid"
          >
            <el-table-column width="25">
              <template slot-scope="scope">
                <el-checkbox @change="check(scope.row)" v-model="scope.row.check"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column label="姓名" align="center">
              <template slot-scope="scope">
                <div
                  style="width: 100%;"
                  class="mouse-pointer"
                  @click="check(scope.row, 'body')"
                >{{ scope.row.username }}</div>
              </template>
            </el-table-column>
            <el-table-column prop="mobile" label="手机号" align="center"></el-table-column>
             <el-table-column label="机构名称" align="center" prop="insOrgId"></el-table-column>
          </el-table>
        </el-col>
        <el-col :span="24" v-if="num=='5'">
          <el-pagination
            small
            :page-size="10"
            @current-change="orgUser"
            class="text-right mt10"
            layout="prev, pager, next"
            :total="unitData.total"
          ></el-pagination>
        </el-col>
        <el-col :span="24" v-if="num=='2'">
          <el-pagination
            small
            :page-size="10"
            @current-change="reportPtcp"
            class="text-right mt10"
            layout="prev, pager, next"
            :total="unitData.total"
          ></el-pagination>
        </el-col>
      </el-row>

      <span slot="footer" class="dialog-footer">
        <el-button @click="confirm('submit')" size="mini" type="primary">确定</el-button>
        <el-button @click="confirm('close')" size="mini">关闭</el-button>
      </span>
    </div>
    <!-- </el-dialog> -->
    <!-- <el-dialog title="用户添加" :visible.sync="dialogAddUser" width="900px" class="dialog"> -->
    <div v-if="dialogAddUser">
      <el-form>
        <el-form
          :model="userInfo"
          ref="userInfo"
          class="mc-addUser"
          :rules="rules"
          size="mini"
          label-width="120px"
        >
          <el-row>
            <el-col :span="12">
              <el-form-item label="姓名：" prop="username">
                <el-input v-model="userInfo.username"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="电话：" prop="mobile">
                <el-input v-model="userInfo.mobile"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="专业领域：" prop="professional">
                <el-input v-model="userInfo.professional"></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="11">
              <el-form-item prop="orgType" label="机构类型：">
                <el-select
                  v-model="userInfo.orgType"
                  clearable
                  placeholder="请选择"
                  @change="getInsOrg"
                >
                  <el-option
                    v-for="item in orgTypes"
                    :key="item.orgType"
                    :label="item.value"
                    :value="item.orgType"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>-->
            <el-col :span="12" >
              <el-form-item prop="insOrgId" label="机构名称：">
                <el-select v-model="userInfo.insOrgId" placeholder="请选择" @change="getInsOrg">
                  <el-option
                    v-for="item in orgIds"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item prop="roleId" label="角色：">
                <el-select v-model="userInfo.roleId" clearable placeholder="请选择">
                  <el-option
                    v-for="item in roleList"
                    :key="item.roleId"
                    :label="item.roleName"
                    :value="item.roleId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="可查看项目区域：" prop='list'>
                <el-input v-model="userInfo.list" style="display: none;" ></el-input>
                <el-table
                  class="mc-table district-table"
                  tooltip-effect="light"
                  :data="userInfo.listTransArea"
                  style="width: 100%;border-radius:2px;"
                >
                  <el-table-column prop="province" align="center" label="省">
                    <template slot-scope="scope">
                      <el-select
                      disabled
                        class="miniColumn"
                        @change="getCity(scope.row,'city')"
                        v-model="scope.row.province"
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in district"
                          :key="item.province"
                          :label="item.province"
                          :value="item.province"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="city" align="center" label="市">
                    <template slot-scope="scope">
                      <el-select
                        class="miniColumn ml5"
                        @change="getCity(scope.row, 'county')"
                        v-model="scope.row.city"
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in scope.row.citys"
                          :key="item.name"
                          :label="item.name"
                          :value="item.name"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="district" align="center" label="区/县">
                    <template slot-scope="scope">
                      <el-select
                        class="miniColumn ml5"
                        v-model="scope.row.county"
                        placeholder="请选择"
                        @change="selectCounty(scope.row.county)"
                      >
                        <el-option
                          v-for="item in scope.row.countys"
                          :key="item.district"
                          :label="item.district"
                          :value="item.district"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="district" align="center">
                    <template slot="header" solt-scope="scope">
                      <i @click="doRowAdd" class="el-icon-circle-plus-outline"></i>
                    </template>
                    <template slot-scope="scope">
                      <i @click="doRowDel(scope.$index)" class="el-icon-remove-outline"></i>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div>
          <el-button size="mini" type="primary" @click="addUserInfo('userInfo')">确 定</el-button>
          <el-button size="mini" @click="dialogAddUser = false">取 消</el-button>
        </div>
      </el-form>
    </div>
    <!-- </el-dialog> -->
  </div>
</template>
<script>
import http from "@/common/request";
import { orgType } from "@/assets/js/codes";
import { mapGetters, mapActions } from "vuex";
import md5 from "js-md5";
export default {
  name: "SelectAgency",
  props: {
    type: {
      type: String,
      required: false,
      default: false
    },
    title: {
      type: String,
      required: false,
      default: false
    },
    num: {
      type: String,
      required: false,
      default: false
    },
    project: {
      type: String,
      required: false,
      default: false
    }
  },
  data() {
    return {
      openVisible: false,
      unitData: {
        total: undefined,
        rows: []
      },
      citys: [],
      county: "",
      buildingType: "",
      province: "", //省
      address: "",
      countys: [],
      dialogUnit: { searchOrg: "" },
      dialogAddUser: false,
      userInfo: {
        list:'114',
        listTransArea: [],
        username: "",
        mobile: "",
        roleId: "",
        insOrgId: "",
        orgType: "",
        professional: "",
        password: md5("123456"),
        status: "1",
        listTransHouseProperty: []
      },
      orgTypes: [...orgType],
      roleList: [],
      orgIds: [],
      rules: {
        list: [
          { required: true, message: " ", trigger: "blur" }
        ],
        username: [{ required: true, message: "请录入姓名", trigger: "blur" }],
        mobile: [{ required: true, message: "请录入手机号", trigger: "blur" }],
        orgType: [
          { required: true, message: "请选择机构类型", trigger: "change" }
        ],
        insOrgId: [
          { required: true, message: "请选择机构名称", trigger: "change" }
        ],
        roleId: [{ required: true, message: "请选择角色", trigger: "change" }]
      }
    };
  },
  computed: {
    ...mapGetters(["listBaseData", "getOrgId", "district", "getCitys"])
  },
  async created() {
    const { code, msg, data } = await this.$api.findCfgAreaInfo();
    if (code === 0) {
      // this.area = data;
    }
    if (this.num == "5") {
      this.riskEvntOrg();
      this.orgUser(1);
    } else if (this.num == "2") {
      this.InsBasicInfo();
      this.reportPtcp(1);
    }
  },
  methods: {
        selectCounty(county) {
      let countyNum = 0;
      this.userInfo.listTransArea.map(item=>{
        if(item.county==county){
          countyNum++;
          if(countyNum>1){
            item.county = "";
            this.$messageError({
            message: "该区域已存在"
          });
            return
          }
        }
      })
    },
    async orgUser(val) {
      let riskReport = {
        projectId: this.project,
        limit: 10,
        offset: val,
        fuzzyQuery:this.dialogUnit.searchOrg
      };
      const res = await this.$api.orgUser(riskReport);
      res.data.rows.map((item, index) => {
        item.check = false;
      });
      this.unitData = {
        total: res.data.total,
        rows: res.data.rows
      };
    },
    async reportPtcp(val) {
      let riskReport = {
        projectId: this.project,
        limit: 10,
        offset: val,
        fuzzyQuery:this.dialogUnit.searchOrg
      };
      const res = await this.$api.reportPtcp(riskReport);
      res.data.rows.map((item, index) => {
        item.check = false;
      });
      this.unitData = {
        total: res.data.total,
        rows: res.data.rows
      };
    },
    check(row, flag) {
      for (let item of this.unitData.rows) {
        if (item.mobile !== row.mobile) {
          item.check = false;
        } else {
          if (flag === "body") {
            item.check = !row.check;
          }
        }
      }
    },
    confirm(flag) {
      if (flag == "submit") {
        let username = "";
        for (let row of this.unitData.rows) {
          if (row.check) {
            username = row.username;
          }
        }
        this.$emit("getAngency", { username: username, type: this.type });
      } else {
        this.dialogUnit.searchOrg = ""; //置空输入框
        this.$emit("getAngency", {});
      }
    },
    getCity(i, flag) {
      if (flag === "county") {
        let list = [];
        for (let item of this.district) {
          list = [...list, ...item.city];
        }
        for (let item of list) {
          if (i.city == item.name) {
            i.countys = item.area;
          }
        }
      } else if (flag === "city") {
        for (let city of this.district) {
          if (city.province == i.province) {
            i.citys = city.city;
          }
        }
      }
    },
    replace() {
      this.dialogAddUser = true;
      this.userInfo = {
        list:'5555',
        listTransArea: [],
        username: "",
        mobile: "",
        roleId: "",
        insOrgId: "",
        orgType: "",
        professional: "",
        password: md5("123456"),
        status: "1",
        listTransHouseProperty: []
      };
    },
    //查询机构
    async riskEvntOrg() {
      const res = await this.$api.riskEvntOrg(this.project);
      this.orgIds = res.data;
    },
    //查询两方机构
    async InsBasicInfo() {
      const res = await this.$api.InsBasicInfo(this.project);
      this.orgIds = res.data;
    },
    //添加用户区域
    doRowAdd(scope) {
      const keywords = {
        province: this.district[0].province,
        citys: []
      };
      for (let city of this.district) {
        if (city.province == this.district[0].province) {
          keywords.citys = city.city;
        }
      }
      this.userInfo.listTransArea.push(keywords);
    },
    //删除用户区域
    doRowDel(curIndex) {
      this.userInfo.listTransArea.splice(curIndex, 1);
    },
    //获取机构名称/角色
    async getInsOrg() {
      this.userInfo.roleId = "";
      const orgid = this.userInfo.insOrgId;
      const res = await this.$api.listRoleByOrgid(orgid);
      this.roleList = res.data;
    },
    //新增用户信息
    async addUserInfo(formName) {
      this.addNewUserFlag = false;
      this.$refs[formName].validate(valid => {
        if (valid) {
          console.log("submit!");
          this.addNewUserFlag = true;
        } else {
          console.log("error submit!!");
          return false;
        }
      });
      if (this.userInfo.mobile.length !== 11) {
        this.$messageError({ message: "请输入正确手机号" });
        return;
      }
      var reg = /^[1][3,4,5,7,8,9][0-9]{9}$/;
      if (!reg.test(this.userInfo.mobile)) {
        this.$messageError({ message: "请输入正确手机号" });
        return;
      }
      if (this.addNewUserFlag) {
        if (this.userInfo.listTransArea.length > 0) {
          this.userInfo.tenantId = JSON.parse(
            sessionStorage.getItem(this.$getversionData.userInfo)
          ).tenantId;
          const keywords = this.userInfo;
          const res = await this.$api.addParticipants(keywords);
          if (res.code == 0) {
            // this.searchUnit(1);
            this.$messageSuccess({ message: "添加成功" });
            this.dialogAddUser = false; //保存成功，关闭弹框
          } else if (res.code == 1) {
            this.$messageError({ message: res.msg });
          }
        } else {
          this.$messageError({ message: "可查看项目区域不能为空" });
        }
      }
    }
  }
};
</script>
<style <style lang="scss" scoped>
.el-select {
  width: 100%;
}
</style>

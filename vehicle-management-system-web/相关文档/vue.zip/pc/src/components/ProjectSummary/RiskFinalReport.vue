<template>
  <div v-if="getRiskFinalReport.sqlstatus==1">
    <el-divider class="mc-divider"></el-divider>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold">风险最终检查报告</span>
    </el-col>
    <el-form
      :model="getRiskFinalReport"
      
      class="mc-form"
      label-width="137px"
      size="mini"
      label-position="left"
      align="left"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="项目报建号：">
            <el-input v-model="getRiskFinalReport.riskReportLastDO.buildPermitNo" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="牵头保险公司：">
            <el-select
             :disabled="disabled"
              v-model="getRiskFinalReport.riskManagementPlanBigDO.insOrgId"
              placeholder="请选择"
            >
              <el-option
                v-for="item in getOrgId.insOrgList"
                :key="item.orgId"
                :label="item.orgName"
                :value="item.orgId"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="风险管理机构：">
            <el-select
            :disabled="disabled"
              v-model="getRiskFinalReport.riskManagementPlanBigDO.tisOrgId"
              placeholder="请选择"
            >
              <el-option
                v-for="item in getOrgId.tisOrgList"
                :key="item.orgId"
                :label="item.orgName"
                :value="item.orgId"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="保险分类：">
            <el-select
            :disabled="disabled"
              v-model="getRiskFinalReport.riskManagementPlanBigDO.insCategory"
              placeholder="请选择"
            >
              <el-option
                v-for="item in listBaseData.IDI_INS_CATEGORIES"
                :key="item.dictKey"
                :label="item.dictValue"
                :value="item.dictKey"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="保单号：">
            <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.insContractNo" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="项目名称：">
            <el-input v-model="getRiskFinalReport.riskReportLastDO.projectName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="15">
          <el-form-item label="项目地址：">
            <el-input v-model="getRiskFinalReport.riskReportLastDO.address" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="建设单位：">
            <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.builderOrgName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item class="area" label="总包单位：">
            <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.gconOrgName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="勘察单位： ">
            <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.invOrgName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item class="area" label="设计单位：">
            <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.designOrgName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item class="area" label="监理单位：">
            <el-input v-model="getRiskFinalReport.riskManagementPlanBigDO.supOrgName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="改正缺陷数量：">
            <el-input v-model="getRiskFinalReport.riskReportDO.faultChangeCount" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="开始介入日期：">
            <el-date-picker
            :disabled="disabled"
              v-model="getRiskFinalReport.riskReportDO.startWorkDate"
              type="date"
              placeholder="选择日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="竣工检查日期：">
            <el-date-picker
            :disabled="disabled"
              v-model="getRiskFinalReport.riskReportDO.reportDate"
              type="date"
              placeholder="选择日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="工程概况：">
            <el-input
            :disabled="disabled"
              type="textarea"
              :autosize="{ minRows: 2}"
              placeholder="请输入内容"
              v-model="getRiskFinalReport.riskReportDO.projDesc"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="本报告所涉及的承保范围：">
            <el-input
            :disabled="disabled"
              type="textarea"
              :autosize="{ minRows: 2}"
              placeholder="请输入内容"
              v-model="getRiskFinalReport.riskReportDO.reportScope"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="针对承保范围的总体风险评价：">
            <el-input
            :disabled="disabled"
              type="textarea"
              :autosize="{ minRows: 2}"
              placeholder="请输入内容"
              v-model="getRiskFinalReport.riskReportDO.reportScopeNote"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="保险公司审核意见：">
            <el-input
            :disabled="disabled"
              type="textarea"
              :autosize="{ minRows: 2}"
              placeholder="请输入内容"
              v-model="getRiskFinalReport.riskReportDO.insReviewNote"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="最终检查报告：">
            <el-input  v-model="getRiskFinalReport.riskReportDO.fileName" :disabled="disabled"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <span style="left: -25px; position: relative">
            <img :src="imgUpload" class="img-upload" />
            <el-upload
              class="inline-block mlr97"
              action
              :http-request="uploadFile"
              :show-file-list="false"
            >
              <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
            </el-upload>
            <el-button size="mini" @click="delBtn()" :disabled="disabled">删除</el-button>
            <el-button size="mini" id="fileName" @click="downloadBtn('fileName')" v-if="getRiskFinalReport.riskReportDO.fileName">下载</el-button>
          </span>
        </el-col>
        <el-col :span="6" style="margin-left: 52px">
          <el-form-item label="报告签发日期：">
            <el-date-picker
             :disabled="disabled"
              v-model="getRiskFinalReport.riskReportDO.assessmentReportFileDate"
              type="date"
              placeholder="选择日期"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import imgUpload from "@/assets/imgs/put.png";
export default {
  name: "RiskFinalReport",
  props: {
    disabled: {
      type: Boolean,
      default: false,
      required: false
    }
  },
  data() {
    return {
      imgUpload,
      value: "",
      textarea1: ""
    };
  },
  computed: {
    ...mapGetters(["getRiskFinalReport", "getOrgId", "listBaseData"])
  },
  methods: {
    ...mapActions(["riskFinalReport"]),

    uploadFile() {},
    //文件下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.getRiskFinalReport.riskReportDO.fileName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" +
        this.getRiskFinalReport.riskReportDO.assessmentReportFileLast +
        "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn() {
      this.dialogUserList.fileOriginalName = "";
      this.url = "";
    }
  },
  mounted() {
    let disableds = ["fileName"];
    for (let item of disableds) {
      let dom = document.getElementById(item);
      if (dom) {
        dom.disabled = false;
        dom.classList.remove("is-disabled");
      }
    }
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.btn {
  width: 56px;
  height: 32px;
  padding: 9px 15px;
  font-size: 12px;
  border-radius: 3px;
}
</style>
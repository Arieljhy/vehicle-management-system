<template>
  <div>
    <div>
      <el-divider class="mc-divider"></el-divider>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">风险事件列表</span>
      </el-col>
      <el-form label-width="137px" size="mini" label-position="left" align="left" class="mc-form">
        <el-row>
          <el-col :span="23">
            <el-form-item label>
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="getRiskEventsList.rows"
                style="width: 100%"
                @row-dblclick="backMytodo"
              >
                <!-- <el-table-column type="index" align="center" label="序号"></el-table-column> -->
                <el-table-column
                  type="index"
                  align="center"
                  label="序号"
                  :index="(index)=>{return(index+1)+(offset-1)*limit}"
                ></el-table-column>
                <el-table-column
                  prop="riskEventName"
                  align="center"
                  label="风险事件名称"
                  :show-overflow-tooltip="true"
                ></el-table-column>
                <el-table-column prop="riskEventType" align="center" label="风险事件类型">
                  <template
                    slot-scope="scope"
                  >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                </el-table-column>
                <el-table-column prop="riskLevel" align="center" label="风险等级">
                  <template
                    slot-scope="scope"
                  >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                </el-table-column>
                <el-table-column align="center" label="最初报告时间">
                  <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate }}</template>
                </el-table-column>
                <el-table-column align="center" label="建议整改截止日期">
                  <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate }}</template>
                </el-table-column>
                <el-table-column align="center" label="风险事件编号" width="120" prop="eventIdForUser"></el-table-column>
                <el-table-column prop="riskEventStatus" align="center" label="业务状态">
                  <template
                    slot-scope="scope"
                  >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                </el-table-column>
                <el-table-column prop="riskEventStatus" align="center" label="处理状态" v-if="outFlag=='outFlag'">
                  <template
                    slot-scope="scope"
                  >{{scope.row.eventStatus | filterCode(listBaseData.IDI_EVENT_STATUS,'dictValue','dictKey')}}</template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-pagination
              small
              class="page-lucency text-right mt10"
              layout="prev, pager, next"
              :current-page.sync="offset"
              :page-size="limit"
              @current-change="getPagination"
              :total="getRiskEventsList.total"
            ></el-pagination>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- 列表弹框 -->
    <el-dialog
      class="dialog"
      title="风险事件列表"
      :visible.sync="dialogVisible"
      :close-on-click-modal="false"
      :before-close="handClose"
    >
      <!-- 基本信息 -->
      <el-row  v-if="outFlag=='outFlag'">
        <el-col class="text-left mc-title" :span="24" >
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">处理状态</span>
        </el-col>
        <el-col :offset="1" :span="23" style="text-align: left;margin-bottom: 20px;">
          <el-radio-group v-model="eventStatus" @change="changeEventStatus">
            <el-radio
              v-for="obj in listBaseData.IDI_EVENT_STATUS"
              :key="obj.dictKey"
              :label="obj.dictKey"
            >{{obj.dictValue}}</el-radio>
          </el-radio-group>
        </el-col>
      </el-row>
      <div>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>

        <el-form
          class="mc-form"
          label-width="137px"
          size="mini"
          :model="caseDetails.riskEventDO"
          label-position="left"
          align="left"
          disabled
        >
          <el-row>
            <el-col :span="12">
              <el-form-item label="风险事件名称：">
                <el-input v-model="caseDetails.riskEventDO.riskEventName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="所属楼栋：">
                <el-input v-model="caseDetails.riskEventDO.riskBldings"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="风险等级：">
                <el-select v-model="caseDetails.riskEventDO.riskLevel" placeholder="请选择">
                  <el-option
                    v-for="item in listBaseData.IDI_RISK_EVENT_LEVEL"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="风险事件类型：">
                <el-select
                  v-model="caseDetails.riskEventDO.riskEventType"
                  clearable
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_RISK_EVENT_TYPE"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="发生时间：">
                <el-date-picker
                  v-model="caseDetails.riskEventDO.riskFoundTime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="date"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="建议整改截止日期:">
                <el-date-picker
                  v-model="caseDetails.riskEventDO.proposedAmendDeadline"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="项目阶段：">
                <el-select
                  v-model="caseDetails.riskEventDO.constructionStage"
                  clearable
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_PROJ_PROCESS"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="形象进度：">
                <el-input v-model="caseDetails.riskEventDO.projectVisualProgress"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row></el-row>
          <el-col :span="12">
            <el-form-item label="风险事件编号：">
              <el-input v-model="caseDetails.riskEventDO.eventIdForUser"></el-input>
            </el-form-item>
          </el-col>
          <el-row>
            <el-col :span="24">
              <el-form-item label="检查方式：">
                <el-checkbox-group v-model="caseDetails.riskEventDO.checkMethods">
                  <el-checkbox
                    v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                    :disabled="$route.query.type=='view'"
                    :key="item.dictKey"
                    :label="item.dictKey"
                  >{{item.dictValue}}</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="缺陷描述：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  placeholder="请输入内容"
                  v-model="caseDetails.riskEventDO.riskDesc"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="整改建议方案：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  placeholder="请输入内容"
                  v-model="caseDetails.riskEventDO.proposedAmendPlan"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="现场图片：">
                <el-table class="mc-table" :data="caseDetails.riskEventPicDO" style="width: 100%">
                  <el-table-column align="center" label="内容" width="350px">
                    <template slot-scope="scope">
                      <el-upload
                        action
                        list-type="picture-card"
                        :http-request="(file) => { uploadFile(file, scope.$index) }"
                        :show-file-list="false"
                        v-if="scope.row.show"
                      >
                        <i class="el-icon-plus"></i>
                      </el-upload>
                      <img
                        v-else
                        width="75%"
                        height="160px"
                        :src="scope.row.imgUrl"
                        @click="openPic(scope.row.imgUrl)"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="描述">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 8}"
                        v-model="scope.row.picDescription"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="参与人：">
                <el-table class="mc-table" :data="caseDetails.userDO" style="width: 100%">
                  <el-table-column align="center" label="联系电话">
                    <template slot-scope="scope">
                      <el-input
                        v-model="scope.row.mobile"
                        size="mini"
                        placeholder="请录入联系电话"
                        @blur="checkUser(scope.row)"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="姓名">
                    <template slot-scope="scope">
                      <el-input v-model="scope.row.username" size="mini" disabled />
                    </template>
                  </el-table-column>
                  <el-table-column align="center" label="专业领域">
                    <template slot-scope="scope">
                      <el-input v-model="scope.row.professional" size="mini" disabled />
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <el-divider class="mc-divider"></el-divider>
      <!-- 历史整改信息 -->
      <div>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">历史整改信息</span>
        </el-col>
        <el-form class="mc-form" size="mini" label-position="left" align="left">
          <el-row>
            <el-col :offset="1" :span="23">
              <el-form-item>
                <el-table
                  class="mc-table"
                  tooltip-effect="light"
                  :data="sqlStatusList"
                  style="width: 95%"
                  @row-dblclick="dbMytodoDetails"
                >
                  <!-- <el-table-column type="index" align="center" label="序号"></el-table-column> -->
                  <el-table-column
                    type="index"
                    align="center"
                    label="序号"
                    :index="(index)=>{return(index+1)+(caseDetails.offsets-1)*caseDetails.limits}"
                  ></el-table-column>
                  <el-table-column prop="riskPepairTime" align="center" label="整改时间"></el-table-column>
                  <el-table-column prop="projectPhase" align="center" label="项目阶段">
                    <template
                      slot-scope="scope"
                    >{{scope.row.projectPhase | filterCode(listBaseData.IDI_PROJ_PROCESS,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="checkPtcp" align="center" label="检查人"></el-table-column>
                  <el-table-column prop="createdBy" align="center" label="整改用户"></el-table-column>
                  <el-table-column prop="orgName" align="center" label="整改机构"></el-table-column>
                  <el-table-column prop="amendProgress" align="center" label="整改进度(%)"></el-table-column>
                  <el-table-column prop="sqlStatus" align="center" label="状态">
                    <template slot-scope="scope">
                      <div v-if="scope.row.sqlStatus==0">已保存</div>
                      <div v-if="scope.row.sqlStatus==1">已提交</div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
              <el-pagination
                layout="prev, pager, next"
                small
                class="text-right mt10 page-lucency"
                @current-change="(val) => { getRectificationHistoryInfo('', val) }"
                :current-page.sync="caseDetails.offsets"
                :page-size="caseDetails.limits"
                :total="caseDetails.total"
              ></el-pagination>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </el-dialog>
    <!-- 历史整改详情弹框 -->
    <el-dialog
      title="整改详情"
      :visible.sync="buildingWindows"
      class="dialog"
      :close-on-click-modal="false"
    >
      <el-form
        class="mc-form"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
        :model="dialogCaseDetails.dialogRectificationInfo"
        disabled
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="整改时间：" prop="riskPepairTime">
              <el-date-picker
                v-model="dialogCaseDetails.dialogRectificationInfo.riskPepairTime"
                value-format="yyyy-MM-dd"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="整改进度(%)：" prop="amendProgress">
              <el-input v-model="dialogCaseDetails.dialogRectificationInfo.amendProgress"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="项目阶段：">
              <el-select
                style="width:266px"
                v-model="dialogCaseDetails.dialogRectificationInfo.projectPhase"
                clearable
                placeholder="请选择"
              >
                <el-option
                  v-for="item in listBaseData.IDI_PROJ_PROCESS"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="形象进度：">
              <el-input v-model="dialogCaseDetails.dialogRectificationInfo.projectVisualProgress"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="检查方式：">
              <el-checkbox-group v-model="dialogCaseDetails.dialogRectificationInfo.checkMethods">
                <el-checkbox
                  v-for="item in listBaseData.IDI_RISK_EVENT_CHECK"
                  :key="item.dictKey"
                  :label="item.dictKey"
                >{{item.dictValue}}</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="检查人：">
              <el-input v-model="dialogCaseDetails.dialogRectificationInfo.checkPtcp"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="整改描述：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                placeholder="请输入内容"
                v-model="dialogCaseDetails.dialogRectificationInfo.amendActionDesc"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="整改图片：">
              <el-table
                class="mc-table"
                :data="dialogCaseDetails.dialogRectificationInfo.imagePathList"
                style="width: 100%"
              >
                <el-table-column prop="address" align="center" label="内容" width="350px">
                  <template slot-scope="scope">
                    <el-upload
                      action
                      list-type="picture-card"
                      :http-request="(file) => { uploadFile(file, scope.$index) }"
                      :show-file-list="false"
                      v-if="scope.row.show"
                    ></el-upload>
                    <img
                      v-else
                      width="75%"
                      height="160px"
                      :src="scope.row.imgUrl"
                      @click="openPic(scope.row.imgUrl)"
                    />
                  </template>
                </el-table-column>
                <el-table-column prop="date" align="center" label="描述">
                  <template slot-scope="scope">
                    <el-input
                      type="textarea"
                      :autosize=" {minRows: 8}"
                      v-model="scope.row.picDescription"
                    ></el-input>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>
    <el-dialog :visible.sync="dialogVisibleImg" :close-on-click-modal="false">
      <img width="100%" :src="dialogImageUrl" alt />
    </el-dialog>
    <el-dialog title="请选择事件处理状态" :visible.sync="submitDialogVisible" width="30%" center>
      <el-radio-group v-model="eventStatus1">
        <el-radio
          v-for="obj in listBaseData.IDI_EVENT_STATUS"
          :key="obj.dictKey"
          :label="obj.dictKey"
        >{{obj.dictValue}}</el-radio>
      </el-radio-group>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="!eventStatus1" @click="changeEventStatus(eventStatus1,'dialog')">确 定</el-button>
        <el-button @click="submitDialogVisible = false,dialogVisible = false">离 开</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import RiskRectficationBase from "@/views/riskManagement/riskRectificationBase"; //基础信息
import config from "@/common/config";
import http from "@/common/request";
export default {
  name: "RiskEventsList",
  data() {
    return {
      outFlag:'',//如果存在值，标识为外网页面访问
      submitDialogVisible: false,
      eventStatus: "",
      eventStatus1: "", //弹框显示的处理状态
      offset: 1,
      limit: 5,
      sqlStatusList: [],
      dialogVisibleImg: false,
      dialogImageUrl: "",
      projectId: "",
      projectIds: "",
      dialogVisible: false,
      buildingWindows: false,
      dialogAddUser: false,
      userInfo: {},
      orgTypes: [],
      orgIds: [],
      roleList: [],
      addNewUserFlag: false,
      rows: "",
      caseDetails: {
        offsets: 1,
        limits: 5,
        total: 0,
        riskEventDO: {},
        rectificationInfo: {
          riskEventId: "", //风险事件编号
          riskPepairTime: "", // 整改时间
          projectPhase: "", // 项目阶段
          amendProgress: "", // 整改进度
          amendActionDesc: "", // 整改描述
          projectVisualProgress: "", // 形象进度
          checkMethod: "", // 检查方式
          checkPtcp: "", // 检查人
          sqlStatus: "", // 保存还是提交 0:未提交，1：已提交
          imagePathList: [],
          other: ""
        },
        rectificationHistoryList: []
      },
      dialogCaseDetails: {
        //弹窗数据
        dialogRectificationInfo: {
          imagePathList: []
        }
      }
    };
  },
  components: {
    RiskRectficationBase
  },
  computed: {
    ...mapGetters(["listBaseData", "getRiskEventsList"])
  },
  methods: {
    ...mapActions(["riskEventsList"]),
    //如果用户没有选择处理状态，提示用户选择，选择后不再提示
    handClose() {
      if (!this.eventStatus && this.outFlag=='outFlag') {
        this.submitDialogVisible = true;
        this.eventStatus1 = "";
      } else {
        this.dialogVisible = false;
      }
    },
    //选择处理状态，存入后台
    async changeEventStatus(value, flag) {
      const keywords = {
        eventStatus: value,
        id: this.rows
      };
      const res = await http.post(
        "/risk/RiskEvent/changeEventStatus",
        keywords
      );

      this.riskEventsList({
        limit: 5,
        offset: 1,
        projectId: this.projectIds,
        isView: true,
        unitId: ""
      });
      if (flag == "dialog") {
        this.submitDialogVisible = false;
        this.dialogVisible = false;
      }
      console.log(value);
    },
    thisAFlag() {
      this.outFlag = "outFlag";
    },
    // 双击打开弹框
    backMytodo(row) {
      this.dialogVisible = true;
      this.eventStatus = row.eventStatus;
      this.rows = row.id;
      this.getRectificationHistoryInfo();
      this.getRectificationBaseInfo();
      this.caseDetails.riskEventDO = row;
      this.caseDetails.rectificationInfo = row;
    },
    dbMytodoDetails(row) {
      this.buildingWindows = true;
      this.dialogCaseDetails.dialogRectificationInfo = row;
      this.dialogCaseDetails.dialogRectificationInfo.imagePathList.map(
        (item, index) => {
          item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
        }
      );
    },
    //获取本次整改基本信息
    async getRectificationHistoryInfo(riskEventId, offset = 1) {
      const keywords = {
        riskEventId: this.rows,
        offset: this.caseDetails.offsets,
        limit: this.caseDetails.limits
      };
      const res = await this.$api.rectificationHistoryInfo(keywords);
      console.log(res);
      this.caseDetails.rectificationHistoryList = res.data.rows;
      // let sqlStatusList = []
      this.sqlStatusList = [];
      this.caseDetails.rectificationHistoryList.map(item => {
        if (item.sqlStatus == 1) {
          this.sqlStatusList.push(item);
        }
      });
      this.caseDetails.total = res.data.total;
    },
    // 获取整改基本信息
    async getRectificationBaseInfo() {
      const projectId = this.rows;
      const res = await this.$api.rectificationBaseInfo(projectId);
      this.caseDetails.riskEventDO = res.data.riskEventDO;
      this.caseDetails.riskEventPicDO = res.data.riskEventPicDO;
      this.caseDetails.riskEventPicDO.map((item, index) => {
        item.show = item.picPath ? false : true;
        item.imgUrl = `/api/processDoc/downloadProcessDoc?cloudDocId=${item.picPath}&view=1`;
      });
      this.caseDetails.userDO = res.data.userDO || [];
      if (this.caseDetails.riskEventDO.other) {
        this.caseDetails.rectificationInfo.other = this.caseDetails.riskEventDO.other;
        if (this.caseDetails.riskEventDO.riskBldings) {
          this.caseDetails.riskEventDO.riskBldings =
            this.caseDetails.riskEventDO.riskBldings +
            "," +
            this.caseDetails.rectificationInfo.other;
        } else {
          this.caseDetails.riskEventDO.riskBldings = this.caseDetails.rectificationInfo.other;
        }
      }
    },
    getPagination(offset = 1, projectId, hasPrama, unitId) {
      if (hasPrama == "hasPrama") {
        this.projectId = projectId;
        this.projectIds = projectId;
      }
      this.riskEventsList({
        limit: 5,
        offset,
        projectId: this.projectId,
        isView: true,
        unitId: unitId
      });
    },
    //图片放大
    openPic(picUrl) {
      this.dialogImageUrl = picUrl;
      this.dialogVisibleImg = true;
    }
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.dialog /deep/ .el-dialog {
  width: 900px;
  background: rgb(248, 245, 245);
}
.dialog /deep/.el-dialog__header {
  padding: 8px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/ .el-input {
  width: 193px !important;
}
</style>
<template>
  <div id="ProjectClaims">
    <el-divider class="mc-divider"></el-divider>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold">项目理赔列表</span>
    </el-col>
    <el-form label-width="137px" size="mini" label-position="left" align="left" class="mc-form">
      <el-row>
        <el-col :span="23">
          <el-form-item label>
            <el-table
              class="mc-table"
              tooltip-effect="light"
              :data="getProjectClaims.rows"
              style="width: 100%"
              @row-dblclick="dbMytodoDetails"
            >
              <el-table-column
                type="index"
                align="center"
                label="序号"
                width="100"
                :index="(index)=>{return(index+1)+(offset-1)*limit}"
              ></el-table-column>
              <!-- <el-table-column type="index" align="center" label="序号" width="100px"></el-table-column> -->
              <el-table-column prop="claimItemName" align="center" label="赔偿项目名称" width="180"></el-table-column>
              <el-table-column
                prop="claimTermName"
                align="center"
                label="赔偿条款名称"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column
                prop="insCaseReportId"
                align="center"
                label="报案号"
                :show-overflow-tooltip="true"
              ></el-table-column>
              <el-table-column prop="riskBldingsName" align="center" label="报案楼栋门牌号"></el-table-column>
            </el-table>
            <el-pagination
              small
              class="page-lucency text-right mt10"
              layout="prev, pager, next"
              :page-size="limit"
              :current-page.sync="offset"
              :total="getProjectClaims.total"
              @current-change="(val) => { projectClaim('', val) }"
            ></el-pagination>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-dialog
      title="理赔服务详情"
      :visible.sync="buildingWindows"
      class="dialog"
      :close-on-click-modal="false"
    >
      <el-form
        class="mc-form"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
        :model="dialogRectificationInfo"
      >
        <el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="赔偿项目名称：">
                <el-input v-model="dialogRectificationInfo.claimItemName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="赔偿条款名称：">
                <el-input v-model="dialogRectificationInfo.claimTermName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="报案受理公司：">
                <el-input v-model="dialogRectificationInfo.claimHanleCompany" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="报案号：">
                <el-input
                  v-model="dialogRectificationInfo.insCaseReportId"
                  disabled
                  style="width: 255px;"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="报案楼栋门牌号：">
                <el-input
                  v-model="dialogRectificationInfo.riskBldingsName"
                  disabled
                  style="width: 255px;"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="详细地址：">
                <el-input v-model="dialogRectificationInfo.address" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="备注：">
                <el-input
                  v-model="dialogRectificationInfo.remark"
                  type="textarea"
                  :autosize=" {minRows: 4}"
                  placeholder="审核意见"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-row>
        <el-row style="min-height:220px;" v-if="dialogRectificationInfo.sqlStatus==1">
          <el-table
            class="mc-table"
            tooltip-effect="light"
            :data="tableData"
            style="width: 100%"
            @row-dblclick="tableDataDetails"
          >
            <el-table-column
              type="index"
              align="center"
              label="序号"
              width="100"
              :index="(index)=>{return(index+1)+(offsets-1)*limits}"
            ></el-table-column>
            <!-- <el-table-column type="index" align="center" label="序号" width="100"></el-table-column> -->
            <el-table-column prop="claimHandleProgress" align="center" label="理赔进度">
              <template
                slot-scope="scope"
              >{{scope.row.claimHandleProgress | filterCode(listBaseData.IDI_CLAIM_HANDLE_PROGRESS,'dictValue','dictKey')}}</template>
            </el-table-column>
            <el-table-column prop="claimAmount" align="center" label="赔偿金额"></el-table-column>
            <el-table-column prop="progressDate" align="center" label="阶段日期">
              <template slot-scope="scope">{{ scope.row.progressDate | filterDate}}</template>
            </el-table-column>
          </el-table>
        </el-row>
        <el-pagination
          v-if="dialogRectificationInfo.sqlStatus==1"
          small
          style="text-align: center;"
          class="page-lucency mt10 page-lucencys"
          layout="prev, pager, next"
          :total="this.totals"
          :current-page="this.offsets"
          :page-size="this.limits"
          @current-change="handleCurrentChange"
        ></el-pagination>
        <el-row style="text-align: right;">
          <el-button size="mini" @click="shutbtn()">关闭</el-button>
        </el-row>
      </el-form>
    </el-dialog>
    <el-dialog
      title="理赔详情"
      :visible.sync="dialogVisible"
      class="dialog"
      :close-on-click-modal="false"
    >
      <el-form
        class="mc-form"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
        :model="dialogCaseDetails"
        disabled
      >
        <el-row>
          <el-row>
            <el-col :span="10">
              <el-form-item label="理赔进度：">
                <el-select
                  v-model="dialogCaseDetails.claimHandleProgress"
                  disabled
                  style="width: 100%"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_CLAIM_HANDLE_PROGRESS"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="10">
              <el-form-item label="赔偿金额：">
                <format-input
                  empty-value="0"
                  text-align="left"
                  :precision="2"
                  v-model="dialogCaseDetails.claimAmount"
                />
              </el-form-item>
            </el-col>
            <el-col :span="10">
              <el-form-item label="阶段日期：" prop="progressDate">
                <!-- <el-input v-model="caseDetails.Data"></el-input> -->
                <el-date-picker
                  type="date"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="选择日期"
                  v-model="dialogCaseDetails.progressDate"
                  disabled
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="赔偿项目名称：">
                <el-input v-model="dialogCaseDetails.claimItemName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="23">
              <el-form-item label="赔偿条款名称：">
                <el-input v-model="dialogCaseDetails.claimTermName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-row>
      </el-form>
      <el-row style="text-align: right;">
        <el-button size="mini" @click="claimbtn()">关闭</el-button>
      </el-row>
    </el-dialog>
  </div>
</template>
<script>
import { mapActions, mapGetters } from "vuex";
import formatInput from "@/components/formatInput";
export default {
  name: "ProjectClaims",
  components: {
    formatInput
  },
  data() {
    return {
      dialogVisible: false,
      buildingWindows: false,
      dialogCaseDetails: {
        claimHandleProgress: "",
        claimAmount: "",
        progressDate: "",
        claimItemName: "",
        claimTermName: ""
      },
      dialogRectificationInfo: {
        claimItemName: "",
        claimTermName: "",
        insCaseReportId: "",
        claimHanleCompany: "",
        riskBldingsName: "",
        address: "",
        remark: ""
      },
      tableData: [],
      total: 0,
      limit: 5, //每页几条数据
      offset: 1,
      offsets: 1, //第几页
      limits: 3, //每页几条数据
      totals: 0
    };
  },
  computed: {
    ...mapGetters(["getProjectClaims", "listBaseData"])
  },
  methods: {
    ...mapActions(["projectClaims"]),
    projectClaim(projectId, offset = 1, unitId) {
      if (projectId) {
        this.projectId = projectId;
      }
      let data = {
        projectId: this.projectId,
        offset,
        limit: 5,
        sqlStatus: 1,
        unitId: unitId
      };
      this.projectClaims(data);
    },
    shutbtn() {
      this.buildingWindows = false;
    },
    dbMytodoDetails(row) {
      this.buildingWindows = true;
      this.dialogRectificationInfo = row;
      this.claimsDetail(this.dialogRectificationInfo.claimId);
    },
    // 分页
    handleCurrentChange(val) {
      this.offsets = val;
      this.claimsDetail(this.dialogRectificationInfo.claimId);
    },
    // 详情数据请求
    async claimsDetail(claimId) {
      const keywords = {
        claimId: claimId,
        offset: this.offsets,
        limit: this.limits,
        sqlStatus: 1
      };
      const data = await this.$api.listPrjClaimDetail(keywords);
      this.tableData = data.data.rows;
      this.totals = data.data.total;
    },
    tableDataDetails(row) {
      this.dialogVisible = true;
      this.dialogCaseDetails = row;
    },
    claimbtn() {
      this.dialogVisible = false;
    }
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.dialog /deep/ .el-dialog {
  width: 900px;
  background: rgb(248, 245, 245);
}
.dialog /deep/.el-dialog__header {
  padding: 8px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.page-lucencys /deep/ button {
  color: #333 !important;
}
.page-lucencys /deep/ li {
  color: #333 !important;
}
</style>
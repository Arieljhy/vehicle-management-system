<template>
  <div id="UnderwritingInformation">
    <el-divider class="mc-divider"></el-divider>
    <div :class="[{'mc-edit':!disabled}, {'mc-bg':!disabled}]">
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">承保信息</span>
      </el-col>
      <el-form
        :model="getUnderwritingInformation.insBasicInfoDO"
        class="mc-form qr-form"
        ref="valid"
        :rules="rules"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
      >
        <!-- <div class="mc-qr">
          <vue-qr
            :text="downloadData.url"
            :margin="0"
            colorDark="RGB(203,164,59)"
            colorLight="#fff"
            :logoSrc="downloadData.icon + '?cache'"
            :logoScale="0.22"
            :size="90"
          ></vue-qr>
        </div>-->
        <el-row>
          <el-col :span="12">
            <el-form-item label="保单号：" prop="insContractNo">
              <!-- onkeyup="value=value.replace(/[\u4e00-\u9fa5]/ig,'')"  判断input能否输入汉字-->
              <el-input
                :disabled="disabled"
                v-model="getUnderwritingInformation.insBasicInfoDO.insContractNo"
                class="login-form-input"
                style="width:365px"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item class="area is-required" label="被保项目：">
              <el-input
                disabled
                v-model="getBasicBstablish.prjBasicInfoDO.projectName"
                style="width:365px"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <!-- 承包信息开始 -->
          <el-col :span="downloadData.url?16:24">
            <!-- <el-col :span="downloadData.url?12:8"> -->
            <!-- <el-form-item label="保单号：" prop="insContractNo"> -->
            <!-- onkeyup="value=value.replace(/[\u4e00-\u9fa5]/ig,'')"  判断input能否输入汉字-->
            <!-- <el-input
                  :disabled="disabled"
                  v-model="getUnderwritingInformation.insBasicInfoDO.insContractNo"
                  class="login-form-input"
            ></el-input>-->
            <!-- </el-form-item> -->
            <!-- </el-col> -->
            <el-col :span="downloadData.url?12:8">
              <el-form-item label="牵头保险公司：" required>
                <el-select
                  disabled
                  v-model="getUnderwritingInformation.insBasicInfoDO.insOrgId"
                  @change="getCode(getOrgId.insOrgList, getUnderwritingInformation.insBasicInfoDO.insOrgId, 'insOrgList')"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.insOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span="downloadData.url?12:8">
              <el-form-item required class="mc-multi-row" label="牵头保险公司社会统一信用编码：">
                <el-input disabled v-model="getUnderwritingInformation.insBasicInfoDO.insOrgCode"></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="downloadData.url?12:8">
              <el-form-item label="风险管理机构：" prop="tisOrgId">
                <el-select
                  :disabled="disableds"
                  v-model="getUnderwritingInformation.insBasicInfoDO.tisOrgId"
                  @change="getCode(getOrgId.tisOrgList, getUnderwritingInformation.insBasicInfoDO.tisOrgId, 'tisOrgList')"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.tisOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.url?12:8">
              <el-form-item class="mc-multi-row" label="风险管理机构社会统一信用编码：">
                <el-input disabled v-model="getUnderwritingInformation.insBasicInfoDO.tisOrgCode"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.url?12:8">
              <el-form-item label="保险分类：" prop="insCategory">
                <el-select
                  :disabled="disabled"
                  v-model="getUnderwritingInformation.insBasicInfoDO.insCategory"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_CATEGORIES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span="downloadData.url?12:8">
              <el-form-item label="保险种类：" prop="typeOfIns">
                <el-select
                  :disabled="disabled"
                  v-model="getUnderwritingInformation.insBasicInfoDO.typeOfIns"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_TYPES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.url?12:8">
              <el-form-item label="投保人：">
                <el-input
                  v-model="getUnderwritingInformation.insBasicInfoDO.applicant"
                  :disabled="disabled"
                ></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="downloadData.url?12:8">
              <el-form-item label="保单签发日期：" prop="signDate">
                <el-date-picker
                  :disabled="disabled"
                  :clearable="false"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :picker-options="dateValid"
                  v-model="getUnderwritingInformation.insBasicInfoDO.signDate"
                  type="date"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>-->

            <!-- <el-col :span="downloadData.url?12:8">
              <el-form-item class="area is-required" label="被保项目：">
                <el-input disabled v-model="getBasicBstablish.prjBasicInfoDO.projectName"></el-input>
              </el-form-item>
            </el-col>-->
            <el-col :span="downloadData.url?12:8">
              <el-form-item class="area" label="被保人名称：" prop="insuredOrgId">
                <el-select
                  filterable
                  :disabled="disabled"
                  clearable
                  @change="getCode(getOrgId.bldOrgList, getUnderwritingInformation.insBasicInfoDO.insuredOrgId, 'bldOrgList')"
                  v-model="getUnderwritingInformation.insBasicInfoDO.insuredOrgId"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.bldOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.url?12:8">
              <el-form-item class="mc-multi-row" label="被保人社会统一信用编码：">
                <el-input
                  disabled
                  v-model="getUnderwritingInformation.insBasicInfoDO.insuredOrgCode"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-col>
          <el-col :span="8" v-if="downloadData.url" style="text-align: right;padding-right: 46px;">
            <vue-qr
              :text="downloadData.url"
              :margin="0"
              colorDark="RGB(203,164,59)"
              colorLight="#fff"
              :logoSrc="downloadData.icon + '?cache'"
              :logoScale="0.23"
              :size="260"
            ></vue-qr>
          </el-col>
        </el-row>
        <el-row>
          <!-- 共保信息开始 -->
          <el-col :span="23">
            <el-form-item label="共保信息：" prop="list">
              <el-input
                v-model="getUnderwritingInformation.insBasicInfoDO.list"
                style="display: none"
              ></el-input>
              <el-table
                :data="getUnderwritingInformation.insCoinsuranceDOList"
                class="mc-table table_list"
                style="width: 100%"
              >
                <el-table-column prop="ins_org_id" align="center" label="共保公司">
                  <template slot-scope="scope">
                    <el-select
                      filterable
                      :disabled="disabled"
                      v-model="scope.row.insOrgId"
                      placeholder="请选择"
                      @change="insOrgIdChange(scope.row,scope.$index)"
                    >
                      <el-option
                        v-for="item in [...getOrgId.sinsOrgList, ...getOrgId.insOrgList]"
                        :key="item.orgId"
                        :label="item.orgName"
                        :value="item.orgId"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="承保比例(%)">
                  <template slot-scope="scope">
                    <format-input
                      :disabled="disabled"
                      text-align="left"
                      :max="100"
                      :min="0"
                      :precision="2"
                      v-model="scope.row.coinsPercent"
                    />
                  </template>
                </el-table-column>
                <el-table-column align="center" label="个人绩效(%)">
                  <template slot-scope="scope">
                    <format-input
                      :disabled="disabled"
                      text-align="left"
                      :max="100"
                      :min="0"
                      :precision="2"
                      v-model="scope.row.indivPerformance"
                    />
                  </template>
                </el-table-column>
                <el-table-column v-if="!disabled" width="50" align="left">
                  <template slot="header">
                    <i
                      @click="add('coinsurance')"
                      class="el-icon-circle-plus-outline mouse-pointer font-size20"
                    ></i>
                  </template>
                  <template slot-scope="scope">
                    <i
                      @click="del(scope.$index, getUnderwritingInformation.insCoinsuranceDOList)"
                      class="el-icon-remove-outline font-size20 mouse-pointer"
                    ></i>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
          <!-- 再保信息 -->
          <el-col :span="23">
            <el-form-item label="再保信息：">
              <el-table
                :data="getUnderwritingInformation.insReinsuranceDOList"
                class="mc-table table_list"
                style="width: 100%;"
              >
                <el-table-column align="center" label="再保险公司">
                  <template slot-scope="scope">
                    <el-select
                      filterable
                      :disabled="disabled"
                      v-model="scope.row.reinsOrgId"
                      placeholder="请选择"
                      @change="handleItemChange(scope.row,scope.$index)"
                    >
                      <el-option
                        v-for="item in getOrgId.rinsOrgList"
                        :key="item.orgId"
                        :label="item.orgName"
                        :value="item.orgId"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="承保比例(%)">
                  <template slot-scope="scope">
                    <format-input
                      :disabled="disabled"
                      text-align="left"
                      empty-value="0"
                      :max="100"
                      :min="0"
                      :precision="2"
                      v-model="scope.row.reinsPercent"
                    />
                  </template>
                </el-table-column>
                <el-table-column v-if="!disabled" width="50" align="left">
                  <template slot="header">
                    <i
                      @click="add('reinsurance')"
                      class="el-icon-circle-plus-outline mouse-pointer font-size20"
                    ></i>
                  </template>
                  <template slot-scope="scope">
                    <i
                      @click="del(scope.$index, getUnderwritingInformation.insReinsuranceDOList)"
                      class="el-icon-remove-outline font-size20 mouse-pointer"
                    ></i>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="承保面积(m²)：" required>
              <format-input
                empty-value="0"
                :precision="2"
                text-align="left"
                required
                :readOnly="true"
                v-model="getUnderwritingInformation.insBasicInfoDO.totalFloorage"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="地下室面积(m²)：">
              <format-input
                empty-value="0"
                :precision="2"
                text-align="left"
                :readOnly="true"
                v-model="getUnderwritingInformation.insBasicInfoDO.basementFloorage"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险起期：" prop="policyStartDate">
              <el-date-picker
                :disabled="disabled"
                :clearable="false"
                :picker-options="startDateValid"
                @change="validData(getUnderwritingInformation.insBasicInfoDO.policyStartDate, getUnderwritingInformation.insBasicInfoDO.policyEndDate)"
                value-format="yyyy-MM-dd HH:mm:ss"
                v-model="getUnderwritingInformation.insBasicInfoDO.policyStartDate"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="保险止期：" prop="policyEndDate">
              <el-date-picker
                :disabled="disabled"
                :picker-options="endDateValid"
                value-format="yyyy-MM-dd HH:mm:ss"
                @change="validData(getUnderwritingInformation.insBasicInfoDO.policyStartDate, getUnderwritingInformation.insBasicInfoDO.policyEndDate)"
                :clearable="false"
                v-model="getUnderwritingInformation.insBasicInfoDO.policyEndDate"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="总保险费(元)：" required>
              <format-input
                :disabled="disabled"
                text-align="left"
                empty-value="0"
                :precision="2"
                :error="error"
                required
                v-model="getUnderwritingInformation.insBasicInfoDO.totalPremium"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险金额(元)：" required>
              <format-input
                :disabled="disabled"
                text-align="left"
                empty-value="0"
                :precision="2"
                :error="error"
                v-model="getUnderwritingInformation.insBasicInfoDO.totalCoverage"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="免赔额(元)：" required>
              <format-input
                :disabled="disabled"
                text-align="left"
                empty-value="0"
                :precision="2"
                :error="error"
                v-model="getUnderwritingInformation.insBasicInfoDO.deductibleAmount"
              />
            </el-form-item>
          </el-col>
          <!-- <el-col :span="8">
          <el-form-item label="保险覆盖范围：" prop="coverageType">
            <el-radio-group
              v-model="getUnderwritingInformation.insBasicInfoDO.coverageType"
            >
              <el-radio label="C01">完全覆盖</el-radio>
              <el-radio label="C02">非完全覆盖</el-radio>
            </el-radio-group>
          </el-form-item>
          </el-col>-->
          <el-col :span="8">
            <el-form-item class="mc-multi-row" label="造价均值(元/平米)：">
              <!-- <el-input disabled v-model="averageCostShow"></el-input> -->
              <format-input
                :readOnly="readOnlyFlag"
                empty-value="0"
                text-align="left"
                :precision="2"
                :error="error"
                v-model="averageCostShow"
              />

              <el-tooltip
                content="核价已通过"
                placement="top"
                effect="light"
                style="position: absolute;right: 0;top: 0%;"
                v-if="heJia"
              >
              <el-image :src="tanhao" style="width:35px;cursor:pointer;" />
                <!-- <el-button>!</el-button> -->
              </el-tooltip>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险费率(%)：">
              <el-input disabled v-model="premiumRateShow"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="是否主承：" prop="isMainIns">
              <el-radio-group
                v-model="getUnderwritingInformation.insBasicInfoDO.isMainIns"
                :disabled="disabled"
              >
                <el-radio label="Y">是</el-radio>
                <el-radio label="N">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保单版本：" prop="contractType">
              <el-radio-group
                :disabled="disabled"
                v-model="getUnderwritingInformation.insBasicInfoDO.contractType"
                @change="agreeChange"
              >
                <el-radio label="NEW">新保单</el-radio>
                <el-radio label="OLD">旧保单</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保单签发日期：" prop="signDate">
              <el-date-picker
                :disabled="disabled"
                :clearable="false"
                value-format="yyyy-MM-dd HH:mm:ss"
                :picker-options="dateValid"
                v-model="getUnderwritingInformation.insBasicInfoDO.signDate"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="主险责任范围：" prop="list">
              <el-input
                v-model="getUnderwritingInformation.insBasicInfoDO.list"
                style="display: none"
              ></el-input>
              <el-table
                :data="disabled ? getUnderwritingInformation.mainInsLiabilitiesDOList : getCopyUnderwriting.mainInsLiabilitiesDOList"
                style="width: 100%"
                class="table_list mc-table"
                ref="mainTable"
                tooltip-effect="dark"
                @select-all="selectChange();selectChange1('main', $event)"
                @selection-change="selectChange('main', $event)"
                @select="selectChange1('main', $event)"
              >
                <el-table-column v-if="!disabled" type="selection" width="55"></el-table-column>
                <el-table-column prop="clause" label="保险条款"></el-table-column>
                <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                <el-table-column align="center" label="责任起期">
                  <template slot-scope="scope">
                    <!-- <span>{{ scope.row.policyStartDate | filterDate}}</span> -->
                    <el-date-picker
                      :disabled="disabled"
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyStartDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.startDateValid"
                      @change="validDataMain(scope.row)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="责任止期">
                  <template slot-scope="scope">
                    <el-date-picker
                      :disabled="disabled"
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyEndDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.endDateValid"
                      @change="validDataMain(scope.row,)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="附加险责任范围：">
              <el-table
                :data="disabled ? getUnderwritingInformation.otherInsLiabilitiesDOList : getCopyUnderwriting.otherInsLiabilitiesDOList"
                style="width: 100%"
                class="table_list mc-table"
                ref="otherTable"
                tooltip-effect="dark"
                @select-all="selectChange();selectChange1('other', $event)"
                @selection-change="selectChange('other', $event)"
                @select="selectChange1('other', $event)"
              >
                <el-table-column v-if="!disabled" type="selection" width="55"></el-table-column>
                <el-table-column prop="clause" label="保险条款"></el-table-column>
                <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                <el-table-column align="center" label="责任起期">
                  <template slot-scope="scope">
                    <!-- <span>{{ scope.row.policyStartDate | filterDate}}</span> -->
                    <el-date-picker
                      :disabled="disabled"
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyStartDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.startDateValid"
                      @change="validDataMain(scope.row)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="责任止期">
                  <template slot-scope="scope">
                    <el-date-picker
                      :disabled="disabled"
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyEndDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.endDateValid"
                      @change="validDataMain(scope.row)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="投保单：">
              <el-input
                disabled
                v-model="getUnderwritingInformation.insBasicInfoDO.insuranceApplicationName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!insuranceApplication" :src="imgUpload" class="img-upload" />
              <el-progress
                v-if="insuranceApplication"
                type="circle"
                :percentage="insuranceApplicationName"
                :width="30"
              ></el-progress>
              <!-- <img v-if="insuranceApplication" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('insuranceApplication', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('insuranceApplication')" :disabled="disabled">删除</el-button>
              <el-button
                id="insuranceApplication"
                @click="download('insuranceApplication')"
                size="mini"
                v-show="getUnderwritingInformation.insBasicInfoDO.insuranceApplicationName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="6">
            <el-form-item label="共保协议：" prop="coinsuranceAgreementName" label-width="144px">
              <el-input
                disabled
                v-model="getUnderwritingInformation.insBasicInfoDO.coinsuranceAgreementName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!coinsuranceAgreement" :src="imgUpload" class="img-upload" />
              <el-progress
                v-if="coinsuranceAgreement"
                type="circle"
                :percentage="coinsuranceAgreementName"
                :width="30"
              ></el-progress>
              <!-- <img v-if="coinsuranceAgreement" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('coinsuranceAgreement', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('coinsuranceAgreement')" :disabled="disabled">删除</el-button>
              <el-button
                id="coinsuranceAgreement"
                @click="download('coinsuranceAgreement')"
                size="mini"
                v-show="getUnderwritingInformation.insBasicInfoDO.coinsuranceAgreementName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="承保工程清单：">
              <el-input
                disabled
                v-model="getUnderwritingInformation.insBasicInfoDO.buildingListName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!buildingList" :src="imgUpload" class="img-upload" />
              <el-progress
                v-if="buildingList"
                type="circle"
                :percentage="buildingListName"
                :width="30"
              ></el-progress>
              <!-- <img v-if="buildingList" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('buildingList', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('buildingList')" :disabled="disabled">删除</el-button>
              <el-button
                id="buildingList"
                @click="download('buildingList')"
                size="mini"
                v-show="getUnderwritingInformation.insBasicInfoDO.buildingListName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="6">
            <el-form-item label="承保报价函：" label-width="144px" prop="riskManageQuotationName">
              <el-input
                disabled
                v-model="getUnderwritingInformation.insBasicInfoDO.riskManageQuotationName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!riskManageQuotation" :src="imgUpload" class="img-upload" />
              <el-progress
                v-if="riskManageQuotation"
                type="circle"
                :percentage="riskManageQuotationName"
                :width="30"
              ></el-progress>
              <!-- <img v-if="riskManageQuotation" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('riskManageQuotation', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('riskManageQuotation')" :disabled="disabled">删除</el-button>
              <el-button
                id="riskManageQuotation"
                @click="download('riskManageQuotation')"
                size="mini"
                v-show="getUnderwritingInformation.insBasicInfoDO.riskManageQuotationName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="保单发票：">
              <el-input disabled v-model="getUnderwritingInformation.insBasicInfoDO.invoiceName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!invoice" :src="imgUpload" class="img-upload" />
              <el-progress v-if="invoice" type="circle" :percentage="invoiceName" :width="30"></el-progress>
              <!-- <img v-if="invoice" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('invoice', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('invoice')" :disabled="disabled">删除</el-button>
              <el-button
                id="invoice"
                @click="download('invoice')"
                size="mini"
                v-show="getUnderwritingInformation.insBasicInfoDO.invoiceName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="6">
            <el-form-item label="保单：" prop="insurancePolicyName" label-width="144px">
              <el-input
                disabled
                v-model="getUnderwritingInformation.insBasicInfoDO.insurancePolicyName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!insurancePolicy" :src="imgUpload" class="img-upload" />
              <el-progress
                v-if="insurancePolicy"
                type="circle"
                :percentage="insurancePolicyName"
                :width="30"
              ></el-progress>
              <!-- <img v-if="insurancePolicy" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('insurancePolicy', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('insurancePolicy')" :disabled="disabled">删除</el-button>
              <el-button
                id="insurancePolicy"
                @click="download('insurancePolicy')"
                size="mini"
                v-show="getUnderwritingInformation.insBasicInfoDO.insurancePolicyName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="备注信息：">
              <el-input
                :disabled="disabled"
                type="textarea"
                :autosize="{ minRows: 3}"
                v-model="getUnderwritingInformation.insBasicInfoDO.remark"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 承包信息结束 -->
      </el-form>
    </div>
  </div>
</template>

<script>
import imgUpload from "@/assets/imgs/put.png";
import { mapGetters, mapActions } from "vuex";
import formatInput from "@/components/formatInput";
import vueQr from "vue-qr";
import erweima from "@/assets/imgs/erweima.png";
import tanhao from "@/assets/imgs/tanhao.png";
import http from "@/common/request";
import axios from "axios";
let blurValid = { required: true, message: "请输入", trigger: "blur" };
let changeValid = { required: true, message: "请选择", trigger: "change" };
export default {
  name: "UnderwritingInformation",
  components: {
    formatInput,
    vueQr
  },
  props: {
    disabled: {
      type: Boolean,
      required: false,
      default: false
    },
    error: {
      type: Boolean,
      required: false,
      default: false
    },
    showMyCase: {
      type: String,
      required: false,
      default: false
    }
  },
  data() {
    return {
      tanhao,
      insuranceApplicationName: 0,
      coinsuranceAgreementName: 0,
      buildingListName: 0,
      riskManageQuotationName: 0,
      invoiceName: 0,
      insurancePolicyName: 0,
      baseUrl: "",
      readOnlyFlag: true,
      insuranceApplication: false,
      coinsuranceAgreement: false,
      insurancePolicy: false,
      riskManageQuotation: false,
      invoice: false,
      buildingList: false,
      imgUpload,
      projectId: "",
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      endDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      rules: {
        insContractNo: [
          blurValid,
          { max: 32, message: "最大长度为 32 个字符", trigger: "blur" }
        ],
        list: [changeValid],
        coinsuranceAgreementName: [changeValid],
        insurancePolicyName: [changeValid],
        riskManageQuotationName: [changeValid],
        insuredOrgId: [changeValid],
        tisOrgId: [changeValid],
        insCategory: [changeValid],
        typeOfIns: [changeValid],
        signDate: [changeValid],
        policyEndDate: [changeValid],
        policyStartDate: [changeValid],
        // coverageType: [changeValid],
        isMainIns: [changeValid],
        contractType: [changeValid]
      },
      downloadData: {
        url: "",
        icon: erweima
      },
      disableds: true
    };
  },
  computed: {
    ...mapGetters([
      "getUnderwritingInformation",
      "getBasicBstablish",
      "getCopyUnderwriting",
      "getOrgId",
      "listBaseData",
      "heJia"
    ]),
    //
    getMain() {
      return this.$store.state.app.projectSummary.copyUnderwriting
        .mainInsLiabilitiesDOList;
    },
    getOther() {
      return this.$store.state.app.projectSummary.copyUnderwriting
        .otherInsLiabilitiesDOList;
    },
    averageCostShow() {
      //造价均值
      let averageCost = (
        Math.round(
          (
            this.getUnderwritingInformation.insBasicInfoDO.totalCoverage /
            this.getUnderwritingInformation.insBasicInfoDO.totalFloorage
          ).toFixed(3) * 100
        ) / 100
      ).toFixed(2);
      if (
        averageCost == "NaN" ||
        averageCost == "" ||
        averageCost == "Infinity"
      ) {
        return 0;
      }
      return averageCost;
    },
    premiumRateShow() {
      //保险费率
      let premiumRate = (
        Math.round(
          (
            (this.getUnderwritingInformation.insBasicInfoDO.totalPremium /
              this.getUnderwritingInformation.insBasicInfoDO.totalCoverage) *
            100
          ).toFixed(5) * 10000
        ) / 10000
      ).toFixed(4);
      if (
        premiumRate == "NaN" ||
        premiumRate == "" ||
        premiumRate == "Infinity"
      ) {
        return 0;
      }
      return premiumRate;
    }
  },
  //
  watch: {
    getMain() {
      let _this = this;
      setTimeout(() => {
        _this.$refs.valid.clearValidate();
      }, 200);
      // this.$refs.valid.resetFields();
      for (let item of this.getCopyUnderwriting.mainInsLiabilitiesDOList) {
        if (item.selected == "Y") {
          setTimeout(() => {
            this.$refs.mainTable.toggleRowSelection(item);
          }, 10);
        }
      }
    },
    getOther() {
      for (let item of this.getCopyUnderwriting.otherInsLiabilitiesDOList) {
        if (item.selected == "Y") {
          setTimeout(() => {
            this.$refs.otherTable.toggleRowSelection(item);
          }, 10);
        }
      }
    }
  },
  methods: {
    ...mapActions(["underwritingInformation"]),
    //新老保单
    agreeChange(val) {
      this.$store.commit("POLICY", val);
    },
    //数组时间校验--
    validDataMain(row) {
      // if (row.policyStartDate) {
      //   this.$set(row, "endDateValid", {
      //     disabledDate(time) {
      //       return time.getTime() < new Date(row.policyStartDate).getTime();
      //     }
      //   });
      // } else {
      //   this.$set(row, "endDateValid", {
      //     disabledDate(time) {
      //       return "";
      //     }
      //   });
      // }
      // if (row.policyEndDate) {
      //   this.$set(row, "startDateValid", {
      //     disabledDate(time) {
      //       return time.getTime() > new Date(row.policyEndDate).getTime();
      //     }
      //   });
      // } else {
      //   this.$set(row, "startDateValid", {
      //     disabledDate(time) {
      //       return "";
      //     }
      //   });
      // }
    },
    //日期校验
    validData(start, end) {
      if (start) {
        this.endDateValid = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          }
        };
      } else {
        this.endDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
      if (end) {
        this.startDateValid = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          }
        };
      } else {
        this.startDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
    },

    //获取险种内期限最大的对象
    getMaxNumInfo(comInsurance) {
      const maxNumList = [];
      comInsurance.map((item, inex) => {
        maxNumList.push(item.deadline);
      });
      const maxNum = Math.max(...maxNumList);
      let maxInfo = {};
      comInsurance.map((item, inex) => {
        if (maxNum == item.deadline) {
          maxInfo = item;
          return;
        }
      });
      return maxInfo;
    },
    //当前时间date，加上年数years，得到新的时间
    getNewData(date, years) {
      var date = new Date(date);
      var year = date.getFullYear() + years;
      var month = date.getMonth() + 1;
      var day = date.getDate();
      var mm = "'" + month + "'";
      var dd = "'" + day + "'";
      //单位数前面加0
      if (mm.length == 3) {
        month = "0" + month;
      }
      if (dd.length == 3) {
        day = "0" + day;
      }
      var time =
        year + "-" + month + "-" + day + " " + "00" + ":" + "00" + ":" + "00";
      return time;
    },
    getAddData(date) {
      var date = new Date(date);
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var day = date.getDate() + 1;
      var mm = "'" + month + "'";
      var dd = "'" + day + "'";
      //单位数前面加0
      if (mm.length == 3) {
        month = "0" + month;
      }
      if (dd.length == 3) {
        day = "0" + day;
      }
      var time =
        year + "-" + month + "-" + day + " " + "00" + ":" + "00" + ":" + "00";
      return time;
    },
    //改变起止时间，获取主副险种时间
    editData(flag, val) {
      const combinationInsurance = [
        ...this.getCopyUnderwriting.mainInsLiabilitiesDOList,
        ...this.getCopyUnderwriting.otherInsLiabilitiesDOList
      ];
      const maxRiskInfo = this.getMaxNumInfo(combinationInsurance);

      let startTime = this.getNewData(
        this.getUnderwritingInformation.insBasicInfoDO.policyEndDate,
        -maxRiskInfo.deadline
      );
      if (
        startTime >
        this.getUnderwritingInformation.insBasicInfoDO.policyStartDate
      ) {
        if (flag == "main") {
          this.getCopyUnderwriting.mainInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    item.policyStartDate = item.policyStartDate
                      ? item.policyStartDate
                      : this.getAddData(startTime);
                    item.policyEndDate = item.policyEndDate
                      ? item.policyEndDate
                      : this.getNewData(startTime, item.deadline);
                    item.checked = true;
                  }
                });
              }
            }
          );
          this.getCopyUnderwriting.mainInsLiabilitiesDOList.map(
            (item, index) => {
              if (!item.checked) {
                item.policyStartDate = "";
                item.policyEndDate = "";
              }
            }
          );
        }

        if (flag == "other") {
          this.getCopyUnderwriting.otherInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    item.policyStartDate = item.policyStartDate
                      ? item.policyStartDate
                      : this.getAddData(startTime);
                    item.policyEndDate = item.policyEndDate
                      ? item.policyEndDate
                      : this.getNewData(startTime, item.deadline);
                    item.checked = true;
                  }
                });
              }
            }
          );
          this.getCopyUnderwriting.otherInsLiabilitiesDOList.map(
            (item, index) => {
              if (!item.checked) {
                item.policyStartDate = "";
                item.policyEndDate = "";
              }
            }
          );
        }
      } else {
        if (flag == "main") {
          this.getCopyUnderwriting.mainInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    if (!item.policyStartDate) {
                      item.policyStartDate =
                        this.getUnderwritingInformation.insBasicInfoDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getUnderwritingInformation.insBasicInfoDO
                              .policyStartDate;
                    }
                    if (!item.policyEndDate) {
                      item.policyEndDate =
                        this.getUnderwritingInformation.insBasicInfoDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getNewData(startTime, item.deadline);
                    }
                    item.checked = true;
                  }
                });
              }
            }
          );
          this.getCopyUnderwriting.mainInsLiabilitiesDOList.map(
            (item, index) => {
              if (!item.checked) {
                item.policyStartDate = "";
                item.policyEndDate = "";
              }
            }
          );
        }

        if (flag == "other") {
          this.getCopyUnderwriting.otherInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    if (!item.policyStartDate) {
                      item.policyStartDate =
                        this.getUnderwritingInformation.insBasicInfoDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getUnderwritingInformation.insBasicInfoDO
                              .policyStartDate;
                    }
                    if (!item.policyEndDate) {
                      item.policyEndDate =
                        this.getUnderwritingInformation.insBasicInfoDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getNewData(startTime, item.deadline);
                    }
                    item.checked = true;
                  }
                });
              }
            }
          );
          this.getCopyUnderwriting.otherInsLiabilitiesDOList.map(
            (item, index) => {
              if (!item.checked) {
                item.policyStartDate = "";
                item.policyEndDate = "";
              }
            }
          );
        }
      }
    },
    // 上传
    uploadFile(flag, param) {
      this[flag] = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", flag);
      file.append("projectId", this.projectId);
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this[`${flag}Name`] = complete == 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp", file, config).then(res => {
        if (res.data.code == 0) {
          this.getUnderwritingInformation.insBasicInfoDO[flag] =
            res.data.data.cloudDocId;
          this.$set(
            this.getUnderwritingInformation.insBasicInfoDO,
            `${flag}Name`,
            res.data.data.fileName
          );
          this[`${flag}Name`] = 100;
        } else {
          this.$messageError({ message: res.data.msg });
        }
        this[flag] = false;
      });
      this[`${flag}Name`] = 0;
    },
    //下载
    download(flag) {
      let a = document.createElement("a");
      a.style = "display: none";
      a.href = `/api/processDoc/downloadProcessDoc?cloudDocId=${this.getUnderwritingInformation.insBasicInfoDO[flag]}&view=2`;
      a.download = this.getUnderwritingInformation.insBasicInfoDO[
        `${flag}Name`
      ];
      document.body.appendChild(a);
      a.click();
    },
    // 删除上传
    delBtn(flag) {
      this.getUnderwritingInformation.insBasicInfoDO[`${flag}Name`] = "";
      this.getUnderwritingInformation.insBasicInfoDO[flag] = "";
    },
    insOrgIdChange(row, index) {
      this.getUnderwritingInformation.insCoinsuranceDOList.map(
        (item, index1) => {
          if (index != index1) {
            if (row.insOrgId == item.insOrgId) {
              this.$messageError({ message: "机构已选择" });
              row.insOrgId = "";
            }
          }
        }
      );
    },
    handleItemChange(row, index) {
      this.getUnderwritingInformation.insReinsuranceDOList.map(
        (item, index1) => {
          if (index != index1) {
            if (row.reinsOrgId == item.reinsOrgId) {
              this.$messageError({ message: "机构已选择" });
              row.reinsOrgId = "";
            }
          }
        }
      );
    },
    //添加行
    add(flag) {
      this.$store.commit("ADDCOIREI", flag);
    },
    //删除
    del(index, list) {
      list.splice(index, 1);
    },

    getCode(list, id, flag) {
      for (let item of list) {
        if (item.orgId == id) {
          if (flag == "insOrgList") {
            return (this.getUnderwritingInformation.insBasicInfoDO.insOrgCode =
              item.orgCode);
          } else if (flag == "tisOrgList") {
            return (this.getUnderwritingInformation.insBasicInfoDO.tisOrgCode =
              item.orgCode);
          } else if (flag === "bldOrgList") {
            return (this.getUnderwritingInformation.insBasicInfoDO.insuredOrgCode =
              item.orgCode);
          }
        }
      }
    },
    selectChange1(flag, val) {
      this.editData(flag, val);
    },
    // 勾选
    selectChange(flag, val) {
      if (this.disabled) {
        return false;
      }
      this.$store.commit("CHECKEDMAINOTHER", { flag, val });
    },
    // 初始化
    init(projectId) {
      this.projectId = projectId;
      this.underwritingInformation(projectId);
      this.getTenantInfoById();
      if(this.showMyCase == "insertInsureInfo" &&
        this.$getversionData.lesseeId=='eidi-beijing' &&
        JSON.stringify(this.getOrgId.tisOrgList).indexOf("未指定")==-1
        ) {
        this.getOrgId.tisOrgList.unshift({orgId: "未指定",orgName: "未指定"})
      }
      if (
        this.showMyCase == "startRiskPlan" ||
        this.showMyCase == "insertInsureInfo"
      ) {
        this.disableds = false;
      } else {
        this.disableds = true;
      }
    },
    //区块链
    getTenantInfoById() {
      http
        .get("/sys/idiInfo/getTenantInfoById/", this.$getversionData.lesseeId)
        .then(res => {
          if (res.code == 0) {
            this.baseUrl = res.domain;
            this.getVueQr(this.projectId);
          }
        });
    },
    //获取二维码
    getVueQr(projectId) {
      this.downloadData.url = "";
      http.get("/project/blockchain/", projectId).then(res => {
        if (res.data) {
          this.downloadData.url =
            this.baseUrl + "/boobyBlock?content=" + res.data.underwritingHash;
        }
      });
    }
  },
  mounted() {
    // let disableds = [
    //   "buildingList",
    //   "invoice",
    //   "riskManageQuotation",
    //   "insurancePolicy",
    //   "coinsuranceAgreement",
    //   "insuranceApplication"
    // ];
    // for (let item of disableds) {
    //   let dom = document.getElementById(item);
    //   dom.disabled = false;
    //   dom.classList.remove("is-disabled");
    // }
  }
};
</script>

<style scoped lang="scss">
@import "@/assets/styles";
.font-size20 {
  font-size: 20px;
}
.ml55 {
  margin-left: 55px;
}
.login-form-input /deep/.el-input__inner {
  padding-right: 0;
}
.mc-qr {
  position: absolute;
  right: 8px;
  z-index: 4;
}
.mc-edit:hover {
  background: rgba(255, 255, 255, 0.6);
}
.mc-bg {
  background: rgba(255, 255, 255, 0.9);
}
.qr-form /deep/ {
  .el-col-12 /deep/ .el-input {
    width: 183.5px;
  }
}
</style>

<template>
  <div id="ProjectReturns">
    <el-divider class="mc-divider"></el-divider>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold">项目回访列表</span>
    </el-col>
    <el-form label-width="137px" size="mini" label-position="left" align="left" class="mc-form" >
      <el-row>
        <el-col :span="23">
          <el-form-item label>
            <el-table
              class="mc-table"
              tooltip-effect="light"
              :data="getProjectReturns.rows"
              style="width: 100%"
              @row-dblclick="backMytodo"
            >
              <!-- <el-table-column type="index" align="center" label="序号" width="100"></el-table-column> -->
              <el-table-column type="index" align="center" label="序号" width="100" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
              <el-table-column prop="surveyDate" align="center" label="回访时间">
                <template slot-scope="scope">{{ scope.row.surveyDate | filterDate}}</template>
              </el-table-column>
              <el-table-column prop="reportScope" align="center" label="本报告所涉及的承保范围" width="180" :show-overflow-tooltip='true'></el-table-column>
              <el-table-column prop="revistSummary" align="center" label="回访小结" :show-overflow-tooltip='true'></el-table-column>
              <el-table-column  align="center" label="报告状态">
                <template slot-scope="scope">
                  <div v-if="scope.row.sqlStatus=='0'">已保存</div>
                  <div v-if="scope.row.sqlStatus=='1'">已提交</div>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              small
              class="page-lucency text-right mt10"
              layout="prev, pager, next"
              :current-page.sync="offset"
              :page-size="limit"
              :total="getProjectReturns.total"
              @current-change="(val) => { projectReturn('', val) }"
            ></el-pagination>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-dialog class="dialog" title="风险回访报告详情列表" :visible.sync="dialogVisible" :close-on-click-modal="false">
      <div>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">项目信息</span>
        </el-col>
        <el-form
          class="mc-form"
          :model="visitDetails.riskCheckReportDO"
          :rules="rules"
          ref="ruleForm"
          label-width="137px"
          size="mini"
          label-position="left"
          align="left"
        >
          <el-row>
            <el-col :span="11">
              <el-form-item label="项目报建号：" prop="buildPermitNo">
                <el-input
                  v-model="visitDetails.riskCheckReportProjectInfoDO.buildPermitNo"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="项目名称：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.projectName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="建设单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.buildOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="总包单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.gconOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="监理单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.supOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="设计单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.designOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="勘察单位：">
                <el-input v-model="visitDetails.riskCheckReportProjectInfoDO.invOrgName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-divider class="mc-divider lucency"></el-divider>
          <el-col class="text-left mc-title" :span="24">
            <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
            <span style="font-size: 14.5px;" class="blue font-bold">回访信息</span>
          </el-col>
          <el-row>
            <el-col :span="11">
              <el-form-item label="回访时间：" prop="surveyDate">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="visitDetails.riskCheckReportDO.surveyDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  disabled
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="报告出具日期：" prop='reportDate'>
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="visitDetails.riskCheckReportDO.reportDate"
                  disabled
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="22">
              <el-form-item label="本报告所涉及的承保范围：" class="mc-multi-row">
                <el-input
                  v-model="visitDetails.riskCheckReportDO.reportScope"
                disabled
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="22">
              <el-form-item>
                <el-table
                  class="mc-table"
                  style="width: 100%"
                  :data="visitDetails.riskCheckReportItemDO"
                >
                  <el-table-column prop="clause" align="center" label="保险责任范围"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)" width="150"></el-table-column>
                   <el-table-column prop="type" align="center" label="保险类型" width="150">
                    <template
                      slot-scope="scope"
                    >{{scope.row.type | filterCode(listBaseData.IDI_LIABILITIES_TYPE,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2 , maxRows: 4}"
                        style="opacity:0.2 color:#3E3A39;"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        class="tex"
                        placeholder="请输入内容"
                        disabled
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="22">
              <el-form-item label="回访小结：">
                <el-input
                  v-model="visitDetails.riskCheckReportDO.revistSummary"
                 disabled
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="风险报告回访：" prop="fileName">
                <el-input v-model="visitDetails.riskCheckReportDO.fileName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="4">
              <span style="left: 90px; position: relative">
                <el-button size="mini" @click="downloadBtn()" :disableds='disableds' >下载</el-button>
              </span>
            </el-col>
          </el-row>
          <el-row style="text-align: right;" class="btns">
            <el-button size="mini" @click="shutbtn()">关闭</el-button>
          </el-row>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
export default {
  name: "ProjectReturns",
  data() {
    return {
      offset: 1,
      limit: 5,
      disableds:true,
      dialogVisible: false,
      projectId: "",
      visitDetails: {
        riskCheckReportDO: {},
        riskCheckReportProjectInfoDO: {},
        riskCheckReportItemDO: []
      },
      rules: {
        surveyDate: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        reportDate:[
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        fileName: [
          { required: true, message: "请上传风险报告", trigger: "blur" }
        ]
      },
      verificationPass: false
    };
  },
  computed: {
    ...mapGetters(["getProjectReturns",'listBaseData'])
  },
  methods: {
    ...mapActions(["projectReturns"]),
    projectReturn(projectId) {
      if (projectId) {
        this.projectId = projectId;
      }
      let data = {
        projectId: this.projectId,
        offset:this.offset,
        limit: this.limit,
        isView: true,
        sqlStatus: 1
      };
      this.projectReturns(data);
    },
    backMytodo(row) {
      this.dialogVisible = true;
      this.rows = row.id;
      this.getVisitReportView()
      // this.getVisitBaseInfo()
    },
    //关闭按钮
    shutbtn() {
      this.dialogVisible =false
    },
    //下载
    downloadBtn() {
      var a = document.createElement("a");
      var filename = this.visitDetails.riskCheckReportDO.fileName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    //查看回访详情
    async getVisitReportView() {
      const id = this.rows;
      const res = await this.$api.visitReportView(id);
      this.visitDetails = res.data;
      this.url = this.visitDetails.riskCheckReportDO.revistReportFile;
      if(this.visitDetails.riskCheckReportDO.fileName){
        this.disableds=false
      }
    },
    //查询项目基本信息
    async getVisitBaseInfo() {
      const projectId = this.projectId;
      const res = await this.$api.visitBaseInfo(projectId);
      this.visitDetails.riskCheckReportDO = res.data.riskCheckReportDO || {
        surveyDate: ""
      };
      this.visitDetails.riskCheckReportProjectInfoDO =
        res.data.riskCheckReportProjectInfoDO;
      this.visitDetails.riskCheckReportItemDO = res.data.riskCheckReportItemDO;
      this.$refs["ruleForm"].resetFields();
    },
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.dialog /deep/ .el-dialog {
  width: 815px;
  background: rgb(248, 245, 245 )
}
.dialog /deep/.el-dialog__header {
  padding: 8px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
// .dialog /deep/ .el-input {
//   width: 193px!important;
// }
.dialog /deep/ .btn1 {
  width: 56px;
  height: 28px;
  background: rgba(16, 143, 235, 1);
  padding: 7px 15px;
  font-size: 12px;
  border-radius: 3px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
  border: rgba(16, 143, 235, 1);
}
</style>
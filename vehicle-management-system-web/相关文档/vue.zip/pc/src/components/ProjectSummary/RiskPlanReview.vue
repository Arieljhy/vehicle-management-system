<template>
  <div id="RiskPlanReview">
    <el-divider id="CompletionInsurance" class="mc-divider"></el-divider>
    <el-col class="text-left mc-title" :span="24">
      <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
      <span style="font-size: 14.5px;" class="blue font-bold">{{ title }}</span>
    </el-col>
    <el-form :disabled="disabled" class="mc-form" label-width="137px" size="mini" label-position="left" align="left">
      <el-row>
        <el-col :span="12">
          <el-form-item label="审核结果：">
            <el-radio-group v-model="caseDetails.apple">
              <el-radio label="同意"></el-radio>
              <el-radio label="不同意"></el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="23">
          <el-form-item label="审核意见：">
             <el-input
                  type="textarea"
                  :autosize=" {minRows: 4}"
                  placeholder="请输入内容"
                  v-model="caseDetails.apple"
                ></el-input>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row>
        <el-col :span="8">
          <el-form-item label="审核人员：">
            <el-input v-model="caseDetails.people"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="所属部门：">
            <el-input v-model="caseDetails.section"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="审核时间：">
            <el-date-picker v-model="value1" type="date" placeholder="选择日期"></el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
export default {
  name: "InsuranceReview",
  props: {
    disabled: {
      type: Boolean,
      required: false,
      default: false
    },
    title: {
      type: String,
      required: false,
      default: '风险管理计划审核'
    }
  },
  data() {
    return {
      caseDetails: {
        apple: "测试内容", 
        people: '',
        section: '',

      },
      value1: ''
    };
  }
};
</script>
<style scoped lang="scss">
@import '@/assets/styles';
</style>
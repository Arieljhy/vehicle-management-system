<template>
  <div id="RiskPlan">
    <el-dialog
      class="dialog"
      :title="dialogUnit.title"
      :visible.sync="queryUnit"
      width="615px"
      :close-on-click-modal="false"
    >
      <!-- 表单 -->
      <el-row v-if="Tables">
        <el-col :span="24">
          <el-input
            @keyup.enter.native="searchUnit()"
            style="width: 50%"
            size="small"
            v-model="dialogUnit.searchOrg"
          >
            <el-button type="primary" @click="searchUnit()" slot="append" icon="el-icon-search"></el-button>
          </el-input>
          <el-button
            style="position: relative;top:8px;left: 114px"
            size="mini"
            type="primary"
            @click="replace"
          >创建</el-button>
        </el-col>
        <el-col :span="24">
          <el-table
            class="mc-table"
            :data="unitData.rows"
            style="width: 100%; margin-top: 20px;border:1px #ccc solid"
          >
            <el-table-column width="25">
              <template slot-scope="scope">
                <el-checkbox @change="check(scope.row)" v-model="scope.row.check"></el-checkbox>
              </template>
            </el-table-column>
            <el-table-column>
              <template slot-scope="scope">
                <div
                  style="width: 100%;"
                  class="mouse-pointer"
                  @click="check(scope.row, 'body')"
                >{{ scope.row.orgName }}</div>
              </template>
            </el-table-column>
          </el-table>
        </el-col>
        <el-col :span="24">
          <el-pagination
            small
            :page-size="10"
            @current-change="(val) => {searchUnit('', val)}"
            class="text-right mt10"
            layout="prev, pager, next"
            :total="unitData.total"
          ></el-pagination>
        </el-col>
      </el-row>
      <!-- 输入TODO -->
      <el-row v-if="Form">
        <el-form
          class="mc-form"
          :model="numberForm"
          :rules="orgRules"
          ref="numberForm"
          label-width="150px"
          size="mini"
          label-position="left"
          align="left"
        >
          <el-form-item :label="dialogUnit.title +':'" prop="orgName">
            <el-input v-model="numberForm.orgName" size="mini" style="width:200px"></el-input>
          </el-form-item>
          <el-form-item label="统一社会机构编码:" prop="orgCode">
            <el-input v-model="numberForm.orgCode" size="mini" style="width:200px"></el-input>
          </el-form-item>
          <el-form-item label="联系人:" prop="contacts">
            <el-input v-model="numberForm.contacts" size="mini" style="width:200px"></el-input>
          </el-form-item>
          <el-form-item
            label="联系电话:"
            prop="contactTel"
            :rules="[
          { required: true, type: 'number', message: '联系电话必须为数字值'}
        ]"
          >
            <el-input
              v-model.number="numberForm.contactTel"
              autocomplete="off"
              size="mini"
              style="width:200px"
            ></el-input>
          </el-form-item>
        </el-form>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button @click="confirm" size="mini" type="primary">{{ Form ? '创建' : '确定' }}</el-button>
        <el-button @click="queryUnit = false" size="mini">关闭</el-button>
      </span>
    </el-dialog>

    <el-divider class="mc-divider"></el-divider>
    <div :class="[{'mc-edit':!disabled}, {'mc-bg':!disabled}]">
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">风险检查工作计划</span>
      </el-col>
      <el-form
        :model="getRiskPlan.riskManagementPlanBigDO"
        ref="validRiskPlan"
        :disabled="disabled"
        class="mc-form"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
      >
        <el-row>
          <el-col :span="8">
            <el-form-item label="牵头保险公司：">
              <el-select
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.insOrgId"
                placeholder="请选择"
              >
                <el-option
                  v-for="item in getOrgId.insOrgList"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="风险管理机构：">
              <el-select
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.tisOrgId"
                placeholder="请选择"
              >
                <el-option
                  v-for="item in getOrgId.tisOrgList"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险分类：">
              <el-select
                v-model="getRiskPlan.riskManagementPlanBigDO.insCategory"
                disabled
                placeholder="请选择"
              >
                <el-option
                  v-for="item in listBaseData.IDI_INS_CATEGORIES"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="保单号：">
              <el-input disabled v-model="getRiskPlan.riskManagementPlanBigDO.insContractNo"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="交底会会议时间:"
              prop="meettingSummaryDate"
              :rules="[{ required: true, message: '请选择', trigger: 'change' }]"
            >
              <el-date-picker
                :clearable="false"
                value-format="yyyy-MM-dd HH:mm:ss"
                v-model="getRiskPlan.riskManagementPlanBigDO.meettingSummaryDate"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="预计开始时间："
              prop="plannedStartDate"
              :rules="[{ required: true, message: '请选择', trigger: 'change' }]"
            >
              <el-date-picker
                :clearable="false"
                value-format="yyyy-MM-dd HH:mm:ss"
                v-model="getRiskPlan.riskManagementPlanBigDO.plannedStartDate"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="项目名称：">
              <el-input disabled v-model="getRiskPlan.riskManagementPlanBigDO.projectName"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="总包单位：">
              <span
                @click="searchUnit({title: '总包单位', orgType: 'SGF',  id: 'gconOrgId',name:'gconOrgName'})"
              >
                <el-input
                  :disabled="disabled"
                  readonly
                  v-model="getRiskPlan.riskManagementPlanBigDO.gconOrgName"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="勘察单位：">
              <span
                @click="searchUnit({title: '勘察单位', orgType: 'KC',  id: 'invOrgId',name:'invOrgName'})"
              >
                <el-input
                  :disabled="disabled"
                  readonly
                  v-model="getRiskPlan.riskManagementPlanBigDO.invOrgName"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="监理单位：">
              <span
                @click="searchUnit({title: '监理单位', orgType: 'JL',  id: 'supOrgId' ,name:'supOrgName'})"
              >
                <el-input
                  :disabled="disabled"
                  readonly
                  v-model="getRiskPlan.riskManagementPlanBigDO.supOrgName"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="设计单位：">
              <span
                @click="searchUnit({title: '设计单位', orgType: 'SJ',  id:'designOrgId',name:'designOrgName' })"
              >
                <el-input
                  :disabled="disabled"
                  readonly
                  v-model="getRiskPlan.riskManagementPlanBigDO.designOrgName"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="建设单位：">
              <span
                @click="searchUnit({title: '建设单位', orgType: 'BLD',  id: 'builderOrgId' ,name:'builderOrgName'})"
              >
                <el-input
                  :disabled="disabled"
                  readonly
                  v-model="getRiskPlan.riskManagementPlanBigDO.builderOrgName"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="项目参与人：">
              <el-table class="mc-table" :data="getRiskPlan.userDO" style="width: 100%">
                <el-table-column prop="mobile" align="center" label="联系电话">
                  <template slot-scope="scope">
                    <el-input
                      v-model="scope.row.mobile"
                      size="mini"
                      placeholder="请录入联系电话"
                      @blur="checkUser(scope.row)"
                    />
                  </template>
                </el-table-column>
                <el-table-column prop="username" align="center" label="姓名">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.username" size="mini" disabled />
                  </template>
                </el-table-column>
                <el-table-column prop="professional" align="center" label="专业领域">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.professional" size="mini" disabled />
                  </template>
                </el-table-column>
                <el-table-column prop="orgName" align="center" label="机构名称">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.orgName" size="mini" disabled />
                  </template>
                </el-table-column>
                <el-table-column v-if="!disabled" align="center" width="180">
                  <template slot="header">
                    <div
                      class="el-icon-circle-plus-outline mouse-pointer"
                      style="font-size:20px;line-height:22px;margin-top: 10px;"
                      @click="addParticipant"
                    ></div>
                  </template>
                  <template slot-scope="scope">
                    <div
                      class="el-icon-remove-outline mouse-pointer"
                      style="font-size:20px;"
                      @click="delParticipant(scope.$index)"
                    ></div>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row></el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item
              class="mc-multi-row"
              label="项目风险管理检查计划："
              prop="riskManagePlanFileName"
              :rules="[{required: true, message: '请上传', trigger: 'change'}]"
            >
              <el-input
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.riskManagePlanFileName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!riskManagePlan" :src="imgUpload" class="img-upload" />
              <el-progress v-if="riskManagePlan" type="circle" :percentage="riskManagePlanFileName" :width="30"></el-progress>
              <!-- <img v-if="riskManagePlan" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('riskManagePlan', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('riskManagePlan')">删除</el-button>
              <el-button
                id="riskManagePlan"
                @click="download('riskManagePlan')"
                size="mini"
                v-show="getRiskPlan.riskManagementPlanBigDO.riskManagePlanFileName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="6">
            <el-form-item
              label-width="160px"
              label="风险交底会议纪要："
              prop="meettingSummaryFileName"
              :rules="[{required: true, message: '请上传', trigger: 'change'}]"
            >
              <el-input
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.meettingSummaryFileName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!meettingSummary" :src="imgUpload" class="img-upload" />
              <el-progress v-if="meettingSummary" type="circle" :percentage="meettingSummaryFileName" :width="30"></el-progress>
              <!-- <img v-if="meettingSummary" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('meettingSummary', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('meettingSummary')">删除</el-button>
              <el-button
                id="meettingSummary"
                @click="download('meettingSummary')"
                size="mini"
                v-show="getRiskPlan.riskManagementPlanBigDO.meettingSummaryFileName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item
              class="mc-multi-row"
              label="项目施工阶段图纸："
              prop="layoutForConstructionFileName"
              :rules="[{required: true, message: '请上传', trigger: 'change'}]"
            >
              <el-input
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.layoutForConstructionFileName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!layoutForConstruction" :src="imgUpload" class="img-upload" />
              <el-progress v-if="layoutForConstruction" type="circle" :percentage="layoutForConstructionFileName" :width="30"></el-progress>
              <!-- <img v-if="layoutForConstruction" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('layoutForConstruction', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('layoutForConstruction')">删除</el-button>
              <el-button
                id="layoutForConstruction"
                @click="download('layoutForConstruction')"
                size="mini"
                v-show="getRiskPlan.riskManagementPlanBigDO.layoutForConstructionFileName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="6">
            <el-form-item
              label-width="160px"
              label="风险初勘报告："
              prop="riskPreProspectFileName"
              :rules="[{required: true, message: '请上传', trigger: 'change'}]"
            >
              <el-input
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.riskPreProspectFileName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!riskPreProspect" :src="imgUpload" class="img-upload" />
              <el-progress v-if="riskPreProspect" type="circle" :percentage="riskPreProspectFileName" :width="30"></el-progress>
              <!-- <img v-if="riskPreProspect" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">  
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('riskPreProspect', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('riskPreProspect')">删除</el-button>
              <el-button
                id="riskPreProspect"
                @click="download('riskPreProspect')"
                size="mini"
                v-show="getRiskPlan.riskManagementPlanBigDO.riskPreProspectFileName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row v-if="$getversionData.lesseeId=='eidi-yangquan'">
          <el-col :span="6">
            <el-form-item
              class="mc-multi-row"
              label="施工许可证："
              prop="constructionLicenseFileName"
              :rules="[{required: true, message: '请上传', trigger: 'change'}]"
            >
              <el-input
                disabled
                v-model="getRiskPlan.riskManagementPlanBigDO.constructionLicenseFileName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="! constructionLicense" :src="imgUpload" class="img-upload" />
              <el-progress v-if="constructionLicense" type="circle" :percentage="constructionLicenseFileName" :width="30"></el-progress>
              <!-- <img v-if=" constructionLicense" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('constructionLicense', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('constructionLicense')">删除</el-button>
              <el-button
                id="constructionLicense"
                @click="download('constructionLicense')"
                size="mini"
                v-show="getRiskPlan.riskManagementPlanBigDO.constructionLicenseFileName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="备注信息：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 3}"
                placeholder="请输入内容"
                v-model="getRiskPlan.riskManagementPlanBigDO.note"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-dialog
        title="用户添加"
        :visible.sync="dialogAddUser"
        class="dialog"
        :close-on-click-modal="false"
      >
        <el-form
          :model="userInfo"
          ref="userInfo"
          class="mc-addUser"
          :rules="rules"
          size="mini"
          label-width="120px"
        >
          <el-row>
            <el-col :span="12">
              <el-form-item label="姓名：" prop="username">
                <el-input v-model="userInfo.username"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="电话：" prop="mobile">
                <el-input v-model="userInfo.mobile" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="专业领域：" prop="professional">
                <el-input v-model="userInfo.professional"></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="12">
            <el-form-item prop="orgType" label="机构类型：">
              <el-select v-model="userInfo.orgType" clearable placeholder="请选择" @change="getInsOrg">
                <el-option
                  v-for="item in orgTypes"
                  :key="item.orgType"
                  :label="item.value"
                  :value="item.orgType"
                ></el-option>
              </el-select>
            </el-form-item>
            </el-col>-->
            <el-col :span="12">
              <el-form-item prop="insOrgId" label="机构名称：">
                <el-select
                  v-model="userInfo.insOrgId"
                  clearable
                  placeholder="请选择"
                  @change="getInsOrg"
                >
                  <el-option
                    v-for="item in orgIds"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item prop="roleId" label="角色：">
                <el-select v-model="userInfo.roleId" clearable placeholder="请选择">
                  <el-option
                    v-for="item in roleList"
                    :key="item.roleId"
                    :label="item.roleName"
                    :value="item.roleId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="可查看项目区域：" prop="list">
                <el-input v-model="userInfo.list" style="display:none"></el-input>
                <el-table
                  class="mc-table district-table"
                  tooltip-effect="light"
                  :data="userInfo.listTransArea"
                  style="width: 100%;border-radius:2px;"
                >
                  <el-table-column prop="province" align="center" label="省">
                    <template slot-scope="scope">
                      <el-select
                        class="miniColumn"
                        @change="getCity(scope.row,'city')"
                        v-model="scope.row.province"
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in district"
                          :key="item.province"
                          :label="item.province"
                          :value="item.province"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="city" align="center" label="市">
                    <template slot-scope="scope">
                      <el-select
                        class="miniColumn ml5"
                        @change="getCity(scope.row, 'county')"
                        v-model="scope.row.city"
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in scope.row.citys"
                          :key="item.name"
                          :label="item.name"
                          :value="item.name"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="district" align="center" label="区/县">
                    <template slot-scope="scope">
                      <el-select
                        class="miniColumn ml5"
                        v-model="scope.row.county"
                        placeholder="请选择"
                        @change="selectCounty(scope.row.county)"
                      >
                        <el-option
                          v-for="item in scope.row.countys"
                          :key="item.district"
                          :label="item.district"
                          :value="item.district"
                        ></el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="district" align="center">
                    <template slot="header" solt-scope="scope">
                      <i
                        @click="doRowAdd"
                        class="el-icon-circle-plus-outline mouse-pointer"
                        style="font-size:20px"
                      ></i>
                    </template>
                    <template slot-scope="scope">
                      <i
                        @click="doRowDel(scope.$index)"
                        class="el-icon-remove-outline mouse-pointer"
                        style="font-size:20px"
                      ></i>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button size="mini" @click="dialogAddUser = false">取 消</el-button>
          <el-button size="mini" type="primary" @click="addUserInfo('userInfo')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import imgUpload from "@/assets/imgs/put.png";
import { mapGetters, mapActions } from "vuex";
import { orgType } from "@/assets/js/codes";
import md5 from "js-md5";
import axios from "axios";
export default {
  name: "RiskPlan",
  props: {
    disabled: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data() {
    return {
      riskManagePlanFileName: 0,
      meettingSummaryFileName: 0,
      layoutForConstructionFileName: 0,
      riskPreProspectFileName: 0,
      constructionLicenseFileName: 0,
      citys: [],
      county: "",
      buildingType: "",
      province: "", //省
      address: "",
      countys: [],
      mechanism: {
        builderOrgName: "",
        builderOrgId: "",
        gconOrgName: "",
        gconOrgId: "",
        invOrgName: "",
        invOrgId: "",
        supOrgName: "",
        supOrgId: "",
        designOrgName: "",
        designOrgId: "",
        insOrgName: "",
        insOrgId: ""
      },
      riskManagePlan: false,
      meettingSummary: false,
      layoutForConstruction: false,
      riskPreProspect: false,
      constructionLicense: false,
      orgTypes: [...orgType],
      imgUpload,
      queryUnit: false,
      title: "",
      Form: false,
      Tables: true,
      orgName: "",
      orgCode: "",
      contacts: "",
      numberForm: {
        contactTel: "",
        contacts: "",
        orgName: "",
        orgCode: ""
      },
      unitData: {},
      dialogUnit: {
        title: "",
        orgType: "",
        searchOrg: ""
      },
      rules: {
        list: [{ required: true, message: " ", trigger: "blur" }],
        username: [{ required: true, message: "请录入姓名", trigger: "blur" }],
        mobile: [{ required: true, message: "请录入手机号", trigger: "blur" }],
        orgType: [
          { required: true, message: "请选择机构类型", trigger: "change" }
        ],
        insOrgId: [
          { required: true, message: "请选择机构名称", trigger: "change" }
        ],
        roleId: [{ required: true, message: "请选择角色", trigger: "change" }]
      },
      orgRules: {
        //TODO
        orgName: [
          { required: true, message: "请选择机构名称", trigger: "change" }
        ],
        orgCode: [
          { required: true, message: "请选择统一社会编码", trigger: "change" }
        ],
        contacts: [
          { required: true, message: "请选择联系人", trigger: "change" }
        ],
        contactTel: [
          { required: true, message: "请选择联系电话", trigger: "change" }
        ]
      },
      dialogAddUser: false,
      userInfo: {
        insOrgId: "",
        roleId: ""
      },
      roleList: [],
      orgIds: [],
      getRiskPlanArray: [],
      addORGFlag: false
    };
  },
  computed: {
    ...mapGetters([
      "getRiskPlan",
      "getOrgId",
      "listBaseData",
      "district",
      "getCitys"
    ]),
    watchProjectId() {
      return this.$store.state.app.projectSummary.riskPlan
        .riskManagementPlanBigDO.projectId;
    }
  },
  watch: {
    watchProjectId(n, o) {
      this.$refs["validRiskPlan"].resetFields();
    },
    queryUnit() {
      if (this.queryUnit == true) {
        this.Form = false;
        this.Tables = true;
      }
      if (this.queryUnit == false) {
        this.dialogUnit.searchOrg = ""; //置空输入框
      }
    }
  },
  async created() {
    if (JSON.parse(sessionStorage.getItem(this.$getversionData.userInfo))) {
      const { code, msg, data } = await this.$api.findCfgAreaInfo();
      if (code === 0) {
        this.districtList = data;
      }
    }
  },
  methods: {
    ...mapActions(["riskPlan"]),
    selectCounty(county) {
      let countyNum = 0;
      this.userInfo.listTransArea.map(item => {
        if (item.county == county) {
          countyNum++;
          if (countyNum > 1) {
            item.county = "";
            this.$messageError({
              message: "该区域已存在"
            });
            return;
          }
        }
      });
    },
    //确定
    async confirm() {
      if (!this.Form) {
        let orgName = "";
        let orgId = "";
        for (let row of this.unitData.rows) {
          if (row.check) {
            orgName = row.orgName;
            orgId = row.orgId;
          }
        }
        this.$set(
          this.getRiskPlan.riskManagementPlanBigDO,
          this.dialogUnit.flag,
          orgName
        );
        this.$set(
          this.getRiskPlan.riskManagementPlanBigDO,
          this.dialogUnit.id,
          orgId
        );
        this.queryUnit = false;
      } else {
        this.$refs.numberForm.validate(valid => {
          if (valid) {
            this.addORGFlag = true;
          } else {
            return false;
          }
        });
        if (this.addORGFlag) {
          const keywords = { contactTel: this.numberForm.contactTel };
          const res = await this.$api.checkContactTel(keywords);
          if (!res.isExist) {
            this.setOrg();
            this.queryUnit = false;
          } else if (res.isExist) {
            this.$messageError({
              message: "号码已存在"
            });
            this.numberForm.contactTel = "";
          }
        }
      }
    },
    //单选
    check(row, flag) {
      for (let item of this.unitData.rows) {
        if (item.orgId !== row.orgId) {
          item.check = false;
        } else {
          if (flag === "body") {
            item.check = !row.check;
          }
        }
      }
    },
    replace() {
      this.Form = true;
      this.Tables = false;
      this.numberForm.orgName = ""; //置空输入框
      this.numberForm.orgCode = "";
      this.numberForm.contacts = "";
      this.orgId = "";
      this.numberForm.contactTel = "";
    },
    // 创建机构
    async setOrg() {
      const keywords = {
        orgId: this.orgId,
        orgName: this.numberForm.orgName,
        orgType: this.dialogUnit.orgType,
        orgCode: this.numberForm.orgCode,
        contacts: this.numberForm.contacts,
        contactTel: this.numberForm.contactTel
      };
      const data = await this.$api.setOrgId(keywords);
      this.$messageSuccess({ message: "创建成功" });
      this.$set(
        this.getRiskPlan.riskManagementPlanBigDO,
        this.dialogUnit.flag,
        data.data.orgName
      );
      this.$set(
        this.getRiskPlan.riskManagementPlanBigDO,
        this.dialogUnit.id,
        data.data.orgId
      );
    },
    //查询
    searchUnit(data, offset = 1) {
      if (this.disabled) {
        return !this.disabled;
      }
      this.queryUnit = true;
      if (data) {
        this.dialogUnit.flag = data.name;
        this.dialogUnit.orgType = data.orgType;
        this.dialogUnit.title = data.title;
        this.dialogUnit.id = data.id;
      }
      this.$api
        .getOrg({
          orgType: this.dialogUnit.orgType,
          orgName: this.dialogUnit.searchOrg,
          limit: 10,
          offset
        })
        .then(res => {
          for (let item of res.data.rows) {
            if (
              this.getRiskPlan.riskManagementPlanBigDO[this.dialogUnit.flag] ==
              item.orgName
            ) {
              item.check = true;
            } else {
              item.check = false;
            }
          }
          this.unitData = res.data;
        });
    },
    getCity(i, flag) {
      if (flag === "county") {
        let list = [];
        for (let item of this.district) {
          list = [...list, ...item.city];
        }
        for (let item of list) {
          if (i.city == item.name) {
            i.countys = item.area;
          }
        }
      } else if (flag === "city") {
        for (let city of this.district) {
          if (city.province == i.province) {
            i.citys = city.city;
          }
        }
      }
    },
    //添加用户区域
    doRowAdd(scope) {
      const keywords = {
        province: this.district[0].province,
        citys: []
      };
      for (let city of this.district) {
        if (city.province == this.district[0].province) {
          keywords.citys = city.city;
        }
      }
      this.userInfo.listTransArea.push(keywords);
    },
    //删除用户区域
    doRowDel(curIndex) {
      this.userInfo.listTransArea.splice(curIndex, 1);
    },
    //添加参与人
    addParticipant() {
      let newPic = { username: "", professional: "", mobile: "", orgName: "" };
      this.getRiskPlan.userDO.push(newPic);
    },
    //删除参与人
    delParticipant(index) {
      this.getRiskPlan.userDO.splice(index, 1);
    },
    // 把对象转换为数组
    ObjectArr(arr, object) {
      for (const key in object) {
        arr.push({
          name: key,
          value: object[key]
        });
      }
      return arr;
    },
    //去重
    arrWeightRemoval(obj) {
      const list = [
        "gconOrg",
        "builderOrg",
        "invOrg",
        "supOrg",
        "designOrg",
        "insOrg"
      ];
      const rightList = [];
      list.map((ob, index) => {
        for (var item in obj) {
          const keywords = { orgName: "", orgId: "" };
          if (item.indexOf(ob) > -1) {
            keywords.orgName = obj[ob + "Id"];
            keywords.orgId = obj[ob + "Name"];
          }
          if (keywords.orgName) {
            rightList.push(keywords);
          }
        }
      });
      return this.duplicateRemoval(rightList);
    },
    duplicateRemoval(arr) {
      var obj = {};
      arr = arr.reduce(function(item, next) {
        obj[next.orgName] ? "" : (obj[next.orgName] = true && item.push(next));
        return item;
      }, []);
      return arr;
    },
    //根据手机号查询参与人信息
    async checkUser(row) {
      if (row.mobile.length !== 11) {
        this.$messageError({ message: "请输入正确手机号" });
        return;
      }
      var reg = /^[1][3,4,5,7,8,9][0-9]{9}$/;
      if (!reg.test(row.mobile)) {
        this.$messageError({ message: "请输入正确手机号" });
        return;
      }
      this.mechanism.insOrgName = JSON.parse(
        sessionStorage.getItem("eidi.ins")
      ).orgId;
      this.mechanism.insOrgId = JSON.parse(
        sessionStorage.getItem("eidi.ins")
      ).orgName;
      this.mechanism.gconOrgName = this.getRiskPlan.riskManagementPlanBigDO.gconOrgId;
      this.mechanism.gconOrgId = this.getRiskPlan.riskManagementPlanBigDO.gconOrgName;
      this.mechanism.builderOrgName = this.getRiskPlan.riskManagementPlanBigDO.builderOrgId;
      this.mechanism.builderOrgId = this.getRiskPlan.riskManagementPlanBigDO.builderOrgName;
      this.mechanism.invOrgName = this.getRiskPlan.riskManagementPlanBigDO.invOrgId;
      this.mechanism.invOrgId = this.getRiskPlan.riskManagementPlanBigDO.invOrgName;
      this.mechanism.supOrgName = this.getRiskPlan.riskManagementPlanBigDO.supOrgId;
      this.mechanism.supOrgId = this.getRiskPlan.riskManagementPlanBigDO.supOrgName;
      this.mechanism.designOrgName = this.getRiskPlan.riskManagementPlanBigDO.designOrgId;
      this.mechanism.designOrgId = this.getRiskPlan.riskManagementPlanBigDO.designOrgName;
      this.getRiskPlanArray = this.arrWeightRemoval(this.mechanism);
      this.orgIds = this.getRiskPlanArray;
      const keywords = { mobile: row.mobile };
      if (row.mobile) {
        const res = await this.$api.getParticipants(keywords);
        if (res.code == 500) {
          this.$confirm("此用户不存在是否添加?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(() => {
              this.userInfo = {
                list: "55",
                password: md5("123456"),
                status: "1",
                insOrgId: "",
                roleId: "",
                listTransArea: [],
                listTransHouseProperty: [],
                mobile: row.mobile,
                username: "",
                professional: "",
                orgType: "",
                orgName: ""
              };
              row.username = "";
              row.professional = "";
              row.orgName = "";
              this.dialogAddUser = true;
              if ((this.dialogAddUser = true)) {
                this.roleList = null;
              }
              this.$nextTick(() => {
                this.$refs.userInfo.resetFields();
                this.userInfo.mobile = row.mobile;
              });
            })
            .catch(() => {
              row.mobile = "";
              row.username = "";
              row.professional = "";
              row.orgName = "";
            });
        } else if (res.code == 0) {
          row.username = res.data.username;
          row.professional = res.data.professional;
          row.userId = res.data.userId;
          row.orgName = res.data.orgName;
        } else if (res.code == 1) {
          this.$messageSuccess({ message: res.msg });
        }
      } else {
        row.username = "";
        row.professional = "";
        row.userId = "";
        row.orgName = "";
      }
    },
    //新增用户信息
    async addUserInfo(formName) {
      this.addNewUserFlag = false;
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.addNewUserFlag = true;
        } else {
          return false;
        }
      });
      if (this.addNewUserFlag) {
        if (this.userInfo.listTransArea.length > 0) {
          this.userInfo.tenantId = JSON.parse(
            sessionStorage.getItem(this.$getversionData.userInfo)
          ).tenantId;
          const keywords = this.userInfo;
          const res = await this.$api.addParticipants(keywords);
          if (res.code == 0) {
            this.getRiskPlan.userDO.map((item, index) => {
              if (item.mobile == res.data.mobile) {
                item.professional = res.data.professional;
                item.userId = res.data.userId;
                item.username = res.data.username;
                item.mobile = res.data.mobile;
                item.orgName = res.data.orgName;
              }
            });
            this.$messageSuccess({ message: "添加成功" });
            this.dialogAddUser = false; //保存成功，关闭弹框
          } else if (res.code == 1) {
            this.$messageError({ message: res.msg });
          }
        } else {
          this.$messageError({ message: "可查看项目区域不能为空" });
        }
      }
    },
    //获取机构名称/角色
    async getInsOrg() {
      this.userInfo.roleId = "";
      const orgid = this.userInfo.insOrgId;
      if (orgid) {
        const res = await this.$api.listRoleByOrgid(orgid);
        this.roleList = res.data;
      } else if (orgid == null || orgid == "") {
        this.roleList = null;
      }
    },

    // 上传
    uploadFile(flag, param) {
      this[flag] = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", flag);
      file.append(
        "projectId",
        this.getRiskPlan.riskManagementPlanBigDO.projectId
      );
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this[`${flag}FileName`] = complete== 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.getRiskPlan.riskManagementPlanBigDO[flag] = res.data.data.cloudDocId;
          this.$set(
            this.getRiskPlan.riskManagementPlanBigDO,
            `${flag}FileName`,
            res.data.data.fileName
          );
           this[`${flag}FileName`] = 100;
        } else {
          this.$messageError({ message: res.data.msg });
        }
        this[flag] = false;
      });
      this[`${flag}FileName`] = 0;
    },
    //下载
    download(flag) {
      let a = document.createElement("a");
      a.style = "display: none";
      a.href = `/api/processDoc/downloadProcessDoc?cloudDocId=${this.getRiskPlan.riskManagementPlanBigDO[flag]}&view=2`;
      a.download = this.getRiskPlan.riskManagementPlanBigDO[`${flag}FileName`];
      document.body.appendChild(a);
      a.click();
    },
    // 删除上传
    delBtn(flag) {
      this.getRiskPlan.riskManagementPlanBigDO[`${flag}FileName`] = "";
      this.getRiskPlan.riskManagementPlanBigDO[flag] = "";
    },
    //初始化查询
    init(projectId) {
      this.riskPlan(projectId);
    }
    // 联系人校验
    // unfocused() {
    //   this.unfocused();
    // },
    // //联系人校验接口
    // async unfocused() {
    //   if (this.numberForm.contactTel !== "") {
    //     const keywords = { contactTel: this.numberForm.contactTel };
    //     const res = await this.$api.checkContactTel(keywords);
    //     if (res.isExist == false) {
    //     } else if (res.isExist == true) {
    //       this.$messageError({
    //         message: "号码已存在"
    //       });
    //       this.numberForm.contactTel = "";
    //     }
    //   }
    // }
  },
  mounted() {
    let disableds = [
      "layoutForConstruction",
      "meettingSummary",
      "riskManagePlan",
      "riskPreProspect",
      "constructionLicense"
    ];
    for (let item of disableds) {
      let dom = document.getElementById(item);
      if (dom) {
        dom.disabled = false;
        dom.classList.remove("is-disabled");
      }
    }
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.dialog /deep/ .el-dialog {
  width: 815px;
}
.dialog /deep/ .el-dialog__body {
  padding: 20px 20px;
}
.dialog /deep/ .el-dialog__header {
  padding: 8px;
  background: rgba(16, 143, 235, 0.6);
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.mc-addUser /deep/ .el-select--mini {
  width: 100%;
}
.mc-edit:hover {
  background: rgba(255, 255, 255, 0.6);
}
.mc-bg {
  background: rgba(255, 255, 255, 0.9);
}
</style>
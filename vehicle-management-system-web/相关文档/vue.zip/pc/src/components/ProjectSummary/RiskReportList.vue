<template>
  <div>
    <div id="RiskReportList">
      <el-divider class="mc-divider"></el-divider>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">风险评估报告列表</span>
      </el-col>
      <el-form :disabled="disabled" label-width="137px" size="mini" label-position="left" align="left" class="mc-form">
        <el-row>
          <el-col :span="23">
            <el-form-item label>
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="getRiskReportList.rows"
                style="width: 100%"
                @row-dblclick="backMytodo"
              >
                <!-- <el-table-column type="index" align="center" label="序号"></el-table-column> -->
                <el-table-column type="index" align="center" label="序号" :index='(index)=>{return(index+1)+(offset-1)*limit}'></el-table-column>
                <el-table-column prop="name" align="center" label="报告名称"></el-table-column>
                <el-table-column prop="reporter" align="center" label="报告人"></el-table-column>
                <el-table-column prop="reviewer" align="center" label="审核人"></el-table-column>
                <el-table-column prop="approver" align="center" label="批准人"></el-table-column>
                <el-table-column align="center" label="报告日期">
                  <template slot-scope="scope">
                    {{ scope.row.reportDate | filterDate}}
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-pagination
              small
              class="page-lucency text-right mt10"
              layout="prev, pager, next"
              @current-change="getPagination"
              :current-page.sync="offset"
              :page-size="limit"
              :total="getRiskReportList.total"
            ></el-pagination>
          </el-col>
        </el-row>
      </el-form>

    </div>
    <el-dialog class="dialog" title="风险评估报告详情列表" :visible.sync="dialogVisible" :close-on-click-modal="false">
      <div>
        <el-col class="text-left mc-title" :span="24">
          <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
          <span style="font-size: 14.5px;" class="blue font-bold">基本信息</span>
        </el-col>
        <el-form class="mc-form" label-width="110px" size="mini" label-position="left" align="left">
          <el-row>
            <el-col :span="12">
              <el-form-item label="报告名称：">
                <el-input v-model="tableData.name" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="涉及风险事件：">
                <template slot-scope="scope">
                  <el-table
                    class="mc-table"
                    :data="riskReportingData.selectionOfRiskEvents"
                    style="width: 100%"
                    ref="multipleTable"
                  >
                    <el-table-column type="index" label="序号" align="center" width="80"></el-table-column>
                    <el-table-column prop="riskEventName" align="center" label="风险事件名称"></el-table-column>
                    <el-table-column
                      prop="riskEventType"
                      align="center"
                      label="风险事件类型"
                      :show-overflow-tooltip="true"
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventType | filterCode(listBaseData.IDI_RISK_EVENT_TYPE,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column
                      prop="riskLevel"
                      align="center"
                      label="风险等级"
                     :show-overflow-tooltip="true"
                    >
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskLevel | filterCode(listBaseData.IDI_RISK_EVENT_LEVEL,'dictValue','dictKey')}}</template>
                    </el-table-column>
                    <el-table-column align="center" label="最初报告时间" :show-overflow-tooltip="true">
                      <template slot-scope="scope">{{ scope.row.riskFoundTime | filterDate}}</template>
                    </el-table-column>
                    <!-- <el-table-column align="center" label="建议整改截止日期" :show-overflow-tooltip="true">
                      <template slot-scope="scope">{{ scope.row.proposedAmendDeadline | filterDate}}</template>
                    </el-table-column> -->
                    <el-table-column prop="riskEventStatus" align="center" label="业务状态">
                      <template
                        slot-scope="scope"
                      >{{scope.row.riskEventStatus | filterCode(listBaseData.IDI_RISK_EVENT__STATUS,'dictValue','dictKey')}}</template>
                    </el-table-column>
                  </el-table>
                </template>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="承保意见：">
                <el-table class="mc-table" style="width: 100%" :data="riskReportItemTrueDO">
                  <el-table-column prop="clause" align="center" label="保险责任范围"></el-table-column>
                  <el-table-column prop="deadline" align="center" label="期限(年)" width="150"></el-table-column>
                  <el-table-column prop="type" align="center" label="保险类型" width="150">
                     <template
                        slot-scope="scope"
                      >{{scope.row.type | filterCode(listBaseData.IDI_LIABILITIES_TYPE,'dictValue','dictKey')}}</template>
                  </el-table-column>
                  <el-table-column prop="insRemark" align="center" label="建议">
                    <template slot-scope="scope">
                      <el-input
                        type="textarea"
                        :autosize=" {minRows: 2 ,maxRows: 4}"
                        style="opacity:0.2 color:#3E3A39;"
                        v-model="scope.row.insRemark"
                        maxlength="80"
                        :disabled="true"
                        class="tex"
                      ></el-input>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="报告人：">
                <el-input v-model="tableData.reporter" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="审核人：">
                <el-input v-model="tableData.reviewer" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="批准人：">
                <el-input v-model="tableData.approver" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="报告时间：">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="tableData.reportDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  disabled
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="下载报告：">
              <el-col :span="12">
                <el-input v-model="tableData.fileName" disabled></el-input>
                 <el-button class="btn1" @click="downloadBtn()" style="margin-left: 20px;" :disabled='disableds'>下载</el-button>
              </el-col>
            </el-form-item>
          </el-row>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
  name: "RiskReportList",
  props: {
    disabled: {
      type: Boolean,
      required: false,
      default: false,
      projectId: ''
    }
  },
  data() {
    return {
      offset: 1,
      limit: 5,
      disableds:true,
      dialogVisible: false,
      countys: [],
      textarea: "",
      url: "",
      insRemark: "",
      assessmentReportFile: "",
      fileName: "",
      rows: '',
      projectId: "", //项目ID
      tableData: [
        {
          startWorkDate: "",
          textarea: "",
          name: "",
          id: ""
        }
      ],
      riskReportItemTrueDO: [],
      riskReportingData:{
        selectionOfRiskEvents: [],
      },
      ids:''
    };
  },
  computed: {
    ...mapGetters(['getRiskReportList','listBaseData'])
  },
  methods: {
    ...mapActions(['riskReportList']),
    backMytodo(row) {
      this.dialogVisible = true
      this.rows = row.id
      this.ids=row.reportId
      this.riskAssessment()
      this.riskEventFunction()
    },
    async riskAssessment() {
      this.id = this.rows;
      const res = await this.$api.riskDetails(this.id);
      this.tableData = res.data.riskReportDO;
      this.url = res.data.riskReportDO.assessmentReportFile;
      this.riskReportItemTrueDO = res.data.riskReportItemTrueDO;
      this.projectId = this.tableData.projectId;
      if(this.tableData.fileName){
        this.disableds=false
      }
    },
      //请求风险事件数据(勾选)
    async riskEventFunction() {
      const rid = {
        reportId: this.ids
      };
      const res = await this.$api.riskEvents(rid);
      this.riskReportingData.selectionOfRiskEvents = res.data;
    },
    //文件下载
     downloadBtn() {
      var a = document.createElement("a");
      var filename = this.tableData.fileName;
      a.style = "display: none";
      a.href =
        "/api/processDoc/downloadProcessDoc?cloudDocId=" + this.url + "&view=2";
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    },
    getPagination(offset = 1, projectId, hasPrama) {
      if(hasPrama == 'hasPrama') {
        this.projectId = projectId
      }
      this.riskReportList({limit: 5, offset, reportType: 1, projectId: this.projectId,sqlStatus: 1})
    }
  }
};
</script>
<style scoped lang="scss">
@import '@/assets/styles';
.dialog /deep/ .el-dialog {
  width: 815px;
  background: rgb(248, 245, 245 )
}
.dialog /deep/.el-dialog__header {
  padding: 8px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/ .el-input {
  width: 193px!important;
}
.dialog /deep/ .btn1 {
  width: 56px;
  height: 28px;
  background: rgba(16, 143, 235, 1);
  padding: 7px 15px;
  font-size: 12px;
  border-radius: 3px;
  font-family: Source Han Sans CN;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
  border: rgba(16, 143, 235, 1);
}
</style>
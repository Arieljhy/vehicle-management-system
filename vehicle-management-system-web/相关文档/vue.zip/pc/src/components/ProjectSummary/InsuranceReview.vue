<template>
  <div id="InsuranceReview">
    <el-divider id="RiskPlanReview" class="mc-divider"></el-divider>
    <div :class="[{'mc-edit':!disabled}, {'mc-bg':!disabled}]">
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">{{title}}</span>
      </el-col>
      <el-form
        :disabled="disabled"
        :model="getInsuranceReview[taskType]"
        :rules="rules"
        class="mc-form"
        ref="validInsurance"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
      >
        <el-row>
          <el-col
            :span="23"
            v-if="getInsuranceReview[taskType].roleType=='OP' && (getInsuranceReview[taskType].tips || getInsuranceReview[taskType].checkMsg)"
          >
            <el-form-item>
              <div class="case_tips">{{getInsuranceReview[taskType].tips}}&nbsp;</div>
              <div
                class="case_tips"
                v-if="getInsuranceReview[taskType].checkMsg"
              >预警：{{getInsuranceReview[taskType].checkMsg}}&nbsp;</div>
              <div class="case_tips">备注：{{getUnderwritingInformation.insBasicInfoDO.description}}&nbsp;</div>
            </el-form-item>
          </el-col>
          <el-col :span="23" v-if="taskType=='underwrite' || taskType=='newUnderwrite'">
            <el-form-item label="推送信息：" prop="ruleTypes">
              <el-checkbox-group
                v-model="getInsuranceReview[taskType].ruleTypes"
                @change="handRuleType"
              >
                <el-checkbox label="INS_RATE_THRESHOLD">保险费率推送</el-checkbox>
                <el-checkbox label="INS_MEAN_COST">平米造价推送</el-checkbox>
                <el-checkbox label="INS_MAIN_UNDERWRITING_RATIO">主承保比例推送</el-checkbox>
                <el-checkbox label="INS_TOTAL_SHARE_OF_IDI_MEMBERS">共保比例推送</el-checkbox>
                <el-checkbox label="INS_MAIN_UNDERWRITING_CONPANY_PERFORMANCE">个人绩效推送</el-checkbox>
                <!-- <el-checkbox label="INS_CO_INSURANCE_CONPAMY_PERFORMANCE">共保方个人绩效</el-checkbox> -->
              </el-checkbox-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="审核结果：" prop="status">
              <el-radio-group v-model="getInsuranceReview[taskType].status">
                <el-radio label="APPROVED">同意</el-radio>
                <el-radio label="UNAPPROVED">不同意</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="审核意见：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 3}"
                placeholder="请输入内容"
                v-model="getInsuranceReview[taskType].comment"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="审核人员：">{{getInsuranceReview[taskType].chsAssignee}}</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="所属部门：">{{getInsuranceReview[taskType].orgName}}</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="审核时间：">
              <el-date-picker
                v-model="getInsuranceReview[taskType].taskEndTime"
                type="date"
                disabled
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
export default {
  name: "InsuranceReview",
  props: {
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    title: {
      type: String,
      default: false,
      required: false
    },
    taskType: {
      type: String,
      default: false,
      required: false
    }
  },
  data() {
    return {
      rules: {
        status: [{ required: true, message: "请选择", trigger: "change" }]
      },
      userInfo: "",
      comment:""
    };
  },
  computed: {
    ...mapGetters(["getInsuranceReview", "getUnderwritingInformation"]),
    getProjectId() {
      return this.$store.state.app.projectSummary.insuranceReview.projectId;
    }
  },
  watch: {
    getProjectId() {
      this.$refs.validInsurance.resetFields();
    }
  },
  methods: {
    ...mapActions(["insuranceReview", "insuranceReviewTips"]),
    handRuleType(value) {
      if (
        value.includes("INS_MAIN_UNDERWRITING_CONPANY_PERFORMANCE") &&
        !value.includes("INS_CO_INSURANCE_CONPAMY_PERFORMANCE")
      ) {
        value.push("INS_CO_INSURANCE_CONPAMY_PERFORMANCE");
      } else if (
        !value.includes("INS_MAIN_UNDERWRITING_CONPANY_PERFORMANCE") &&
        value.includes("INS_CO_INSURANCE_CONPAMY_PERFORMANCE")
      ) {
        value.splice(
          value.findIndex(
            item => item === "INS_CO_INSURANCE_CONPAMY_PERFORMANCE"
          ),
          1
        );
      }
    }
  },
  created() {}
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.case_tips {
  color: red;
  font-size: 13px;
  line-height: 16px;
}
.mc-edit:hover {
  background: rgba(255, 255, 255, 0.6);
}
.mc-bg {
  background: rgba(255, 255, 255, 0.9);
}
</style>
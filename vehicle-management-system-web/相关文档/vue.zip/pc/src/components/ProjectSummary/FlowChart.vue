<template>
  <div>
    <el-row class="text-left mc-title">
      <el-col :span="20">
        <span class="mouse-pointer" @click="goBack()">
          <i
            style="font-size: 18px;position: relative; top: 1.5px; right: -3px"
            class="el-icon-arrow-left blue font-bold"
          ></i>
          <!-- <el-divider class="mc-divider-vertical" direction="vertical"></el-divider> -->
          <span style="font-size: 14.5px;" class="blue font-bold">流程图</span>
        </span>
      </el-col>
      <el-col :span="4" style="text-align: right;">
        <div class="mouse-pointer" style="margin-right:17px;" @click="switchFlats">
          <span class="el-icon-sort"></span>
          <span class="title" v-show="this.switchFlat ==true">历史信息</span>
          <span class="title" v-show="this.switchFlat ==false">流程图</span>
        </div>
      </el-col>
    </el-row>
    <el-form
      label-width="137px"
      size="mini"
      v-if="switchFlat"
      label-position="left"
      align="left"
      class="mc-form"
    >
      <el-row>
        <el-col :span="6" :push="6">
          <div>
            <img src="../../assets/imgs/lan1.png" alt style="width: 160px; margin-left: 25px;" />
          </div>
        </el-col>
        <el-col :span="6" :push="10">
          <div>
            <img src="../../assets/imgs/huang1.png" alt style="width: 160px; margin-left: 13px;" />
          </div>
        </el-col>
      </el-row>
      <el-row class="row-bg" type="flex" align="middle">
        <el-col :span="2">
          <div class="flow-cell" @click="goView('BasicInformation')">
            <img
              v-if="current.finished.includes('newProject')"
              src="../../assets/imgs/lan2.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bailan2.png" class="mouse-pointer" />
            <img v-show="current.current.includes('newProject')" :src="form_border_blue" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/lan3.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('UnderwritingInformation')">
            <img
              v-if="current.finished.includes('enteringIns')"
              src="../../assets/imgs/lan4.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bailan4.png" class="mouse-pointer" />
            <img v-show="current.current.includes('enteringIns')" :src="form_border_blue" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/lan3.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('InsuranceReview')">
            <img
              v-if="current.finished.includes('insuranceAudit')"
              src="../../assets/imgs/lan5.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bailan5.png" class="mouse-pointer" />
            <img v-show="current.current.includes('insuranceAudit')" :src="form_border_blue" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/lan3.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('BasicInformation')">
            <img
              v-if="current.finished.includes('launchRisk')"
              src="../../assets/imgs/nei1.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei1.png" class="mouse-pointer" />
            <img v-show="current.current.includes('launchRisk')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/zou.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('RiskPlan')">
            <img
              v-if="current.finished.includes('enteringRisk')"
              src="../../assets/imgs/nei2.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei2.png" class="mouse-pointer" />
            <img v-show="current.current.includes('enteringRisk')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/zou.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('RiskPlanReview')">
            <img
              v-if="current.finished.includes('checkRisk')"
              src="../../assets/imgs/nei3.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei3.png" class="mouse-pointer" />
            <img v-show="current.current.includes('checkRisk')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div></div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="3" :offset="17" class="text-right">
          <div>
            <img src="../../assets/imgs/xia.png" style="width: 23.5px;" />
          </div>
        </el-col>
      </el-row>
      <el-row class="row-bg" type="flex" align="middle">
        <el-col :span="2">
          <div class="flow-cell">
            <img
              v-if="current.finished.includes('projectCompletion')"
              src="../../assets/imgs/f1cef242d8378a296cccb3ce7cff896.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/finished.png" class="mouse-pointer" />
            <img v-show="current.current.includes('projectCompletion')" :src="form_border_green" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/lvzuo.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('ProjectClaims')">
            <img
              v-if="current.finished.includes('claim')"
              src="../../assets/imgs/nei9.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei9.png" class="mouse-pointer" />
            <img v-show="current.current.includes('claim')" :src="form_border_green" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/you.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('ProjectReturns')">
            <img
              v-if="current.finished.includes('riskReturn')"
              src="../../assets/imgs/nei8.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei8.png" class="mouse-pointer" />
            <img v-show="current.current.includes('riskReturn')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/you.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('CompletionInsurance')">
            <img
              v-if="current.finished.includes('insuranceCheck')"
              src="../../assets/imgs/nei7.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei7.png" class="mouse-pointer" />
            <img v-show="current.current.includes('insuranceCheck')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/you.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('InsuranceCoverage')">
            <img
              v-if="current.finished.includes('entreingCompleted')"
              src="../../assets/imgs/nei6.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei6.png" class="mouse-pointer" />
            <img v-show="current.current.includes('entreingCompleted')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <img src="../../assets/imgs/you.png" class="horizontal-arrows" />
          </div>
        </el-col>
        <el-col :span="2">
          <div class="flow-cell" @click="goView('RiskReportList')">
            <img
              v-if="current.finished.includes('riskManage')"
              src="../../assets/imgs/nei4.png"
              class="mouse-pointer"
            />
            <img v-else src="../../assets/imgs/bainei4.png" class="mouse-pointer" />
            <img v-show="current.current.includes('riskManage')" :src="form_border_yellow" />
          </div>
        </el-col>
        <el-col :span="2">
          <div></div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="5">
          <div></div>
        </el-col>
        <el-col :span="5" :push="13">
          <div>
            <img src="../../assets/imgs/huang3.png" alt style="width: 160px;padding-left: 5px" />
          </div>
        </el-col>
      </el-row>
    </el-form>
    <el-form v-if="!switchFlat">
      <div class="fileContent" style="height:275.43px;overflow: overlay;">
        <el-table
          :data="historyInfo"
          class="mc-table"
          row-key="id"
          default-expand-all
          :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
        >
          <el-table-column prop="taskChnName" label="步骤" width="200"></el-table-column>
          <el-table-column prop="status" label="操作" align="center" width="170">
            <template slot-scope="scope">
              <span v-if="scope.row.assignee!=='system'">
                <span v-if="scope.row.status == 'UNAPPROVED'">
                  <span>未通过</span>
                </span>
                <span v-if="scope.row.status == 'APPROVED'">
                  <span>已通过</span>
                </span>
                <span v-if="scope.row.taskChnName=='新建项目'">
                  <span>已通过</span>
                </span>
              </span>
              <span v-else></span>
            </template>
          </el-table-column>
          <el-table-column prop="comment" label="处理结果" align="center" width="170"></el-table-column>
          <el-table-column prop="chsAssignee" label="处理人" align="center" width="200"></el-table-column>
          <el-table-column prop="orgName" label="处理人部门" align="center" width="170"></el-table-column>
          <el-table-column prop="taskEndTime" label="处理时间" align="center" width="170"></el-table-column>
        </el-table>
      </div>
    </el-form>
  </div>
</template>

<script>
import form_border_blue from "@/assets/imgs/form_border_blue.png";
import form_border_green from "@/assets/imgs/form_border_green.png";
import form_border_yellow from "@/assets/imgs/form_border_yellow.png";
import http from "@/common/request";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "FlowChart",
  props: {
    // newProject,enteringIns,insuranceAudit,launchRisk,enteringRisk,checkRisk,riskManage,entreingCompleted,insuranceCheck,riskReturn,claim,projectCompletion
    current: {
      type: Object,
      default: {
        finished: [],
        current: [],
        projectId: ""
      },
      required: false
    }
  },
  data() {
    return {
      form_border_yellow,
      form_border_green,
      form_border_blue,
      switchFlat: true,
      historyInfo: []
    };
  },
  watch: {
    //监听初始显示流程图
    current(value) {
      this.switchFlat = true;
    }
  },
  methods: {
    ...mapActions(["riskScreen"]),
    goView(view) {
      if (document.getElementById(view)) {
        document.getElementById(view).scrollIntoView();
      }
    },
    //返回
    goBack() {
      this.$emit("goBack");
      this.riskScreen(false);
    },
    //切换流程图和历史信息
    switchFlats() {
      this.switchFlat = !this.switchFlat;
      if (!this.switchFlat) this.getHistory();
    },
    //获取历史信息
    getHistory() {
      const keywords = this.current.projectId;
      http.get("/workflow/process/searchHistoryTask/", keywords).then(res => {
        this.historyInfo = res.data;
      });
    }
  }
};
</script>
<style scoped lang="scss">
img {
  width: "329px";
  height: "60px";
}
.row-bg {
  margin-left: 120px;
}
.el-col-2 {
  width: 7.612222222%;
}
.horizontal-arrows {
  width: 65.5px;
  padding: 0 4.5px;
}
.flow-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    &:first-child {
      width: 74px;
      height: 74px;
    }
    &:last-child {
      width: 45.5px;
      height: 6px;
      margin-top: 5.5px;
    }
  }
}
.el-icon-sort {
  background: #e8e5e5;
  color: #297ae3;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  line-height: 20px;
  font-weight: 540;
}
.mc-table /deep/ th /deep/.cell {
  text-align: center;
}
.mouse-pointer /deep/ .title {
  color: #297ae3;
  margin-left: 5px;
  font-weight: 540;
}
// 滚动条样式
.fileContent {
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 5px;
    box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    -webkit-box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.6);
    background-color: rgba(255, 255, 255, 1);
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    background-color: rgba(158, 159, 160, 0.8);
  }
}
</style>
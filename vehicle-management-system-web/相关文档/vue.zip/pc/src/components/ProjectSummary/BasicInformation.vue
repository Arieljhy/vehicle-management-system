<template>
  <div id="BasicInformation">
    <el-divider class="mc-divider"></el-divider>
    <div :class="[{'mc-edit':!disabled}, {'mc-bg':!disabled}]">
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="message">基本信息</span>
      </el-col>
      <el-form
        :model="getBasicBstablish.prjBasicInfoDO"
        :disabled="disabled"
        class="mc-form"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
      >
        <el-row>
          <el-col :span="23">
            <el-form-item label="项目名称：" required>
              <el-input v-model="getBasicBstablish.prjBasicInfoDO.projectName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="项目地址：" required>
              <el-select
                class="miniColumn"
                disabled
                @change="getCity(getBasicBstablish.prjBasicInfoDO.province,'city')"
                v-model="getBasicBstablish.prjBasicInfoDO.province"
              >
                <el-option
                  v-for="item in district"
                  :key="item.province"
                  :label="item.province"
                  :value="item.province"
                ></el-option>
              </el-select>
              <el-select
                class="miniColumn ml5"
                @change="getCity(getBasicBstablish.prjBasicInfoDO.city, 'county')"
                v-model="getBasicBstablish.prjBasicInfoDO.city"
              >
                <el-option
                  v-for="item in getCitys"
                  :key="item.name"
                  :label="item.name"
                  :value="item.name"
                ></el-option>
              </el-select>
              <el-select class="miniColumn ml5" v-model="getBasicBstablish.prjBasicInfoDO.district">
                <el-option
                  v-for="item in getCountys"
                  :key="item.district"
                  :label="item.district"
                  :value="item.district"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12" class="addressStyle">
            <el-input v-model="getBasicBstablish.prjBasicInfoDO.address"></el-input>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="住宅性质：" required>
              <el-radio-group v-model="getBasicBstablish.prjBasicInfoDO.buildingType"    v-if="$getversionData.lesseeId!='eidi-maanshan'">
                <el-radio
                  v-for="item of listBaseData.IDI_PROJECT_TYPES"
                  :key="item.ddId"
                  :label="item.dictKey"
                >{{item.dictValue}}</el-radio>
              </el-radio-group>
               <el-select v-model="getBasicBstablish.prjBasicInfoDO.buildingType"  placeholder="请选择"   v-if="$getversionData.lesseeId=='eidi-maanshan'">
                  <el-option
                    v-for="item in listBaseData.IDI_PROJECT_TYPES"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="小区名称：">
              <el-input v-model="getBasicBstablish.prjBasicInfoDO.communityName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="项目概述：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 3}"
                v-model="getBasicBstablish.prjBasicInfoDO.projectInfo"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  name: "BasicInformation",
  data() {
    return {};
  },
  props: {
    disabled: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  computed: {
    ...mapGetters([
      "district",
      "getCitys",
      "getCountys",
      "listBaseData",
      "getBasicBstablish"
    ])
  },
  methods: {
    getCity(i, flag) {
      if (flag === "county") {
        this.getBasicBstablish.prjBasicInfoDO.district = "";
        let list = [];
        for (let item of this.district) {
          list = [...list, ...item.city];
        }
        for (let item of list) {
          if (i == item.name) {
            this.getCountys = item.area;
          }
        }
      } else if (flag === "city") {
        this.getBasicBstablish.prjBasicInfoDO.city = "";
        this.getBasicBstablish.prjBasicInfoDO.district = "";
        for (let city of this.district) {
          if (city.province == i) {
            this.getCitys = city.city;
          }
        }
      }
    }
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.el-form-item--mini {
  margin-bottom: 12px;
}
.addressStyle {
  margin-left: -5px;
  /deep/ .el-input__inner {
    height: 28px;
    width: 507px;
  }
}
</style>
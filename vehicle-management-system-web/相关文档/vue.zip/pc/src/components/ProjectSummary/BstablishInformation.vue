<template>
  <div>
    <el-divider class="mc-divider"></el-divider>
    <div :class="[{'mc-edit':!disabled}, {'mc-bg':!disabled}]">
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold" id="BstablishInformation">标的信息</span>
      </el-col>
      <el-form
        :model="getBasicBstablish.prjConstructionInfoDO"
        class="mc-form"
        label-width="137px"
        size="mini"
        ref="validForm"
        label-position="left"
        align="left"
      >
        <el-row>
          <el-col :span="8" v-if="$getversionData.lesseeId!='eidi-shanghai'">
            <el-form-item
              label="项目报建号："
              prop="buildPermitNo"
              :rules="[{required: true, message: '请输入', trigger: 'blur'}]"
            >
              <el-input
                v-model="getBasicBstablish.prjConstructionInfoDO.buildPermitNo"
                :disabled="disabled"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="$getversionData.lesseeId=='eidi-shanghai'">
            <el-form-item
              label="项目报建号："
              prop="buildPermitNo"
              :rules="[{required: true, message: '请输入', trigger: 'blur'}]"
            >
              <el-input
                @blur="sendZJW();getBjxxByBjbh()"
                v-model="getBasicBstablish.prjConstructionInfoDO.buildPermitNo"
                :disabled="disabled"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="建筑幢数：">
              <format-input
                :disabled="disabled"
                text-align="left"
                v-model="getBasicBstablish.prjConstructionInfoDO.numOfBuilding"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="承保面积(m²)："
              prop="totalFloorage"
              :rules="[{required: true, message: '请输入', trigger: 'blur'}]"
            >
              <format-input
                :disabled="disabled"
                :precision="2"
                @blur="setUnderwriting('totalFloorage', getBasicBstablish.prjConstructionInfoDO.totalFloorage)"
                text-align="left"
                v-model="getBasicBstablish.prjConstructionInfoDO.totalFloorage"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="地下室面积(㎡)：">
              <format-input
                :disabled="disabled"
                :precision="2"
                @blur="setUnderwriting('basementFloorage', getBasicBstablish.prjConstructionInfoDO.basementFloorage)"
                text-align="left"
                v-model="getBasicBstablish.prjConstructionInfoDO.basementFloorage"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="设计图纸：">
              <el-input disabled v-model="getBasicBstablish.prjConstructionInfoDO.layoutName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!upload" :src="imgUpload" class="img-upload" />
              <el-progress v-if="upload" type="circle" :percentage="progress" :width="30"></el-progress>
              <!-- <img v-if="upload" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="uploadFile"
                :show-file-list="false"
              >
              <el-button size="mini" type="primary" :disabled="disabled">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn()" :disabled="disabled">删除</el-button>
              <el-button
                id="layout"
                @click="download"
                size="mini"
                v-show="getBasicBstablish.prjConstructionInfoDO.layoutName"
              >下载</el-button>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="地块编号：">
              <el-input
                v-model="getBasicBstablish.prjConstructionInfoDO.landNo"
                :disabled="disabled"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="15">
            <el-form-item label="施工许可证编号：" v-if="$getversionData.lesseeId!='eidi-shanghai'">
              <el-input
                :disabled="disabled"
                v-model="getBasicBstablish.prjConstructionInfoDO.constructionLicenseNo"
                placeholder="多条信息请以 ',' 分割"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="15">
            <el-form-item label="施工许可证编号：" v-if="$getversionData.lesseeId=='eidi-shanghai'">
              <el-select
                class="construction"
                :loading="loading"
                value-key="constructionLicenseNo"
                @change="selectGetFn"
                @click.native="sendZJW"
                :disabled="disableds"
                v-model="getBasicBstablish.prjConstructionLicensesDOLists"
                multiple
                placeholder="请选择"
                style="width: 546px;"
              >
                <el-option
                  v-for="item in prjConstructionLicensesDOLists"
                  :key="item.constructionLicenseNo"
                  :label="item.constructionLicenseNo"
                  :value="item"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-form-item label="地块地址：">
              <el-input
                v-model="getBasicBstablish.prjConstructionInfoDO.landAddr"
                :disabled="disabled"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23" style="text-align:center">
            <gaoMap
              :allocation="getBasicBstablish.prjConstructionInfoDO"
              ref="gaoMap"
              @getAllocation="getAllocation"
              :disabled="disabled"
            ></gaoMap>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="住宅楼信息：">
              <el-table
                class="mc-table residence-table"
                :data="getBasicBstablish.prjSingleUnitsDOList.rowList"
                style="width: 100%"
              >
                <el-table-column prop="buildingName" align="center" label="竣工后楼栋门牌号"></el-table-column>
                <el-table-column prop="unitId" align="center" label="单体编号"></el-table-column>
                <el-table-column prop="unitName" align="center" label="单体名称"></el-table-column>
                <el-table-column prop="buildingType" align="center" label="类别"></el-table-column>
                <el-table-column prop="totalStories" align="center" label="总层数"></el-table-column>
                <el-table-column prop="totalUnits" align="center" label="总户数"></el-table-column>
                <el-table-column align="center" width="80">
                  <template slot-scope="scope">
                    <el-dropdown
                      placement="bottom"
                      size="small"
                      trigger="click"
                      @command="handleCommand(scope.row.id,$event)"
                    >
                      <span class="el-dropdown-link">
                        <i class="el-icon-more el-icon--right" style="cursor:pointer"></i>
                      </span>
                      <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item
                          icon="el-icon-remove-outline"
                          command="0"
                          v-if="!disabled&&$getversionData.lesseeId!='eidi-shanghai'"
                        >删除</el-dropdown-item>
                        <el-dropdown-item
                          icon="el-icon-edit-outline"
                          command="1"
                          v-if="!disabled"
                        >修改</el-dropdown-item>
                        <el-dropdown-item icon="el-icon-edit-outline" command="2">详情</el-dropdown-item>
                      </el-dropdown-menu>
                    </el-dropdown>
                  </template>
                </el-table-column>
              </el-table>
              <div
                class="mouse-pointer"
                v-if="!disabled&&$getversionData.lesseeId!='eidi-shanghai'"
              >
                <div @click="maintenanceMonomer()" class="outline">
                  维护项目单体
                  <i
                    class="el-icon-circle-plus-outline"
                    style="color: #2A7BE3;font-size: 20px;position: absolute;top:10px;right:10px"
                  ></i>
                </div>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-row>
        <el-col :span="23">
          <el-pagination
            small
            :page-size.sync="pageSize"
            class="page-lucency text-right mt10"
            layout="prev, pager, next"
            @current-change="getBuildingInfo"
            :total="getBasicBstablish.prjSingleUnitsDOList.total"
          ></el-pagination>
        </el-col>
      </el-row>
      <!-- 新增 -->
      <el-dialog
        title="住宅楼信息"
        :visible.sync="addedBuildingWindows"
        width="900px"
        class="dialog"
        :close-on-click-modal="false"
      >
        <el-form
          class="mc-form"
          label-width="155px"
          size="mini"
          label-position="right"
          align="left"
          :rules="rules"
          :model="newMonomer"
          ref="newMonomer"
        >
          <el-row>
            <el-col :span="11">
              <el-form-item label="单体编号：" prop="unitId">
                <el-input v-model="newMonomer.unitId" text-align="left"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="单体名称：" prop="unitName">
                <el-input v-model="newMonomer.unitName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="总层数：">
                <format-input v-model="newMonomer.totalStories" text-align="left"></format-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="地下层数：">
                <format-input v-model="newMonomer.basementStories" text-align="left"></format-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="竣工后楼栋门牌号：">
                <el-input v-model="newMonomer.buildingName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="楼栋类别：">
                <el-select v-model="newMonomer.buildingType" clearable style="width: 100%">
                  <el-option
                    v-for="item in listBaseData.IDI_BUILDING_TYPES"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="土地性质：">
                <el-select v-model="newMonomer.landType" clearable style="width: 100%">
                  <el-option
                    v-for="item in listBaseData.IDI_BUILDING_NATURE"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="结构类型：">
                <el-select v-model="newMonomer.structureType" clearable style="width: 100%">
                  <el-option
                    v-for="item in listBaseData.IDI_BUILDING_FWORK"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="开工日期：">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  :picker-options="startDateValid"
                  @change="validData(newMonomer.conStartDate, newMonomer.conCompleteDate)"
                  v-model="newMonomer.conStartDate"
                  style="width: 250.3px"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="竣工日期：">
                <el-date-picker
                  type="date"
                  :picker-options="endDateValid"
                  placeholder="选择日期"
                  @change="validData(newMonomer.conStartDate, newMonomer.conCompleteDate)"
                  v-model="newMonomer.conCompleteDate"
                  style="width: 250.3px"
                  value-format="yyyy-MM-dd HH:mm:ss"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="总户数：">
                <format-input v-model="newMonomer.totalUnits" text-align="left"></format-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="商业用房、车棚 层、住宅层分布：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  maxlength="512"
                  show-word-limit
                  v-model="newMonomer.floorDistribution"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="基础信息：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  v-model="newMonomer.basicDesc"
                  maxlength="512"
                  show-word-limit
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="其他情况：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  v-model="newMonomer.otherDesc"
                  maxlength="512"
                  show-word-limit
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row style="text-align: right; margin-top: 30px margin-right: 45px" class="btns">
          <el-button type="primary" size="mini" @click="newPreservation('newMonomer')">保存</el-button>
          <el-button size="mini" @click="residentialClosingButton()">关闭</el-button>
        </el-row>
      </el-dialog>
      <!-- 修改 -->
      <el-dialog
        title="住宅楼信息"
        :visible.sync="buildingWindows"
        width="900px"
        class="dialog"
        :close-on-click-modal="false"
      >
        <el-form
          class="mc-form"
          label-width="155px"
          size="mini"
          label-position="right"
          align="left"
          :disabled="disableDialog"
        >
          <el-row>
            <el-col :span="11">
              <el-form-item label="单体编号：">
                <el-input v-model="residentialBuildingDetails.unitId" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="单体名称：">
                <el-input v-model="residentialBuildingDetails.unitName" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="总层数：">
                <el-input v-model="residentialBuildingDetails.totalStories"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="地下层数：">
                <el-input v-model="residentialBuildingDetails.basementStories"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="竣工后楼栋门牌号：">
                <el-input v-model="residentialBuildingDetails.buildingName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="楼栋类别：">
                <el-select
                  v-model="residentialBuildingDetails.buildingType"
                  clearable
                  style="width: 100%"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_BUILDING_TYPES"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="土地性质：">
                <el-select
                  v-model="residentialBuildingDetails.landType"
                  clearable
                  style="width: 100%"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_BUILDING_NATURE"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="结构类型：">
                <el-select
                  v-model="residentialBuildingDetails.structureType"
                  clearable
                  style="width: 100%"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_BUILDING_FWORK"
                    :key="item.ddId"
                    :label="item.dictValue"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="开工日期：">
                <el-date-picker
                  :clearable="false"
                  type="date"
                  placeholder="选择日期"
                  @change="validDatas(residentialBuildingDetails.conStartDate, residentialBuildingDetails.conCompleteDate)"
                  v-model="residentialBuildingDetails.conStartDate"
                  style="width: 250.3px"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :picker-options="pickerOptionsStart"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="竣工日期：">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  @change="validDatas(residentialBuildingDetails.conStartDate, residentialBuildingDetails.conCompleteDate)"
                  v-model="residentialBuildingDetails.conCompleteDate"
                  style="width: 250.3px"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :picker-options="pickerOptionsEnd"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="11">
              <el-form-item label="总户数：">
                <el-input v-model="residentialBuildingDetails.totalUnits"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="商业用房、车棚 层、住宅层分布：">
                <el-input
                  type="textarea"
                  maxlength="512"
                  show-word-limit
                  :autosize=" {minRows: 2}"
                  v-model="residentialBuildingDetails.floorDistribution"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="基础信息：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  maxlength="512"
                  show-word-limit
                  v-model="residentialBuildingDetails.basicDesc"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="23">
              <el-form-item label="其他情况：">
                <el-input
                  type="textarea"
                  :autosize=" {minRows: 2}"
                  maxlength="512"
                  show-word-limit
                  v-model="residentialBuildingDetails.otherDesc"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row style="text-align: right; margin-top: 30px margin-right: 45px" class="btns">
          <el-button type="primary" size="mini" @click="submitButton()" v-if="!disableDialog">保存</el-button>
          <el-button size="mini" @click="residentialClosingButton()">关闭</el-button>
        </el-row>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
import imgUpload from "@/assets/imgs/put.png";
import formatInput from "@/components/formatInput";
import gaoMap from "@/components/gaoMap";
import axios from 'axios';
export default {
  name: "BstablishInformation",
  components: {
    formatInput,
    gaoMap
  },
  props: {
    disabled: {
      type: Boolean,
      required: false,
      default: false
    },
    showMyCase: {
      type: String,
      required: false,
      default: false
    }
  },
  data() {
    return {
      progress: 0,
      upload: 0,
      loading: false,
      constructionLicenseNos: "",
      prjConstructionLicensesDOLists: [],
      disableds: false,
      disableDialog: false,
      upload: false,
      imgUpload,
      projectId: "",
      pageSize: 5,
      total: undefined,
      addedBuildingWindows: false,
      addedBuildingWindows: false,
      buildingWindows: false,
      allocation: [116.397405, 39.908667],
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      endDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      pickerOptionsEnd: {
        disabledDate(data) {
          return "";
        }
      },
      pickerOptionsStart: {
        disabledDate(data) {
          return "";
        }
      },
      rules: {
        unitId: [{ required: true, message: "请输单体编号", trigger: "blur" }],
        unitName: [{ required: true, message: "请输单体名称", trigger: "blur" }]
      },
      rule: {},
      citys: [],
      newMonomer: {},
      residentialBuildingDetails: {}
    };
  },
  computed: {
    ...mapGetters([
      "getBasicBstablish",
      "getUnderwritingInformation",
      "district",
      "listBaseData"
    ]),
    listenshowpage() {
      return this.$store.state.app.projectSummary.basicBstablish
        .constructionList;
    }
  },
  create() {
    // console.log(this.showMyCase);
  },
  watch: {
    listenshowpage() {
      this.prjConstructionLicensesDOLists = this.getBasicBstablish.constructionList;
      this.constructionLicenseNos = this.getBasicBstablish.prjConstructionInfoDO.buildPermitNo;
    }
  },
  methods: {
    ...mapActions(["basicBstablish", "buildingInfo"]),
    // 承包信息联动
    setUnderwriting(flag, val) {
      this.getUnderwritingInformation.insBasicInfoDO[flag] = val;
    },
    getAllocation(e) {
      this.getBasicBstablish.prjConstructionInfoDO.prjLocationX = e.lng;
      this.getBasicBstablish.prjConstructionInfoDO.prjLocationY = e.lat;
    },
    //初始化
    init(projectId) {
      this.projectId = projectId;
      this.basicBstablish(projectId).then(() => {
        this.$refs.gaoMap.initSearch();
      });
      this.getBuildingInfo();
      if (this.$getversionData.lesseeId == "eidi-shanghai") {
        if (
          this.showMyCase == "startRiskPlan" ||
          this.showMyCase == "insertInsureInfo"
        ) {
          this.disableds = false;
        } else {
          this.disableds = true;
        }
      }
    },
    // 上海施工许可证
    async sendZJW() {
      if (this.getBasicBstablish.prjConstructionInfoDO.buildPermitNo) {
        this.loading = true;
        if (!this.disableds) {
          if (
            this.constructionLicenseNos !=
            this.getBasicBstablish.prjConstructionInfoDO.buildPermitNo
          ) {
            this.prjConstructionLicensesDOLists = [];
            this.getBasicBstablish.prjConstructionLicensesDOLists = [];
          }
          const res = await this.$api.sendZJW({
            buildPermitNo: this.getBasicBstablish.prjConstructionInfoDO
              .buildPermitNo
          });
          if (res.code == 0) {
            this.loading = false;
            this.prjConstructionLicensesDOLists = res.data;
          } else {
            this.$messageError({
              message: "查询施工许可证失败,请稍后重试"
            });
          }
        }
        this.constructionLicenseNos = this.getBasicBstablish.prjConstructionInfoDO.buildPermitNo;
      } else {
        this.prjConstructionLicensesDOLists = [];
        this.getBasicBstablish.prjConstructionLicensesDOLists = [];
        this.$messageSuccess({
          message: "请输入报建号"
        });
      }
    },
    async getBjxxByBjbh() {
      if (this.getBasicBstablish.prjConstructionInfoDO.buildPermitNo) {
        const res = await this.$api.getBjxxByBjbh({
          buildPermitNo: this.getBasicBstablish.prjConstructionInfoDO
            .buildPermitNo
        });
        if (res.code == 0) {
          this.getBasicBstablish.prjConstructionInfoDO.totalFloorage =
            res.data.zmj;
          this.getBasicBstablish.prjConstructionInfoDO.landAddr = res.jsdd;
          this.setUnderwriting(
            "totalFloorage",
            this.getBasicBstablish.prjConstructionInfoDO.totalFloorage
          );
        } else {
          this.$messageError({
            message: "查询报建信息失败,请稍后重试或手动填写"
          });
        }
      }else {
        this.$messageSuccess({
          message: "请输入报建号"
        });
      }
    },
    getBuildingInfo(offset = 1) {
      this.buildingInfo({
        limit: this.pageSize,
        offset,
        projectId: this.projectId
      });
    },
    selectGetFn(row) {
      this.getBasicBstablish.prjConstructionLicensesDOLists = row;
    },
    //日期校验
    validData(start, end) {
      if (start) {
        this.endDateValid = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          }
        };
      } else {
        this.endDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
      if (end) {
        this.startDateValid = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          }
        };
      } else {
        this.startDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
    },
    //日期校验
    validDatas(start, end) {
      if (start) {
        this.pickerOptionsEnd = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          }
        };
      } else {
        this.pickerOptionsEnd = {
          disabledDate(data) {
            return "";
          }
        };
      }
      if (end) {
        this.pickerOptionsStart = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          }
        };
      } else {
        this.pickerOptionsStart = {
          disabledDate(data) {
            return "";
          }
        };
      }
    },
    // 上传
    uploadFile(param) {
      this.upload = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", "layout");
      file.append("projectId", this.projectId);
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this.progress = complete==100?99:complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.getBasicBstablish.prjConstructionInfoDO.layout =
            res.data.data.cloudDocId;
          this.getBasicBstablish.prjConstructionInfoDO.layoutName =
            res.data.data.fileName;
            this.progress=100
        } else {
          this.$messageError({ message: res.data.msg });
        }
        this.upload = false;
      });
      this.progress = 0;
    },
    // 下载
    download() {
      let a = document.createElement("a");
      a.style = "display: none";
      a.href = `/api/processDoc/downloadProcessDoc?cloudDocId=${this.getBasicBstablish.prjConstructionInfoDO.layout}&view=2`;
      a.download = this.getBasicBstablish.prjConstructionInfoDO.layoutName;
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn() {
      this.getBasicBstablish.prjConstructionInfoDO.layoutName = "";
      this.getBasicBstablish.prjConstructionInfoDO.layout = "";
    },
    maintenanceMonomer() {
      // this.monomerMaintenance();
      this.addedBuildingWindows = true;
      this.newMonomer = {};
      this.validData();
    },
    //弹窗修改保存按钮
    submitButton() {
      this.preservationMonomer();
    },
    //报建信息请求
    async requestForConstruction(offset = 1) {
      const reportBuildingData = {
        limit: this.pageSize,
        offset,
        projectId: this.projectId
      };
      const res = await this.$api.buildingInformation(reportBuildingData);
      this.getBasicBstablish.prjSingleUnitsDOList.total = res.data.total;
      this.getBasicBstablish.prjSingleUnitsDOList.rowList = res.data.rows;
    },
    //保存单体住宅楼信息
    async preservationMonomer() {
      const res = await this.$api.monomerHousing(
        this.residentialBuildingDetails
      );
      if (res.code == 0) {
        this.buildingWindows = false;
        this.$messageSuccess({
          message: res.msg
        });
        this.requestForConstruction();
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    //删除
    async deleteMonomerInformation(id) {
      this.$confirm("此操作将删除该信息，是否继续？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          const res = await this.$api.deleteMonomer(id);
          if (res.code == 0) {
            this.$messageSuccess({
              message: res.msg
            });
            this.requestForConstruction();
          } else {
            this.$messageError({
              message: res.msg
            });
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    //住宅楼详情
    async detailedInformation() {
      const id = this.reportBuildingId;
      const res = await this.$api.buildingDetails(id);
      this.residentialBuildingDetails = res.data;
    },
    async saveNewMonomer() {
      this.newMonomer.projectId = this.projectId;
      const res = await this.$api.newPreservation(this.newMonomer);
      if (res.code == 0) {
        this.buildingWindows = false;
        this.$messageSuccess({
          message: res.msg
        });
        this.requestForConstruction();
        this.addedBuildingWindows = false;
      } else {
        this.$messageError({
          message: res.msg
        });
      }
    },
    residentialClosingButton() {
      this.buildingWindows = false;
      this.addedBuildingWindows = false;
    },
    handleCommand(id, command) {
      //删除
      if (command === "0") {
        this.deleteMonomerInformation(id);
      } else if (command === "1") {
        (this.pickerOptionsEnd = {
          disabledDate(data) {
            return "";
          }
        }),
          (this.pickerOptionsStart = {
            disabledDate(data) {
              return "";
            }
          });
        this.buildingWindows = true;
        this.reportBuildingId = id;
        this.disableDialog = false;
        this.detailedInformation(this.reportBuildingId);
      } else {
        this.disableDialog = true;
        this.reportBuildingId = id;
        this.detailedInformation(this.reportBuildingId);
        this.buildingWindows = true;
      }
    },
    //弹窗新增保存
    newPreservation(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.saveNewMonomer();
        } else {
          this.$messageError({
            message: "请完善信息"
          });
        }
      });
    }
  },
  mounted() {
    let dom = document.getElementById("layout");
    if (dom) {
      dom.disabled = false;
      dom.classList.remove("is-disabled");
    }
  }
};
</script>
<style scoped lang='scss'>
@import "@/assets/styles";
.residence-table {
  border-radius: 0px;
}
.mouse-pointer {
  width: 910.4px;
  background-color: rgba(255, 255, 255, 0.9);
  height: 36.8px;
  color: #3e3a39;
  border-radius: 0 0 5px 5px;
  cursor: default;
  position: relative;
}
.outline {
  width: 150px;
  text-align: center;
  height: 36.8px;
  line-height: 36.8px;
  cursor: pointer;
  position: absolute;
  left: 370px;
}
.dialog /deep/.el-dialog__header {
  padding: 10px;
  background: #297ae3;
}
.dialog /deep/ .el-dialog__title {
  color: #fff;
  font-size: 15px;
  font-weight: bold;
}
.dialog /deep/ .el-dialog__headerbtn {
  position: absolute;
  top: 12px;
  right: 20px;
  padding: 0;
}
.dialog /deep/.el-dialog__headerbtn .el-dialog__close {
  color: #fff;
}
.dialog /deep/.el-dialog__body {
  padding: 30px 10px;
}
.mc-edit:hover {
  background: rgba(255, 255, 255, 0.6);
}
.mc-bg {
  background: rgba(255, 255, 255, 0.9);
}
.construction /deep/ .el-select__tags {
  min-width: 514px;
  /deep/.el-select__tags-text{
      color: #297ae3;
  }
}
</style>

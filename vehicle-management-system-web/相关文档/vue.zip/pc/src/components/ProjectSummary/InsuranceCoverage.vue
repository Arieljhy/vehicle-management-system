<template>
  <div id="InsuranceCoverage">
    <div :class="[{'mc-edit':!disabled}, {'mc-bg':!disabled}]">
      <el-divider class="mc-divider"></el-divider>
      <el-col class="text-left mc-title" :span="24">
        <el-divider class="mc-divider-vertical" direction="vertical"></el-divider>
        <span style="font-size: 14.5px;" class="blue font-bold">竣工项目保险信息</span>
      </el-col>
      <el-form
        :model="getInsuranceCoverage.insBasicInfoCompletedDO"
        :disabled="disabled"
        label-width="137px"
        size="mini"
        label-position="left"
        align="left"
        class="mc-form qr-form"
        :rules="rules"
        ref="validForm"
      >
        <!-- <div class="mc-qr" v-if="downloadData.insUrl">
          <vue-qr
            :text="downloadData.insUrl"
            :margin="0"
            colorDark="RGB(203,164,59)"
            colorLight="#fff"
            :logoSrc="downloadData.icon + '?cache'"
            :logoScale="0.22"
            :size="90"
          ></vue-qr>
        </div>-->
        <el-row>
          <el-col :span="12">
            <el-form-item label="保单号：" prop="insContractNo">
              <el-input
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insContractNo"
                disabled
                style="width:365px"
              ></el-input>
            </el-form-item>
          </el-col>
            <el-col :span="12">
              <el-form-item label="被保项目：" prop="projectName">
                <el-input
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.projectName"
                  disabled
                  style="width:365px"
                ></el-input>
              </el-form-item>
            </el-col>
        </el-row>
        <el-row>
          <el-col :span="downloadData.insUrl?16:24">
            <!-- <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="保单号：" prop="insContractNo">
                <el-input
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insContractNo"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col> -->
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="牵头保险公司：" prop="insOrgId">
                <el-select
                  disabled
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insOrgId"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in getOrgId.insOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item class="mc-multi-row" label="牵头保险公司社会统一信用编码：">
                <el-input
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insOrgCode"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="风险管理机构：" prop="tisOrgId">
                <el-select
                  disabled
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.tisOrgId"
                  placeholder="请选择"
                  @change="getCode(getOrgId.tisOrgList, getInsuranceCoverage.insBasicInfoCompletedDO.tisOrgId, 'tisOrgList')"
                >
                  <el-option
                    v-for="item in getOrgId.tisOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item class="mc-multi-row" label="风险管理机构社会统一信用编码：">
                <el-input
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.tisOrgCode"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="保险分类：" prop="insCategory">
                <el-select
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insCategory"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_CATEGORIES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="保险种类：" prop="typeOfIns">
                <el-select
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.typeOfIns"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in listBaseData.IDI_INS_TYPES"
                    :key="item.dictKey"
                    :label="item.dictValue"
                    :value="item.dictKey"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="投保人：">
                <el-input v-model="getInsuranceCoverage.insBasicInfoCompletedDO.applicant"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="被保人名称：" prop="insuredOrgId">
                <el-select
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insuredOrgId"
                  placeholder="请选择"
                  @change="getCode(getOrgId.bldOrgList, getInsuranceCoverage.insBasicInfoCompletedDO.insuredOrgId, 'bldOrgList')"
                >
                  <el-option
                    v-for="item in getOrgId.bldOrgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
             <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="竣工时间：" prop="prjCompletedDate">
                <el-date-picker
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.prjCompletedDate"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="date"
                  placeholder="选择日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="downloadData.insUrl?12:8">
              <el-form-item class="mc-multi-row" label-width="137px" label="被保人组织机构代码或统一社会信用代码：">
                <el-input
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insuredOrgCode"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
           
            <!-- <el-col :span="downloadData.insUrl?12:8">
              <el-form-item label="被保项目：" prop="projectName">
                <el-input
                  v-model="getInsuranceCoverage.insBasicInfoCompletedDO.projectName"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col> -->
          </el-col>
          <el-col
            :span="8"
            v-if="downloadData.insUrl"
            style="text-align: right;padding-right: 46px;"
          >
            <vue-qr
              :text="downloadData.insUrl"
              :margin="0"
              colorDark="RGB(203,164,59)"
              colorLight="#fff"
              :logoSrc="downloadData.icon + '?cache'"
              :logoScale="0.23"
              :size="260"
            ></vue-qr>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="共保信息：">
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="getInsuranceCoverage.insCoinsuranceCompletedDOList"
                style="width: 100%"
              >
                <el-table-column prop="orgName" align="center" label="共保公司">
                  <template slot-scope="scope">
                    <el-select
                    filterable
                      v-model="scope.row.insOrgId"
                      placeholder="请选择"
                      @change="insOrgIdChange(scope.row,scope.$index)"
                    >
                      <el-option
                        v-for="item in [...getOrgId.sinsOrgList, ...getOrgId.insOrgList]"
                        :key="item.orgId"
                        :label="item.orgName"
                        :value="item.orgId"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column prop="coins_percent" align="center" label="承保比例(%)">
                  <template slot-scope="scope">
                    <format-input
                      text-align="left"
                      empty-value="0"
                      :max="100"
                      :min="0"
                      :precision="2"
                      v-model="scope.row.coinsPercent"
                    />
                  </template>
                </el-table-column>
                <el-table-column prop="indiv_performance" align="center" label="个人绩效(%)">
                  <template slot-scope="scope">
                    <format-input
                      text-align="left"
                      empty-value="0"
                      :max="100"
                      :min="0"
                      :precision="2"
                      v-model="scope.row.indivPerformance"
                    />
                  </template>
                </el-table-column>
                <el-table-column v-if="!disabled" width="50" align="left">
                  <template slot="header">
                    <i
                      @click="add('coinsuranceCoverage')"
                      class="el-icon-circle-plus-outline mouse-pointer font-size20"
                    ></i>
                  </template>
                  <template slot-scope="scope">
                    <i
                      @click="del(scope.$index, getInsuranceCoverage.insCoinsuranceCompletedDOList)"
                      class="el-icon-remove-outline font-size20 mouse-pointer"
                    ></i>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="再保信息：">
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="getInsuranceCoverage.insReinsuranceCompletedDOList"
                style="width: 100%"
              >
                <el-table-column prop="ins_org_id" align="center" label="再保险公司">
                  <template slot-scope="scope">
                    <el-select
                    filterable
                      v-model="scope.row.reinsOrgId"
                      placeholder="请选择"
                      @change="handleItemChange(scope.row,scope.$index)"
                    >
                      <el-option
                        v-for="item in getOrgId.rinsOrgList"
                        :key="item.orgId"
                        :label="item.orgName"
                        :value="item.orgId"
                      ></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column prop="coins_percent" align="center" label="承保比例(%)">
                  <template slot-scope="scope">
                    <format-input
                      text-align="left"
                      empty-value="0"
                      :max="100"
                      :min="0"
                      :precision="2"
                      v-model="scope.row.reinsPercent"
                    />
                  </template>
                </el-table-column>
                <el-table-column v-if="!disabled" width="50" align="left">
                  <template slot="header">
                    <i
                      @click="add('reinsuranceCoverage')"
                      class="el-icon-circle-plus-outline mouse-pointer font-size20"
                    ></i>
                  </template>
                  <template slot-scope="scope">
                    <i
                      @click="del(scope.$index, getInsuranceCoverage.insReinsuranceCompletedDOList)"
                      class="el-icon-remove-outline font-size20 mouse-pointer"
                    ></i>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="总建筑面积(m²)：">
              <format-input
                :precision="2"
                empty-value="0"
                text-align="left"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.totalFloorage"
                disabled
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="地下室面积(m²)：">
              <format-input
                :precision="2"
                empty-value="0"
                text-align="left"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.basementFloorage"
                disabled
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险起期：" prop="policyStartDate">
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.policyStartDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                @change="validData(getInsuranceCoverage.insBasicInfoCompletedDO.policyStartDate, getInsuranceCoverage.insBasicInfoCompletedDO.policyEndDate)"
                type="date"
                :picker-options="startDateValid"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险止期：" prop="policyEndDate">
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.policyEndDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :picker-options="endDateValid"
                @change="validData(getInsuranceCoverage.insBasicInfoCompletedDO.policyStartDate, getInsuranceCoverage.insBasicInfoCompletedDO.policyEndDate)"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="总保险费(元)：" prop="totalPremium">
              <format-input
                empty-value="0"
                text-align="left"
                :precision="2"
                :error="error"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.totalPremium"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险金额(元)：" prop="totalCoverage">
              <format-input
                empty-value="0"
                text-align="left"
                :precision="2"
                :error="error"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.totalCoverage"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="免赔额(元)：" prop="deductibleAmount">
              <format-input
                empty-value="0"
                text-align="left"
                :precision="2"
                :error="error"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.deductibleAmount"
              />
            </el-form-item>
          </el-col>
          <!-- <el-col :span="8">
          <el-form-item label="保险覆盖范围：" prop="coverageType">
            <el-radio-group v-model="getInsuranceCoverage.insBasicInfoCompletedDO.coverageType">
              <el-radio label="C01">完全覆盖</el-radio>
              <el-radio label="C02">非完全覆盖</el-radio>
            </el-radio-group>
          </el-form-item>
          </el-col>-->
          <el-col :span="8">
            <el-form-item class="mc-multi-row" label="造价均值(元/平米)：">
              <!-- <el-input disabled v-model="averageCostShow"></el-input> -->
              <format-input
                :readOnly="readOnlyFlag"
                empty-value="0"
                text-align="left"
                :precision="2"
                :error="error"
                v-model="averageCostShow"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保险费率(%)：">
              <el-input disabled v-model="premiumRateShow"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="是否主承：" prop="isMainIns">
              <el-radio-group v-model="getInsuranceCoverage.insBasicInfoCompletedDO.isMainIns">
                <el-radio label="Y">是</el-radio>
                <el-radio label="N">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保单版本：" prop="contractType">
              <el-radio-group
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.contractType"
                @change="agreeChange"
              >
                <el-radio label="NEW">新保单</el-radio>
                <el-radio label="OLD">旧保单</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保单签发日期：">
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.signDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :picker-options="dateValid"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="主险责任范围：" prop="list">
              <el-input
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.list"
                style="display: none"
              ></el-input>
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="disabled?getInsuranceCoverage.mainInsLiabilitiesDOList1:getCopyInsuranceCoverage.mainInsLiabilitiesDOList"
                style="width: 100%"
                ref="mainIns"
                @selection-change="handleSelectionChange('mainRisk', $event)"
                @select="selectChange1('mainRisk', $event)"
                @select-all="selectChange1('mainRisk', $event)"
              >
                <el-table-column
                  type="selection"
                  v-if="!disabled"
                  width="55"
                  :selectable="checkboxT"
                ></el-table-column>
                <el-table-column prop="clause" label="保险条款"></el-table-column>
                <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                <el-table-column align="center" label="责任起期">
                  <template slot-scope="scope">
                    <el-date-picker
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyStartDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.startDateValid"
                      @change="validDataMain(scope.row)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="责任止期">
                  <template slot-scope="scope">
                    <el-date-picker
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyEndDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.endDateValid"
                      @change="validDataMain(scope.row,)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
          <el-col :span="23">
            <el-form-item label="附加险责任范围：">
              <el-table
                class="mc-table"
                tooltip-effect="light"
                :data="disabled?getInsuranceCoverage.addInsLiabilitiesDOList1:getCopyInsuranceCoverage.addInsLiabilitiesDOList"
                style="width: 100%"
                ref="addIns"
                @selection-change="handleSelectionChange('additionalRisk', $event)"
                @select="selectChange1('additionalRisk', $event)"
                @select-all="selectChange1('additionalRisk', $event)"
              >
                <el-table-column type="selection" v-if="!disabled" width="55"></el-table-column>
                <el-table-column prop="clause" label="保险条款"></el-table-column>
                <el-table-column prop="deadline" align="center" label="期限(年)"></el-table-column>
                <el-table-column align="center" label="责任起期">
                  <template slot-scope="scope">
                    <!-- <span>{{ scope.row.policyStartDate | filterDate}}</span> -->
                    <el-date-picker
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyStartDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.startDateValid"
                      @change="validDataMain(scope.row)"
                    ></el-date-picker>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="责任止期">
                  <template slot-scope="scope">
                    <el-date-picker
                      :clearable="false"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      v-model="scope.row.policyEndDate"
                      type="date"
                      placeholder="选择日期"
                      :picker-options="scope.row.endDateValid"
                      @change="validDataMain(scope.row,)"
                    ></el-date-picker>
                    <!-- {{scope.row.policyEndDate | filterDate}} -->
                  </template>
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="责任免除：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                placeholder="请输入内容"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.disclaimerOfLiability"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="备注信息：">
              <el-input
                type="textarea"
                :autosize=" {minRows: 2}"
                placeholder="请输入内容"
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.remark"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="7">
            <el-form-item
              class="mc-multi-row"
              label="保险责任范围说明书："
              prop="insuranceResponsibilitySpecificationName"
            >
              <el-input
                disabled
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insuranceResponsibilitySpecificationName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!insuranceResponsibilitySpecification" :src="imgUpload" class="img-upload" />
              <!-- <img
                v-if="insuranceResponsibilitySpecification"
                src="../../assets/imgs/gif.gif"
                class="img-upload"
              /> -->
              <el-progress v-if="insuranceResponsibilitySpecification" type="circle" :percentage="insuranceResponsibilitySpecificationName" :width="30"></el-progress>
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('insuranceResponsibilitySpecification', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('insuranceResponsibilitySpecification')">删除</el-button>
              <el-button
                size="mini"
                id="insuranceResponsibilitySpecification"
                @click="download('insuranceResponsibilitySpecification')"
                v-show="getInsuranceCoverage.insBasicInfoCompletedDO.insuranceResponsibilitySpecificationName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="11">
            <el-form-item
              label-width="235px"
              label="保险责任范围说明书签发日期："
              prop="insuranceResponsibilitySpecificationDate"
            >
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insuranceResponsibilitySpecificationDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :picker-options="endDateValid"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="7">
            <el-form-item
              class="mc-multi-row"
              label="保险入户告知书："
              prop="insuranceHouseholdsSpecificationName"
            >
              <el-input
                disabled
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insuranceHouseholdsSpecificationName"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!insuranceHouseholdsSpecification" :src="imgUpload" class="img-upload" />
              <el-progress v-if="insuranceHouseholdsSpecification" type="circle" :percentage="insuranceHouseholdsSpecificationName" :width="30"></el-progress>
              <!-- <img
                v-if="insuranceHouseholdsSpecification"
                src="../../assets/imgs/gif.gif"
                class="img-upload"
              /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('insuranceHouseholdsSpecification', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('insuranceHouseholdsSpecification')">删除</el-button>
              <el-button
                size="mini"
                id="insuranceHouseholdsSpecification"
                @click="download('insuranceHouseholdsSpecification')"
                v-show="getInsuranceCoverage.insBasicInfoCompletedDO.insuranceHouseholdsSpecificationName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="11">
            <el-form-item
              label-width="235px"
              label="保险入户告知书签发日期："
              prop="insuranceHouseholdsSpecificationDate"
            >
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.insuranceHouseholdsSpecificationDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :picker-options="endDateValid"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="7">
            <el-form-item label="测绘报告：" >
              <el-input
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.mappingReportName"
                disabled
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!mappingReport" :src="imgUpload" class="img-upload" />
              <el-progress v-if="mappingReport" type="circle" :percentage="mappingReportName" :width="30"></el-progress>
              <!-- <img v-if="mappingReport" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('mappingReport', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('mappingReport')">删除</el-button>
              <el-button
                size="mini"
                id="mappingReport"
                @click="download('mappingReport')"
                v-show="getInsuranceCoverage.insBasicInfoCompletedDO.mappingReportName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="11">
            <el-form-item label="测绘报告签发日期：" label-width="235px">
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.mappingReportDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :picker-options="endDateValid"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="7">
            <el-form-item label="批单：" >
              <el-input
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.endorsementName"
                disabled
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-col :span="3" style="position: relative; left: 10px">
              <img v-if="!endorsement" :src="imgUpload" class="img-upload" />
              <el-progress v-if="endorsement" type="circle" :percentage="endorsementName" :width="30"></el-progress>
              <!-- <img v-if="endorsement" src="../../assets/imgs/gif.gif" class="img-upload" /> -->
            </el-col>
            <el-col :span="21">
              <el-upload
                class="inline-block mlr97"
                action
                :http-request="(e) => { uploadFile('endorsement', e) }"
                :show-file-list="false"
              >
                <el-button size="mini" type="primary">上传</el-button>
              </el-upload>
              <el-button size="mini" @click="delBtn('endorsement')">删除</el-button>
              <el-button
                size="mini"
                id="endorsement"
                @click="download('endorsement')"
                v-show="getInsuranceCoverage.insBasicInfoCompletedDO.endorsementName"
              >下载</el-button>
            </el-col>
          </el-col>
          <el-col :span="11">
            <el-form-item label="批单签发日期："  label-width="235px">
              <el-date-picker
                v-model="getInsuranceCoverage.insBasicInfoCompletedDO.endorsementDate"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="date"
                :picker-options="endDateValid"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import imgUpload from "@/assets/imgs/put.png";
import formatInput from "@/components/formatInput";
import vueQr from "vue-qr";
import erweima from "@/assets/imgs/erweima.png";
import http from "@/common/request";
import axios from 'axios';
export default {
  name: "InsuranceCoverage",
  props: {
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    error: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  components: {
    formatInput,
    vueQr
  },
  data() {
    return {
      insuranceResponsibilitySpecificationName:0,
      insuranceHouseholdsSpecificationName:0,
      mappingReportName:0,
      endorsementName:0,
      projectId: "",
      baseUrl: "",
      readOnlyFlag: true,
      insuranceResponsibilitySpecification: false,
      insuranceHouseholdsSpecification: false,
      mappingReport: false,
      endorsement: false,
      downloadData: {
        insUrl: "",
        icon: erweima
      },
      imgUpload,
      rules: {
        list: [{ required: true, message: "请选择", trigger: "change" }],
        insContractNo: [
          { required: true, message: "请输入保单号", trigger: "blur" }
        ],
        insOrgId: [
          { required: true, message: "请输入牵头保险公司", trigger: "blur" }
        ],
        tisOrgId: [
          { required: true, message: "请先选择风险管理机构", trigger: "blur" }
        ],
        insCategory: [
          { required: true, message: "请输入保险分类", trigger: "blur" }
        ],
        typeOfIns: [
          { required: true, message: "请输入保险种类", trigger: "blur" }
        ],
        projectName: [
          { required: true, message: "请输入被保项目", trigger: "blur" }
        ],
        insuredOrgId: [
          { required: true, message: "请输入被保人名称", trigger: "blur" }
        ],
        policyStartDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        policyEndDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        totalPremium: [
          { required: true, message: "请输入总保险费", trigger: "blur" }
        ],
        totalCoverage: [
          { required: true, message: "请输入保险金额", trigger: "blur" }
        ],
        deductibleAmount: [
          { required: true, message: "请输入免赔额", trigger: "blur" }
        ],
        // coverageType: [
        //   { required: true, message: "请选择保险覆盖范围", trigger: "change" }
        // ],
        isMainIns: [
          { required: true, message: "请选择是否主承", trigger: "blur" }
        ],
        contractType: [
          { required: true, message: "请选择保单版本", trigger: "blur" }
        ],
        insuranceResponsibilitySpecificationName: [
          {
            required: true,
            message: "请上传保险责任范围说明书",
            trigger: "change"
          }
        ],
        insuranceHouseholdsSpecificationName: [
          { required: true, message: "请上传保险入户告知书", trigger: "change" }
        ],
        mappingReportName: [
          { required: true, message: "请上传测绘报告", trigger: "change" }
        ],
        endorsementName: [
          { required: true, message: "请上传批单报告", trigger: "change" }
        ],
        insuranceResponsibilitySpecificationDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        insuranceHouseholdsSpecificationDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        mappingReportDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        endorsementDate: [
          { required: true, message: "请选择日期", trigger: "change" }
        ],
        prjCompletedDate:[
          { required: true, message: "请选择日期", trigger: "change" }
        ]
      },
      dateValid: {
        disabledDate(data) {
          return data.getTime() > Date.now();
        }
      },
      endDateValid: {
        disabledDate(data) {
          return "";
        }
      },
      startDateValid: {
        disabledDate(data) {
          return "";
        }
      }
    };
  },
  computed: {
    ...mapGetters([
      "getInsuranceCoverage",
      "getCopyInsuranceCoverage",
      "getOrgId",
      "listBaseData"
    ]),
    getMain() {
      return this.$store.state.app.projectSummary.copyInsuranceCoverage
        .mainInsLiabilitiesDOList;
    },
    getOther() {
      return this.$store.state.app.projectSummary.copyInsuranceCoverage
        .addInsLiabilitiesDOList;
    },
    premiumRateShow() {
      //保险费率
      let premiumRate = (
        Math.round(
          (
            (this.getInsuranceCoverage.insBasicInfoCompletedDO.totalPremium /
              this.getInsuranceCoverage.insBasicInfoCompletedDO.totalCoverage) *
            100
          ).toFixed(5) * 10000
        ) / 10000
      ).toFixed(4);
      if (
        premiumRate == "NaN" ||
        premiumRate == "" ||
        premiumRate == "Infinity"
      ) {
        return 0;
      }
      return premiumRate;
    },
    averageCostShow() {
      //造价均值
      let averageCost = (
        Math.round(
          (
            this.getInsuranceCoverage.insBasicInfoCompletedDO.totalCoverage /
            this.getInsuranceCoverage.insBasicInfoCompletedDO.totalFloorage
          ).toFixed(3) * 100
        ) / 100
      ).toFixed(2);
      if (
        averageCost == "NaN" ||
        averageCost == "" ||
        averageCost == "Infinity"
      ) {
        return 0;
      }
      return averageCost;
    }
  },
  watch: {
    getMain() {
      let _this = this;
      setTimeout(() => {
        _this.$refs.validForm.clearValidate();
      }, 200);
      for (let item of this.getCopyInsuranceCoverage.mainInsLiabilitiesDOList) {
        if (item.selected == "Y") {
          setTimeout(() => {
            this.$refs.mainIns.toggleRowSelection(item);
          }, 10);
        }
      }
    },
    getOther() {
      for (let item of this.getCopyInsuranceCoverage.addInsLiabilitiesDOList) {
        if (item.selected == "Y") {
          setTimeout(() => {
            this.$refs.addIns.toggleRowSelection(item);
          }, 10);
        }
      }
    },
  },
  methods: {
    ...mapActions(["insuranceCoverage"]),
    getCode(list, id, flag) {
      for (let item of list) {
        if (item.orgId == id) {
          if (flag == "insOrgList") {
            return (this.getInsuranceCoverage.insBasicInfoCompletedDO.insOrgCode =
              item.orgCode);
          } else if (flag == "tisOrgList") {
            return (this.getInsuranceCoverage.insBasicInfoCompletedDO.tisOrgCode =
              item.orgCode);
          } else if (flag === "bldOrgList") {
            return (this.getInsuranceCoverage.insBasicInfoCompletedDO.insuredOrgCode =
              item.orgCode);
          }
        }
      }
    },
    agreeChange(val) {
      this.$store.commit("INSURANCECOVERAGEPOLICY", val);
    },
    insOrgIdChange(row, index) {
      this.getInsuranceCoverage.insCoinsuranceCompletedDOList.map(
        (item, index1) => {
          if (index != index1) {
            if (row.insOrgId == item.insOrgId) {
              this.$messageError({ message: "机构已选择" });
              row.insOrgId = "";
            }
          }
        }
      );
    },
    handleItemChange(row, index) {
      this.getInsuranceCoverage.insReinsuranceCompletedDOList.map(
        (item, index1) => {
          if (index != index1) {
            if (row.reinsOrgId == item.reinsOrgId) {
              this.$messageError({ message: "机构已选择" });
              row.reinsOrgId = "";
            }
          }
        }
      );
    },
    //数组时间校验--
    validDataMain(row) {
      // if (row.policyStartDate) {
      //   this.$set(row, "endDateValid", {
      //     disabledDate(time) {
      //       return time.getTime() < new Date(row.policyStartDate).getTime();
      //     }
      //   });
      // } else {
      //   this.$set(row, "endDateValid", {
      //     disabledDate(time) {
      //       return false;
      //     }
      //   });
      // }
      // if (row.policyEndDate) {
      //   this.$set(row, "startDateValid", {
      //     disabledDate(time) {
      //       return time.getTime() > new Date(row.policyEndDate).getTime();
      //     }
      //   });
      // } else {
      //   this.$set(row, "startDateValid", {
      //     disabledDate(time) {
      //       return false;
      //     }
      //   });
      // }
    },
    validData(start, end) {
      if (start) {
        this.endDateValid = {
          disabledDate(data) {
            return data.getTime() < new Date(start).getTime();
          }
        };
      } else {
        this.endDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
      if (end) {
        this.startDateValid = {
          disabledDate(data) {
            return data.getTime() > new Date(end).getTime();
          }
        };
      } else {
        this.startDateValid = {
          disabledDate(data) {
            return "";
          }
        };
      }
    },

    //获取险种内期限最大的对象
    getMaxNumInfo(comInsurance) {
      const maxNumList = [];
      comInsurance.map((item, inex) => {
        maxNumList.push(item.deadline);
      });
      const maxNum = Math.max(...maxNumList);
      let maxInfo = {};
      comInsurance.map((item, inex) => {
        if (maxNum == item.deadline) {
          maxInfo = item;
          return;
        }
      });
      return maxInfo;
    },
    //当前时间date，加上年数years，得到新的时间
    getNewData(date, years) {
      var date = new Date(date);
      var year = date.getFullYear() + years;
      var month = date.getMonth() + 1;
      var day = date.getDate();
      var mm = "'" + month + "'";
      var dd = "'" + day + "'";
      //单位数前面加0
      if (mm.length == 3) {
        month = "0" + month;
      }
      if (dd.length == 3) {
        day = "0" + day;
      }
      var time =
        year + "-" + month + "-" + day + " " + "00" + ":" + "00" + ":" + "00";
      return time;
    },
    //改变起止时间，获取主副险种时间
    editData(flag, val) {
      const combinationInsurance = [
        ...this.getCopyInsuranceCoverage.addInsLiabilitiesDOList,
        ...this.getCopyInsuranceCoverage.mainInsLiabilitiesDOList
      ];
      const maxRiskInfo = this.getMaxNumInfo(combinationInsurance);

      let startTime = this.getNewData(
        this.getInsuranceCoverage.insBasicInfoCompletedDO.policyEndDate,
        -maxRiskInfo.deadline
      );
      if (
        startTime >
        this.getInsuranceCoverage.insBasicInfoCompletedDO.policyStartDate
      ) {
        if (flag == "mainRisk") {
          this.getCopyInsuranceCoverage.mainInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    item.policyStartDate = item.policyStartDate
                      ? item.policyStartDate
                      : startTime;
                    item.policyEndDate = item.policyEndDate
                      ? item.policyEndDate
                      : this.getNewData(startTime, item.deadline);
                    item.checked = true;
                  }
                });
              }
            }
          );
          this.getCopyInsuranceCoverage.mainInsLiabilitiesDOList.map(
            (item, index) => {
              if (!item.checked) {
                item.policyStartDate = "";
                item.policyEndDate = "";
              }
            }
          );
        }
        if (flag == "additionalRisk") {
          this.getCopyInsuranceCoverage.addInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    item.policyStartDate = item.policyStartDate
                      ? item.policyStartDate
                      : startTime;
                    item.policyEndDate = item.policyEndDate
                      ? item.policyEndDate
                      : this.getNewData(startTime, item.deadline);
                    item.checked = true;
                  }
                });
              }
            }
          );
          this.getCopyInsuranceCoverage.addInsLiabilitiesDOList.map(
            (item, index) => {
              if (!item.checked) {
                item.policyStartDate = "";
                item.policyEndDate = "";
              }
            }
          );
        }
      } else {
        if (flag == "mainRisk") {
          this.getCopyInsuranceCoverage.mainInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    if (!item.policyStartDate) {
                      item.policyStartDate =
                        this.getInsuranceCoverage.insBasicInfoCompletedDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getInsuranceCoverage.insBasicInfoCompletedDO
                              .policyStartDate;
                    }
                    if (!item.policyEndDate) {
                      item.policyEndDate =
                        this.getInsuranceCoverage.insBasicInfoCompletedDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getNewData(startTime, item.deadline);
                    }
                    item.checked = true;
                  }
                });
              }
              this.getCopyInsuranceCoverage.mainInsLiabilitiesDOList.map(
                (item, index) => {
                  if (!item.checked) {
                    item.policyStartDate = "";
                    item.policyEndDate = "";
                  }
                }
              );
              // item.policyStartDate =
              //   this.getInsuranceCoverage.insBasicInfoCompletedDO
              //     .policyStartDate > this.getNewData(startTime, item.deadline)
              //     ? ""
              //     : this.getInsuranceCoverage.insBasicInfoCompletedDO
              //         .policyStartDate;
              // item.policyEndDate =
              //   this.getInsuranceCoverage.insBasicInfoCompletedDO
              //     .policyStartDate > this.getNewData(startTime, item.deadline)
              //     ? ""
              //     : this.getNewData(startTime, item.deadline);
            }
          );
        }
        if (flag == "additionalRisk") {
          this.getCopyInsuranceCoverage.addInsLiabilitiesDOList.map(
            (item, index) => {
              item.checked = false;
              if (val.length > 0) {
                val.map((item1, index) => {
                  if (item.id == item1.id) {
                    if (!item.policyStartDate) {
                      item.policyStartDate =
                        this.getInsuranceCoverage.insBasicInfoCompletedDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getInsuranceCoverage.insBasicInfoCompletedDO
                              .policyStartDate;
                    }
                    if (!item.policyEndDate) {
                      item.policyEndDate =
                        this.getInsuranceCoverage.insBasicInfoCompletedDO
                          .policyStartDate >
                        this.getNewData(startTime, item.deadline)
                          ? ""
                          : this.getNewData(startTime, item.deadline);
                    }
                    item.checked = true;
                  }
                });
              }
              this.getCopyInsuranceCoverage.addInsLiabilitiesDOList.map(
                (item, index) => {
                  if (!item.checked) {
                    item.policyStartDate = "";
                    item.policyEndDate = "";
                  }
                }
              );

              // item.policyStartDate =
              //   this.getInsuranceCoverage.insBasicInfoCompletedDO
              //     .policyStartDate > this.getNewData(startTime, item.deadline)
              //     ? ""
              //     : this.getInsuranceCoverage.insBasicInfoCompletedDO
              //         .policyStartDate;
              // item.policyEndDate =
              //   this.getInsuranceCoverage.insBasicInfoCompletedDO
              //     .policyStartDate > this.getNewData(startTime, item.deadline)
              //     ? ""
              //     : this.getNewData(startTime, item.deadline);
            }
          );
        }
      }
    },
    //添加行
    add(flag) {
      this.$store.commit("ADDCOIREI", flag);
    },
    //删除
    del(index, list) {
      list.splice(index, 1);
    },
    selectChange1(flag, val) {
      this.editData(flag, val);
    },
    //勾选主险（mainRisk）附加险(additionalRisk)
    handleSelectionChange(flag, val) {
      this.$store.commit("CHECKEDMAINOTHER", { flag, val });
    },
    checkboxT() {
      return true;
    },
    // 上传
    uploadFile(flag, param) {
      this[flag] = true;
      let file = new FormData();
      file.append("file", param.file);
      file.append("fileIcon", flag);
      file.append(
        "projectId",
        this.getInsuranceCoverage.insBasicInfoCompletedDO.projectId
      );
      const config = {
        onUploadProgress: progressEvent => {
          var complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          this[`${flag}Name`] = complete== 100 ? 99 : complete;
        }
      };
      axios.post("/processDoc/uploadProcessDocTmp",file,config).then(res => {
        if (res.data.code == 0) {
          this.getInsuranceCoverage.insBasicInfoCompletedDO[flag] =
            res.data.data.cloudDocId;
          this.$set(
            this.getInsuranceCoverage.insBasicInfoCompletedDO,
            `${flag}Name`,
            res.data.data.fileName
          );
           this[`${flag}Name`] = 100 ;
        } else {
          this.$messageError({ message: res.data.msg });
        }
        this[flag] = false;
      });
      this[`${flag}Name`] = 0;
    },
    //下载
    download(flag) {
      let a = document.createElement("a");
      a.style = "display: none";
      a.href = `/api/processDoc/downloadProcessDoc?cloudDocId=${this.getInsuranceCoverage.insBasicInfoCompletedDO[flag]}&view=2`;
      a.download = this.getInsuranceCoverage.insBasicInfoCompletedDO[
        `${flag}Name`
      ];
      document.body.appendChild(a);
      a.click();
    },
    // 删除
    delBtn(flag) {
      this.getInsuranceCoverage.insBasicInfoCompletedDO[`${flag}Name`] = "";
      this.getInsuranceCoverage.insBasicInfoCompletedDO[flag] = "";
    },
    init(projectId) {
      this.projectId=projectId
      this.getTenantInfoById()
    },
     getTenantInfoById() {
      http.get("/sys/idiInfo/getTenantInfoById/", this.$getversionData.lesseeId).then(res => {
        if (res.code == 0) {
          this.baseUrl = res.domain;
          this.getVueQr(this.projectId);
        }
      });
    },
    //获取二维码
    getVueQr(projectId) {
      http.get("/project/blockchain/", projectId).then(res => {
        if (res.data)
          if (res.data.completedHash)
            this.downloadData.insUrl =
              this.baseUrl +
              "/boobyBlock?content=" +
              res.data.completedHash;
      });
    }
  },
  mounted() {
    let disableds = [
      "insuranceResponsibilitySpecification",
      "endorsement",
      "mappingReport",
      "insuranceHouseholdsSpecification"
    ];
    for (let item of disableds) {
      let dom = document.getElementById(item);
      dom.disabled = false;
      dom.classList.remove("is-disabled");
    }
  }
};
</script>
<style scoped lang="scss">
@import "@/assets/styles";
.ml55 {
  margin-left: 55px;
}
.font-size20 {
  font-size: 20px;
}
.mc-qr {
  position: absolute;
  right: 8px;
  z-index: 4;
}
.mc-edit:hover {
  background: rgba(255, 255, 255, 0.6);
}
.mc-bg {
  background: rgba(255, 255, 255, 0.9);
}
.qr-form /deep/ {
  .el-col-12 /deep/ .el-input {
    width: 183.5px;
  }
}
</style>
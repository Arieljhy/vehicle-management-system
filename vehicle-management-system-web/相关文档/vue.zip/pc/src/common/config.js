export default{
    http:{
        baseUrl:"http://172.25.147.176/",
    }
}
import http from "@/common/request";
const url = require('../url');

export function mytodo(param) {
    return http.get(url.mytodo, param);
}
export function risk(param) {
    return http.post(url.risk, param);
}
export function todorisk(param) {
    return http.get(url.todorisk, param);
}
export function todorun(param) {
    return http.get(url.todorun, param);
}
export function getTips(param) {
    return http.get(url.getTips, param);
}
export function myChart(param) {
    return http.post(url.myChart, param);
}
export function getOrg(param) {
    return http.get(url.getOrg, param);
}
export function regionCoding(param) {
    return http.get(url.regionCoding, param);
}
export function riskReport(param) {
    return http.get(url.riskReport, param);
}
export function deleteRisk(param) {
    return http.delete(url.deleteRisk, param);
}
export function selects(param) {
    return http.get(url.selects, param);
}
export function districts(param) {
    return http.get(url.districts, param);
}
export function deleteRiskEvent(param) {
    return http.delete(url.deleteRiskEvent, param);
}
export function clearConnector(param) {
    return http.post(url.clearConnector, param);
}
export function riskDetails(param) {
    return http.get(url.riskDetails, param);
}
export function riskEvents(param) {
    return http.get(url.riskEvents, param);
}
export function getCaseNumber(param) {
    return http.get(url.getCaseNumber, param);
}
export function riskDuty(param) {
    return http.get(url.riskDuty, param);
}
//查询项目列表
export function getProjectList(params) {
    return http.get(url.projectList, params);
}
//运营管理-项目列表开发
export function getOMList(params) {
    return http.get(url.OMList, params);
}
export function riskEvent(param) {
    return http.get(url.riskEvent, param);
}
export function underwritingInformation(param) {
    return http.get(url.underwritingInformation, param);
}
export function insuranceReview(param) {
    return http.get(url.insuranceReview, param);
}
export function getOrgId(param) {
    return http.get(url.getOrgId, param);
}
export function setOrgId(param) {
    return http.post(url.setOrgId, param);
}
export function insuranceCoverage(param) {
    return http.get(url.insuranceCoverage, param);
}
export function buildingInfo(param) {
    return http.get(url.buildingInfo, param);
}
// 理赔
export function projectClaims(param) {
    return http.get(url.projectClaimsDetail, param);
}
// 理赔列表查询
export function projectClaimsDetail(param) {
    return http.get(url.projectClaimsDetail, param);
}
// 理赔列表下的详情查询
export function listPrjClaimDetail(param) {
    return http.get(url.listPrjClaimDetail, param);
}
// 理赔列表查询新增
export function savePrjClaim(param) {
    return http.post(url.savePrjClaim, param);
}
// 理赔列表查询新增修改
export function amendPrjClaim(param) {
    return http.put(url.amendPrjClaim, param);
}
// 理赔列表下的详情查询新增
export function savePrjClaimDetail(param) {
    return http.post(url.savePrjClaimDetail, param);
}
// 理赔列表下的详情查询删除
export function deleteClaimDetail(param) {
    return http.delete(url.deleteClaimDetail, param);
}
// 理赔列表下的详情查询修改
export function amendClaimDetail(param) {
    return http.put(url.amendClaimDetail, param);
}
// 理赔列表下的详情查询查看
export function checkClaimDetail(param) {
    return http.get(url.checkClaimDetail, param);
}

export function projectReturns(param) {
    return http.get(url.visitReport01, param);
}
export function riskEventsList(param) {
    return http.get(url.riskEventsList, param);
}
export function riskFinalReport(param) {
    return http.get(url.riskFinalReport, param);
}
export function riskReportList(param) {
    return http.get(url.riskReportList, param);
}
export function riskPlan(param) {
    return http.get(url.riskPlan, param);
}
export function basicBstablish(param) {
    return http.get(url.basicBstablish, param);
}
//获取风险报告管理list
export function getReportManagement(param) {
    return http.get(url.getReportManagement, param);
}
// 待办echarts
export function echarts(param) {
    return http.get(url.echarts, param);
}
// 风险管理echarts
export function riskecharts(param) {
    return http.get(url.riskecharts, param);
}
// echarts列表
export function echartList(param) {
    return http.get(url.echartList, param);
}
// 勾选的echart
export function checkEchartList(param) {
    return http.post(url.checkEchartList, param);
}

//获取回访报告list
export function visitReport(param) {
    return http.get(url.visitReport01, param);
}
//删除回访
export function visitReportDele(param) {
    return http.delete(url.visitReport02, param);
}
//新增保存回访
export function visitReportNew(param) {
    return http.post(url.visitReport01, param);
}
//编辑保存回访
export function visitReportEdit(param) {
    return http.put(url.visitReport01, param);
}
//查看回访详情
export function visitReportView(param) {
    return http.get(url.visitReport02, param);
}
//回访详情基础数据
export function visitBaseInfo(param) {
    return http.get(url.visitBaseInfo, param);
}
export function preservationRiskReports(param) {
    return http.post(url.riskReport, param);
}
export function buildingInformation(param) {
    return http.get(url.buildingInformation, param);
}
//系统管理-账户管理-查询机构
export function orgList(params) {
    return http.get(`${url.orgOperation}/`, params);
}
// 系统管理-账户管理-查询机构
export function orgOperation(params) {
    return http.get(url.orgOperation, params)
}
//系统管理-账户管理-查询机构列表树
export function orgListTree(params) {
    return http.get(url.orgListTree, params);
}
//系统管理-建设单位管理-查询机构列表树
export function listTreeJianShe(params) {
    return http.get(url.listTreeJianShe, params);
}
//系统管理-保险条款-查询机构列表树
export function listTreeLicenilities(params) {
    return http.get(url.listTreeLicenilities, params);
}

//系统管理-账户管理-查询用户列表
export function userList(params) {
    return http.get(url.eidiListUserByInsOrgId, params);
}
//系统管理-账户管理-查询用户
export function selectUserByUserId(params) {
    return http.get(url.selectUserByUserId, params);
}
//系统管理 -账户管理-查询用户区域、住宅性质
export function userTrans(params) {
    return http.get(url.userTrans, params);
}
//查询全部的省
export function sysFindAreaProvince(params) {
    return http.post(url.sysFindAreaProvince, params);
}
//查询某省下的全部的市
export function sysFindAreaAreaCity(params) {
    return http.post(url.sysFindAreaAreaCity, params);
}
//查询某市下的全部的区域
export function sysFindAreaDistrict(params) {
    return http.post(url.sysFindAreaDistrict, params);
}

//查询省市下的全部区域
export function findCfgAreaInfo() {
    return http.get(url.findCfgAreaInfo);
}

//系统管理-账户管理-角色列表
export function listRoleByuserId(params) {
    return http.get(url.listRoleByuserId, params);
}
//系统管理-保险条款-单条记录查询
export function showInsLiability(id) {
    return http.get(url.showInsLiability.replace(":id", id));
}
//系统管理-保险条款-列表查询
export function insLiabilities(params) {
    return http.post(url.insLiabilities, params);
}
//报建信息详情
export function buildingDetails(param) {
    return http.get(url.buildingDetails, param);
}
//保存提交 风险报告
export function preservationRisk(param) {
    return http.put(url.riskReport, param);
}
//保存单体住在楼信息
export function monomerHousing(param) {
    return http.put(url.buildingInformation, param);
}
//报建信息单体维护
export function maintenanceRequest(param) {
    return http.get(url.maintenanceRequest, param);
}
//报建信息页面保存
export function newspaperPreservation(param) {
    return http.put(url.newspaperPreservation, param);
}
//tis风险管理查询
export function getManagementRiskList(param) {
    return http.get(url.riskManagementRisk, param);
}
//最终风险检查报告
export function finalRiskCheck(param) {
    return http.get(url.finalRiskCheck, param);
}
//保存最终风险报告
export function saveFinalRiskCheck(param) {
    return http.post(url.saveFinalRiskCheck, param);
}
//删除单体
export function deleteMonomer(param) {
    return http.delete(url.buildingDetails, param);
}
//保存新增住在楼
export function newPreservation(param) {
    return http.post(url.buildingInformation, param);
}
//获取参与人信息
export function getParticipants(param) {
    return http.post(url.participant, param);
}
//添加新参与人
export function addParticipants(param) {
    return http.post(url.addParticipants, param);
}
//图片上传
export function pictureProcessDoc(param) {
    return http.post(url.pictureProcessDoc, param);
}
//历史整改保存
export function newRectificationHistory(param) {
    return http.put(url.newRectificationHistory, param);
}
//历史整改删除
export function deleteRectificationEvent(param) {
    return http.delete(url.deleteRectificationEvent, param);
}
//风险事件筛选
export function riskEventScreening(param) {
    return http.post(url.riskEventScreening, param);
}
//ods风险事件列表查询
export function odsRiskEvent(param) {
    return http.post(url.odsRiskEvent, param);
}
//ods风险事件详情(修改)
export function odsRiskEventDetails(param) {
    return http.post(url.odsRiskEventDetails, param);
}
// 站内信息写信息
export function writeMessage(param) {
    return http.post(url.writeMessage, param);
}
// 所以信息
export function allMessage(param) {
    return http.get(url.allMessage, param)
}
// 已发送
export function sendMessage(param) {
    return http.get(url.sendMessage, param)
}
//ods整改列表查询
export function odsRiskEventRepair(param) {
    return http.post(url.odsRiskEventRepair, param);
}
//ods整改详情(修改)
export function odsRiskEventRepairDetails(param) {
    return http.post(url.odsRiskEventRepairDetails, param);
}
// 未读个数
export function unreadMessage(param) {
    return http.get(url.unreadMessage, param)
}
// 信息列表
export function messageDetail(param) {
    return http.get(url.messageDetail, param)
}
//ods评估报告列表查询
export function odsRiskEventReport(param) {
    return http.post(url.odsRiskEventReport, param);
}
//ods评估报告详情(修改)
export function odsRiskEventReportDetails(param) {
    return http.post(url.odsRiskEventReportDetails, param);
}
//ods回访列表查询
export function odsRiskCheckReport(param) {
    return http.post(url.odsRiskCheckReport, param);
}
//ods回访详情(修改)
export function odsRiskCheckReportDetails(param) {
    return http.post(url.odsRiskCheckReportDetails, param);
}
//查询审核提示信息
export function insuranceReviewTips(param) {
    return http.get(url.insuranceReviewTips, param);
}
//查询机构信息
export function insOrg(param) {
    return http.get(url.insOrg, param);
}
//造价阈值
export function costThreshold(param) {
    return http.post(url.costThreshold, param);
}
//ods造价阈值详情(修改)
export function thresholdModification(param) {
    return http.get(url.thresholdModification, param);
}
//ods造价阈值保存
export function thresholdPreservation(param) {
    return http.post(url.thresholdPreservation, param);
}
//管理系统
//app版本发布
export function appEditionList(param) {
    return http.get(url.appEditionList, param);
}
export function appEditionSave(params) {
    return http.post(url.appEditionSave, params);
}
export function appEditionUpdate(params) {
    return http.post(url.appEditionUpdate, params);
}
export function appEditionRemove(params) {
    return http.delete(url.appEditionRemove, params);
}
//获取省
export function findAreaProvince(params) {
    return http.post(url.findAreaProvince, params);
}
//获取市
export function findAreaCity(params) {
    return http.post(url.findAreaCity, params);
}
//获取区
export function findAreaDistrict(params) {
    return http.post(url.findAreaDistrict, params);
}
//查询租户下的省市区配置
export function queryTenantArea(params) {
    return http.post(url.queryTenantArea, params);
}
//基础数据-父列表
export function baseParentData(params) {
    return http.post(url.baseParentData, params);
}

//基础数据-父详情
export function baseParentDataInfo(params) {
    return http.post(url.baseParentDataInfo, params);
}

//基础数据-子列表
export function baseSubData(params) {
    return http.post(url.baseSubData, params);
}
//基础数据-子详情
export function baseSubDataInfo(params) {
    return http.post(url.baseSubDataInfo, params)
}
//租户列表-查询所有的租户进行分页 
export function tenantData(params) {
    return http.get(url.listAllTenant, params)
}
//获取某个租户的机构列表
export function listOrg(params) {
    return http.post(url.listOrg, params)
}
// 根据机构查询用户 
export function generatorSelectUserByOrgId(params) {
    return http.get(url.generatorSelectUserByOrgId, params)
}
//查询租户下用户
export function manageUserInfo(params) {
    return http.get(url.manageUserInfo, params);
}

//查询租户下的角色
export function eidiGetRoleListByTenant(params) {
    return http.get(url.eidiGetRoleListByTenant, params);
}
//查询租户下的住宅性质和所属区域
export function findUserTransCode(params) {
    return http.post(url.findUserTransCode, params);
}

//查询租户下的省
export function findTenantAreaProvince(params) {
    return http.post(url.findTenantAreaProvince, params);
}
//查询租户下的市
export function findTenantAreaCity(params) {
    return http.post(url.findTenantAreaCity, params);
}
//查询租户下的区
export function findTenantAreaDistrict(params) {
    return http.post(url.findTenantAreaDistrict, params);
}
//租户详情
export function tenantDataInfo(params) {
    return http.post(url.tenantDataInfo, params)
}
//获取应用系统流程管理
export function tenantProcessList(params) {
    return http.get(url.tenantProcessList,params);
}
//获取应用系统流程管理-列表
export function listUserTaskByProcessMgrId(params) {
    return http.get(url.listUserTaskByProcessMgrId,params);
}
//获取应用系统流程管理-菜单列表
export function getGenMenu(params) {
    return http.get(url.getGenMenu,params);
}
//查询ODS列表
export function ODSList(params){
    return http.post(url.ODSList,params);
}
//查询ODS详情
export function ODSInfo(params){
    return http.post(url.ODSInfo,params);
}
//消息管理
export function emailTemplate(param) {
    return http.post(url.emailTemplate, param)
}
//消息管理详情(修改)
export function emailTemplateDetail(param) {
    return http.get(url.emailTemplateDetail, param)
}
//ods风险事件保存
export function odsRiskEventPreservation(param) {
    return http.post(url.odsRiskEventPreservation, param)
}
//ods整改保存
export function odsRiskEventRepairPreservation(param) {
    return http.post(url.odsRiskEventRepairPreservation, param)
}
//ods风险报告保存
export function odsRiskEventReportPreservation(param) {
    return http.post(url.odsRiskEventReportPreservation, param)
}
//ods回访报告保存
export function odsRiskCheckReportPreservation(param) {
    return http.post(url.odsRiskCheckReportPreservation, param)
}
//抄送人
export function searchUser(param) {
    return http.get(url.searchUser, param)
}
//消息管理机构查询
export function mechanismList(param) {
    return http.get(url.mechanismList, param)
}

//获取小区论坛基本信息
export function getForumInfo(param) {
    return http.get(url.forumInfo, param)
}
//消息保存
export function messagePreservation(param) {
    return http.post(url.messagePreservation, param)
}
//  文本信息
// 首页文本信息列表
export function messageList(param) {
    return http.get(url.messageList, param)
}
// 首页文本信息列表详情
export function messageListDetail(param) {
    return http.get(url.messageListDetail, param)
}
// 文本信息列表
export function messageLists(param) {
    return http.get(url.messageLists, param)
}
// 文本信息列表详情
export function messageListDetails(param) {
    return http.get(url.messageListDetails, param)
}
// 文本信息列表新增
export function messageSave(param) {
    return http.post(url.messageSave, param)
}
// 文本信息列表修改
export function messagePut(param) {
    return http.put(url.messagePut, param)
}
// 文本信息列表删除
export function messageDelete(param) {
    return http.delete(url.messageDelete, param)
}

export function mainOrderPost(param) {
    return http.get(url.mainOrderPost, param)
}

// ods理赔列表
export function odsDetailsList(param) {
    return http.post(url.odsDetailsList, param)
}
// ods理赔详情(修改)
export function odsDetails(param) {
    return http.post(url.odsDetails, param)
}
// ods理赔提交
export function odsDetailsSubmission(param) {
    return http.post(url.odsDetailsSubmission, param)
}
// ods保单列表
export function odsInsurancePolicy(param) {
    return http.post(url.odsInsurancePolicy, param)
}
// ods保单详情(修改)
export function odsInsurancePolicyDetails(param) {
    return http.post(url.odsInsurancePolicyDetails, param)
}
// ods保单提交
export function odsInsurancePolicySubmission(param) {
    return http.post(url.odsInsurancePolicySubmission, param)
}
// 联系人校验
export function checkContactTel(param) {
    return http.get(url.checkContactTel, param)
}
// 热帖板块
export function hotNotes(param) {
    return http.get(url.hotNotes, param)
}
// 查询机构
export function queryMechanism (param) {
    return http.get(url.queryMechanism, param)
}
// 查询角色
export function listRoleByOrgid (param) {
    return http.get(url.listRoleByOrgid, param)
}
// 查询机构
export function riskEvntOrg (param) {
    return http.get(url.riskEvntOrg, param)
}
// 查询两方机构
export function InsBasicInfo (param) {
    return http.get(url.InsBasicInfo, param)
}
// 查询两方机构下的人
export function reportPtcp (param) {
    return http.post(url.reportPtcp, param)
}
// 项目报价
export function quotes (param) {
  return http.post(url.quotes, param)
}
// 项目报价新增
export function quotesave (param) {
  return http.post(url.quotesave, param)
}
// 项目报价修改
export function quoteRevision (param) {
  return http.post(url.quoteRevision, param)
}
// 项目报价详情
export function quoteDetail (param) {
  return http.get(url.quoteDetail, param)
}
// tis项目报价列表
export function TisQuotes (param) {
  return http.post(url.TisQuotes, param)
}
// 项目报价修改
export function TisQuoteRevision (param) {
  return http.post(url.TisQuoteRevision, param)
}
// 项目报价详情
export function TisQuoteDetail (param) {
  return http.get(url.TisQuoteDetail, param)
}
// 项目报价上传
export function updatas (param) {
  return http.post(url.updatas, param)
}
//获取人,机构,手机号
export function orgUser (param) {
    return http.get(url.orgUser, param)
  }
//查询保单(ods)
export function enquiryPolicy (param) {
    return http.get(url.enquiryPolicy, param)
  }
//   ------------定时页面
// 定时页面list
export function timingTaskList (param) {
    return http.get(url.timingTaskList, param)
  }
//定时页面执行一次
export function openSave (param) {
    return http.post(url.openSave, param)
  }
  //定时页面修改
export function setTimeModify (param) {
    return http.post(url.setTimeModify, param)
  }
  //定时页面新增保存
export function setTimeNewSave (param) {
    return http.post(url.setTimeNewSave, param)
  }
  //校验表达式
  export function checkCron (param) {
    return http.post(url.checkCron, param)
  }
  //定时任务开启
export function changeStatusOpen (param) {
    return http.post(url.changeStatusOpen, param)
  }
  //定时页面修改保存
export function setTimeModifySve (param) {
    return http.post(url.setTimeModifySve, param)
  }
  //定时页面删除
export function setTimeDelete (param) {
    return http.get(url.setTimeDelete, param)
  }
  //日志页面list
export function journalList (param) {
    return http.get(url.journalList, param)
  }
    //日志页面清空
export function journalClean (param) {
    return http.post(url.journalClean, param)
  }
  //日志页面删除
export function journalRemove (param) {
    return http.get(url.journalRemove, param)
  }
//   ----------------角色权限配置页面
  //角色权限配置左边
export function rolePermissionList (param) {
    return http.get(url.rolePermissionList, param)
}
  //角色权限配置右边
export function roleList (param) {
    return http.get(url.roleList, param)
}
  //角色权限配置树形结构
export function getRoleTree2 (param) {
    return http.get(url.getRoleTree2, param)
}
  //角色权限配置树形结构确定
export function addRoleMenu (param) {
    return http.post(url.addRoleMenu, param)
}
  //理赔删除
export function removeClaimsServiceHandle (param) {
    return http.delete(url.removeClaimsServiceHandle, param)
}
  //报价删除
export function closeClaim (param) {
    return http.post(url.closeClaim, param)
}
//单体
export function singleZJW (param) {
    return http.post(url.singleZJW, param)
}
//确认整改
export function confirmCloseRectification (param) {
    return http.put(url.confirmCloseRectification, param)
}
//标的信息
export function getBjxxByBjbh (param) {
    return http.post(url.getBjxxByBjbh, param)
}
//标的信息
export function rescindPrj (param) {
    return http.post(url.rescindPrj, param)
}
//推送保险信息
export function pushBdshInfo (param) {
    return http.get(url.pushBdshInfo, param)
}

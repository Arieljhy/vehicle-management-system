import http from '@/common/request'
import axios from "axios"
const url = require('../url')
// 文件上传
export function processDoc(param) {
  return http.post(url.processDoc, param)
}
// 结束风险事件
export function endRiskEvent(param) {
  return http.put(url.endRisk, param)
}
//催办
export function urgentCase(param) {
  return http.post(url.pressMessage, param)
}
//更新报建信息
export function singleZJW(params) {
  return http.post(url.singleZJW, params);
}
//推送保险审核结果
export function sendInfo(params) {
  return http.post(url.sendInfo, params);
}
//查询施工许可
export function sendZJW(params) {
  return http.post(url.sendZJW, params);
}
//系统管理-账户管理-新增机构
export function addOrg(params) {
  return http.post(url.orgOperation, params);
}
//系统管理-账户管理-修改机构
export function updateOrg(params) {
  return http.put(url.orgOperation, params);
}
//系统管理-账户管理-删除机构
export function deleteOrg(orgId) {
  return http.delete(`${url.orgOperation}/${orgId}`);
}
//系统管理-账户管理-新增用户
export function addUser(params) {
  return http.post(url.addUser, params);
}
//系统管理-账户管理-修改用户
export function updateUser(params) {
  return http.post(url.updateUser, params);
}
//系统管理-账户管理-删除用户
export function deleteUser(params) {
  return http.get(url.deleteUser, params);
}
//系统管理-保险条款-新增某条记录
export function addLiability(params) {
  return http.post(url.addLiability, params);
}
//系统管理-保险条款-删除某条记录
export function deleteInsLiability(params) {
  return http.delete(url.deleteInsLiability, params);
}
//系统管理-保险条款-修改某条记录
export function updateInsLiability(params) {
  return http.put(url.updateInsLiability, params);
}
//获取整改基本信息
export function rectificationBaseInfo(params) {
  return http.get(url.rectificationBase, params);
}
//新增整改基础信息保存
export function rectificationBaseInfoSave(params) {
  return http.post(url.rectificationBaseSave, params);
}
//编辑整改基础信息保存
export function rectificationBaseEditSave(params) {
  return http.put(url.rectificationBaseSave, params);
}
//获取整改历史list信息
export function rectificationHistoryInfo(params) {
  return http.get(url.rectificationHistory, params);
}
//整改详情信息保存
export function rectificationHistoryInfoSave(params) {
  return http.post(url.rectificationHistory, params);
}
export function rectificationHistoryEditSave(params) {
  return http.put(url.rectificationHistory, params);
}
//进入理赔-大表单-提交
export function doComplete(projectId) {
  return http.get(url.doComplete.replace(":projectId", projectId));
}

//管理系统
//登录
export function manageLoginCas(params) {
  return http.post(url.manageLoginCas, params);
}
//登出
export function manageAuthlogout(params) {
  return http.get(url.manageAuthlogout, params);
}
//配置租户的区域
export function tenantArea(params) {
  return http.post(url.tenantArea, params);
}
//新增父字典表
export function saveBaseParentData(params) {
  return http.post(url.saveBaseParentData, params)
}
//修改父字典表
export function updateBaseParentData(params) {
  return http.post(url.updateBaseParentData, params)
}

//删除父字典表
export function removeBaseParentData(params) {
  return http.post(url.removeBaseParentData, params)
}
//新增子字典表
export function saveBaseSubData(params) {
  return http.post(url.saveBaseSubData, params)
}
//修改子字典表
export function updateBaseSubData(params) {
  return http.post(url.updateBaseSubData, params)
}

//删除子字典表
export function removeSubDataInfo(params) {
  return http.post(url.removeSubDataInfo, params)
}

//新增租户信息
export function saveTenant(params) {
  return http.post(url.saveTenant, params)
}
//删除租户信息
export function removeTenant(params) {
  return http.post(url.removeTenant, params)
}
//修改租户信息
export function updateTenant(params) {
  return http.post(url.updateTenant, params)
}
//新增租户下用户
export function manageAddUser(params) {
  return http.post(url.manageAddUser, params);
}
//修改租户下用户
export function manageUpdateUser(params) {
  return http.post(url.manageUpdateUser, params);
}
//删除租户下用户
export function manageRemoveUser(params) {
  return http.get(url.manageRemoveUser, params);
}
//任务节点配置
export function setProcess(params) {
  return http.post(url.setProcess, params);
}
//新增流程
export function addTenantProcess(params) {
  return http.post(url.addTenantProcess, params);
}
//任务节点激活
export function startProcess(params) {
  return http.get(url.startProcess, params);
}
//任务节点挂起
export function pauseProcess(params) {
  return http.get(url.pauseProcess, params);
}
//任务节点删除
export function removeProcess(params) {
  return http.get(url.removeProcess, params);
}
//下载流程定义模板
export function processDownload(params) {
  //return http.get(url.processDownload);
  return axios.post(url.processDownload, params, { responseType: "blob" });
}
//上传流程图
export function uploadAndDeploy(params) {
  return http.post(url.uploadAndDeploy, params);
}
//修改ODS详情
export function ODSUpdate(params) {
  return http.post(url.ODSUpdate, params);
}



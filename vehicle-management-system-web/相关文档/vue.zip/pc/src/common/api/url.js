module.exports = {
  myChart: '/myChart',
  login: '/logincas',//登录
  logout: '/logout',//退出
  getTips: '/send/getPressMessage',//消息提示
  changePwd: '/changePwd',//修改密码
  getLoginCode: '/getLoginCode',//获取验证码
  findPwd: '/findPwd',//找回密码
  selects: '/sysconfig/DictionaryData/listBaseData',//数据字典
  districts: '/sysconfig/DictionaryData/listAreaData',//数据字典
  menu: '/sys/menu/list',//菜单
  messageDisclosure: '/common/HomePage/pageInfo', // 信息公开
  mytodo: '/project/PrjBasicPlusInfo/listIns', // 保险公司待办页面查询
  todorun: '/project/PrjBasicPlusInfo/listOper', // 代办（运营方）
  todorisk: '/project/PrjBasicPlusInfo/listRisk', // 代办（风险管理）
  risk: '/risk/RiskEvent/listRiskEvent', // 风险事件
  endRisk: '/risk/RiskEvent/completeType', // 结束风险事件
  deleteRiskEvent: '/risk/RiskEvent/', // 删除风险事件
  regionCoding: '/sysconfig/DictionaryData/listAreaData', // 地区地域编码
  riskReport: '/risk/RiskReport', // 风险评估报告管理
  deleteRisk: '/risk/RiskReport/', // 删除风险评估报告管理
  clearConnector: '/project/PrjBasicInfo', // 补录
  processDoc: '/processDoc/uploadProcessDocTmp', // 文件上传
  riskDetails: '/risk/RiskReport/', //风险评估报告详情
  // riskEvents:'/risk/RiskEvent', //涉及风险事件查询
  getCaseNumber: '/workflow/process/countMyTask',//获取待办案件数
  riskEvents: '/risk/RiskEvent/done', //涉及风险事件查询(选中))
  riskEvent: '/risk/RiskEvent/opt', //涉及风险事件查询(全部)
  riskDuty: '/insurance/InsLiabilities/projectId', // 保险责任范围查询
  underwritingInformation: '/insurance/compose/underWriting/',//承保信息
  insuranceReview: '/sysconfig/findCheckByProjectId',//保险审核
  buildingInfo: '/project/PrjSingleUnits',//住宅信息
  insuranceCoverage: '/completed/completedUnderWriting/',//保险责任范围说明书
  riskEventsList: '/risk/RiskEvent/',//风险事件列表
  projectClaimsDetail: '/insurance/InsCaseReport/listPrjClaim', // 理赔列表详情 
  listPrjClaimDetail: '/insurance/InsClaimDetail/', // 理赔列表详情下查询
  savePrjClaim: '/insurance/InsCaseReport/savePrjClaim', //  新增理赔列表详情添加
  amendPrjClaim: '/insurance/InsCaseReport/updatePrjClaim', //  新增理赔列表详情修改
  getOrgId: '/sysconfig/Org/getOrgListDto',//机构下拉
  setOrgId: '/sysconfig/Org/autoBLDOrg', // 创建机构
  savePrjClaimDetail: '/insurance/InsClaimDetail', // 新增理赔列表详情下查询添加
  deleteClaimDetail: '/insurance/InsClaimDetail/', // 删除理赔列表详情下查询添加
  amendClaimDetail: '/insurance/InsClaimDetail', // 修改理赔列表详情下查询添加
  checkClaimDetail: '/insurance/InsClaimDetail', // 查看理赔列表详情下查询添加
  riskFinalReport: '/risk/RiskReport',//风险最终检查报告
  riskPlan: '/risk/RiskManagementPlan/',//风险检查工作计划
  riskReportList: '/risk/RiskReport',//风险评估报告列表
  basicBstablish: '/project/compose/construction/',//基本信息、报建信息
  pressMessage: '/send/pressMessage',
  projectList: '/project/PrjQueryInfo', // 获取项目查询列表
  OMList: '/project/omList',// 获取运营管理-项目查询列表
  singleZJW: '/project/PrjSingleUnits/singleZJW', // 更新报建信息
  sendInfo: '/project/PrjBasicInfo/sendInfo', // 推送保险审核结果
  sendZJW: '/project/PrjConstructionLicenses/sendZJW', // 查询施工许可
  orgOperation: '/sysconfig/Org',// 系统管理 -账户管理-机构列表查询\新增机构
  orgListTree: '/sysconfig/Org/listTree',// 系统管理 -账户管理-机构列表树查询
  listTreeLicenilities: '/sysconfig/Org/listTreeLicenilities',// 系统管理 -保险条款-保险公司子公司机构列表树查询
  listTreeJianShe: '/sysconfig/Org/listTreeJianShe',// 系统管理 -账户管理-机构列表树查询
  listRoleByuserId: '/sys/role/eidi/listRoleByuserId',// 系统管理 -账户管理-角色列表查询
  eidiListUserByInsOrgId: '/sys/user/eidiListUserByInsOrgId',// 系统管理 -账户管理-根据机构ID获取用户列表
  addUser: '/sys/user/addUser',// 系统管理 -账户管理-新增用户
  deleteUser: '/sys/user/deleteUserId',// 系统管理 -账户管理-删除用户
  updateUser: '/sys/user/updateUser',// 系统管理 -账户管理-修改用户
  selectUserByUserId: '/sys/user/selectUserByUserId',// 系统管理 -账户管理-查询用户详情
  userTrans: '/sys/trans', // 系统管理 -账户管理-查询用户区域、住宅性质
  sysFindAreaProvince:'sys/user/findAreaProvince', // 查询全部省
  sysFindAreaAreaCity:'sys/user/findAreaCity', // 查询某省下的市
  sysFindAreaDistrict:'sys/user/findAreaDistrict', // 查询全部区域
  findCfgAreaInfo: '/findCfgAreaInfo', // 查询省市下的全部区域
  insLiabilities: '/insurance/InsLiabilities/query',// 获取保险条款列表 
  showInsLiability: '/insurance/InsLiabilities/:id',// 查询保险条款详情
  deleteInsLiability: '/insurance/InsLiabilities/delete',// 删除保险条款详情
  updateInsLiability: '/insurance/InsLiabilities/modify',// 修改保险条款详情
  addLiability: '/insurance/InsLiabilities/addBatch',// 新增保险条款详情
  getReportManagement: '/project/PrjBasicPlusInfo',//获取风险报告管理
  visitReport: '/risk/RiskCheckReport',//获取回访报告list
  visitReportDele: '/risk/RiskCheckReport/',//获取回访报告list
  visitReport01: '/risk/RiskCheckReport',//回访报告相关操作01
  visitReport02: '/risk/RiskCheckReport/',//回访报告相关操作02
  visitBaseInfo: 'risk/RiskCheckReport/initBasePage/',//回访详情基础数据
  echarts: '/echart/schedule', // （待办）echarts查询
  riskecharts: '/echart/riskManagement', // （风险管理）echarts查询
  echartList: '/echart/all', // echarts列表详情
  checkEchartList: 'echart/setPersonalEChart', // 勾选的echart
  buildingInformation: '/project/PrjSingleUnits',//风险管理中报建信息
  buildingDetails: '/project/PrjSingleUnits/', //报建信息详情
  maintenanceRequest: '/insurance/InsPushRecord/',//报建信息单体维护
  newspaperPreservation: '/project/BaseConstructionSingle', //报建信息保存
  riskManagementRisk: '/project/PrjBasicPlusInfo/listRiskTis', //tis风险管理查看
  rectificationBase: 'risk/RiskEvent/',//整改基础信息查询
  rectificationBaseSave: 'risk/RiskEvent',//整改基础信息保存/提交
  rectificationHistory: 'risk/RiskEventRepair',//整改信息保存post、查询get
  finalRiskCheck: '/risk/RiskReport/lastReport/',//获取最终风险检查报告
  saveFinalRiskCheck: '/risk/RiskReport/lastReport',//保存最终风险检查
  participant: '/sys/user/querUser',//获取参与人        
  addParticipants: '/sys/user/autoBLDUser',//添加新的参与人
  getOrg: '/sysconfig/Org/likelist',//单位查询
  doComplete: '/sysconfig/complete/:projectId',//进入理赔-大表单-提交
  pictureProcessDoc: '/processDoc/uploadProcessPicsTmp', //图片上传
  newRectificationHistory: '/risk/RiskEventRepair', //修改整改信息保存
  deleteRectificationEvent: '/risk/RiskEventRepair/', //删除整改事件
  riskEventScreening: '/risk/RiskEvent/listRiskEvent', //风险事件筛选
  odsRiskEvent: "/OdsRiskQuery/odsRiskEvent/list",//ods风险事件列表
  odsRiskEventDetails: '/OdsRiskQuery/odsRiskEvent/details', //ods风险事件详情(修改)
  writeMessage: '/send/message', // 站内信息-写消息
  allMessage: '/send/getUserAllMessage', // 站内信息-查询用户下的所有的消息
  sendMessage: '/send/getUserAllSendMessage', // 站内信息-查询已发送
  odsRiskEventRepair: '/OdsRiskQuery/odsRiskEventRepair/list',//ods整改列表
  odsRiskEventRepairDetails: '/OdsRiskQuery/odsRiskEventRepair/details',//ods整改详情(修改)          
  unreadMessage: '/send/getPressMessage', // 站内信息-未读消息个数
  messageDetail: '/send/getUserMessageById/', // 站内信息-信息详情
  odsRiskEventReport: '/OdsRiskQuery/odsRiskEventReport/list',//ods风险报告
  odsRiskEventReportDetails: '/OdsRiskQuery/odsRiskEventReport/details',//ods风险报告详情(整改)
  odsRiskCheckReport: "/OdsRiskQuery/odsRiskCheckReport/list",//ods回访
  odsRiskCheckReportDetails: '/OdsRiskQuery/odsRiskCheckReport/details',//ods回访报告详情(整改)
  insuranceReviewTips: '/sysconfig/BussinessRule/checkDuplicate/',
  insOrg: 'sysconfig/Org/',
  costThreshold: '/sysconfig/BussinessRule/list',//造价阈值
  thresholdModification: '/sysconfig/BussinessRule/detail/',//阈值修改
  thresholdPreservation: '/sysconfig/BussinessRule/update ', //阈值保存
  //管理系统
  manageLoginCas:'/logincas', // 登录
  manageAuthlogout:'/authlogout', // 登出
  appEditionList:'/sys/app/list',//app版本发布list
  appEditionSave:'/sys/app/save',
  appEditionUpdate:'/sys/app/update',
  appEditionRemove:'/sys/app/remove/',
  findAreaProvince:'/common/application/findAreaProvince', // 获取省
  findAreaCity:'/common/application/findAreaCity', // 获取市
  findAreaDistrict:'/common/application/findAreaDistrict', // 获取区
  tenantArea:'/config/tenantArea', // 配置租户的区域
  queryTenantArea:'/config/selectTenantArea', // 查询配置租户的区域
  baseParentData: '/configBaseData/list',// 查询租户的字典表
  baseParentDataInfo: '/configBaseData/getDictionaryBydictId',// 查询租户的字典表详情
  saveBaseParentData: '/configBaseData/save',// 新增租户的字典表
  updateBaseParentData: '/configBaseData/update',// 更新租户的字典表
  removeBaseParentData: '/configBaseData/remove',// 删除租户的字典表
  baseSubData: '/config/listDictionaryData',// 基础数据子表
  saveBaseSubData: '/config/saveDictionaryData', // 新增子字典表
  updateBaseSubData: '/config/updateDictionaryData', // 更新子字典表
  removeSubDataInfo: '/config/removeDictionaryData', // 删除字典表详情数据
  baseSubDataInfo: '/config/getDictionaryDataByDdid', // 字典表详情数据
  listAllTenant:'/common/application/listAllTenantGenerator', // 查询所有的租户进行分页
  tenantDataInfo: '/common/application/getTenantById', // 租户详情
  updateTenant:'/common/application/update', // 更新租户 
  removeTenant:'/common/application/remove', // 删除某个租户
  saveTenant:'/common/application/save', // 新增某个租户
  listOrg:'/system/sysDept/listOrg', // 获取某个租户的机构列表
  generatorSelectUserByOrgId:'/sys/user/eidiListUserByOrgIdFenye', // 根据机构查询用户
  eidiGetRoleListByTenant:'/sys/role/eidiGetRoleListByTenantGenerator', // 机构新增用户，查询角色列表
  findTenantAreaProvince:'/sys/user/findAreaProvince', // 机构用户，查询租户下的省
  findTenantAreaCity:'/sys/user/findAreaCity', // 机构用户，查询租户下的市
  findTenantAreaDistrict:'/sys/user/findAreaDistrict', // 机构用户，查询租户下的区域
  manageAddUser:'/sys/user/GenAddUser', // 机构新增用户
  manageUserInfo:'/sys/user/getUserByUserNameGenerator', // 机构查询用户
  findUserTransCode:'/sys/user/findUserTransCode', // 机构查询用户的住宅区域和所属地区
  manageUpdateUser:'/sys/user/GenUpdateUser', // 机构更新用户
  manageRemoveUser:'/sys/user/deleteUserId', // 机构删除用户
  tenantProcessList:'/workflow/process/list', // 应用系统流程管理
  processDownload:'/workflow/process/download', // 流程模板下载
  addTenantProcess:'/workflow/process/save', // 新增流程
  setProcess:'/workflow/process/batchUpdateUserTasks', // 任务节点配置
  startProcess:'/workflow/process/activateProcess', // 任务节点激活
  pauseProcess:'/workflow/process/suspendProcess', // 任务节点挂起
  removeProcess:'/workflow/process/remove', // 任务节点删除
  uploadAndDeploy:'/workflow/process/uploadAndDeploy', // 上传流程图
  listUserTaskByProcessMgrId:'/workflow/process/listUserTaskByProcessMgrId', // 流程节点配置查询
  getGenMenu:'/sys/menu/getGenMenu', // 流程节点配置-菜单查询
  ODSList:'/gen/OdsIns/list', // ODS保单-列表
  ODSInfo:'/gen/OdsIns/details', // ODS保单-详情
  ODSUpdate:'/gen/OdsInsUpdate', // ODS保单-修改详情-发起流程
  emailTemplate: '/sysconfig/EmailTemplate/list', //消息管理
  emailTemplateDetail: '/sysconfig/EmailTemplate/detail/', //消息管理详情(修改)
  odsRiskEventPreservation: 'OdsRiskQuery/odsRiskEvent/update', //ods风险事件提交
  odsRiskEventRepairPreservation: 'OdsRiskQuery/odsRiskEventRepair/update', //ods整改提交
  odsRiskEventReportPreservation: 'OdsRiskQuery/odsRiskEventReport/update',//ods风险报告提交
  odsRiskCheckReportPreservation: 'OdsRiskQuery/odsRiskCheckReport/update',//ods回访提交
  searchUser: '/sys/user/searchUser',//抄送人
  mechanismList: "/sysconfig/Org/list",//消息管理机构
  forumInfo: "/forum/getForumInfoByProjectId/",
  messagePreservation: "/sysconfig/EmailTemplate/update",//消息保存
  // 文本信息
  messageList: '/common/HomePage/pageInfoList', // 首页文本信息列表
  messageListDetail: '/common/HomePage/pageInfo', // 首页文本信息列表详情
  messageLists: '/sysconfig/Content/pageInfo', // 文本信息列表
  messageListDetails: '/sysconfig/Content/pageInfo/', // 文本信息列表详情
  messagePut: '/sysconfig/Content', // 文本信息修改
  messageSave: '/sysconfig/Content/pageInfo', // 文本信息列表新增
  messageDelete: '/sysconfig/Content/', // 文本信息列表删除
  mainOrderPost:'/forum/listMainOrderByCommentCount',
  odsDetailsList:"/OdsQuery/list",//ods理赔列表
  odsDetails:'/OdsQuery/details',//ods理赔详情
  odsDetailsSubmission:'/OdsRiskQuery/InsClaim/update',//ods理赔提交
  odsInsurancePolicy:'OdsQuery/OdsIns/list',//ods保单list
  odsInsurancePolicyDetails:'OdsQuery/OdsIns/details',//ods保单详情(修改)
  odsInsurancePolicySubmission:'OdsQuery/OdsIns/update',//ods保单提交
  checkContactTel: "/sysconfig/Org/checkContactTel", // 联系电话
  hotNotes:'/forum/listForumTop', //热帖板块,
  queryMechanism :'/risk/RiskReport/ReportPtcp', //查询机构
  listRoleByOrgid:'/sys/role/eidi/listRoleByOrgid/',//查询角色
  riskEvntOrg:'/risk/RiskEventRepair/org/', //查询机构
  InsBasicInfo:'/insurance/InsBasicInfo/org/',//tis机构
  reportPtcp:'/risk/RiskReport/ReportPtcp', //获取人
  quotes:'/bidding/insProjectBidding/list', //项目报价list
  quotesave: '/bidding/insProjectBidding/save', // 项目新增
  quoteRevision: '/bidding/insProjectBidding/update', // 项目修改
  quoteDetail: '/bidding/insProjectBidding/', // 项目详情
  TisQuotes: '/bidding/tisProjectBidding/list', // tis下项目报价list
  TisQuoteRevision: '/bidding/tisProjectBidding/update', // tis下项目修改
  TisQuoteDetail: '/bidding/tisProjectBidding/', // tis下项目详情
  updatas:'/bidding/tisProjectBidding/uploadDoc', // 上传文件
  orgUser:'/risk/RiskEventRepair/orgUser',//获取机构类型,人,手机号
  enquiryPolicy:'OdsRiskQuery/task',//查询有无次保单(ods)
  // ---------定时页面接口--------
  timingTaskList:'common/job',//定时页面list
  openSave:'common/job/run',//定时页面执行一次
  setTimeModify: '',//定时页面修改
  setTimeNewSave: 'common/job/add', // 定时页面新增保存
  checkCron:'/common/job/checkCronExpressionIsValid',//校验表达式
  changeStatusOpen:'/common/job/changeStatus',//定时页面开启
  setTimeModifySve: 'common/job/edit', // 定时页面修改保存edit
  setTimeDelete: '/common/job/remove',//定时页面删除
  journalList:'/common/jobLog',//日志页面list
  journalClean:'/common/jobLog/clean',//日志页面清空
  journalRemove:'/common/jobLog/remove',//日志页面删除
  removeClaimsServiceHandle:'/insurance/InsCaseReport/', // 理赔删除
  // ---------定时页面接口--------
  rolePermissionList:'common/application/listAllTenantGenerator',//角色权限配置左边
  roleList:'/sys/role/list',//角色权限配置右边,
  getRoleTree2:'/sys/menu/tree2', // 角色权限配置树形结构
  addRoleMenu:'/sys/role/addRoleMenu', // 角色权限配置树形结构确定
  closeClaim:'/bidding/insProjectBidding/remove',//报价删除
  confirmCloseRectification:"/risk/RiskEvent/repairConfirm",//确认关闭
  getBjxxByBjbh:'/jsscapi/GetBjxxByBjbh',//标的信息
  rescindPrj:"/project/PrjBasicInfo/rescindPrj",//撤销保单
  pushBdshInfo:'/insurance/InsBasicInfo/PushBdshInfo/',//推送保险信息
}

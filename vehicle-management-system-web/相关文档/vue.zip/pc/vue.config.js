
module.exports = {
  lintOnSave: false,
  publicPath: process.env.VUE_APP_BASE_URL,
  outputDir:process.env.VUE_APP_BASE_FLAG,
  productionSourceMap: false,
  devServer: {
    // open: true,
    proxy: {
      "/api": {
        target: process.env.VUE_APP_BASE_API, // 开发环境 
        // target: 'http://172.23.100.193:9999', // 子宁
        pathRewrite: {
          "^/api": ""
        },
        changeOrigin: true
      }
    }
  }
}


//租户平台配置
// module.exports = {
//   lintOnSave: false,
//   publicPath: 'manageMent',
//   devServer: {
//     // open: true,
//     proxy: {
//       "/manage/api": {//租户管理平台
//         target: "http://172.25.147.175:6060", // 开发环境  租户平台端口号：6060
//         pathRewrite: {
//           "^/manage/api": ""//租户管理平台
//         },
//         changeOrigin: true
//       }
//     }
//   }
// }



